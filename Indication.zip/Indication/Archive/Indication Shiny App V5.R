#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
######################################################
############ Actuarial Indication ####################
############ Author: Ian Starkey  ####################
######################################################

######################### Notes: check to see how the spatialkey and HU all are getting chosen. want to look at the between statement to see if last spatial key ends on 3/31/2022 or on 4/1/2022.
######################### The spatial key will be hard to back reconcile because we always use the most current satialKey, but that does not correspond to the indicationDate or evaluationdate
######################### maybe add a fitlering date just for spatialKey date for the time when the indicaiton is being compeleted. Or was complete
######################### Add a Fill Out Date date in RShiny that will be used for the spatialKey, AAL, and OnLevelFactors

#Install Packages if Necessary
if (!require(DBI)) install.packages('DBI')
if (!require(lubridate)) install.packages('lubridate')
if (!require(openxlsx)) install.packages('openxlsx')
if (!require(shiny)) install.packages('shiny')
if (!require(shinyWidgets)) install.packages('shinyWidgets')
if (!require(dplyr)) install.packages('dplyr')
if (!require(DT)) install.packages('DT')
if (!require(miscTools)) install.packages('miscTools')
if (!require(tidyr)) install.packages('tidyr')
if (!require(shinythemes)) install.packages('shinythemes')
if (!require(markdown)) install.packages('markdown')
if (!require(shinyjs)) install.packages('shinyjs')
if (!require(shinycssloaders)) install.packages('shinycssloaders')
if (!require(odbc)) install.packages('odbc')
if (!require(sjmisc)) install.packages('sjmisc')
if (!require(ggplot2)) install.packages('ggplot2')
if (!require(kimisc)) install.packages('kimisc')
if (!require(mailtoR)) install.packages('mailtoR')

#load packages
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails

#define input options
LOB <- data.frame(matrix(ncol = 4,nrow=0))
colnames(LOB) <- c('HO','DF','RE','CO')

#define Perils

#defin Checklists
peerChecklist_list <- c('Expense Load',
  'Experience Adjustment Factors',
  'Total Years for Experience Adjustment',
  'LDFs',
  'Loss Trends ',
  'LLL',
  'Premium Trend',
  'Class Variable Analysis')

technicalChecklist_list <- c('Modeled Cat Load',
                             'LDFs',
                             'Loss Trend',
                             'LLL',
                             'Premium Trend',
                             'Expense Ratios',
                             'Rate Level Indication',
                             'Territorial Analysis',
                             'Class Variable Analysis')

selectorChecklist_list <- c('Modeled Cat Load',
                            'Non-Modeled Results',
                            'LDFs - State',
                            'LDFs - CW',
                            'Loss Trend - State',
                            'Loss Trend - CW',
                            'LLL',
                            'Premium Trend',
                            'Expense Ratios',
                            'Rate Level Indication',
                            'Territorial Analysis',
                            'Class Variable Analysis',
                            'Endorsement Analysis')

#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')

#JavaScript function to allow drop down boxes inside of a LDF data table
js <- c(
  "function(settings){",
  "  $('#mselect').selectize()",
  "}"
)

#get current state options with a SQL rater
state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select state from 
      actuarialsandbox.",program,".modeledCatLoad
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}

#get a list of indication dates available in SQL
date_options <- function(program) {
  dframe <- dbGetQuery(con,paste0(
    "select indicationdate
    from actuarialsandbox.[",program,"].modeledCatLoad
    group by indicationdate
    order by indicationdate desc "
  ))%>%
    mutate(IndicationName = as.character(as.numeric(substr(as.character( year(as.Date(indicationdate) %m-% months(1))),3,4))*100+ month(as.Date(indicationdate) %m-% months(1))))
  
  out <- list()
  for (i in 1:nrow(dframe)) {
    out <- append(out, list(dframe$indicationdate[i]))
  }
  names(out) <- dframe[['IndicationName']]
  return(out)
}

ratingVersionID <- function(Program, State, IndicationDate, EvaluationDate) {
  dframe <- dbGetQuery(con, paste0("
                                   select ratingVersionID
                                   from ActuarialSandbox.",Program,".modeledCatLoad
                                   where State ='",State,"'
                                   and IndicationDate = '",IndicationDate,"'
                                   and EvaluationDate ='",EvaluationDate,"'
                                   
                                   "))
  return(unlist(dframe))
}

#Used to attach Actuary names to indication Selections
selections_id <- function(IndicationDate, EvaluationDate, State, Program) {
  dframe <- dbGetQuery(con,paste0(
    "
    select selected_by, FirstName+ ' ' + LastName as Name
    from ActuarialSandbox.dbo.TeamId a
    left join (
    SELECT min(selected_by) as selected_by
    from ActuarialSandbox.",Program,".indicationSelections
      where region= '",State,"'
      and IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      group by region) b on b.selected_by=a.teamID
      where selected_by is not null
    "
  ))
  df_out <- as.data.frame(dframe$selected_by)
  
  if (nrow(df_out) > 0) {
    colnames(df_out) <- c(dframe[['Name']])
    return(df_out)
  } else {
    other <- data.frame(matrix(ncol=1,nrow=1))
    other[1] <- c(1)
    colnames(other) <- c('Donte Riddick')
    return(other)
  }
}
#list of actuary names
actuaryNames <- function(except) {
  dframe <- dbGetQuery(con,"
                    select teamID,
                    FirstName,
                    LastName
                    from ActuarialSandbox.dbo.TeamId
                    where status = 'Active'
                    and Role = 'Actuarial'
                   ")%>%
    mutate(FullName = paste(FirstName, LastName, sep = ' '))
  out <- list()
  for (i in 1:nrow(dframe)){
    out <- append(out, list(dframe$teamID[i]))
  }
  names(out) <- dframe$FullName
  return(out[!(out %in% except)])
}

actuaryReturn <- function(id) {
  dframe <- dbGetQuery(con,paste0("
                    select
                    FirstName,
                    LastName
                    from ActuarialSandbox.dbo.TeamId
                    where teamID = ",id,"
                    
                   "))
  return(dframe)
}

eval_date_options <- function(IndicationDateIn, Program) { #create list of evaluation dates saved in SQL with the selected Indication Date, prevent app from crashing when any date selections is available. 
  IndicationDateIn <- as.Date(IndicationDateIn)
  dframe <- dbGetQuery(con, paste0(
    "select indicationdate, evaluationdate
    from actuarialsandbox.[",Program,"].modeledCatLoad
    group by indicationdate, evaluationdate"
  ))
  options <- dframe[as.Date(dframe$indicationdate)==IndicationDateIn,]
  out <- list()
  for (i in 1:nrow(options)) {
    out <- append(out, list(options$evaluationdate[i]))
  }
  
  names(out) <- options[['evaluationdate']]
  return(out)
}
#Program Full
table_name <- function(LOB_short) { #define the long names for each programs
  LOB_full <- ifelse(LOB_short=='HO', 'Homeowners',
                     ifelse(LOB_short=='DF', 'Dwelling Fire',
                            ifelse(LOB_short=='CO', 'Condo',
                                   ifelse(LOB_short=='TE' | LOB_short == 'RE','Tenant','LOB Error'))))
  return(LOB_full)
}

state_name_full <- function(state_short) { #full state name assignments from abreviation
  state_full <- state.name[match(c(state_short),state.abb)]
  return(as.character(state_full))
}
#end display funcitons

peril_list <- function(Program, State, IndicationDate, EvaluationDate) { 
  dframe <- dbGetQuery(con, paste0(
    "    select  right(columnName,len(columnName) - len('IncludePeril'))
    from ActuarialSandbox.",Program,".indicationSelections
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and region = '",State,"'
      and lower(columnName) like '%includeperil%'
      and columnValue='1'
    "
  )) 
  vector.out <- if (nrow(dframe) > 0 ) {
    unlist(as.vector(dframe))
  } else {
    if (Program == 'HO') {
      c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane')
    }else if (Program == 'DF') {
      c('Fire', 'Water', 'Theft', 'Explosion', 'Other' ,'NCW', 'STS', 'Hurricane')
    } else {
      c('')
    }
  }
  return(vector.out)
}

expense_cw<- function(Program, As_Of_Date,Rolling_Year_End) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
  dframe <- dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Program,".[claim] 
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep=""))
  dframe%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(dframe$`Loss Reserve`),`Expense Reserve` = sum(dframe$`Expense Reserve`),`Legal Expense Reserve` = sum(dframe$`Legal Expense Reserve`),
            `Expense Load`=coalesce((sum(dframe$`Loss Reserve`)+sum(dframe$`Expense Reserve`)+sum(dframe$`Legal Expense Reserve`))/sum(dframe$`Loss Reserve`),0))
} #cw expense load table

expense_state<- function(Program, As_Of_Date,Rolling_Year_End,State) {
  As_Of_Date <- as.Date(As_Of_Date)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  dframe<-dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Program,".[claim]
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and state = '",State,"'
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep="")) 
  dframe<-dframe%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(dframe$`Loss Reserve`),`Expense Reserve` = sum(dframe$`Expense Reserve`),`Legal Expense Reserve` = sum(dframe$`Legal Expense Reserve`),
            `Expense Load`=coalesce((sum(dframe$`Loss Reserve`)+sum(dframe$`Expense Reserve`)+sum(dframe$`Legal Expense Reserve`))/sum(dframe$`Loss Reserve`),0))
  
} #state expense load table

expense_select <- function(Program, As_Of_Date,Rolling_Year_End,State, StateWeight,cw_exclude,state_exclude) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
  cw <- expense_cw(Program, As_Of_Date,Rolling_Year_End)%>%
    filter(!Year %in% c(cw_exclude,"Total"))
  cw_load<-(sum(cw$`Loss Reserve`)+sum(cw$`Expense Reserve`)+sum(cw$`Legal Expense Reserve`))/sum(cw$`Loss Reserve`)
  state <- expense_state(Program, As_Of_Date,Rolling_Year_End,State)%>%
    filter(!Year %in% c(state_exclude,"Total"))
  state_load<-(sum(state$`Loss Reserve`)+sum(state$`Expense Reserve`)+sum(state$`Legal Expense Reserve`))/sum(state$`Loss Reserve`)
  dframe<-data.frame() 
  dframe["Calculated Expense Load",' '] <-coalesce(cw_load,1)*(1-StateWeight) + coalesce(state_load,1)*StateWeight
  dframe
} #selected expense Load table with exclude years for state and cw

#figure out status on Targit, spatial key, and AAL

#Modeled cat load
modeled_cat_load <- function(Program,As_Of_Date,Rolling_Year_End,State,IncludePolicyFee,cat_load) {
  As_Of_Date <- as.Date(As_Of_Date)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  dframe <- dbGetQuery(con, paste0(
    "SELECT [In Force Premium @ Current Level]
    ,[In Force Policy Charge]
      ,[Hurricane In Force Premium @ CRL]
      ,[Hurricane Gross AAL]
      ,[Modeled HU CAT Loss Ratio]
      ,[STS In Force Premium @ CRL]
      ,[Convective Storm Gross AAL]
      ,[Modeled CS CAT Loss Ratio]
      ,[Total Cat Loss]
  FROM [ActuarialSandbox].[",Program,"].[modeledCatLoad]
  where state = '",State,"'
  and IndicationDate = '",Rolling_Year_End,"'
  and EvaluationDate = '",As_Of_Date  ,"'
    ")
  )
  df_out <- dframe %>%
    select(-`In Force Policy Charge`)%>%
    mutate(`CAT LAE Load` = cat_load, `Modeled Hurricane Loss & LAE Ratio` = `Modeled HU CAT Loss Ratio` * cat_load, `Modeled CS Loss & LAE Ratio` = `Modeled CS CAT Loss Ratio` * cat_load)%>%
    mutate(`Total Modeled Cat Loss & LAE Ratio` = `Modeled Hurricane Loss & LAE Ratio` + `Modeled CS Loss & LAE Ratio`)
  return(df_out)
}

column_names <- function(dframe,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  if (table == 'Losses') {
    c(
      ifelse(month(Rolling_Year_End %m-% months(1))==12,
             'Accident Year',
             paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 12*c(1:(length(dframe)-1)))
  }
  else {
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(dframe)))) {
      if (i == length(colnames(dframe))) {
        names <- c(names,paste(as.character((i-1)*12+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*12+adder),':',as.character((i-1)*12+adder+12),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
} #rename to the 12,24,... or the 15,27... name

LDF <- function(Program,Rolling_Year_End,AsOfDate,state) {
  AsOfDate<- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  losses <- dbGetQuery(con,paste0("SELECT [IndicationDate]
      ,[EvaluationDate]
      ,[TableName]
      ,[Class]
      ,[Years]
      ,[Region]
	  ,	colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ, colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ
  FROM [ActuarialSandbox].[",Program,"].[ldfTriangles]
  pivot (avg(columnValue) for columnName in (colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ) ) as PivotTable 
  where indicationDate = '",Rolling_Year_End,"'
                             and EvaluationDate = '",AsOfDate,"'
                             
  "))%>%
    filter(Region == state | Region == 'CW')
  return(losses)
} #working to create tabels on LDF tabs for CW, state, weighted

LDF_display <- function(data,SQL_table,Classes,state,Rolling_Year_End,AsOfDate,prefix,Program) {
  AsOfDate <- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  data <- data%>%
    filter(TableName == SQL_table & Class == Classes & Region == state)%>%
    select(-IndicationDate,-EvaluationDate, -Class,-Region,-TableName)
  data_clean <- data[,colSums(is.na(data))<nrow(data)]
  if (SQL_table != 'Losses') {
    if (nrow(data_clean) < 1) {
      return(data.frame(matrix(nrow=1,ncol=1)))
    }
    data_clean$add <- NA
    data_clean <- data_clean
  }
  save_new_rows <- c('')
  for (i in 2:length(data_clean$Years)) {save_new_rows <- c(save_new_rows,paste0(save_new_rows[i-1]," "))}
  row.names(data_clean) <- save_new_rows
  colnames(data_clean) <- column_names(data_clean,SQL_table,Rolling_Year_End,AsOfDate)
  if (SQL_table == 'Averages') {
    stored_selections <- dbGetQuery(con,paste0(
      "		select max(LDF1select),max(LDF2select),max(LDF3select),max(LDF4select),max(LDF5select),max(LDF6select),max(LDF7select),max(LDF8select),max(LDF9select)
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1select,LDF2select ,LDF3select,LDF4select,LDF5select,LDF6select,LDF7select,LDF8select,LDF9select)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
    ))
    stored_selections <- na.omit(stored_selections)
    if (nrow(stored_selections)>=1) {
      stored <- c()
      custom <- c('Custom')
      
      if (length(data_clean) < 11) {
        for (i in 1:(length(data_clean)-2)) {
          stored_value <- max(data_clean[data_clean[i+1] == as.numeric(stored_selections[i]),][[1]],na.rm=T)
          stored <- c(stored,ifelse(is.na(stored_value),'Custom',stored_value))
          custom <- c(custom, ifelse(is.na(stored_value),as.numeric(stored_selections[i]),1))
        }
      } else {
        for (i in 1:length(stored_selections)) {
          stored_value <- max(data_clean[data_clean[i+1] == as.numeric(stored_selections[i]),][[1]],na.rm=T)
          stored <- c(stored,ifelse(is.na(stored_value),'Custom',stored_value))
          custom <- c(custom, ifelse(is.na(stored_value),as.numeric(stored_selections[i]),1))
        }
      }
    } else {
      stored <- c('Averages')
      custom <- c('Custom',rep(1,length(data_clean)-2))
    }
    data_clean[nrow(data_clean)+1,] <- c(custom,NA)  
    data_clean[nrow(data_clean)+1,] <- selections_function(prefix,length(data_clean)-1,stored) 
  }
  return(data_clean)
}

LDF_display_averages <- function(cwData,stateData, indicator) {
  if (indicator > 0) {
    out <- stateData
  } else {
    out <- cwData
  }
  send <- data.frame(head(out,-1))%>%mutate(across(2:length(out),as.numeric))
  return(send)
}

LDF_Cumulative <- function(averagesDF,choices,dummy) {#in progress > interactive elements to make LDF selections
  selections <- c()
  for (col in 1:(length(averagesDF)-2)) {
    selections <- c(selections,as.numeric(averagesDF[averagesDF[1]==choices[col],][col+1]))
  }
  dframe <- data.frame(
    NAME = c('Selection','Cumulative'),
    OUTPUT1 = ifelse(c(is.na(selections[1]),is.na(selections[1])),c(NA,NA),c(selections[1],prod(selections[1:9],na.rm=T))),
    OUTPUT2 = ifelse(c(is.na(selections[2]),is.na(selections[2])),c(NA,NA),c(selections[2],prod(selections[2:9],na.rm=T))),
    OUTPUT3 = ifelse(c(is.na(selections[3]),is.na(selections[3])),c(NA,NA),c(selections[3],prod(selections[3:9],na.rm=T))),
    OUTPUT4 = ifelse(c(is.na(selections[4]),is.na(selections[4])),c(NA,NA),c(selections[4],prod(selections[4:9],na.rm=T))),
    OUTPUT5 = ifelse(c(is.na(selections[5]),is.na(selections[5])),c(NA,NA),c(selections[5],prod(selections[5:9],na.rm=T))),
    OUTPUT6 = ifelse(c(is.na(selections[6]),is.na(selections[6])),c(NA,NA),c(selections[6],prod(selections[6:9],na.rm=T))),
    OUTPUT7 = ifelse(c(is.na(selections[7]),is.na(selections[7])),c(NA,NA),c(selections[7],prod(selections[7:9],na.rm=T))),
    OUTPUT8 = ifelse(c(is.na(selections[8]),is.na(selections[8])),c(NA,NA),c(selections[8],prod(selections[8:9],na.rm=T))),
    OUTPUT9 = ifelse(c(is.na(selections[9]),is.na(selections[9])),c(NA,NA),c(selections[9],prod(selections[9:9],na.rm=T))),
    OUTPUT10 = c(NA,NA))
  row.names(dframe) <- c('',' ')
  colnames(dframe) <- c(' ',colnames(averagesDF)[-1])
  df_out <- dframe[!is.na(colnames(dframe))]
  return(df_out)
  
}
LDF_selections_choose <- function(data, data_weighted, weight) {
  if (weight == 0 | weight ==1) {
    return(data)
  } else {
    return(data_weighted)
  }
}
LDF_pull_selections <- function(Rolling_Year_End,AsOfDate,state,Classes,Program, RegionCW) {
  #pull the most recent LDF selections
  dframe <- dbGetQuery(con,paste0("	
	select
	  'Cumulative' as Name,max(LDF1cumulative",RegionCW,"),max(LDF2cumulative",RegionCW,"),max(LDF3cumulative",RegionCW,"),max(LDF4cumulative",RegionCW,"),max(LDF5cumulative",RegionCW,"),max(LDF6cumulative",RegionCW,"),max(LDF7cumulative",RegionCW,"),max(LDF8cumulative",RegionCW,"),max(LDF9cumulative",RegionCW,")
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1cumulative",RegionCW,",LDF2cumulative",RegionCW,",LDF3cumulative",RegionCW,",LDF4cumulative",RegionCW,",LDF5cumulative",RegionCW,",LDF6cumulative",RegionCW,",LDF7cumulative",RegionCW,",LDF8cumulative",RegionCW,",LDF9cumulative",RegionCW,")) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
  ))
  df2 <- dbGetQuery(con,paste0("
	select
	  'Selection' as Name,max(LDF1select",RegionCW,"),max(LDF2select",RegionCW,"),max(LDF3select",RegionCW,"),max(LDF4select",RegionCW,"),max(LDF5select",RegionCW,"),max(LDF6select",RegionCW,"),max(LDF7select",RegionCW,"),max(LDF8select",RegionCW,"),max(LDF9select",RegionCW,") 
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1select",RegionCW,",LDF2select",RegionCW,",LDF3select",RegionCW,",LDF4select",RegionCW,",LDF5select",RegionCW,",LDF6select",RegionCW,",LDF7select",RegionCW,",LDF8select",RegionCW,",LDF9select",RegionCW,")) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"'
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published'
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end
	and currentRow = 1
	group by currentRow
      "
  ))
  colnames(dframe) <- c('Name','x1','x2','x3','x4','x5','x6','x7','x8','x9')
  colnames(df2) <- c('Name','x1','x2','x3','x4','x5','x6','x7','x8','x9')
  dframe <- union_all(df2,dframe)%>%
    mutate(x1 = as.numeric(x1),
          x2 = as.numeric(x2),
          x3 = as.numeric(x3),
          x4 = as.numeric(x4),
          x5 = as.numeric(x5),
          x6 = as.numeric(x6),
          x7 = as.numeric(x7),
          x8 = as.numeric(x8),
          x9 = as.numeric(x9))
  
  dframe<-na.omit(dframe)
  print(dframe)
  
  if (nrow(dframe) > 0) {
    dframe <- dframe %>%
      mutate(x10 = NA)
    print(dframe)
    return(dframe)
    
  } else {
    return(data.frame(NAME = c('Selection','Cumulative'),x1=c(1,1),x2=c(1,1),x3=c(1,1),x4=c(1,1),x5=c(1,1),x6=c(1,1),x7=c(1,1),x8=c(1,1),x9=c(1,1),x10=c(NA,NA)))
  }
}

selections_function <- function(prefix,columns,order) {
  dframe <- data.frame(matrix(ncol = columns,nrow=1),stringsAsFactors = FALSE)
  names <- c('Name',toupper(letters[1:columns-1]))
  dframe[1][1] <- 'Choose'
  for (col in 2:length(dframe)) {
    string <- 'selected = "selected"'
    string_out <- list('Averages' =        list(string,'','','','',''),
                       'All Yr. Wtd Avg' = list('',string,'','','',''),
                       'Ex Hi/Low' =       list('','',string,'','',''),
                       '5 Yr. Wtd Avg' =   list('','','',string,'',''),
                       '3 Yr. Wtd Avg' =   list('','','','',string,''),
                       'Custom' =          list('','','','','',string)) #switch Custom as the Default selection, or add 1 as an option
    dframe[col][1]<- paste0(' 
                       <select id="',prefix,names[col],'select" class="form-control">
                       <option ',string_out[[order[col-1]]][[1]],'value="Averages">Averages</option>
                       <option ',string_out[[order[col-1]]][[2]],'value="All Yr. Wtd Avg">All Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[3]],'value="Ex Hi/Low">Ex Hi/Low</option>
                       <option ',string_out[[order[col-1]]][[4]],'value="5 Yr. Wtd Avg">5 Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[5]],'value="3 Yr. Wtd Avg">3 Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[6]],'value="Custom">Custom</option>
                    </select>
')
    removeUI(#remove the existing input elements in the session if the exist, allowing to make edits to different state without refreshing the page
      selector = paste0("#",prefix,names[col],"select")
    )
  }
  dframe$last <- NA
  return(dframe)
}


#Premium Trend
#Premium On-Level Factors > absorb calculation into premium trend SP
#Targit Data
premium_trend_data <- function(Program,IndicationDate, EvaluationDate, State) {
  Evalutionadjust <- ifelse(as.Date(EvaluationDate)<as.Date('2022-06-01'),'2022-06-01', EvaluationDate)
  dframe <- dbGetQuery(con,paste0("SET NOCOUNT ON
        DECLARE @T Table (Date  varchar(10),
        				  EHY decimal(16,6),
        				  EP decimal(16,6),
        				  AdjustedEP decimal(16,6))
        INSERT @T Exec  ActuarialSandbox.",Program,".sp_PremiumTrend '",IndicationDate,"', '",Evalutionadjust,"','",State,"'
        Select * from @T")
  )
  return(dframe)
}

premium_trend <- function(dframe) {
  df_out <- data.frame(matrix(ncol=6,nrow=1))
  colnames(df_out) <- c('Index', 'Date','Year Ending Quarter - X', 'Earned Exposures', 'Earned Premium', 'Adjusted Earned Premium') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(dframe)):1) {
    df_out <- df_out%>%
      add_row(Index = row,
              Date = as.Date(dframe[["Date"]][row]),
              `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(dframe[["Date"]][row])),' - ', year( as.Date(dframe[["Date"]][row]))),  #paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['EHY']][max((row-3),0):row]),
              `Earned Premium`=sum(dframe[['EP']][max((row-3),0):row]),
              `Adjusted Earned Premium`=sum(dframe[['AdjustedEP']][max((row-3),0):row]))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(`Average Earned Premium at CRL` = `Adjusted Earned Premium`/`Earned Exposures`)%>%
    arrange(Index)%>%
    select (-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
}

logest <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  exp(coef(result))
}

premium_trend_fitting <- function(data,lagtime){
  dframe <- data%>%
    mutate(day_num = as.numeric(lubridate::ceiling_date(as.Date(Date),'month')-1)/365)%>%
    select(day_num,`Average Earned Premium at CRL`)
  df_out <- data.frame(matrix(ncol = 2,nrow=1))
  colnames(df_out) <- c('Exponential Trend','Pure Premium')
  fill_range <- c(24,20,16,12,8,6,4)
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                `Pure Premium`=logest(dframe[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#Loss Trend 
loss_trend_data <- function(program,IndicationDate,EvaluationDate) {
  dframe <- dbGetQuery(con, paste0(
    "SELECT *
  FROM [ActuarialSandbox].[",program,"].[LossTrend]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
    "
  ))%>%arrange(state,Accident_Year, Accident_Year_Quarter)
}

loss_trend_cw <- function(data) {
  dframe <- data %>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index','Year','Quarter', 'Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(dframe)):4) {
    df_out <- df_out%>%
      add_row(Index=row,
              Year = dframe[["Accident_Year"]][row],
              Quarter = dframe[["Accident_Year_Quarter"]][row],
              `Year Ending Quarter - X` = paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['Earned Exposures']][(row-3):row]),
              `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']][(row-3):row]),
              `Incurred Claims`=sum(dframe[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(dframe$Accident_Year_Quarter[row]),' - ',as.character(dframe$AccidentYear[row])))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(Frequency = `Incurred Claims`/`Earned Exposures`*100,
           Severity = `Capped Incurred Loss & LAE`/`Incurred Claims`)%>%
    mutate(`Pure Premium` =Frequency*Severity/100)%>%
    arrange(Index)%>%
    select(-Index)
  
  data_clean <- na.omit(df_out)
  return(data_clean)
}

loss_trend_state <- function(data,input_state) {
  dframe <- data %>%
    filter(state == input_state)%>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index', 'Year','Quarter','Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(dframe)):4) {
    df_out <- df_out%>%
      add_row(Index=row,
              Year = dframe[["Accident_Year"]][row],
              Quarter = dframe[["Accident_Year_Quarter"]][row],
              `Year Ending Quarter - X`=paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['Earned Exposures']][(row-3):row]),
              `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']][(row-3):row]),
              `Incurred Claims`=sum(dframe[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(dframe$Accident_Year_Quarter[row]),' - ',as.character(dframe$AccidentYear[row])))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(Frequency = `Incurred Claims`/`Earned Exposures`*100,
           Severity = `Capped Incurred Loss & LAE`/`Incurred Claims`)%>%
    mutate(`Pure Premium` =Frequency*Severity/100)%>%
    arrange(Index)%>%
    select(-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
  
}


loss_trend_fitting <- function(data,lagtime) {
  dframe <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365,0))%>%
    select(day_num,Frequency, Severity, `Pure Premium`)
  df_out <- data.frame(matrix(ncol = 4,nrow=1))
  colnames(df_out) <- c('Exponential Trend', 'Frequency','Severity','Pure Premium')
  fill_range <- c(24,20,16,12,8,6,4,2)
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                Frequency=logest(dframe[['Frequency']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1, #select the right rows accounting for lag time
                Severity=logest(dframe[['Severity']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1,
                `Pure Premium`=logest(dframe[['Pure Premium']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#Loss Trend Plots functions
logest_fit <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  #exp(coef(result))
}

loss_trend_fitting_plot <- function(data,pt,name) {
  data$varChoose <- data[[name]]
  
  data1 <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365.25,0),
           YearQuarter = `Year Ending Quarter - X`)%>%
    separate(YearQuarter,into = c('one', 'two'), sep = ' - ')%>%
    unite('YearQuarter',c('two', 'one'), sep = ' - ')%>%
    select(YearQuarter,day_num,varChoose)
  
  data2 <- na.omit(data1)
  
  data2$Index <- 1:nrow(data2)

  chosenName=logest_fit(data2$varChoose[(nrow(data2)-pt+1):(nrow(data2))],data2[['day_num']][(nrow(data2)-pt+1):(nrow(data2))])
  
  data2 <- data2%>%
    mutate(IndexA = ifelse(Index > nrow(data2)-pt,1,NA))%>%
    select(YearQuarter, IndexA)
  
  data3 <- na.omit(data2)
  
  data1 <- data1%>%
    left_join(data2, by = c('YearQuarter'='YearQuarter'))%>%
    mutate(plotName = ifelse(YearQuarter >= min(data3$YearQuarter), exp(chosenName$coefficients['(Intercept)'] + chosenName$coefficients['x'] * day_num) ,NA),
           day_num = as.Date(day_num*365.25, origin = "1970-01-01"))
  
  return(list(data1,chosenName, summary(chosenName)))
}


#LLL 

LLL_data <- function(Program, IndicationDate, EvaluationDate,proposedEffective, state, current, proj,capped) {
  IndicationDate <- as.Date(IndicationDate)
  EvaluationDate <- as.Date(EvaluationDate)
  proposedEffective <- as.Date(proposedEffective)
  period <- round(((as.numeric(as.Date(proposedEffective))+365.25) - (as.numeric(as.Date(IndicationDate))-(365.25/2)))/365.25,2)
  dframe <- dbGetQuery(con,paste0("
          Set NOCOUNT ON
          Declare @T Table (peril varchar(50),
          				  Loss_Rolling_Year varchar(10),
          				  TrendedIncurred decimal(16,6),
          				  [Number of Excess Claims] decimal(16,6),
          				  [Ground Up Excess Losses] decimal(16,6),
          				  [Loss Excess of Cap] decimal(16,6),
          				  [Non-Excess Losses] decimal(16,6),
          				  [Excess Ratio] decimal(16,6))
          Insert @T Exec ActuarialSandbox.",Program,".sp_LLL '",IndicationDate,"','",EvaluationDate,"', '",state,"',",coalesce(current,0),",",coalesce(proj,0),",",coalesce(period,0),",",coalesce(capped,0),"
          Select * from @T
          "))
  colnames(dframe)[2] <- ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))) ,'/', as.character(day(IndicationDate %m-% days(1)))))
  colnames(dframe)[3] <- paste0('Incurred Losses Trended to ', year(IndicationDate %m-% months(1)))
  return(dframe)
}

LLL_select_data <- function(data,peril_choose) {
  dframe <- data %>%
    filter(peril == peril_choose)%>%
    select(-peril)
  dframe[nrow(dframe)+1,] <-c('Total',sum(dframe[2]),sum(dframe[3]),sum(dframe[4]),sum(dframe[5]),sum(dframe[6]),sum(dframe[5])/sum(dframe[6])) #add totals row here
  return(dframe)
}

LLL_selections <- function(data,name) {#function that outputs dframe with the calculated Large Loss Load, and defaults the selected to the calculated
  out <- data.frame()
  out[name,'Large Loss Load']<- 1+as.numeric(data[data[1]== 'Total',]$`Excess Ratio`)
  return(out)
}
#expense exhibit

LLL_weighted <- function(cw_data, state_data, weight){
  out <- data.frame()
  out['Selected','Weighted LLL'] <-coalesce(as.numeric(cw_data['Selected','Large Loss Load']) * (1-weight) + coalesce(as.numeric(state_data['Selected','Large Loss Load']),1) * weight,1)
  return(out)
}

profit <- function(state, IndicationDate,Program) {
  dframe <- dbGetQuery(con, paste0(
    "select [profitLoad]
        from [ActuarialSandbox].[",Program,"].[profitContingency]
        where State = '",state,"'
        and '",IndicationDate,"' between rowStartDate and rowEndDate
        "
  ))
  if (nrow(dframe)<1) {
    dframe[1,1] <- 0.05 #do not have profit target stored for all states yet
  }
  return(dframe)
}
reinsurance <- function(state, EvaluationDate,Program,peril) {
  dframe <- dbGetQuery(con, paste0(
    "select [Premium Rate Current]
        from [ActuarialSandbox].[",Program,"].[CostOfReinsurance]
        where State = '",state,"'
        and '",EvaluationDate,"' between rowStartDate and rowEndDate
        and peril = '",peril,"'
        "
  )) 
  dreturn <- if(nrow(dframe)==0) data.frame(0) else dframe
 
  return(dreturn)
}

df_transpose <- function(dframe) {
  dframe <- sjmisc::rotate_df(dframe)
  colnames(dframe) <- as.character(unlist(dframe[1,]))
  dframe[-1,]
}

expense_load <- function(IndicationDate, EvaluationDate, state,Program) {
  dframe <- dbGetQuery(con,paste0(
    "DECLARE @IndicationDate varchar(10) = '",IndicationDate,"'
      DECLARE @IndicationYear varchar(4) = year(@IndicationDate)
      SELECT 
        Year
        ,[Written Premium]/1000 as [Written Premium]
        ,[Earned Premium]/1000 as [Earned Premium]
        ,[Commission]/1000 as [Commission]
        ,[Other Acquisition]/1000 as [Other Acquisition]
        ,[General Expenses]/1000 as [General Expenses]
        ,[Taxes Licenses & Fees]/1000 as [Taxes Licenses & Fees]
    FROM [ActuarialSandbox].[",Program,"].[ExpenseIEE]
    where Year between @IndicationYear-3 and @IndicationYear-1"
  ))%>%
    arrange(Year)

  df_out <- df_transpose(dframe)
  
  save_names <- colnames(df_out)
  
  colnames(df_out) <- c('year3','year2','year1')
  
  df_next <- df_out%>%
    mutate(year3per=NA,year2per=NA,year1per=NA, average=NA, selected=NA)
  
  df_next['Commission','year3per']<- as.numeric(df_next['Commission','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Commission','year2per']<- as.numeric(df_next['Commission','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Commission','year1per']<- as.numeric(df_next['Commission','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['Other Acquisition','year3per']<- as.numeric(df_next['Other Acquisition','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Other Acquisition','year2per']<- as.numeric(df_next['Other Acquisition','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Other Acquisition','year1per']<- as.numeric(df_next['Other Acquisition','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['General Expenses','year3per']<- as.numeric(df_next['General Expenses','year3'])/as.numeric(df_next['Earned Premium','year3'])
  df_next['General Expenses','year2per']<- as.numeric(df_next['General Expenses','year2'])/as.numeric(df_next['Earned Premium','year2'])
  df_next['General Expenses','year1per']<- as.numeric(df_next['General Expenses','year1'])/as.numeric(df_next['Earned Premium','year1'])
  df_next['Taxes Licenses & Fees','year3per']<- as.numeric(df_next['Taxes Licenses & Fees','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Taxes Licenses & Fees','year2per']<- as.numeric(df_next['Taxes Licenses & Fees','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Taxes Licenses & Fees','year1per']<- as.numeric(df_next['Taxes Licenses & Fees','year1'])/as.numeric(df_next['Written Premium','year1'])
  
  df_next['Commission','average']<- (as.numeric(df_next['Commission','year1'])+
                                       as.numeric(df_next['Commission','year2'])+
                                       as.numeric(df_next['Commission','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['Other Acquisition','average']<- (as.numeric(df_next['Other Acquisition','year1'])+
                                              as.numeric(df_next['Other Acquisition','year2'])+
                                              as.numeric(df_next['Other Acquisition','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['General Expenses','average']<- (as.numeric(df_next['General Expenses','year1'])+
                                             as.numeric(df_next['General Expenses','year2'])+
                                             as.numeric(df_next['General Expenses','year3']))/sum(as.numeric(df_next['Earned Premium',]),na.rm=T)
  df_next['Taxes Licenses & Fees','average']<- (as.numeric(df_next['Taxes Licenses & Fees','year1'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year2'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next$selected <- df_next$average
  df_table <- df_next[c('year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  df_table['','selected']<- NA
  df_table['Reinsurance Provision', 'selected'] <- reinsurance(state,EvaluationDate,Program,'All Perils')
  df_table[' ','selected']<- NA
  df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected'] <- df_next['Commission','selected']+
    df_next['Other Acquisition','selected']+
    df_next['General Expenses','selected']+
    df_next['Taxes Licenses & Fees','selected']+
    df_table['Reinsurance Provision', 'selected']
  df_table['  ','selected']<- NA
  df_table['Profit Load','selected'] <- profit(state,IndicationDate,Program)
  df_table['Total Expenses & Profit = (8) + (9)', 'selected'] <- df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected']+df_table['Profit Load','selected']
  df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected'] <- 1-df_table['Total Expenses & Profit = (8) + (9)', 'selected']
  df_table['Fixed Expense Ratio = (4) + (5)','selected'] <- df_next['Other Acquisition','selected']+df_next['General Expenses','selected']
  df_table['   ','selected']<- NA
  df_table['Permissible Loss, LAE, & Fixed Expense Ratio = (11) + (12)','selected'] <- df_table['Fixed Expense Ratio = (4) + (5)','selected']+df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected']
  df_table$names <- rownames(df_table)
  df_table$ids <- c('(1)','(2)','(3)','(4)','(5)','(6)','','(7)','','(8)','','(9)','(10)','(11)','(12)','','(13)')
  df_table <- df_table[c('ids','names','year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  
  colnames(df_table)<-c('','',save_names[1],'',save_names[2],'',save_names[3],'','3 Yr Average', 'Selected')
  return(df_table)
}
#reinsurance table
#add to Sandbox

#indication
#parts of all previous tabs as inputs
#by peril tabs 
on_level_factors_load <- function(Program,IndicationDate, State) {
  dframe <- dbGetQuery(con,paste0("
  select * from ActuarialSandbox.",Program,".onLevelFactors
  where IndicationDate = '",IndicationDate,"' and state = '",State,"'
  "))%>%
    mutate(CalenderYear = as.character(CalenderYear))
  return(dframe)
}

coverage_report_load <- function(IndicationDate, EvaluationDate, State,Program) {
  dframe <- dbGetQuery(con, paste0("
      select RollingYear, ReratedEP ,ptsEHY, policyCharge , Peril,CappedTotalIncurred, claimCount from ActuarialSandbox.",Program,".coveragereport
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and state = '",State,"'
                               "))
  return(dframe)
}

targit_EP_load <- function(Program,IndicationDate, EvaluationDate, State){
  dframe <- dbGetQuery(con, paste0("
  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  EP decimal(16,6))
  Insert @T Exec ActuarialSandbox.",Program,".sp_IndicationEP  '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T
  "
  ))
  return(dframe)
}

rate_level_losses <- function (Program,IndicationDate,EvaluationDate,State) {
  dframe <- dbGetQuery(con,paste0(
    "  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  [Capped Incurred Loss & LAE] decimal(16,6),
  				  [Incurred Claims] int)
  Insert @T Exec ActuarialSandbox.",Program,".sp_IndicationLossSummary '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T"
  ))
  
  return(dframe)
}

rate_level_indication <- function(Program,on_level, coverageReport, targitPrem, Policyfee, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect) {
  IndicationDate <- as.Date(IndicationDate)
  dframe <- on_level
  #if we include policy fee then use the pts EP with the policyCharge
  if (Policyfee == 'Y' & perilTab == 'All Perils') {
    dframe <- dframe%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP + policyCharge)%>%
      select(CalenderYear,EP, OnLevelFactor)
  } 
  else if (Policyfee == 'N' & perilTab == 'All Perils') { #otherwise use the EP stored in Targit for total tab
    dframe <- dframe%>%
      left_join(targitPrem, by = c('CalenderYear' = 'Year'))%>%
      select(CalenderYear,EP, OnLevelFactor)
  } else { #use rerated EP for each of the perils
    dframe <- dframe%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP)%>%
      select (-ReratedEP , -policyCharge, -Peril)%>%
      select(CalenderYear,EP, OnLevelFactor)
  }
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  dframe <- dframe %>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(TrendedPremium = EP * OnLevelFactor * PremTrend)
  
  #add in the Capped Incurred Losses
  losses <- rate_level_losses(Program,IndicationDate, EvaluationDate, state)%>%
    mutate(Year = as.character(Year))
  
  losses2 <- coverageReport%>%
    filter(Peril==perilTab)%>%
    mutate(`Capped Incurred Loss & LAE` = CappedTotalIncurred)%>%
    select(RollingYear, `Capped Incurred Loss & LAE`)
  
  dframe <- dframe%>%
    #left_join(losses, by = c('CalenderYear' = 'Year'))%>%
    #select(-`Incurred Claims`)%>%
    left_join(losses2, by = c('CalenderYear' = 'RollingYear'))%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(`Capped Incurred Loss & LAE`),0,`Capped Incurred Loss & LAE`))
  
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  colnames(LDFselect)[1:6] <- c('Name', IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)
  LDFselect <- LDFselect[LDFselect$Name == 'Cumulative',][1:6]%>%
    pivot_longer(!Name, names_to = 'Year', values_to = 'LDF')%>%
    select(-Name)
  
  print(LDFselect)
  print(LLLselect)
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  dframe <- dframe %>%
    left_join(LDFselect, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL)%>%
    mutate(LAERatio = AdjustedLosses/TrendedPremium)
  print(dframe$LossTrend)
  dframe <- dframe%>% 
    add_row(CalenderYear = 'Total',
            EP = sum(dframe$EP),
            OnLevelFactor = NA,
            PremTrend = NA,
            TrendedPremium = sum(dframe$TrendedPremium,na.rm=T),
            `Capped Incurred Loss & LAE` = sum(dframe$`Capped Incurred Loss & LAE`,na.rm=T),
            LDF = NA,
            LossTrend = NA,
            LLL = NA,
            AdjustedLosses = sum(dframe$AdjustedLosses,na.rm=T),
            LAERatio = sum(dframe$AdjustedLosses,na.rm=T)/sum(dframe$TrendedPremium,na.rm=T))
  
  #dframe$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(dframe$CalenderYear)-1) ,dframe$CalenderYear) 
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Earned Premium', 'On-Level Factor', 'Premium Trend', 'Trended On-Level Premium', 'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', 'Projected Loss & LAE Ratio (ex Cat)')
  
  return(dframe)
}

rate_level_summary<- function(rate_df, cat_df,expense_ratios,rate_level_losses,projPrem, projLoss,sts_adj,hu_adj, peril) {
  out <- data.frame(matrix(ncol = 2,nrow = 0))
  colnames(out) <- c('',' ')
  hurr_add <- 0
  sts_add <- 0
  hur_LAE <- 0
  sts_LAE <- 0
  if ('Hurricane' %in% peril) {
    hurr_add <- 1
    hur_LAE <- cat_df$`Modeled Hurricane Loss & LAE Ratio`*hu_adj
    out['(11)',] <- c('Projected Hurricane Loss & LAE Ratio',cat_df$`Modeled Hurricane Loss & LAE Ratio` * hu_adj)
  } 
  if ('STS' %in% peril) {
    sts_add <- 1
    sts_LAE <- cat_df$`Modeled CS Loss & LAE Ratio`*sts_adj
    out[paste0('(',11+hurr_add,')'),] <- c('Projected Wind/Hail Loss & LAE Ratio',cat_df$`Modeled CS Loss & LAE Ratio` * sts_adj)
  }
  
  out[paste0('(',11+hurr_add+sts_add,')'),] <- c('Projected Loss & LAE Ratio',rate_df[rate_df[1]=='Total',]$`Projected Loss & LAE Ratio (ex Cat)`+hur_LAE+sts_LAE)
  out[paste0('(',12+hurr_add+sts_add,')'),] <- c('Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  out[paste0('(',13+hurr_add+sts_add,')'),] <- c('Projected Loss, LAE, & Fixed Expense Ratio',as.numeric(out[paste0('(',12+hurr_add+sts_add,')'),' '])+as.numeric(out[paste0('(',11+hurr_add+sts_add,')'), ' ']))
  out[paste0('(',14+hurr_add+sts_add,')'),] <- c('Permissible Loss, LAE, & Fixed Expense Ratio',as.numeric(out[paste0('(',12+hurr_add+sts_add,')'),' '])+(1-expense_ratios['Total Expenses & Profit','Selected']))
  out[paste0('(',15+hurr_add+sts_add,')'),] <- c('Raw Indicated Rate Level Change',as.numeric(out[paste0('(',13+hurr_add+sts_add,')'),' '])/as.numeric(out[paste0('(',14+hurr_add+sts_add,')'),' '])-1)
  out[paste0('(',16+hurr_add+sts_add,')'),] <- c('Credibility',min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1))
  out[paste0('(',17+hurr_add+sts_add,')'),] <- c('Compliment of Credibility',(1+projLoss)/(1+projPrem)-1)
  out[paste0('(',18+hurr_add+sts_add,')'),] <- c('Credibility-weighted Indicated Rate Level Change',as.numeric(out[paste0('(',15+hurr_add+sts_add,')'), ' '])*as.numeric(out[paste0('(',16+hurr_add+sts_add,')'),' '])+as.numeric(out[paste0('(',17+hurr_add+sts_add,')'),' '])*(1-as.numeric(out[paste0('(',16+hurr_add+sts_add,')'),' '])))
  
  return(out)
}

credibility_exhibit <- function(rate_level_losses) {
  dframe <- data.frame(matrix(ncol=3,nrow=0))
  dframe[1,] <- c(format(sum(round(rate_level_losses$`Incurred Claims`),0),big.mark = ','),format(round(1082,0),big.mark = ','),paste0(format(round(100*min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1),0)),'%'))
  colnames(dframe) <- c('Earned Exposures','Full Credibility Standard', 'Credibility')
  return(dframe)
}

on_level_cumulative <- function(IndicationDate,Program,State) {
  dframe <- dbGetQuery(con, paste0(
    "select EffectiveDate as [Eff. Date Renewal], RateChange as [Rate Change], Cumulative
    from ActuarialSandbox.",Program,".cumulativeRateChanges
    where IndicationDate = '",IndicationDate,"'
    and state = '",State,"'
    "
  ))
  return(dframe)
}

rate_level_indication_peril <- function(on_level, proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect,coverageReport,peril) {
  IndicationDate <- as.Date(IndicationDate)
  dframe <- on_level%>%
    select(CalenderYear)
  #if we include policy fee then use the pts EP with the policyCharge
  #add in the Capped Incurred Losses
  losses <- coverageReport%>%
    filter(Peril == peril)%>%
    select(RollingYear, CappedTotalIncurred, claimCount)%>%
    mutate(RollingYear = as.character(RollingYear))
  dframe <- dframe%>%
    left_join(losses, by = c('CalenderYear' = 'RollingYear'))%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(CappedTotalIncurred),0,CappedTotalIncurred))
  
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  colnames(LDFselect)[1:6] <- c('Name', IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)
  LDFselect <- LDFselect[LDFselect$Name == 'Cumulative',][1:6]%>%
    pivot_longer(!Name, names_to = 'Year', values_to = 'LDF')%>%
    select(-Name)
  
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  dframe <- dframe %>%
    left_join(LDFselect, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL,claimCount = ifelse(is.na(claimCount),0,claimCount))%>%
    select(CalenderYear, `Capped Incurred Loss & LAE`, LDF,LossTrend, LLL,AdjustedLosses,claimCount)
  
  
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', '# of Claims')
  
  return(dframe)
}

rate_level_indication_prem_peril <- function(on_level, coverageReport, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,EvaluationDate,state,byperil) {
  IndicationDate <- as.Date(IndicationDate)
  dframe <- on_level
  dframe <- dframe%>%
    left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
    filter(Peril == perilTab)%>%
    mutate(EP = ReratedEP,EHY = ptsEHY)%>%
    select(CalenderYear,EP, OnLevelFactor,EHY)
  
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  dframe <- dframe %>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(OnLevelFactor = ifelse(byperil == 'Y',1,OnLevelFactor))%>%
    mutate(spacer = NA,TrendedPremium = EP * OnLevelFactor * PremTrend)%>%
    select(CalenderYear,EP, OnLevelFactor,PremTrend,spacer,TrendedPremium,EHY)
  
  
  
  #dframe$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(dframe$CalenderYear)-1) ,dframe$CalenderYear) 
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Rerated Premium', 'On-Level Factor', 'Premium Trend','                ' ,'Trended On-Level Premium', 'Earned House Years')
  
  return(dframe)
}

by_peril_indication_summary <- function(state, EvaluationDate, Program,losses, prem,expense_ratios) {
  dframe <- data.frame(matrix(ncol=3, nrow=0))
  dframe[1,] <- c('(14)', 'Projected Loss & LAE Ratio', sum(losses$`Adjusted Ultimate Loss & LAE`)/sum(prem$`Trended On-Level Premium`))
  dframe[2,] <- c('(15)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  dframe[3,] <- c('(16)','Projected Loss, LAE & Fixed Expense Ratio',as.numeric(dframe[1,3])+as.numeric(dframe[2,3]))
  dframe[4,] <- c('(17)','Permissible Loss, LAE & Fixed Expense Ratio',as.numeric(dframe[2,3])+(1-expense_ratios['Total Expenses & Profit','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils'))
  dframe[5,] <- NA
  dframe[6,] <- c('(18)','Raw Indicated Rate Level Change',as.numeric(dframe[3,3])/as.numeric(dframe[4,3])-1)
  dframe[7,] <- c('(19)', 'Claim Count', sum(losses$`# of Claims`))
  dframe[8,] <- c('(20)','Credibility', min((as.numeric(dframe[7,3])/1082)^.5,1))
  dframe[9,] <- NA
  dframe[10,]<- c('(21)','Compliment of Credibility',0)
  dframe[11,]<- c('(22)','Credibility-weighted Indicated Rate Level Change', as.numeric(dframe[6,3])*as.numeric(dframe[8,3])+(1-as.numeric(dframe[8,3]))*as.numeric(dframe[10,3]))
  
  return(dframe)
}

cat_peril_table <- function(peril,inforce,experienceAdj){
  if (peril == 'Hurricane') {
    dframe <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level` = `Hurricane In Force Premium @ CRL`, `Peril Modeled Gross AAL` = `Hurricane Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else if (peril == 'STS') {
    dframe <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level`=`STS In Force Premium @ CRL`, `Peril Modeled Gross AAL`=`Convective Storm Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else {
    break
  }
  dframe <- dframe%>%
    mutate(`Modeled Loss & LAE Ratio`=coalesce(`Peril Modeled Gross AAL`*`CAT LAE Load`/`Inforce Premium @ Current Rate Level`,0),
           `Experience Adjustment Factor` = experienceAdj)%>%
    mutate(`Selected Loss & LAE Ratio` = `Experience Adjustment Factor` * `Modeled Loss & LAE Ratio`)
  
  return(dframe)
  
}
cat_peril_summary <- function(state,EvaluationDate,Program,catTable, expense_ratios,peril,experience_adj,experience_years,modeled_cat){
  dframe <- data.frame(matrix(ncol=3, nrow=0))
  dframe[1,] <- c('(8)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  dframe[2,] <- c('(9)','Selected Loss, LAE & Fixed Expense Ratio', as.numeric(dframe[1,3]) + catTable$`Selected Loss & LAE Ratio`)
  dframe[3,] <- c('(10','Permissible Loss & LAE Ratio',(expense_ratios['Permissible Loss, LAE, & Fixed Expense Ratio','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils') - 
                coalesce(as.numeric(modeled_cat$`In Force Premium @ Current Level` * reinsurance(state,EvaluationDate,Program,peril) / modeled_cat[[paste(peril,'In Force Premium @ CRL',sep=' ')]]),0)
  )#peril cost of reinsurance
  dframe[4,] <- NA
  dframe[5,] <- c('(11)', 'Raw Indicated Rate Level Change', as.numeric(dframe[2,3])/as.numeric(dframe[3,3])-1)
  dframe[6,] <- NA
  dframe[7,] <- c('(12)','Credibility',ifelse(experience_adj ==1, 1, experience_years/20))
  dframe[8,] <- NA
  dframe[9,] <- c('(13)','Compliment of Credibility',0)
  dframe[10,]<- c('(14)','STS Credibility-weighted Indicated Rate Level Change',as.numeric(dframe[5,3])*as.numeric(dframe[7,3])+(1-as.numeric(dframe[7,3]))*as.numeric(dframe[9,3]))
  
  return(dframe)
}

non_peril_pull <- function(Program,IndicationDate, EvaluationDate, state) {
  dframe <- dbGetQuery(con, paste0(
    "
    select nonPerilPremium
    from ActuarialSandbox.",Program,".nonPerilPremium
    where IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and state = '",state,"'
    "
  ))
  return(as.numeric(dframe))
}

indication_memo <- function(total, fire, water, theft, liability, otherAOP, NCW, STS, HU,coverageReport,nonperil, peril) {
  dframe <- data.frame(matrix(ncol = 5, nrow = 0))
  if (is.data.frame(fire)) {
    dframe['1',] <- c('Fire','Fire',fire[3,3],fire[8,3],fire[11,3])
  }
  if (is.data.frame(water)) {
    dframe['2',] <- c('Water','Water',water[3,3],water[8,3],water[11,3])
  }
  if (is.data.frame(theft)) {
    dframe['3',] <- c('TheftVMM','Theft & VMM',theft[3,3],theft[8,3],theft[11,3])
  }
  if (is.data.frame(liability)) {
    dframe['4',] <- c('Liability','Liability',liability[3,3],liability[8,3],liability[11,3])
  }
  if (is.data.frame(otherAOP)) {
    dframe['5',] <- c('OtherAOP','All Other Perils',otherAOP[3,3],otherAOP[8,3],otherAOP[11,3])
  }
  if (is.data.frame(NCW)) {
    dframe['6',] <- c('NCW','Non-Cat Weather',NCW[3,3],NCW[8,3],NCW[11,3])
  }
  if (is.data.frame(STS)) {
    dframe['7',] <- c('STS','STS',STS[2,3],STS[7,3],STS[10,3])
  }
  if (is.data.frame(HU)) {
    dframe['8',] <- c('Hurricane','Hurricane',HU[2,3],HU[7,3],HU[10,3])
  }
  colnames(dframe) <- c('joiner','Peril','LAE','Cred','RateChange')
  
  sts_add <- if ('STS'       %in% peril) 1 else 0
  hur_add <- if ('Hurricane' %in% peril) 1 else 0
  if (nrow(dframe) > 0) {
    
    
    coverageReport_clean <- coverageReport%>%
      group_by(Peril)%>%
      summarise(Prem = sum(ReratedEP))
    df_out <- dframe%>%
      left_join(coverageReport_clean, by = c('joiner'='Peril'))%>%
      select(-joiner)
    sumprod <- df_out%>%
      group_by()%>%
      summarise(sumProduct = sum(as.numeric(RateChange)*as.numeric(Prem),na.rm=T))
    balanced <- (1-nonperil)*(1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1
    df_out['9',] <- c('Total', total[3+sts_add + hur_add,2],total[6+sts_add + hur_add,2],total[8+sts_add + hur_add,2],(1-nonperil)*(1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1)
    
    sumProd_adj <- (1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))-1
    cred_adj <- ((1+as.numeric(total[8+sts_add + hur_add,2]))-nonperil)/(1-nonperil)-1
    
    df_final <- df_out%>%
      mutate(balanced = ifelse(Peril=='Total',NA,
                               (1+as.numeric(RateChange))*(1+cred_adj)/(1+sumProd_adj)-1))
    sumprodBalance <- df_final%>%
      group_by()%>%
      summarise(sum(as.numeric(Prem)*as.numeric(balanced),na.rm=T))
    
    df_final['9',6] <- (1-nonperil)*(1+(as.numeric(sumprodBalance)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1
    
    df_final <- df_final%>%
      select(Peril, LAE,Cred,balanced)
    
  } else {#if the indication is not by any perils
    df_out <- data.frame(matrix(ncol = 4, nrow = 0)) 
    df_out['1',] <- c('Total', total[3+sts_add + hur_add,2],total[6+sts_add + hur_add,2],total[8+sts_add + hur_add,2]) 
    df_final <- df_out
  }
  colnames(df_final) <- c('Peril', 'Projected Loss, LAE & Fixed Expense Ratio','Credibility','Balanced Credibility-weighted Indicated Rate Level Change')
  return(df_final)
}

memoToTables <- function(memo,peril){ 
  
  dframe <- na.omit(memo[memo$Peril == peril,]) 
  if (nrow(dframe) > 0) {
    out <- as.numeric(dframe[4])
  } else {
    out <- 1
  }
  df_out <- data.frame(matrix(ncol=3,nrow=0))
  df_out[1,]<- c(ifelse(peril == 'STS' | peril == 'Hurricane','(15)','(23)'),'Balanced Cred-weighted Indicated Rate Level Change',out)
  return(df_out)
}


reinsurance_exhibit <- function(State_Full, LOB_Full, HUreinsurance, STSreinsurance,CostOfReinsurance,modeled_cat) {
  dframe <- data.frame(matrix(ncol=5, nrow=0))
  colnames(dframe) <- c('Peril', paste('Inforce Premium at CRL',State_Full,LOB_Full,sep=' '),'Premium Rated Cost of Reinsurance Margin', 'Net Cost of Reinsurance','Cost of Reinsurance')
  dframe[3,] <- c('Hurricane',format(round(modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
              paste0(format(round(HUreinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * HUreinsurance,0),big.mark = ','),
              modeled_cat$`In Force Premium @ Current Level` * HUreinsurance / modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]]
  )
  dframe[4,] <- c('STS',format(round(modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
              paste0(format(round(STSreinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * STSreinsurance,0),big.mark = ','),
              modeled_cat$`In Force Premium @ Current Level` * STSreinsurance / modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]]
  )
  dframe[5,] <- c('Total',format(round(modeled_cat$`In Force Premium @ Current Level`,0),big.mark = ','),
              paste0(format(round(CostOfReinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * CostOfReinsurance,0),big.mark = ','),
              CostOfReinsurance)
  dframe <- na.omit(dframe)
  return(dframe)
}

#pull selections based on variable name
pull_variable <- function(Program,IndicationDate,EvaluationDate,state,Classes,variable_name,default) {
  dframe <- dbGetQuery(con,paste0("	
	select
	columnValue,status
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	where IndicationDate = '",IndicationDate,"' 
	and EvaluationDate = '",EvaluationDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	and columnName = '",variable_name,"'
      "
  ))
  dframe <- dframe%>%
    filter(status == ifelse('Published' %in% dframe$status,'Published',
                            ifelse('In Review' %in% dframe$staus, 'In Review', 'In Progress')))%>%
    select(-status)
  
  
  if (variable_name == 'catLoadSelection') {
    if (nrow(dframe)>0) {
      catLoad <- as.data.frame(dframe)
    } else {
      catLoad <- as.data.frame(default)
    }
    row.names(catLoad) <- c('Selected Expense Load')
    return(catLoad)
  }else if (variable_name == 'proposedEffective') {
    if (nrow(dframe) > 0) {
      return(dframe[[1]])
    } else {
      d <- ymd(EvaluationDate)
      d <- d %m+% months (8)
      return(d)
    }
  }
  if (nrow(dframe)>0) {
    if (variable_name == 'catExclude' & nchar(dframe) >=4 ) {
      string <- as.character(round(as.numeric(dframe),0))
      out <- sapply(seq(from=1, to=nchar(string), by=4), function(i) substr(string, i, i+3))
      return(out)
    } else {
      return(as.numeric(dframe))
    }
  } else {
    return(default)
  }
}

#save 
save_selections <- function(Program,IndicationDate,EvaluationDate, Region,CWRegion,Class,Status,LDFselections,LDFfinal,selected_by,technicalReviewer, PeerReviewer){
  
  find_vector <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][2:(length(LDFselections[LDFselections[1] == 'Selection',])-1)])
  cumulative <-as.numeric(LDFselections[LDFselections[1] == 'Cumulative',][2:(length(LDFselections[LDFselections[1] == 'Cumulative',])-1)])
  if (length(LDFselections)<10) {
    selections <- c(find_vector,rep(1,10-length(find_vector)))
    cumulative <- c(cumulative,rep(1,10-length(cumulative)))
  } else {
    selections <- find_vector
  }
  
  if (CWRegion == 'CW') {
    cw_condition <- " "
    cw_fill<-" "
  } else {
    finalselected <-   as.numeric(LDFfinal[LDFfinal[1] == 'Selection',][2:(length(LDFfinal[LDFfinal[1] == 'Selection',])-1)])
    finalcumulative <- as.numeric(LDFfinal[LDFfinal[1] == 'Cumulative',][2:(length(LDFfinal[LDFfinal[1] == 'Cumulative',])-1)])
    finalselected <- c(finalselected, rep(1,10-length(finalselected)))
    finalcumulative <- c(finalcumulative, rep(1,10-length(finalcumulative)))
    
    cw_condition<-paste0("
    cast(",finalselected[1]," as nvarchar(50)) as LDF1selectFinal,
    cast(",finalselected[2]," as nvarchar(50)) as LDF2selectFinal,
    cast(",finalselected[3]," as nvarchar(50)) as LDF3selectFinal,
    cast(",finalselected[4]," as nvarchar(50)) as LDF4selectFinal,
    cast(",finalselected[5]," as nvarchar(50)) as LDF5selectFinal,
    cast(",finalselected[6]," as nvarchar(50)) as LDF6selectFinal,
    cast(",finalselected[7]," as nvarchar(50)) as LDF7selectFinal,
    cast(",finalselected[8]," as nvarchar(50)) as LDF8selectFinal,
    cast(",finalselected[9]," as nvarchar(50)) as LDF9selectFinal,
    cast(",finalcumulative[1]," as nvarchar(50)) as LDF1cumulativeFinal,
    cast(",finalcumulative[2]," as nvarchar(50)) as LDF2cumulativeFinal,
    cast(",finalcumulative[3]," as nvarchar(50)) as LDF3cumulativeFinal,
    cast(",finalcumulative[4]," as nvarchar(50)) as LDF4cumulativeFinal,
    cast(",finalcumulative[5]," as nvarchar(50)) as LDF5cumulativeFinal,
    ")
    cw_fill<-",LDF1selectFinal,LDF2selectFinal,LDF3selectFinal,LDF4selectFinal,LDF5selectFinal,LDF6selectFinal,LDF7selectFinal,LDF8selectFinal,LDF9selectFinal,
		LDF1cumulativeFinal,LDF2cumulativeFinal,LDF3cumulativeFinal,LDF4cumulativeFinal,LDF5cumulativeFinal"
  }
  print('saving')
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
technicalReviewer,
PeerReviewer,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
cast(",selections[1]," as nvarchar(50)) as LDF1select",CWRegion,",
cast(",selections[2]," as nvarchar(50)) as LDF2select",CWRegion,",
cast(",selections[3]," as nvarchar(50)) as LDF3select",CWRegion,",
cast(",selections[4]," as nvarchar(50)) as LDF4select",CWRegion,",
cast(",selections[5]," as nvarchar(50)) as LDF5select",CWRegion,",
cast(",selections[6]," as nvarchar(50)) as LDF6select",CWRegion,",
cast(",selections[7]," as nvarchar(50)) as LDF7select",CWRegion,",
cast(",selections[8]," as nvarchar(50)) as LDF8select",CWRegion,",
cast(",selections[9]," as nvarchar(50)) as LDF9select",CWRegion,",
cast(",cumulative[1]," as nvarchar(50)) as LDF1cumulative",CWRegion,",
cast(",cumulative[2]," as nvarchar(50)) as LDF2cumulative",CWRegion,",
cast(",cumulative[3]," as nvarchar(50)) as LDF3cumulative",CWRegion,",
cast(",cumulative[4]," as nvarchar(50)) as LDF4cumulative",CWRegion,",
cast(",cumulative[5]," as nvarchar(50)) as LDF5cumulative",CWRegion,",
cast(",cumulative[6]," as nvarchar(50)) as LDF6cumulative",CWRegion,",
cast(",cumulative[7]," as nvarchar(50)) as LDF7cumulative",CWRegion,",
cast(",cumulative[8]," as nvarchar(50)) as LDF8cumulative",CWRegion,",
cast(",cumulative[9]," as nvarchar(50)) as LDF9cumulative",CWRegion,",
",cw_condition,"
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(LDF1select",CWRegion,",LDF2select",CWRegion,",LDF3select",CWRegion,",LDF4select",CWRegion,",LDF5select",CWRegion,",LDF6select",CWRegion,",LDF7select",CWRegion,",LDF8select",CWRegion,",LDF9select",CWRegion,",
		LDF1cumulative",CWRegion,",LDF2cumulative",CWRegion,",LDF3cumulative",CWRegion,",LDF4cumulative",CWRegion,",LDF5cumulative",CWRegion,",LDF6cumulative",CWRegion,",LDF7cumulative",CWRegion,",LDF8cumulative",CWRegion,",LDF9cumulative",CWRegion," ",cw_fill,")
	) as unpvt2

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
  print('done saving')
}

save_selections_rest <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,
                                 catLoadWeight,catLoadExclude,catLoadSelection,LDFweight,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearsAdjFactor,includePerils,proposedEffective,
                                 selected_by,technicalReviewer,PeerReviewer) {
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  
  print(proposedEffective)
  
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)

  print(1)
  print(Status)
  
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
technicalReviewer,
PeerReviewer,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
cast(",catLoadWeight," as nvarchar(50)) as catLoadWeight,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",catLoadSelection," as nvarchar(50)) as catLoadSelection,
cast(",LDFweight," as nvarchar(50)) as LDFweight,
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
cast(",LLLweight," as nvarchar(50)) as LLLweight,
cast(",LLLfire," as nvarchar(50)) as LLLfire,
cast(",LLLwater," as nvarchar(50)) as LLLwater,
cast(",LLLtheft," as nvarchar(50)) as LLLtheft,
cast(",LLLliability," as nvarchar(50)) as LLLliability,
cast(",LLLotherAOP," as nvarchar(50)) as LLLotherAOP,
cast(",LLLweather," as nvarchar(50)) as LLLweather,
cast(",curPremTrend," as nvarchar(50)) as curPremTrend,
cast(",projPremTrend," as nvarchar(50)) as projPremTrend,
cast(",HUexpFactor," as nvarchar(50)) as HUexpFactor,
cast(",HUyearsAdjFactor," as nvarchar(50)) as HUyearsAdjFactor,
cast(",STSexpFactor," as nvarchar(50)) as STSexpFactor,
cast(",STSyearsAdjFactor," as nvarchar(50)) as STSyearsAdjFactor,
cast(",if ('Fire' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilFire,
cast(",if ('Water' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilWater,
cast(",if ('Theft' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilTheft,
cast(",if ('Liability' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilLiability,
cast(",if ('Explosion' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilExplosion,
cast(",if ('Other' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilOther,
cast(",if ('NCW' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilNCW,
cast(",if ('STS' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilSTS,
cast(",if ('Hurricane' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilHurricane,
cast('",proposedEffective,"' as nvarchar(50)) as proposedEffective,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catLoadWeight,catExclude,catLoadSelection,LDFweight,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearsAdjFactor,
                                 IncludePerilFire,IncludePerilWater,IncludePerilTheft,IncludePerilLiability,IncludePerilExplosion,IncludePerilOther,IncludePerilNCW,IncludePerilSTS,IncludePerilHurricane,
                                 proposedEffective)
	) as unpvt2

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
  print(2)
}

save_selections_cw <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,curLossTrend,projLossTrend,catLoadExclude,
                               selected_by, technicalReviewer,PeerReviewer) {
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)
  #selections <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][-1])
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
technicalReviewer,
PeerReviewer,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catExclude,curLossTrend,projLossTrend)
	) as unpvt2

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer		

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
}



########################################################################################
######################## Territorial Analysis Functions ################################
########################################################################################

LossesCapped <- function(Program,IndicationDate, EvaluationDate, state) {
  dframe <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCapped
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))
}

LossesCappedByPeril <- function(Program,IndicationDate, EvaluationDate, state,peril) {
  dframe <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode,Peril, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCappedByPeril
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and peril = '",peril,"'
      "
  ))
}

EHY_Prem <- function(Program,IndicationDate, EvaluationDate, state) {
  dframe <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".Territorial_EHY_Prem
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


InforceAAL <- function(Program,IndicationDate, EvaluationDate, state) {
  dframe <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".TerritorialInforceAAL
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


ExperienceFactor <- function(Program,IndicationDate, EvaluationDate, state, name) {
  dframe <- dbGetQuery(con, paste0("
                               SELECT Territory, columnValue as ",name,"
  FROM [ActuarialSandbox].[",Program,"].[TerritorialExperienceAdjustmentFactor]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and Region = '",state,"'
  and columnName = '",name,"'
                               
                               "))
  if (nrow(dframe)>0) {
    return(dframe)
  } else {
    return(dframe)
  }
  
}

TerritorialExhibit <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
                               TargetLossRatio,TargetIndicatedChange,nonPeril){
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumatCRL*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode), EHY = as.numeric(EHY))
  
  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHY)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHY = sum(EHY,na.rm = T))%>% #ENDING adding InforceCount as a column so that I can show Snapshot Tab
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(STSexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    left_join(HUexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHY = coalesce(EHY,0), InforceCount = coalesce(InforceCount,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0),
           ModeledHUloss = coalesce(as.numeric(`HU AAL Total`) * as.numeric(ExpenseLAE) * coalesce(as.numeric(HUexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           ModeledSTSloss=  coalesce(as.numeric(`STS AAL Total`)* as.numeric(ExpenseLAE) * coalesce(as.numeric(STSexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           HU_Re_Load = coalesce(as.numeric((HUprojLossLAE+HURe)/HUprojLossLAE),0),
           TO_Re_Load = coalesce(as.numeric((STSprojLossLAE+STSRe)/STSprojLossLAE),0))%>%
    mutate(HU_Cost_Re = ModeledHUloss*(HU_Re_Load-1),
           TO_Cost_Re = ModeledSTSloss*(TO_Re_Load-1))%>%
    select(-state,-`HU AAL Total`, -`STS AAL Total`,-`HU Premium`,-`STS Premium`)%>%
    mutate(AdjLossLAEcost = round(ModeledHUloss + ModeledSTSloss + HU_Cost_Re + TO_Cost_Re + ProjLossTotal,3),
           Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = AdjLossLAEcost/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange)-1)*basePremTotal)%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  print(Main[Main$territoryCode==10,])
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange)-1,
           AveragePremium = coalesce(TrendedReratedEP/EHY,1),
           CatLossRatio = ModeledHUloss+ModeledSTSloss,
           CostOfReinsurance = HU_Cost_Re+TO_Cost_Re)%>%
    mutate(AdjTotalLoss = CatLossRatio+CostOfReinsurance+ProjLossTotal,CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange))  )%>%
    select(territoryCode,EHY,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,CatLossRatio,CostOfReinsurance,
           AdjLossLAEcost,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange,InforceCount)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Cat Loss Ratio',
                         'Cost of Reinsurance','Adj Total Loss, LAE, & Cost of Reinsurance','Indicated Changed','Credibility',
                         'Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change', 'InforceCount')
  
  
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `Average Premium` = sum(Exhibit$`Trended Earned Rerated Premium at CRL`)/sum(Exhibit$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(Exhibit$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(Exhibit$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`= NA , `Cat Loss Ratio` = NA,`Cost of Reinsurance`=NA,`Adj Total Loss, LAE, & Cost of Reinsurance`=NA,`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange, InforceCount = NA)#TargetIndicatedChange
  
  
  
  return(Exhibit)
}

TerritorialExhibitTop10 <- function(dframe) {
  dframe.filter <- dframe%>%
    filter(!is.na(InforceCount))%>%
    arrange(desc(InforceCount), desc(`Earned Exposures`))%>% #arrange by inforce count, and the EHY for case when there are ties in inforce count.
    head(10)%>%
    select(-InforceCount)
  
  
  dframe.out <- dframe.filter%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(dframe.filter$`Earned Exposures`),
            `Average Premium` = sum(dframe.filter$`Trended Earned Rerated Premium at CRL`)/sum(dframe.filter$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(dframe.filter$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(dframe.filter$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`= NA , `Cat Loss Ratio` = NA,`Cost of Reinsurance`=NA,`Adj Total Loss, LAE, & Cost of Reinsurance`=NA,`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=NA,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=NA)
}

TerritorialExhibitAttritionalNCW <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
                                             TargetLossRatio,TargetIndicatedChange,nonPeril,peril){

  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',ifelse(peril=='Theft', 'TheftVMM',peril))]]
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumUse*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))

  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>% #right join before adding on the premium columns, prevent data loss when low expereince and no losses
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHYUse = coalesce(EHYUse,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0))%>%
    mutate(Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = ProjLossTotal/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange[3])-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1,
           AveragePremium = coalesce(TrendedReratedEP/EHYUse,1))%>%
    mutate(CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange)))%>%
    select(territoryCode,EHYUse,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,Claim_Count,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Claim Count'
                         ,'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `Average Premium` = sum(Exhibit$`Trended Earned Rerated Premium at CRL`)/sum(Exhibit$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(Exhibit$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(Exhibit$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`=  coalesce(sum(Exhibit$`Capped Ultimate Losses Ex-Cat`)/sum(Exhibit$`Trended Earned Rerated Premium at CRL`),0),
            `Claim Count`=sum(Exhibit$`Claim Count`),`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange[3])

  
  return(Exhibit)
}

TerritorialExhibitAttritionalCAT <- function(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                             TargetLossRatio,TargetIndicatedChange,peril,peril_short,catExpAdj,perilLossLAE, CostRe, catYearsAdj,catCredStandard){
 
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',peril)]]
  InforceAALTable$CatPrem <- InforceAALTable[[paste(peril_short,'Premium',sep = ' ')]]
  InforceAALTable$CatAAL <- InforceAALTable[[paste(peril_short,'AAL Total',sep = ' ')]]
  catExpAdj$expFactor <- as.numeric(catExpAdj[[paste0(peril_short,'expFactor')]])
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    select(territoryCode,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  Main <- EHY_PremTableJoin%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(catExpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(ModeledLossRatio = ifelse(CatPrem > 0,CatAAL*ExpenseLAE/CatPrem ,0),
           ReinsLoad = (perilLossLAE+CostRe)/perilLossLAE,
           expFactor = coalesce(expFactor,1))%>%
    mutate(TerritoryCostRe = ModeledLossRatio*expFactor*(ReinsLoad - 1))%>%
    mutate(ProjectedLoss = ModeledLossRatio * expFactor + TerritoryCostRe,
           Credibility = coalesce(ifelse(EHYUse==0, 0, 
                                         ifelse(expFactor==1, 1, catYearsAdj/catCredStandard)),0),
           EHYUse = coalesce(EHYUse, 0))%>%
    mutate(IndicatedChange = ProjectedLoss/TargetLossRatio - 1)%>%
    mutate(CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+as.numeric(TargetIndicatedChange[3]))-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1)%>%
    mutate(CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),
           BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange)))%>%
    select(territoryCode,EHYUse,CatPrem,CatAAL,ModeledLossRatio,expFactor,TerritoryCostRe,ProjectedLoss,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'In Force Premium @ Currend Rate Level','Peril Modeled Gross AAL','Modeled Loss & LAE Ratio','Experience Adjustment Factor','Cost of Reinsurance','Adj Loss, LAE, & Cost of Reinsurance',
                         'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `In Force Premium @ Currend Rate Level`=sum(Exhibit$`In Force Premium @ Currend Rate Level`),
            `Peril Modeled Gross AAL` = sum(Exhibit$`Peril Modeled Gross AAL`),`Modeled Loss & LAE Ratio` = NA,`Experience Adjustment Factor` = NA,
            `Cost of Reinsurance` = NA,`Adj Loss, LAE, & Cost of Reinsurance` = NA,`Indicated Changed` = NA,`Credibility` = NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange[3])
  return(Exhibit)
}


##########################Class Variable Analysis Functions##########################

counter <- 0
defaultBinNumber <- 10

variableOptions <- function(program) {
  dframe <- dbGetQuery(con, paste0(
    "
    select distinct variableName as [Variable Names]
    from ActuarialSandbox.",program,".CVAraw
    order by variableName

    "
  ))
  return(head(dframe$`Variable Names`,-1))
}

cvaPull <- function(Program,IndicationDate, state, variableName,HUadj,LAE) { 
  dframe <- dbGetQuery(con, paste0(
    "select variableValue ,EarnedPremiumatCRL, EHY, Total_Capped_Incurred, Total_Claim_Count,Peril
    from actuarialSandbox.",Program,".CVAraw
    where IndicationDate = '",IndicationDate,"'
    and state = '",state,"' 
    and lower(variableName) = lower('",variableName,"')
    "
  )) %>%
    filter(variableValue !='-1')%>%
    mutate(Total_Capped_Incurred = coalesce(Total_Capped_Incurred,0),
           Total_Claim_Count = coalesce(Total_Claim_Count,0))%>%
    mutate(Total_Capped_Incurred=ifelse(Peril == 'ModeledHU', Total_Capped_Incurred*HUadj*LAE, Total_Capped_Incurred))
  #recalculate the Total_Capped_Incurred using HUadj and LAE
  dftotal <-  dframe%>%
    filter(Peril == 'Total')%>%
    mutate(All_Capped_Incurred=Total_Capped_Incurred)%>%
    select(variableValue, All_Capped_Incurred)
  
  dfHU <-  dframe%>%
    filter(Peril == 'Hurricane')%>%
    mutate(HU_Capped_Incurred=Total_Capped_Incurred )%>%
    select(variableValue, HU_Capped_Incurred)
  
  dfTotalModeled <- dframe%>%
    filter(Peril ==  'TotalModeledHU')%>%
    left_join(dftotal, by = c('variableValue'='variableValue'))%>%
    left_join(dfHU, by = c('variableValue'='variableValue'))%>%
    mutate(Total_Capped_Incurred=All_Capped_Incurred-HU_Capped_Incurred+Total_Capped_Incurred*HUadj*LAE)%>%
    select(-All_Capped_Incurred,-HU_Capped_Incurred)
  
  return(dframe)
}

cvaDisplayName <- function(Program,variableName) {
  dframe <- dbGetQuery(con,paste0("
  select DisplayName
  from ActuarialSandbox.",Program,".CVAnameMapping
  where lower(SQLname) = lower('",variableName,"')
"
  ))
  
  df2 <- ifelse(as.character(dframe)!="character(0)",as.character(dframe),'Enter Title...')
  
  return(df2)
  
}

cvaClean <- function(data, peril, HUadj , LAE){
  
  dframe <- data%>%
    filter(Peril == peril)%>%
    group_by(variableValue,Peril)%>%
    summarise(EarnedPremiumatCRL = sum(EarnedPremiumatCRL), EHY = sum(EHY),Total_Capped_Incurred=sum(Total_Capped_Incurred),Total_Claim_Count=sum(Total_Claim_Count), .groups = 'drop')
  dframe$order <- NA
  for (i in 1:nrow(dframe)) {
    dframe$order[i] <- tryCatch(as.numeric(gsub('[+]','',gsub(',','',unlist(strsplit(as.character(dframe$variableValue[i]),'[-]'))[1]))), warning = function(w) {NA})
  }
  
  df1 <- dframe%>%
    arrange(order)%>%
    mutate(AveragePrem = coalesce(EarnedPremiumatCRL/EHY,0),
           Loss_Ratio = Total_Capped_Incurred/EarnedPremiumatCRL,
           Frequency = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Total_Claim_Count/EHY *100,0)),
           Severity = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Total_Capped_Incurred/Total_Claim_Count,0)),
           Loss_Cost = coalesce(Total_Capped_Incurred/EHY,0))%>%
    select(Peril,variableValue, EarnedPremiumatCRL, EHY, AveragePrem,Total_Capped_Incurred,Total_Claim_Count,Loss_Ratio,Frequency, Severity, Loss_Cost)
  TotalLossRatio <- sum(dframe$Total_Capped_Incurred)/sum(dframe$EarnedPremiumatCRL)
  TotalFrequency <- sum(dframe$Total_Claim_Count)/sum(dframe$EHY) *100
  TotalSeverity <- sum(dframe$Total_Capped_Incurred)/sum(dframe$Total_Claim_Count)
  df2 <-df1%>%
    mutate(IndicatedChange = Loss_Ratio/TotalLossRatio-1,
           Credibility= ifelse(Peril == 'Total' | Peril == 'TotalModeledHU' | Peril == 'ExCat', ifelse((EHY/40000)^.5 < 1, (EHY/40000)^.5,1), ifelse((Total_Claim_Count/1082)^0.5<1, (Total_Claim_Count/1082)^0.5,1)))%>%
    mutate(CredWeighted = IndicatedChange * Credibility,
           FreqRel = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Frequency/TotalFrequency,0)),
           SevRel = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Severity/TotalSeverity,0)),
           LossRel = Loss_Ratio/TotalLossRatio)
  CredTotal <- df2%>%
    group_by()%>%
    summarise(CredTotal = sum(EarnedPremiumatCRL*CredWeighted))%>%
    mutate(CredTotal = CredTotal/sum(dframe$EarnedPremiumatCRL))
  df3 <- df2%>%
    add_row(Peril = '',variableValue = 'Total',EarnedPremiumatCRL = sum(dframe$EarnedPremiumatCRL),EHY = sum(dframe$EHY),AveragePrem = coalesce(sum(dframe$EarnedPremiumatCRL)/sum(EHY),0),
            Total_Capped_Incurred  = sum(dframe$Total_Capped_Incurred), Total_Claim_Count = sum(dframe$Total_Claim_Count),
            Loss_Ratio = sum(dframe$Total_Capped_Incurred)/sum(dframe$EarnedPremiumatCRL),
            Frequency = ifelse(peril == 'ModeledHU' | peril == 'TotalModeledHU',NA,sum(dframe$Total_Claim_Count)/sum(dframe$EHY) *100),
            Severity = ifelse(peril == 'ModeledHU' | peril == 'TotalModeledHU',NA,sum(dframe$Total_Capped_Incurred)/sum(dframe$Total_Claim_Count)),
            Loss_Cost = sum(dframe$Total_Capped_Incurred)/sum(dframe$EHY),
            IndicatedChange = NA, Credibility=NA,CredWeighted=as.numeric(CredTotal),FreqRel=NA,SevRel=NA,LossRel=NA
    )
  
  return(df3)
  
}

CVAvalueMapping <- function(Program,State,variableName,Data,peril){ 
  dframe <- dbGetQuery(con, paste0("
        select variableValue, DisplayValue
                               
        from ActuarialSandbox.",Program,".CVAvalueMapping
        where lower(variableName) = lower('",variableName,"')
        and state = '",State,"'"))
  
  
  if (nrow(dframe) > 0) {
    Data2 <- Data%>%
      left_join(dframe, by = c("variableValue" = "variableValue"))%>%
      mutate(variableValue = DisplayValue)%>%
      select(-DisplayValue) 
    df2 <- dframe%>%
      group_by(DisplayValue)%>%
      summarise(variableValueAlter = min(variableValue))
    Data2 <- cvaClean(Data2,peril)%>%
      left_join(df2, by = c(c("variableValue" = "DisplayValue")))%>%
      arrange(variableValueAlter)%>%
      select(-variableValueAlter) 
    Data <- Data2
  }
  return(Data)
  
  
}


#Review Progress
review_progress <- function(Program, State, IndicationDate, EvaluationDate) { #pulling in whether the technical and/or peer review have been completed
  dframe <- dbGetQuery(con, paste0("
                                   SELECT distinct
                                      max(selected_by) as [selector],
                                      max(TechnicalReviewer) as [Technical Review],
                                      max(PeerReviewer) as [Peer Review] 
                                      FROM [ActuarialSandbox].[",Program,"].[indicationSelections]
                                    where IndicationDate = '",IndicationDate,"'
                                    and EvaluationDate = '",EvaluationDate,"'
                                    and Region = '",State,"'
                                    and (Status = 'In Review' or Status = 'Published')
                                    group by Region, IndicationDate, EvaluationDate
                                   "))
  if (nrow(dframe) > 0 ) {
    dframe <- data.frame(Step = c('Confirm Selections','Technical Review', 'Peer Review'),Status = c(
                                                                                if (dframe$selector > 0)           {'Complete'} else  {'Incomplete'}, 
                                                                                if (dframe$`Technical Review` > 0) {'Complete'} else  {'Incomplete'}, 
                                                                                if (dframe$`Peer Review` > 0)      {'Complete'} else  {'Incomplete'}))
  } else {
    dframe <- data.frame(Step = c('Confirm Selections','Technical Review', 'Peer Review'), Status = c('Incomplete','Incomplete', 'Incomplete'))
  }
 
  return(dframe)
}

#####################################################################################
############################# RShiny User Interface #################################
#####################################################################################

ui <- fluidPage(#align='center',#theme = shinytheme('sandstone'),
  tags$script("
    Shiny.addCustomMessageHandler('EvaluationDate', function(value) {
    Shiny.setInputValue('EvaluationDate', value);
    });"),
  titlePanel(title=div(img(src='HOA Pic.jpg', height = 50, width = 225))),
  titlePanel("Actuarial Indication"),
  tabsetPanel(
    tabPanel('Choose Indication',
             fluidRow(
               column(width = 4,
                      br(),
                      varSelectInput("Program", "Line Of Buisness", LOB, colnames(LOB)[1]),
                      varSelectInput("State", "State", state_options('HO'),'SC'),
                      selectInput("IndicationDate", 'Indication Name', choices = date_options('ho'),date_options('ho')[2] ),
                      selectInput("EvaluationDate", 'Evaluated As Of:', choices = eval_date_options(date_options('ho')[[1]],'ho'), selected =eval_date_options(date_options('ho')[[1]],'ho')[1]),
                      uiOutput('ratingVersionID'),br(),
                      actionButton('searchIndication', 'Load Indication', icon = NULL)
               ),
               column(8)
             )
    ),
    tabPanel("Inputs",
             fluidRow(
               column(width = 4,
                      br(),
                      dateInput("proposedEffective",'Proposed Effective Date','2022-09-01'),
                      selectInput('selected_by', 'Selections Made By:',choices = actuaryNames('All')),
                      selectInput('technical_reviewed_by', 'Technical Review Completed By:',choices = actuaryNames(actuaryNames('All')[1])),
                      selectInput('peer_reviewed_by', 'Peer Review Completed By:',choices = actuaryNames(actuaryNames('All')[1])),
                      numericInput('capped', 'Cap Losses at:', 250000),
                      checkboxGroupInput('includePerils', 'Peril List:', choices = c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane'), selected = 1),
                      actionButton('saveInputs','Save Inputs' , icon = NULL)
               ),
               column(8)
             )
    ),
    tabPanel('Indication',
             tabsetPanel(
               tabPanel("Modeled Cat Load",
                        tabsetPanel(
                          tabPanel("Expense Load",
                                   fluidRow(
                                     column(width = 6,br(),
                                            tableOutput("cw_expense")
                                     ),    
                                     column(2, br(),
                                            checkboxGroupInput("cw_exclude", 
                                                               "CW Exclude Year", 
                                                               choices = NULL,
                                                               selected = 1)),
                                     column(1,
                                            currencyInput("CATstateweight", uiOutput("state1"),1,format = "percentageUS2dec"),
                                            DTOutput("expense_load_output"),
                                            DTOutput('expense_load_output_selected'),
                                            br(),
                                            actionButton('catLoadtoSQL','Save Selection' , icon = NULL)),
                                     column(1),
                                     column(1,br(),br(),br(),
                                            actionButton('useCalcExpense','Use Calculated',icon=NULL)) 
                                   ),
                                   fluidRow(
                                     column(6,
                                            tableOutput("state_expense")),
                                     column(2,br(),
                                            checkboxGroupInput("state_exclude", 
                                                               uiOutput('state2'), 
                                                               choices = NULL,
                                                               selected = 1)),
                                     column(1)
                                   )
                          ),
                          tabPanel("Modeled Results",
                                   fluidRow(
                                     column(1),
                                     column(width = 10,align = 'center',
                                            uiOutput("state6"),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('LOB_header'),
                                            h5('Modeled Catastrophe (CAT) Load'),
                                            withSpinner(DTOutput('ModeledCatLoad'))
                                     ),
                                     column(1)
                                   )
                          ),
                          tabPanel('Non-Modeled Results',
                                   fluidRow(
                                     column(3),
                                     column(3,align = 'center',
                                            h4('Hurricane'),
                                     ),
                                     column(3,align = 'center',
                                            h4('STS'),
                                     ),
                                     column(3,
                                            actionButton('nonmodeledsave','Save Selections',icon=NULL))
                                   ),                      
                                   fluidRow(
                                     column(3,align = 'right',br(),
                                            h4('Exp Adj Factor')),
                                     column(3,align = 'center',
                                            numericInput('HUexpFactor','',1.00)),
                                     column(3,align = 'center',
                                            numericInput('STSexpFactor','',1.00)),
                                     column(3)
                                   ),
                                   fluidRow(
                                     column(3,align = 'right',br(),
                                            h4('Total Years for Exp Adj')),
                                     column(3,align = 'center',
                                            numericInput('HUyearExpAdj','',0,step = 1)),
                                     column(3,align = 'center',
                                            numericInput('STSyearExpAdj','',0,step = 1)),
                                     column(3)
                                   ))
                        ) #Close inner tabsetPanel
               ),
               tabPanel("LDFs",
                        tabsetPanel(
                          
                          tabPanel("State",
                                   tabsetPanel(id = 'LDF',
                                               tabPanel("All Perils",
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 uiOutput('state3'),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header4'),
                                                                 h5(strong('Loss Development Factors')),
                                                                 withSpinner(DTOutput('LDFallstateloss')),
                                                                 withSpinner(DTOutput('LDFallstateratio')),
                                                                 br(),br(),
                                                                 withSpinner(DTOutput("LDFallstateaverages")),
                                                                 h4(strong('Selections'))
                                                                 
                                                          ),
                                                          column(2)
                                                          
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 withSpinner(DTOutput('LDFallstatecumulative')),
                                                                 br(),br(),br(),
                                                                 DTOutput('LDFshowCWselectionAllPerils'),
                                                                 br(),br(),br(),
                                                                 DTOutput('LDFweightedCumulativeAllPerils')
                                                          ),
                                                          column(1,
                                                                 currencyInput("LDFstateweight", "State Weight",.50,format = "percentageUS2dec"),
                                                                 br(),
                                                                 actionButton('ldfselectionToSQLstate','Save Selection',icon = NULL)
                                                          ),
                                                          column(1)
                                                        )
                                               ),
                                               tabPanel(title = "Weather", value = 'Weather',
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 uiOutput('state4'),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header5'),
                                                                 h5(strong('Loss Development Factors - Weather')),
                                                                 withSpinner(DTOutput('LDFallstatelossWeather')),
                                                                 withSpinner(DTOutput('LDFallstateratioWeather')),
                                                                 br(),br(),
                                                                 withSpinner(DTOutput("LDFallstateaveragesWeather")),
                                                                 h4(strong('Selections'))
                                                                 
                                                          ),
                                                          column(2)
                                                          
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 withSpinner(DTOutput('LDFallstatecumulativeWeather')),
                                                                 br(),br(),
                                                                 DTOutput('LDFshowCWselectionWeather'),
                                                                 br(),br(),br(),
                                                                 DTOutput('LDFweightedCumulativeWeather')
                                                          ),
                                                          column(2,
                                                                 actionButton('ldfselectionToSQLstateWeather','Save Selection',icon = NULL))
                                                        )
                                               ),
                                               tabPanel(title = "Attritional", value = 'Attritional',
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 uiOutput('state5'),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header6'),
                                                                 h5(strong('Loss Development Factors - Attritional')),
                                                                 withSpinner(DTOutput('LDFallstatelossAttritional')),
                                                                 withSpinner(DTOutput('LDFallstateratioAttritional')),
                                                                 br(),br(),
                                                                 withSpinner(DTOutput("LDFallstateaveragesAttritional")),
                                                                 h4(strong('Selections'))      
                                                          ),
                                                          column(2)
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 withSpinner(DTOutput('LDFallstatecumulativeAttritional')),
                                                                 br(),br(),
                                                                 DTOutput('LDFshowCWselectionAttritional'),
                                                                 br(),br(),br(),
                                                                 DTOutput('LDFweightedCumulativeAttritional')
                                                          ),
                                                          column(2,
                                                                 actionButton('ldfselectionToSQLstateAttritional','Save Selection',icon = NULL))
                                                        )
                                                        
                                               )
                                   )
                          ),
                          tabPanel("CW",
                                   tabsetPanel(id = 'LDFCW',
                                               tabPanel("All Perils",
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 h4(strong(';wide')),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header1'),
                                                                 h5(strong('Loss Development Factors')),
                                                                 withSpinner(DTOutput('LDFallCWloss')),
                                                                 withSpinner(DTOutput('LDFallCWratio')),
                                                                 h4(strong('Summary')),
                                                                 withSpinner(DTOutput("LDFallCWaverages")),
                                                                 h4(strong('Selections'))
                                                                 
                                                          )
                                                          
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 DTOutput('LDFallCWcumulative')
                                                          ),
                                                          column(2,
                                                                 actionButton('ldfselectionToSQL','Save Selection',icon = NULL))
                                                        )
                                                        
                                               ),
                                               tabPanel(title = "Weather", value = 'Weather',
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 h4(strong('Countrywide')),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header2'),
                                                                 h5(strong('Loss Development Factors - Weather')),
                                                                 withSpinner(DTOutput('LDFallCWlossWeather')),
                                                                 withSpinner(DTOutput('LDFallCWratioWeather')),
                                                                 h4(strong('Summary')),
                                                                 withSpinner(DTOutput("LDFallCWaveragesWeather")),
                                                                 h4(strong('Selections'))
                                                                 
                                                          )
                                                          
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 withSpinner(DTOutput('LDFallCWcumulativeWeather'))
                                                          ),
                                                          column(2,
                                                                 actionButton('ldfselectionToSQLWeather','Save Selection',icon = NULL))
                                                        )
                                               ),
                                               tabPanel(title = "Attritional", value = 'Attritional',
                                                        fluidRow(
                                                          column(2),
                                                          column(8,align = 'center',
                                                                 h4(strong('Countrywide')),
                                                                 h4(strong('Homeowners of America Insurance Company')),
                                                                 uiOutput('LOB_header3'),
                                                                 h5(strong('Loss Development Factors - Attritional')),
                                                                 withSpinner(DTOutput('LDFallCWlossAttritional')),
                                                                 withSpinner(DTOutput('LDFallCWratioAttritional')),
                                                                 h4(strong('Summary')),
                                                                 withSpinner(DTOutput("LDFallCWaveragesAttritional")),
                                                                 h4(strong('Selections'))
                                                                 
                                                          )
                                                          
                                                        ),
                                                        fluidRow(
                                                          column(2),
                                                          column(8,
                                                                 withSpinner(DTOutput('LDFallCWcumulativeAttritional'))
                                                          ),
                                                          column(2,
                                                                 actionButton('ldfselectionToSQLAttritional','Save Selection',icon = NULL))
                                                        )
                                               )
                                   )
                          )
                        )
               ),
               tabPanel('Loss Trend',
                        tabsetPanel(
                          tabPanel('State',
                                   fluidRow(
                                     column(4),
                                     column(4,align = 'center',
                                            uiOutput('state7'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('lossTrendLOBheader'),
                                            h5(strong('Loss Trend Selections')),
                                            withSpinner(DTOutput('lossTrendstate')),
                                            br(),
                                            br()
                                     ),
                                     column(4, 
                                     ),
                                     fluidRow(
                                       column(5),
                                       column(3,
                                              withSpinner(DTOutput('lossTrendstatefitting')),
                                              br()),
                                       column(4,
                                              radioButtons("LosstrendstateLag", label = "Number of Quarters to Lag to allow for full development",
                                                           choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                                           selected = 0)
                                       ))
                                   ),
                                   fluidRow(
                                     column(7),
                                     column(1,
                                            currencyInput("currentLossTrendState", 'Current Selection',0,format = "percentageUS2dec"),
                                            currencyInput("projLossTrendState", 'Projected Selection',0,format = "percentageUS2dec")),
                                     column(4,
                                            actionButton('stateLossTrendtoSQL', 'Save Selection',icon=NULL))
                                   ),
                                   fluidRow(
                                     column(3),
                                     column(6,
                                            sliderInput('LossTrendSlider', 'How many points?', min = 2, max = 2, value = 2, ticks = T)
                                            )
                                   ),
                                   fluidRow(
                                     column(3),
                                     column(6,
                                            withSpinner(plotOutput("StateLossPlot")),
                                            withSpinner(plotOutput("StateFrequencyPlot")),
                                            withSpinner(plotOutput("StateSeverityPlot"))),
                                     column(2,
                                            checkboxGroupInput("LossTrendExclude", 
                                                               'Exclude Data Points:', 
                                                               choices = NULL,
                                                               selected = 1))
                                   )
                          ),
                          tabPanel('Countrywide',
                                   fluidRow(
                                     column(4),
                                     column(4,align = 'center',
                                            h4(strong('Countrywide')),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('lossTrendLOBheaderCW'),
                                            h5(strong('Loss Trend Selections')),
                                            withSpinner(DTOutput('lossTrendCW')),
                                            br(),
                                            br()
                                     ),
                                     column(4)
                                   ),
                                   fluidRow(
                                     column(5),
                                     column(3,
                                            withSpinner(DTOutput('lossTrendCWfitting')),
                                            br()),
                                     column(4
                                            #,
                                            # radioButtons("LosstrendCWLag", label = "Number of Quarters to Lag to allow for full development",
                                            #              choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                            #              selected = 0)
                                     )
                                   ),
                                   fluidRow(
                                     column(7),
                                     column(1,
                                            currencyInput("currentLossTrendCW", 'Current Selection',0,format = "percentageUS2dec"),
                                            currencyInput("projLossTrendCW", 'Projected Selection',0,format = "percentageUS2dec")),
                                     column(4,
                                            actionButton('cwLossTrendtoSQL', 'Save Selection',icon=NULL))
                                   )
                          )
                        )),
               tabPanel('LLL',
                        tabsetPanel(id = 'LLL',
                                    tabPanel('Total',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLL'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load'),
                                                      withSpinner(DTOutput('LLLTotalTablestate')),
                                                      br()
                                               ),
                                               column(3,
                                                      currencyInput("LLLstateweightTotal", uiOutput("state10"),0,format = "percentageUS2dec"),
                                                      actionButton('LLLselectionsToSQL','Save Selection'))
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateTotal'),
                                                      DTOutput('LLLselectStateTotalSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load'),
                                                      withSpinner(DTOutput('LLLTotalTableCW')),
                                                      br(),
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWTotal'),
                                                      DTOutput('LLLselectCWTotalSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedTotal')
                                               )
                                             )),
                                    tabPanel(title = 'Fire', value = 'Fire',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLFire'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Fire'),
                                                      withSpinner(DTOutput('LLLTotalTablestateFire')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateFire'),
                                                      DTOutput('LLLselectStateFireSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Fire'),
                                                      withSpinner(DTOutput('LLLTotalTableCWFire')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWFire'),
                                                      DTOutput('LLLselectCWFireSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedFire'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Water',value = 'Water',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLWater'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Water'),
                                                      withSpinner(DTOutput('LLLTotalTablestateWater')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateWater'),
                                                      DTOutput('LLLselectStateWaterSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Water'),
                                                      withSpinner(DTOutput('LLLTotalTableCWWater')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWWater'),
                                                      DTOutput('LLLselectCWWaterSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedWater'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Theft',value = 'Theft',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLTheft'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Theft'),
                                                      withSpinner(DTOutput('LLLTotalTablestateTheft')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateTheft'),
                                                      DTOutput('LLLselectStateTheftSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Theft'),
                                                      withSpinner(DTOutput('LLLTotalTableCWTheft')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWTheft'),
                                                      DTOutput('LLLselectCWTheftSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedTheft'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Liability',value = 'Liability',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLLiability'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Liability'),
                                                      withSpinner(DTOutput('LLLTotalTablestateLiability')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateLiability'),
                                                      DTOutput('LLLselectStateLiabilitySelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Liability'),
                                                      withSpinner(DTOutput('LLLTotalTableCWLiability')))
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWLiability'),
                                                      DTOutput('LLLselectCWLiabilitySelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedLiability'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Other AOP',value = 'OtherAOP',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLOtherAOP'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Other AOP'),
                                                      withSpinner(DTOutput('LLLTotalTablestateOtherAOP')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateOtherAOP'),
                                                      DTOutput('LLLselectStateOtherAOPSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Other AOP'),
                                                      withSpinner(DTOutput('LLLTotalTableCWOtherAOP')))
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWOtherAOP'),
                                                      DTOutput('LLLselectCWOtherAOPSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedOtherAOP'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Weather', value = 'Weather',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLWeather'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Weather'),
                                                      withSpinner(DTOutput('LLLTotalTablestateWeather')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateWeather'),
                                                      DTOutput('LLLselectStateWeatherSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Weather'),
                                                      withSpinner(DTOutput('LLLTotalTableCWWeather')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWWeather'),
                                                      DTOutput('LLLselectCWWeatherSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedWeather'),
                                                      br(),
                                                      br()
                                               )
                                             ))
                        )
               ),
               tabPanel('Premium Trend',
                        fluidRow(
                          column(4),
                          column(4,align = 'center',
                                 uiOutput('state8'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('PremiumTrendLOBheader'),
                                 h5(strong('Premium Trend Selection')),
                                 withSpinner(DTOutput('premiumTrend')),
                                 br(),
                                 br()
                          ),
                          column(4
                          ),
                          fluidRow(
                            column(5),
                            column(3,
                                   withSpinner(DTOutput('PremiumTrendfitting')),
                                   br()),
                            column(4)
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(1,
                                 currencyInput("currentPremiumTrend", 'Current Selection',0,format = "percentageUS2dec"),
                                 currencyInput("projPremiumTrend", 'Projected Selection',0,format = "percentageUS2dec")),
                          column(4,
                                 actionButton('PremiumSave','Save Selection', icon = NULL))
                        )
               ),
               tabPanel('Expense Ratios',
                        tabsetPanel(
                          tabPanel('Expense Exhibit',
                                   fluidRow(
                                     column(3),
                                     column(6,align = 'center',
                                            uiOutput('state30'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('ExpenseLOBheader'),
                                            h4('Expense Provisions'),
                                            br(),
                                            withSpinner(DTOutput('expenseExhibit'))),
                                     column(3)
                                   )
                          ),
                          tabPanel('CAT Reinsurance Provision By Peril',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('stateReinsurance'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('ReinsuranceLOB'),
                                            h4('Reinsurance Exhibit'),
                                            withSpinner(DTOutput('reinsuranceExhibit'))
                                     ),
                                     column(3)
                                   ))
                        )),
               tabPanel('Indication',
                        tabsetPanel(
                          tabPanel('Memo Exhibit',
                                   fluidRow(
                                     column(3),
                                     column(6,br(),
                                            DTOutput('memo')),
                                     column(3)
                                   )),
                          tabPanel('Total',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state9'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('TotalLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('TotalProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            br(),
                                            withSpinner(DTOutput('TotalRateLevelIndication'))
                                     ),
                                     column(3)),
                                   fluidRow(
                                     column(4),
                                     column(5,
                                            br(),
                                            br(),
                                            withSpinner(DTOutput('TotalRateLevelSummary'))),
                                     column(3)
                                   )),
                          tabPanel(title = 'Fire',value = 'Fire',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state15'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('FireLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('FireProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Fire')),
                                            br(),
                                            withSpinner(DTOutput('FireIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('FireIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('FireIndicationSummary')),br(),
                                            withSpinner(DTOutput('FireRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Water',value = 'Water',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state16'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('WaterLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('WaterProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Water')),
                                            br(),
                                            withSpinner(DTOutput('WaterIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('WaterIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('WaterIndicationSummary')),br(),
                                            withSpinner(DTOutput('WaterRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Theft VMM',value = 'Theft',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state17'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('TheftLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('TheftProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Theft & VMM')),
                                            br(),
                                            withSpinner(DTOutput('TheftIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('TheftIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('TheftIndicationSummary')),br(),
                                            withSpinner(DTOutput('TheftRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Other AOP',value = 'OtherAOP',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state18'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('OtherAOPLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('OtherAOPProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Other AOP')),
                                            br(),
                                            withSpinner(DTOutput('OtherAOPIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('OtherAOPIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('OtherAOPIndicationSummary')),br(),
                                            withSpinner(DTOutput('OtherAOPRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Liability',value = 'Liability',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state20'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('LiabilityLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('LiabilityProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Liability')),
                                            br(),
                                            withSpinner(DTOutput('LiabilityIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('LiabilityIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('LiabilityIndicationSummary')),br(),
                                            withSpinner(DTOutput('LiabilityRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Non-Cat Weather',value = 'NCW',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state21'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('NCWLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('NCWProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Non-Cat Weather')),
                                            br(),
                                            withSpinner(DTOutput('NCWIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('NCWIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('NCWIndicationSummary')),br(),
                                            withSpinner(DTOutput('NCWRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='STS', value = 'STS',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state22'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('STSLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('STSProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('STS')),
                                            br(),
                                            withSpinner(DTOutput('STSIndication')),br(),
                                            withSpinner(DTOutput('STSIndicationSummary')),br(),
                                            withSpinner(DTOutput('STSRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Hurricane', value = 'Hurricane',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state23'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('HULOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('HUProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Hurricane')),
                                            br(),
                                            withSpinner(DTOutput('HUIndication')),br(),
                                            withSpinner(DTOutput('HUIndicationSummary')),br(),
                                            withSpinner(DTOutput('HURateLevelChange')),br()
                                     ))),
                          id = 'Indication'
                        )
               ))),
    tabPanel('Territorial Analysis',
             tabsetPanel(id = 'TerritorialAnalysis',
                         tabPanel('Exhibit',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibit'))
                                  )),
                         tabPanel('Exhibit Snapshot',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitSnapshot'))
                                  )),
                         tabPanel(title = 'Exhibit Fire', value = 'ExhibitFire',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitFire'))
                                  )),
                         tabPanel(title = 'Exhibit Water', value = 'ExhibitWater', 
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitWater'))
                                  )),
                         tabPanel(title = 'Exhibit Theft', value = 'ExhibitTheft',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitTheft'))
                                  )),
                         tabPanel(title ='Exhibit Liab', value = 'ExhibitLiab',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitLiab'))
                                  )),
                         tabPanel(title ='Exhibit AOP', value = 'ExhibitAOP',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitAOP'))
                                  )),
                         tabPanel(title ='Exhibit NCW', value = 'ExhibitNCW',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitNCW'))
                                  )),
                         tabPanel(title ='Exhibit STS', value = 'ExhibitSTS',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitSTS'))
                                  )),
                         tabPanel(title ='Exhibit HU', value = 'ExhibitHU',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitHU'))
                                  ))
             )),
    tabPanel('Class Variable Analysis',
             tabsetPanel(
               tabPanel('Choose CVA Variables',
             sidebarLayout(
               sidebarPanel(width = 2,
                            checkboxGroupInput('ProgramvariableOptions', label = 'Homeowners Variable Options',choices = variableOptions('ho'),selected = variableOptions('ho'))
               ), 
               mainPanel()
               )),
               
               # Show a plot of the generated distribution
               tabPanel('Review Plots',
                 fluidRow(
                   column(3,
                          selectInput('selectVariable', label = 'Class Variable SQL Name:',choices = NULL)),
                   column(3,
                          selectInput('selectPeril', label = 'Peril:',choices = NULL)),
                   column(3,
                          textInput("variableTitle", label = "Class Variable Display Name:", value = "Enter Title..."),
                          actionButton('saveTitle', label ='Save New Display Name')),
                   column(3,br(),
                          autonumericInput("binSize", label = "Bin Size",value = 50000,decimalPlaces = 0,digitGroupSeparator = ","),br(),
                          autonumericInput("binNumber", label = "Number of Bins",value = defaultBinNumber,decimalPlaces = 0)#,br(),
                          #switchInput(inputId = "useBins", value = F)
                   )
                 ),
                 fluidRow(br(),br(),
                          column(12,
                                 withSpinner(plotOutput("distPlot")),br(),
                                 withSpinner(DTOutput('table'))
                          )
                 )
               )
             )),
    tabPanel('Endorsement Analysis',
             tabsetPanel(
               tabPanel('Inc Liability and Inc Med'),
               tabPanel('Other Endorsements')
             )),
    tabPanel('Review Selections',
             tabsetPanel(
               tabPanel('Confirm Selections',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       h3('Selector Checklist:'),
                                       h5('Confirm that each selection has been made.'),br(),
                                       checkboxGroupInput('SelectorChecklist', label = 'Confirm Selections and Data for:',
                                                          choices = selectorChecklist_list),
                                       h5('Once you have checked all of the 
                             boxes, then you will be able to send for Technical Review.'),
                                       br(),
                                       actionButton('saveSelectionsForReview','Selections Complete'),br(),br(),br(),
                                       uiOutput('EmailReviewToTechnical'), #send to Peer reviewer if all things check out and cc the Indication selector
                                       #if there is a problem with reconciliation, then send a different email to just Ian so he can track down the error and cc the indication selector
                                       use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )
                        ),
               tabPanel('Technical Review',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                          h3('Technical Review Checklist:'),
                          h5('Confirm that Premium and Losses reconcile to each other in the shiny app and that they are consistent with our expectations.'),br(),
                          checkboxGroupInput('TechnicalreviewChecklist', label = 'Premium and Losses Reconcile for:',
                                             choices = technicalChecklist_list),
                          h5('Once you have checked all of the 
                             boxes, then you will be able to notify Peer review to begin their evaluation.'),
                          br(),
                          actionButton('saveTechnicalReview','Techincal Review Complete'),br(),br(),br(),
                          uiOutput('EmailReviewToPeer'), #send to Peer reviewer if all things check out and cc the Indication selector
                          #if there is a problem with reconciliation, then send a different email to just Ian so he can track down the error and cc the indication selector
                          use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )),
               tabPanel('Peer Review',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       h3('Peer Review Checklist:'),
                                       h5('Review each of the selections made in the indication.'),br(),
                                       checkboxGroupInput('PeerReviewChecklist', label = 'Approve the following Selections:',
                                                          choices = peerChecklist_list),
                                       h5('Once you have checked all of the 
                             boxes, then you will be able to notify that the indication is ready to be published and sent out.'),
                                       
                             br(),
                             actionButton('savePeerReview','Peer Review Complete'),br(),br(),br(),
                             uiOutput('EmailReviewToSelector'), 
                             use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )),
               tabPanel('Publish',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       tableOutput('ReviewProgress'),
                                       h5('Once each step has been completed. Then selections can be published.'),
                                       
                                       br(),
                                       actionButton('PublishSelections','Publish')
                          ),
                          mainPanel(
                          )
                        ))
             )),
    tabPanel('Download',
             column(6,align = 'center',
                    downloadButton("report", "Download Indication Exhibits")
             ), 
             column(6,align = 'center',
                    downloadButton("territorial_report", "Download Territorial Analysis Exhibits")
             )
             
    )
  ) #Close outer tabsetPanel
) #Close FluidPage

server <- function(input, output,session) {
  #define all data frames as empty. then update them with observe event when indication, asOFdate, state, LOB change. reduce the number of times that data is reloaded into the server. Better practice
  cw_expense =LDFdata = data.frame()
  LDFchoices = data.frame(matrix(nrow = 0, ncol = 11))
  evaluation_date_proxy <- NULL
  indication_change <- FALSE
  searchIndication <- 0
  emailCount<-0
  #start of expense display function

  
  observeEvent({c(input$selected_by)},
               { 
                  
                 updateSelectInput(session, input = 'technical_reviewed_by',
                                   choices = actuaryNames(input$selected_by))
                 
                 updateSelectInput(session, input = 'peer_reviewed_by',
                                   choices = actuaryNames(c(input$selected_by,input$technical_reviewed_by))) 
                 
               })
  observeEvent({c(input$technical_reviewed_by)},
               { 
                
                 updateSelectInput(session, input = 'peer_reviewed_by',
                                   choices = actuaryNames(c(input$selected_by,input$technical_reviewed_by))) 
                 
               })

  
  observeEvent({c(input$selected_by,input$technical_reviewed_by,input$peer_reviewed_by,input$IndicationDate, input$State, input$Program, input$SelectorChecklist,input$TechnicalreviewChecklist,input$PeerReviewChecklist)}, #prep the review email to send out
               { 
                   
                 
                 selector <- actuaryReturn(input$selected_by)
                 techreviewer <- actuaryReturn(input$technical_reviewed_by)
                 peerreviewer <- actuaryReturn(input$peer_reviewed_by)
                 emailCount <<- emailCount+1
                 sendToTech = paste0(tolower(substr(techreviewer$FirstName, start=1, stop = 1)),tolower(techreviewer$LastName),"@hoaic.com")
                 sendToPeer = paste0(tolower(substr(peerreviewer$FirstName, start=1, stop = 1)),tolower(peerreviewer$LastName),"@hoaic.com")
                 sendToSelector = paste0(tolower(substr(selector$FirstName, start=1, stop = 1)),tolower(selector$LastName),"@hoaic.com")
                 support = 'istarkey@hoaic.com'
 
                 IndicationName <- strftime(as.Date(input$IndicationDate)-1, format = "%y%m")
                 
                 if (length(input$SelectorChecklist) == length(selectorChecklist_list) ) {
                 output$EmailReviewToTechnical <- renderUI({mailtoR(email = sendToTech,
                                                                     cc = c(" "),
                                                                     bcc = c(" "),
                                                                     text = "Send Email for Technical Review", 
                                                                     subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                     body = glue::glue(
                                                                       
                                                                     paste0("
                                                     Hi ",techreviewer$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," is ready for the technical review. Let me know if there are any discrepancies in the data!
                                                                  
                                                     Thanks,
                                                     ",selector$FirstName)))
                 })
                 } else {
                   output$EmailReviewToTechnical <- renderUI({mailtoR(email = sendToTech,
                                                                      cc = c(" "),
                                                                      bcc = c(" "),
                                                                      text = "", 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(""))
                   })
                 }
                 
                 if (length(input$TechnicalreviewChecklist) == length(technicalChecklist_list) ) {
                   output$EmailReviewToPeer <- renderUI({mailtoR(email = sendToPeer,
                                                                      cc = c(sendToSelector),
                                                                      bcc = c(" "),
                                                                      text = "Send Email for Peer Review", 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(
                                                                        
                                                                      paste0("
                                                     Hi ",peerreviewer$FirstName,",
                                                                
                                                     The Technical Review is complete for ",selector$FirstName,"'s selections for ",input$State," ", input$Program," Indication ",IndicationName," and is ready for Peer Review.
                                                                  
                                                     Thanks,
                                                     ",techreviewer$FirstName)))
                   })
                   
                 } else {
                   output$EmailReviewToPeer <- renderUI({mailtoR(email = support,
                                                                 cc = c(sendToSelector),
                                                                 bcc = c(" "),
                                                                 text = "Report an issue with the data", 
                                                                 subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                 body = glue::glue(
                                                                   
                                                                   paste0("
                                                     Hi Ian,
                                                                
                                                     There is a data error in the ",input$State," ", input$Program," Indication ",IndicationName," for the following tables:
                                                                  
                                                     Thanks,
                                                     ",techreviewer$FirstName)))
                   })
                 }
                 
                 if (length(input$PeerReviewChecklist) == length(peerChecklist_list) ) {
                   output$EmailReviewToSelector <- renderUI({mailtoR(email = sendToSelector,
                                                                      cc = c(" "),
                                                                      bcc = c(" "),
                                                                      text = paste("Notify",selector$FirstName,'selections are ready to Publish.', sep = ' '), 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(
                                                                        
                                                                      paste0("
                                                     Hi ",selector$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," peer review is complete. The selections are ready to be published.
                                                                  
                                                     Thanks,
                                                     ",peerreviewer$FirstName)))
                   })
                 } else {
                   output$EmailReviewToSelector <- renderUI({mailtoR(email = sendToSelector,
                                                                     cc = c(" "),
                                                                     bcc = c(" "),
                                                                     text = paste("Notify",selector$FirstName,'selections need revision.', sep = ' '), 
                                                                     subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                     body = glue::glue(
                                                                       
                                                                       paste0("
                                                     Hi ",selector$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," peer review is in progress. 
                                                     The following selections need revision:
                                                                  
                                                     Thanks,
                                                     ",peerreviewer$FirstName)))
                   })
                 }
               },priority = 9)
  
  observeEvent({c(input$Program, input$State, input$IndicationDate, input$EvaluationDate)},
               {
                 ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)
                 output$ReviewProgress <- renderTable(ReviewProgressData)
                 output$ratingVersionID <- renderUI(h5(strong('Rating Version ID @ CRL: '), ratingVersionID(input$Program, input$State, input$IndicationDate, input$EvaluationDate)))
                 
               },priority = 9)
  
  observeEvent({c(input$saveTechnicalReview,input$savePeerReview, input$saveSelectionsForReview)},
               {
                 print('change')
                 #Sys.sleep(15)
                 ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)
                 ReviewProgressDataFilter <<- ReviewProgressData%>%
                   filter(Status == 'Complete')
                 
                 
                 output$ReviewProgress <- renderTable(ReviewProgressData)
                 
               },priority = 9)
  


  
  observeEvent({input$Program},
               { 
                 updateVarSelectInput(session, input = 'State',
                                      data = state_options(input$Program), selected = 'SC')#colnames(state_options(input$Program))[1])
                 
                 date_update <- date_options(input$Program)
                 
                 updateSelectInput(session,inputId='IndicationDate',
                                   choices = date_update)
               },priority = 1000)
  
  observeEvent({input$IndicationDate},{
    eval_update <- eval_date_options(input$IndicationDate, input$Program)
    updateSelectInput(session,inputId='EvaluationDate',
                      choices = eval_update,selected = eval_update[[length(eval_update)]])
    evaluation_date_proxy <<- eval_update[[length(eval_update)]]
    indication_change <<- TRUE
  },priority = 100
  )
  observe({
    #hide by peril tabs if no selected 
    if ('Fire' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Fire')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitFire')
      showTab(inputId = 'LLL', target = 'Fire')
    } else {
      hideTab(inputId = 'Indication', target = 'Fire')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitFire')
      hideTab(inputId = 'LLL', target = 'Fire')
    }
    if ('Water' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Water')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitWater')
      showTab(inputId = 'LLL', target = 'Water')
    } else {
      hideTab(inputId = 'Indication', target = 'Water')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitWater')
      hideTab(inputId = 'LLL', target = 'Water')
    }
    if ('Theft' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Theft')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitTheft')
      showTab(inputId = 'LLL', target = 'Theft')
    } else {
      hideTab(inputId = 'Indication', target = 'Theft')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitTheft')
      hideTab(inputId = 'LLL', target = 'Theft')
    }
    if ('Liability' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Liability')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitLiab')
      showTab(inputId = 'LLL', target = 'Liability')
    } else {
      hideTab(inputId = 'Indication', target = 'Liability')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitLiab')
      hideTab(inputId = 'LLL', target = 'Liability')
    }
    if ('Other' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'OtherAOP')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitAOP')
      showTab(inputId = 'LLL', target = 'OtherAOP')
    } else {
      hideTab(inputId = 'Indication', target = 'OtherAOP')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitAOP')
      hideTab(inputId = 'LLL', target = 'OtherAOP')
    }
    # if ('Explosion' %in% input$includePerils) {
    #   showTab(inputId = 'Indication', target = 'Explosion')
    #   showTab(inputId = 'TerritorialAnalysis', target = 'Explosion')
    # } else {
    #   hideTab(inputId = 'Indication', target = 'Explosion')
    #   hideTab(inputId = 'TerritorialAnalysis', target = 'Explosion')
    # }
    if ('NCW' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'NCW')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitNCW')
      showTab(inputId = 'LLL', target = 'NCW')
    } else {
      hideTab(inputId = 'Indication', target = 'NCW')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitNCW')
      hideTab(inputId = 'LLL', target = 'NCW')
    }
    if ('STS' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'STS')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitSTS')
      showTab(inputId = 'LLL', target = 'STS')
    } else {
      hideTab(inputId = 'Indication', target = 'STS')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitSTS')
      hideTab(inputId = 'LLL', target = 'STS')
    }
    if ('Hurricane' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Hurricane')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitHU')
      showTab(inputId = 'LLL', target = 'Hurricane')
    } else {
      hideTab(inputId = 'Indication', target = 'Hurricane')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitHU')
      hideTab(inputId = 'LLL', target = 'Hurricane')
    }
    
  })
  observeEvent({input$IndicationDate
    input$EvaluationDate},
    {
      if (indication_change) {
        indication_change <<- FALSE
        evaluation_use <<- evaluation_date_proxy
      } else {
        evaluation_use <<- input$EvaluationDate
      }
      
    },priority = 99)
  
  
  
  observeEvent({c(input$Program, input$State, input$IndicationDate, input$EvaluationDate)},{
    
    searchIndication <<- input$searchIndication
    
  }, priority = 99)
  
  
  observeEvent({input$searchIndication},{
    searchIndication <<- 0
    searchIndicationInput <<- input$searchIndication
    
  }, priority = 99)
  
  observe({
    
    if (input$searchIndication > searchIndication) {
    
  observeEvent({input$State
    input$Program
    input$EvaluationDate
    input$IndicationDate
  },
  {if (input$searchIndication > searchIndication) {
    #load in data based on inputs tab selections
    LDF_selection <<-         LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils', input$Program,'')
    LDF_selection_weather <<-  LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Weather', input$Program,'')
    LDF_selection_attritional <<-  LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Attritional', input$Program,'')
    
    LDFstate_selection_All <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils', input$Program,'')
    
    print(LDFstate_selection_All)
    
    LDFcw_selection_All<<-LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils', input$Program,'CW')
    print(LDFcw_selection_All)
    
    LDFcw_selection_Weather <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Weather', input$Program,'CW')
    LDFstate_selection_Weather <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Weather', input$Program,'')
    
    LDFcw_selection_Attritional <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Attritional', input$Program,'CW')
    LDFstate_selection_Attritional <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Attritional', input$Program,'')
    
    cw_expense <<- expense_cw(input$Program, evaluation_use,input$IndicationDate)
    LossTrendDate <<- loss_trend_data(input$Program, input$IndicationDate, evaluation_use)
    LDFdata <<- LDF(input$Program, input$IndicationDate, evaluation_use,input$State)
    PremiumData <<- premium_trend_data(input$Program,input$IndicationDate, evaluation_use,input$State)
    LDFallAverages <<- LDF_display(LDFdata,'Averages','All Perils','CW',input$IndicationDate, evaluation_use,'LDF',input$Program)
    LDFallAveragesState <<- LDF_display(LDFdata,'Averages','All Perils',input$State,input$IndicationDate, evaluation_use,'LDFstate',input$Program)
    LDFallAveragesWeather <<- LDF_display(LDFdata,'Averages','Weather','CW',input$IndicationDate, evaluation_use,'LDFWeather',input$Program)
    LDFallAveragesStateWeather <<- LDF_display(LDFdata,'Averages','Weather',input$State,input$IndicationDate, evaluation_use,'LDFstateWeather',input$Program)
    LDFallAveragesAttritional <<- LDF_display(LDFdata,'Averages','Attritional','CW',input$IndicationDate, evaluation_use,'LDFAttritional',input$Program)
    LDFallAveragesStateAttritional <<- LDF_display(LDFdata,'Averages','Attritional',input$State,input$IndicationDate, evaluation_use,'LDFstateAttritional',input$Program)
    
    print('ldfs')
    
    
    #execute renderTable for tables that only depend on inputs tab
    output$LOB_header=output$LOB_header1=output$LOB_header2=output$LOB_header3=output$LOB_header4=output$LOB_header5=output$LOB_header6 <- renderUI({h4(strong(table_name(input$Program)))})
    output$state1 = output$state10<- renderUI(paste(state_name_full(input$State),'Weight',sep = ' '))
    output$state2 <- renderUI(paste(state_name_full(input$State),'Exclude Year',sep = ' '))
    output$state3=output$state4=output$state5=output$state6=output$state7=output$state8=output$state9=output$state15=output$state16=output$state17=output$state18=output$state20=output$state21=output$state22=output$state23=output$state30=output$stateReinsurance=output$stateLLL=output$stateLLLFire=output$stateLLLWater=output$stateLLLTheft=output$stateLLLLiability=output$stateLLLOtherAOP=output$stateLLLWeather <- renderUI(h4(strong(state_name_full(input$State))))
    output$lossTrendLOBheader = output$lossTrendLOBheaderCW <- renderUI(h4(strong(paste0(table_name(input$Program),' : All Forms Combined - Excluding Catastrophe'))))
    output$PremiumTrendLOBheader= output$TotalLOBheader= output$FireLOBheader= output$WaterLOBheader= output$TheftLOBheader= output$LiabilityLOBheader= output$OtherAOPLOBheader= output$NCWLOBheader= output$HULOBheader= output$STSLOBheader=output$ReinsuranceLOB <- renderUI(h4(strong(paste0(table_name(input$Program),' : All Forms Combined'))))
    state_profit <<- profit(input$State, input$IndicationDate,input$Program)
    output$TotalProfit=output$FireProfit=output$WaterProfit=output$TheftProfit=output$LiabilityProfit=output$OtherAOPProfit=output$NCWProfit=output$NCWProfit=output$STSProfit=output$HUProfit<- renderUI(h5(paste0('Priced to a ',(1-as.numeric(state_profit))*100,'% Combined Ration')))
    ####
    output$cw_expense <- renderTable(cw_expense,width = '100%')
    output$state_expense <-renderTable(expense_state(input$Program, evaluation_use,input$IndicationDate, input$State),width = '100%')
    updateCheckboxGroupInput(session, input = "cw_exclude",
                             choices = head(expense_cw(input$Program, evaluation_use,input$IndicationDate)$Year,-1),
                             selected = pull_variable(input$Program,input$IndicationDate,evaluation_use,'CW','All Perils','catExclude',NULL))

    updateCheckboxGroupInput(session, input = "state_exclude",
                             choices = head(expense_state(input$Program, evaluation_use,input$IndicationDate, input$State)$Year,-1),
                             selected = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catExclude',NULL))
    
    updateCurrencyInput(session, input='LLLstateweightTotal',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','LLLweight',0))
    updateCurrencyInput(session, input='CATstateweight',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadWeight',0))
    
    updateCurrencyInput(session, input='LDFstateweight',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','LDFweight',0))
    
    updateCurrencyInput(session, input='currentLossTrendCW',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,'CW','All Perils','curLossTrend',0))
    
    updateCurrencyInput(session, input='projLossTrendCW',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,'CW','All Perils','projLossTrend',0))
    
    updateCurrencyInput(session, input='currentLossTrendState',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','curLossTrend',0))
    
    updateCurrencyInput(session, input='projLossTrendState',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','projLossTrend',0))
    
    
    updateCurrencyInput(session, input='currentPremiumTrend',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','curPremTrend',0))
    
    updateCurrencyInput(session, input='projPremiumTrend',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','projPremTrend',0))
    
    updateSelectInput(session, input = 'selected_by',
                      selected = selections_id(input$IndicationDate, evaluation_use, input$State, input$Program))
    #input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
    updateNumericInput(session, input = 'HUexpFactor',
                       value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','HUexpFactor',1))
    updateNumericInput(session, input = 'STSexpFactor',
                       value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','STSexpFactor',1))
    updateNumericInput(session, input = 'HUyearExpAdj',
                       value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','HUyearsAdjFactor',0))
    updateNumericInput(session, input = 'STSyearExpAdj',
                       value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','STSyearsAdjFactor',0))
    
    updateDateInput(session, input = 'proposedEffective',
                    value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','proposedEffective',0))
    
    updateCheckboxGroupInput(session,input = 'includePerils', 
                             choices = if (input$Program=='HO') {
                               c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane')
                             } else if (input$Program=='DF') {
                               c('Fire', 'Water', 'Theft', 'Explosion', 'Other' ,'NCW', 'STS', 'Hurricane')
                             } else {
                               c('No By Peril States in Program')
                             },
                             selected = peril_list(input$Program, input$State, input$IndicationDate, evaluation_use))
    
    ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)

    if (ReviewProgressData[3,2]=='Complete') updateCheckboxGroupInput(session,input = 'PeerReviewChecklist',selected = peerChecklist_list)
    if (ReviewProgressData[2,2]=='Complete') updateCheckboxGroupInput(session,input = 'TechnicalreviewChecklist',selected = technicalChecklist_list)
    if (ReviewProgressData[1,2]=='Complete') updateCheckboxGroupInput(session,input = 'SelectorChecklist',selected = selectorChecklist_list)
      
      
      selected_expense_data_selected<<- pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadSelection',0)
      output$LDFallCWloss  <- renderDT(datatable(LDF_display(LDFdata,'Losses','All Perils','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:11,digits = 0))
      output$LDFallCWratio  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','All Perils','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)),list(width='5%',targets = c(1)))))%>%formatRound(2:11,digits = 3))
      output$LDFallCWaverages <<- renderDataTable(datatable(LDFallAverages, escape = FALSE,editable = list(target = 'cell'),selection = 'none',class = 'compact',
                                                          options = list(dom = 't', 
                                                                         initComplete = JS(js),
                                                                         preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                         drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                         autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAverages)-1))
    )
    
    output$LDFallCWlossWeather  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Weather','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:11,digits = 0))
    output$LDFallCWratioWeather  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Weather','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:11,digits = 3))
    output$LDFallCWaveragesWeather <<- renderDataTable(datatable(LDFallAveragesWeather,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                                 options = list(dom = 't', 
                                                                                initComplete = JS(js),
                                                                                preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                                drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                                autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAveragesWeather)-1))
    )
    
    output$LDFallCWlossAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Attritional','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:11,digits = 0))
    output$LDFallCWratioAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Attritional','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:11,digits = 3))
    output$LDFallCWaveragesAttritional <<- renderDataTable(datatable(LDFallAveragesAttritional,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                                     options = list(dom = 't', 
                                                                                    initComplete = JS(js),
                                                                                    preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                                    drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                                    autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAveragesAttritional)-1))
    )
    
    #initialize the state tables
    spacing <<- paste0(as.character(100/length(LDFallAveragesState)),'%')
    output$LDFallstateloss  <-             renderDT(datatable(LDF_display(LDFdata,'Losses','All Perils',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
    output$LDFallstatelossWeather  <-         renderDT(datatable(LDF_display(LDFdata,'Losses','Weather',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
    output$LDFallstatelossAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Attritional',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
    
    output$LDFallstateratio  <-             renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','All Perils',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))
    output$LDFallstateratioWeather  <-         renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Weather',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))
    output$LDFallstateratioAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Attritional',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))
    
    output$LDFallstateaverages <<- renderDataTable(datatable(LDFallAveragesState,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                             options = list(dom = 't', 
                                                                            initComplete = JS(js),
                                                                            preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                            drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                            autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
    ) 
    
    output$LDFallstateaveragesWeather <<- renderDataTable(datatable(LDFallAveragesStateWeather,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                                    options = list(dom = 't', 
                                                                                   initComplete = JS(js),
                                                                                   preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                                   drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                                   autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
    )
    output$LDFallstateaveragesAttritional <<- renderDataTable(datatable(LDFallAveragesStateAttritional,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                                        options = list(dom = 't', 
                                                                                       initComplete = JS(js),
                                                                                       preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                                       drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                                       autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
    )
    lossTrendCWData <<-loss_trend_cw(LossTrendDate)
    lossTrendstateData <<- loss_trend_state(LossTrendDate,input$State)
    
    updateCheckboxGroupInput(session, input = "LossTrendExclude",
                             choices = head(lossTrendstateData$`Year Ending Quarter - X`, nrow(lossTrendstateData) ),
                             selected = NULL)
    
    
    output$lossTrendCW <- renderDT(datatable(lossTrendCWData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                     formatRound(c(2,3,4,6),digits=0)%>%
                                     formatRound(c(5,7),digits = 2))#,spacing='xs')
    output$lossTrendstate <- renderDT(datatable(lossTrendstateData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                        formatRound(c(2,3,4,6),digits=0)%>%
                                        formatRound(c(5,7),digits = 2))
   
    output$lossTrendCWfitting <- renderDT(datatable(loss_trend_fitting(lossTrendCWData,as.numeric(0)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                            formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
    output$lossTrendstatefitting <- renderDT(datatable(loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                               formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
    
    
    PremiumData_state <<- premium_trend(PremiumData)
    output$premiumTrend <- renderDT(datatable(PremiumData_state%>%select(-Date),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatRound(c(2,3,4), digits = 0)%>%formatRound(c(5),digits = 2))
    output$PremiumTrendfitting <- renderDT(datatable(premium_trend_fitting(PremiumData_state,0),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatPercentage(c(2), digits = 1))
    
    expense_ratios <<- expense_load(input$IndicationDate, evaluation_use,input$State, input$Program)
 
    output$expenseExhibit <- renderDT(datatable(expense_ratios,selection = 'none',class = 'compact',
                                                options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                        formatCurrency(c(3,5,7), digits =0)%>%
                                        formatPercentage(c(4,6,8,9,10), digits=1)
    )
    print('end prioity 3') 
    
  }
  },priority = 3) 
  
  observeEvent({c(input$State, input$Program, input$IndicationDate, input$EvaluationDate, input$LossTrendPoints, input$LossTrendExclude)},{
    print(input$LossTrendSlider)
    updateSliderInput(session, inputId = 'LossTrendSlider',
                      max = nrow(lossTrendstateData) - length(input$LossTrendExclude),
                      step = 1)
  }, priority = 3)
      
  observeEvent({c(input$State, input$Program, input$IndicationDate, input$EvaluationDate, input$LossTrendSlider, input$LossTrendExclude)}, #add the year selections select all column that modeled cat load has!
               {
                 if (input$searchIndication > searchIndication) {
                   if (length(input$LossTrendExclude)<nrow(lossTrendstateData) & nrow(lossTrendstateData) >2 ) {
                   points <- input$LossTrendSlider
                   
                   print(input$LossTrendExclude)
                   print(length(input$LossTrendExclude))
                   print(points)
                   print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                   
                   lossTrendstateDataFilter <<- lossTrendstateData%>%
                     mutate(Frequency = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude, NA,Frequency),
                            Severity = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude, NA,Severity),
                            `Pure Premium` = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude,NA, `Pure Premium`))
                   
                   
                   purePremiumPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Pure Premium') #fix the line when the eliminated data point is below the threshold
                   frequencyPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Frequency')
                   severityPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Severity')

                   print('Loss trend plots')

                   output$StateFrequencyPlot <- renderPlot({ggplot(data.frame(frequencyPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Frequency')+
                       xlab('')+
                       ggtitle(paste0('Frequency Exponential Trend: ' , round((exp(frequencyPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(frequencyPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   output$StateSeverityPlot <- renderPlot({ggplot(data.frame(severityPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Severity')+
                       xlab('')+
                       ggtitle(paste0('Severity Exponential Trend: ' , round((exp(severityPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(severityPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   output$StateLossPlot <- renderPlot({ggplot(data.frame(purePremiumPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Pure Premium')+
                       xlab('')+
                       ggtitle(paste0('Pure Premium Exponential Trend: ' , round((exp(purePremiumPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(purePremiumPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   print('end Loss Trend Plots')
                 }}
               },
               priority = 3)
  
  observeEvent(input$LDFallCWaverages_cell_edit,
               
               if (input$searchIndication > searchIndication) {
                 {print('LDF1')
                 LDFallAverages <<- editData(LDFallAverages,input$LDFallCWaverages_cell_edit,'LDFallCWaverages',rownames = FALSE) }
                 },priority = 2) 
  observeEvent(input$LDFallCWaveragesWeather_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   print('ldf1.5')
                   LDFallAveragesWeather <<- editData(LDFallAveragesWeather,input$LDFallCWaverages_cell_edit,'LDFallCWaveragesWeather',rownames = FALSE) }},priority = 2)
  observeEvent(input$LDFallCWaveragesAttritional_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   print('LDF2')
                   LDFallAveragesAttritional <<- editData(LDFallAveragesAttritional,input$LDFallCWaveragesAttritional_cell_edit,'LDFallCWaveragesAttritional',rownames = FALSE) }},priority = 2)
  observeEvent(input$LDFallstateaverages_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   print('LDF3')
                   LDFallAveragesState <<- editData(LDFallAveragesState,input$LDFallstateaverages_cell_edit,'LDFallstateaverages',rownames = FALSE)} },priority = 2) 
  observeEvent(input$LDFallstateaveragesWeather_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   print('LDF4')
                   LDFallAveragesStateWeather <<- editData(LDFallAveragesStateWeather,input$LDFallstateaveragesWeather_cell_edit,'LDFallstateaveragesWeather',rownames = FALSE)} },priority = 2) 
  observeEvent(input$LDFallstateaveragesAttritional_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   print('LDF5')
                   LDFallAveragesStateAttritional <<- editData(LDFallAveragesStateAttritional,input$LDFallstateaveragesAttritional_cell_edit,'LDFallstateaveragesAttritional',rownames = FALSE)} },priority = 2)
  
  observeEvent({c(input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFHselect,input$State)},
               { 
                 if (input$searchIndication > searchIndication) {
                   print('LDF6')
                 LDFcw_choose_All<<- c(input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect)
                 if (!is.null(LDFcw_choose_All)) {
                   LDFcw_selection_All <<- LDF_Cumulative(LDFallAverages,LDFcw_choose_All)
                   output$LDFallCWcumulative <- renderDataTable(datatable(LDFcw_selection_All,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
                 }}},priority = 2)
  observeEvent({c(input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,input$State)},
               {
                 if (input$searchIndication > searchIndication) { 
                   print('LDF7')
                   LDFcw_choose_Weather<- c(input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect)
               if (!is.null(LDFcw_choose_Weather)) {
                 LDFcw_selection_Weather <<- LDF_Cumulative(LDFallAveragesWeather,LDFcw_choose_Weather)
                 output$LDFallCWcumulativeWeather <- renderDataTable(datatable(LDFcw_selection_Weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
               }}},priority = 2)
  observeEvent({c(input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,input$State)},
               { 
                 if (input$searchIndication > searchIndication) {
                   print('LDF8')
                   LDFcw_choose_Attritional<- c(input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect)
                    print(LDFcw_choose_Attritional)
                 if (!is.null(LDFcw_choose_Attritional)) {
                 print('null enter')
                 LDFcw_selection_Attritional <<- LDF_Cumulative(LDFallAveragesAttritional,LDFcw_choose_Attritional)
                 print(LDFcw_selection_Attritional)
                 output$LDFallCWcumulativeAttritional <- renderDataTable(datatable(LDFcw_selection_Attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
                 print('LDF8.1')
                 } 
                    
                    }},priority = 2)
  
  
  #state LDF selections tables
  observeEvent({c(input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect)},
               {
                 if (input$searchIndication > searchIndication) {
                   print('LDF9')
                   LDFstate_choose_All<- c(input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect)
               LDFstate_selection_All <<- LDF_Cumulative(LDFallAveragesState,LDFstate_choose_All)
               output$LDFallstatecumulative <- renderDataTable(datatable(LDFstate_selection_All,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
               }},priority = 2)
  observeEvent({c(input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect)},
               { 
                 if (input$searchIndication > searchIndication) {
                   print('LDF10')
                   LDFstate_choose_Weather<- c(input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect)
               LDFstate_selection_Weather <<- LDF_Cumulative(LDFallAveragesStateWeather,LDFstate_choose_Weather)
               output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDFstate_selection_Weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
               }},priority = 2)
  observeEvent({c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect)},
               { 
                 if (input$searchIndication > searchIndication) {
                   print('LDF11')
                   LDFstate_choose_Attritional<- c(input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect)
               LDFstate_selection_Attritional <<- LDF_Cumulative(LDFallAveragesStateAttritional,LDFstate_choose_Attritional)
               output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDFstate_selection_Attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
               }},priority = 2)
  
  #LDF selections , bulky work around, not the best haha
  observe(
    { 
      if (input$searchIndication > searchIndication) { 
        print('************************************')
      dummy <<- c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect,
                  input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect,
                  input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect,
                  input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,
                  input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,
                  input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect)
      if (input$LDFstateweight == 0) {
        
        LDF_selection <<- LDFcw_selection_All
        LDF_selection_weather <<- LDFcw_selection_Weather
        LDF_selection_attritional <<- LDFcw_selection_Attritional
        LDF_selection_display <<- LDF_selection[1:length(LDFstate_selection_All)]
        LDF_selection_display[length(LDF_selection_display)] <- NA
        LDF_selection_display_weather <<- LDF_selection_weather[1:length(LDFstate_selection_Weather)]
        LDF_selection_display_weather[length(LDF_selection_display_weather)] <- NA
        LDF_selection_display_attritional <<- LDF_selection_attritional[1:length(LDFstate_selection_Attritional)]
        LDF_selection_display_attritional[length(LDF_selection_display_attritional)] <- NA
        
        
        colnames(LDF_selection_display) <- colnames(LDFstate_selection_All)
        colnames(LDF_selection_display_weather) <- colnames(LDFstate_selection_Weather)
        colnames(LDF_selection_display_attritional) <- colnames(LDFstate_selection_Attritional)
        
        output$LDFallstatecumulative <- renderDataTable(datatable(LDF_selection_display,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
        output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDF_selection_display_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
        output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDF_selection_display_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
        
      } else if (input$LDFstateweight <1) {
        
        LDFstate_selection_All_proxy <<- LDFstate_selection_All
        LDFstate_selection_All_proxy <<- if (ncol(LDFstate_selection_All_proxy)<ncol(LDFcw_selection_All)) {
          LDFstate_selection_All_proxy[(ncol(LDFstate_selection_All_proxy)):ncol(LDFcw_selection_All)]<<-1
          LDFstate_selection_All_proxy
        } else {
          LDFstate_selection_All_proxy}
        
        LDFstate_selection_Weather_proxy <<- LDFstate_selection_Weather
        LDFstate_selection_Weather_proxy <<- if (ncol(LDFstate_selection_Weather_proxy)<ncol(LDFcw_selection_Weather)) {
          LDFstate_selection_Weather_proxy[(ncol(LDFstate_selection_Weather_proxy)):ncol(LDFcw_selection_Weather)]<<-1
          LDFstate_selection_Weather_proxy
        } else {
          LDFstate_selection_Weather_proxy}
        
        LDFstate_selection_Attritional_proxy <<- LDFstate_selection_Attritional
        LDFstate_selection_Attritional_proxy <<- if (ncol(LDFstate_selection_Attritional_proxy)<ncol(LDFcw_selection_Attritional)) {
          LDFstate_selection_Attritional_proxy[(ncol(LDFstate_selection_Attritional_proxy)):ncol(LDFcw_selection_Attritional)]<<-1
          LDFstate_selection_Attritional_proxy
        } else {
          LDFstate_selection_Attritional_proxy}
        
        LDF_selection <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_All[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_All_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_All))]
        LDF_selection_weather <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_Weather[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_Weather_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_Weather))]
        
        LDF_selection_attritional <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_Attritional[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_Attritional_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_Attritional))]
        
        LDFstate_selection_All_copy <<- LDFstate_selection_All[1,][1:(ncol(LDFstate_selection_All))]
        
        LDFstate_selection_All_copy[1] <- paste(input$State,'Selection', sep = ' ')
        
        LDFcw_selection_All_weighted <- LDFcw_selection_All[1,][1:(ncol(LDFstate_selection_All_copy))]
        LDFcw_selection_All_weighted[1] <- 'CW Selection'
        LDFcw_selection_All_weighted[ncol(LDFcw_selection_All_weighted)]<-NA
        weighted_plot_all <- LDFstate_selection_All_copy
        weighted_plot_all['first',] <- NA
        weighted_plot_all['first2',] <- NA
        weighted_plot_all['cw',] <- LDFcw_selection_All_weighted
        weighted_plot_all['second',] <- NA
        weighted_plot_all['second2',] <- NA
        weighted_plot_all['weighted_select',] <- LDF_selection[1,]
        weighted_plot_all['weighted_cum',] <- LDF_selection[2,]
        weighted_plot_all[ncol(weighted_plot_all)]<- NA
        weighted_plot_all<<-weighted_plot_all
        
        LDFstate_selection_Weather_copy <- LDFstate_selection_Weather[1,][1:(ncol(LDFstate_selection_Weather))]
        LDFstate_selection_Weather_copy[1] <- paste(input$State,'Selection', sep = ' ')
        LDFcw_selection_Weather_weighted <- LDFcw_selection_Weather[1,][1:(ncol(LDFstate_selection_Weather_copy))]
        LDFcw_selection_Weather_weighted[ncol(LDFcw_selection_Weather_weighted)]<-NA
        LDFcw_selection_Weather_weighted[1] <- 'CW Selection'
        weighted_plot_weather <- LDFstate_selection_Weather_copy
        weighted_plot_weather['first',] <- NA
        weighted_plot_weather['first2',] <- NA
        weighted_plot_weather['cw',] <- LDFcw_selection_Weather_weighted
        weighted_plot_weather['second',] <- NA
        weighted_plot_weather['second2',] <- NA
        weighted_plot_weather['weighted_select',] <- LDF_selection_weather[1,]
        weighted_plot_weather['weighted_cum',] <- LDF_selection_weather[2,]
        weighted_plot_weather[ncol(weighted_plot_weather)] <- NA
        weighted_plot_weather<<-weighted_plot_weather
        
        LDFstate_selection_Attritional_copy <- LDFstate_selection_Attritional[1,][1:(ncol(LDFstate_selection_Attritional))]
        LDFstate_selection_Attritional_copy[1] <- paste(input$State,'Selection', sep = ' ')
        LDFcw_selection_Attritional_weighted <- LDFcw_selection_Attritional[1,][1:(ncol(LDFstate_selection_Attritional_copy))]
        LDFcw_selection_Attritional_weighted[ncol(LDFcw_selection_Attritional_weighted)]<-NA
        LDFcw_selection_Attritional_weighted[1] <- 'CW Selection'
        weighted_plot_attritional <- LDFstate_selection_Attritional_copy
        weighted_plot_attritional['first',] <- NA
        weighted_plot_attritional['first',] <- NA
        weighted_plot_attritional['cw',] <- LDFcw_selection_Attritional_weighted
        weighted_plot_attritional['second',] <- NA
        weighted_plot_attritional['second',] <- NA
        weighted_plot_attritional['weighted_select',] <- LDF_selection_attritional[1,]
        weighted_plot_attritional['weighted_cum',] <- LDF_selection_attritional[2,]
        weighted_plot_attritional[ncol(weighted_plot_attritional)] <- NA
        weighted_plot_attritional<<- weighted_plot_attritional
        
        output$LDFallstatecumulative <- renderDataTable(datatable(weighted_plot_all,selection = 'none',class = 'compact',options = list(dom = 't'), rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All_copy)),digits = 3))
        output$LDFallstatecumulativeWeather <- renderDataTable(datatable(weighted_plot_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
        output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(weighted_plot_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
        
      } else {
        LDF_selection <<- LDFstate_selection_All
        LDF_selection_weather <<- LDFstate_selection_Weather
        LDF_selection_attritional <<- LDFstate_selection_Attritional
        
        output$LDFallstatecumulative <- renderDataTable(datatable(LDF_selection,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
        output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDF_selection_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
        output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDF_selection_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
        
      }}
    },priority = 1)
  
  
  observeEvent( {c(input$Program, input$EvaluationDate,input$IndicationDate, input$State, input$CATstateweight,input$cw_exclude,input$state_exclude,input$expense_load_output_selected_cell_edit,input$useCalcExpense)},
                { 
                  if (input$searchIndication > searchIndication) {
                    print('modeledCat - expenses')
                  selected_expense_data <<- expense_select(input$Program, evaluation_use,input$IndicationDate, input$State, input$CATstateweight,input$cw_exclude,input$state_exclude)
                  if (as.numeric(selected_expense_data_selected)==as.numeric(selected_expense_data) | input$useCalcExpense | as.numeric(selected_expense_data_selected)==0) {
                    selected_expense_data_selected <<- selected_expense_data
                    row.names(selected_expense_data_selected) <<- c('Selected Expense Load')
                  }
                  print('mod1')
                  output$expense_load_output <- renderDT(datatable(selected_expense_data,selection = 'none',class = 'compact',colnames='',rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  
                  print('mod2')
                  modeled_cat <<- modeled_cat_load(input$Program, evaluation_use,input$IndicationDate, input$State,'N',as.numeric(selected_expense_data_selected))
                  
                  if (!('Hurricane' %in% input$includePerils)) {
                    
                  }
                  
                  output$ModeledCatLoad <- renderDT(datatable(modeled_cat,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%formatRound(c(1,2,3,5,6),digits = 0)%>%formatPercentage(c(4,7,8,10,11,12),digits = 1)%>%formatRound(c(9),digits = 2))
                  
                  print('mod3')
                  reinsurance_exhibit_table <<- reinsurance_exhibit(state_name_full(input$State), 
                                                                    table_name(input$Program), 
                                                                    reinsurance(input$State,evaluation_use,input$Program,'Hurricane'), 
                                                                    reinsurance(input$State,evaluation_use,input$Program,'STS'),
                                                                    reinsurance(input$State,evaluation_use,input$Program,'All Perils'),
                                                                    modeled_cat)
                  
                  output$reinsuranceExhibit <- renderDT(datatable(reinsurance_exhibit_table,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%
                                                          formatPercentage(5,digits = 1 ))
                  
                  print('mod4')
                }},priority = 2
  )
  observeEvent( {c(input$expense_load_output_selected_cell_edit)},
                { 
                  if (input$searchIndication > searchIndication) {
                    print('expense load')
                  selected_expense_data_selected <<- editData(selected_expense_data_selected,input$expense_load_output_selected_cell_edit,'expense_load_output_selected',rownames = T)
                  
                  output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  
                }},priority = 2
  )
  observeEvent( {
    c(input$Program,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendCW, input$projLossTrendCW,input$capped)
  },
  {
    if (input$searchIndication > searchIndication) { #load in all the LLL data tables for each tab
      print('LLL')
    LLLdata_CW <<- LLL_data(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped)
    LLLdata_CW_total <<- LLL_select_data(LLLdata_CW,'All Perils')
    LLLdata_CW_fire <<- LLL_select_data(LLLdata_CW,'FIRE')
    LLLdata_CW_water <<- LLL_select_data(LLLdata_CW,'WATER')
    LLLdata_CW_theft <<- LLL_select_data(LLLdata_CW,'THEFTVMM')
    LLLdata_CW_liability <<- LLL_select_data(LLLdata_CW,'LIABILITY')
    LLLdata_CW_otherAOP <<- LLL_select_data(LLLdata_CW,'OTHERAOP')
    LLLdata_CW_weather <<- LLL_select_data(LLLdata_CW,'NCW')
    LLLdata_CW_total_selected <<- LLL_selections(LLLdata_CW_total,'Selected')
    LLLdata_CW_fire_selected <<- LLL_selections(LLLdata_CW_fire,'Selected')
    LLLdata_CW_water_selected <<- LLL_selections(LLLdata_CW_water,'Selected')
    LLLdata_CW_theft_selected <<- LLL_selections(LLLdata_CW_theft,'Selected')
    LLLdata_CW_liability_selected <<- LLL_selections(LLLdata_CW_liability,'Selected')
    LLLdata_CW_otherAOP_selected <<- LLL_selections(LLLdata_CW_otherAOP,'Selected')
    LLLdata_CW_weather_selected <<- LLL_selections(LLLdata_CW_weather,'Selected')
    
    output$LLLTotalTableCW <- renderDT(datatable(LLLdata_CW_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWTotal<- renderDT(datatable(LLL_selections(LLLdata_CW_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWTotalSelected<- renderDT(datatable(LLLdata_CW_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWFire <- renderDT(datatable(LLLdata_CW_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWFire<- renderDT(datatable(LLL_selections(LLLdata_CW_fire,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWFireSelected<- renderDT(datatable(LLLdata_CW_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWWater <- renderDT(datatable(LLLdata_CW_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWWater<- renderDT(datatable(LLL_selections(LLLdata_CW_water,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWWaterSelected<- renderDT(datatable(LLLdata_CW_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWTheft <- renderDT(datatable(LLLdata_CW_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWTheft<- renderDT(datatable(LLL_selections(LLLdata_CW_theft,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWTheftSelect<- renderDT(datatable(LLLdata_CW_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWLiability <- renderDT(datatable(LLLdata_CW_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWLiability<- renderDT(datatable(LLL_selections(LLLdata_CW_liability,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWLiabilitySelected<- renderDT(datatable(LLLdata_CW_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWOtherAOP <- renderDT(datatable(LLLdata_CW_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_CW_otherAOP,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWOtherAOPSelected<- renderDT(datatable(LLLdata_CW_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWWeather <- renderDT(datatable(LLLdata_CW_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWWeather<- renderDT(datatable(LLL_selections(LLLdata_CW_weather,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWWeatherSelected<- renderDT(datatable(LLLdata_CW_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
  }},priority = 2
  )
  
  observeEvent(input$LLLselectCWTotalSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_total_selected <<- editData(LLLdata_CW_total_selected,input$LLLselectCWTotalSelected_cell_edit,'LLLselectCWTotalSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWFireSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_fire_selected <<- editData(LLLdata_CW_fire_selected,input$LLLselectCWFireSelected_cell_edit,'LLLselectCWFireSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWWaterSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_water_selected <<- editData(LLLdata_CW_water_selected,input$LLLselectCWWaterSelected_cell_edit,'LLLselectCWWaterSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWTheftSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_theft_selected <<- editData(LLLdata_CW_theft_selected,input$LLLselectCWTheftSelected_cell_edit,'LLLselectCWTheftSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWLiabilitySelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_liability_selected <<- editData(LLLdata_CW_liability_selected,input$LLLselectCWLiabilitySelected_cell_edit,'LLLselectCWLiabilitySelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWOtherAOPSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_otherAOP_selected <<- editData(LLLdata_CW_otherAOP_selected,input$LLLselectCWOtherAOPSelected_cell_edit,'LLLselectCWOtherAOPSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWWeatherSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_weather_selected <<- editData(LLLdata_CW_weather_selected,input$LLLselectCWWeatherSelected_cell_edit,'LLLselectCWWeatherSelect',rownames = TRUE) }},priority = 2) 
  
  observeEvent( {
    c(input$State,input$Program,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState,input$capped)
  },
  { 
    if (input$searchIndication > searchIndication) {
      LLLdata_state <<- LLL_data(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped)
    LLLdata_state_total <<-LLL_select_data(LLLdata_state,'All Perils')
    LLLdata_state_fire <<-LLL_select_data(LLLdata_state,'FIRE')
    LLLdata_state_water <<-LLL_select_data(LLLdata_state,'WATER')
    LLLdata_state_theft <<-LLL_select_data(LLLdata_state,'THEFTVMM')
    LLLdata_state_liability <<-LLL_select_data(LLLdata_state,'LIABILITY')
    LLLdata_state_otherAOP <<-LLL_select_data(LLLdata_state,'OTHERAOP')
    LLLdata_state_weather <<-LLL_select_data(LLLdata_state,'NCW')
    LLLdata_state_total_selected<<-LLL_selections(LLLdata_state_total,'Selected')
    LLLdata_state_fire_selected<<-LLL_selections(LLLdata_state_fire,'Selected')
    LLLdata_state_water_selected<<-LLL_selections(LLLdata_state_water,'Selected')
    LLLdata_state_theft_selected<<-LLL_selections(LLLdata_state_theft,'Selected')
    LLLdata_state_liability_selected<<-LLL_selections(LLLdata_state_liability,'Selected')
    LLLdata_state_otherAOP_selected<<-LLL_selections(LLLdata_state_otherAOP,'Selected')
    LLLdata_state_weather_selected<<-LLL_selections(LLLdata_state_weather,'Selected')
    
    output$LLLTotalTablestate <- renderDT(datatable(LLLdata_state_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTotal<- renderDT(datatable(LLL_selections(LLLdata_state_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTotalSelected<- renderDT(datatable(LLLdata_state_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateFire <- renderDT(datatable(LLLdata_state_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateFire<- renderDT(datatable(LLL_selections(LLLdata_state_fire,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateFireSelected<- renderDT(datatable(LLLdata_state_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWater<- renderDT(datatable(LLLdata_state_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWater<- renderDT(datatable(LLL_selections(LLLdata_state_water,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWaterSelected<- renderDT(datatable(LLLdata_state_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateTheft <- renderDT(datatable(LLLdata_state_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTheft<- renderDT(datatable(LLL_selections(LLLdata_state_theft,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTheftSelected<- renderDT(datatable(LLLdata_state_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateLiability <- renderDT(datatable(LLLdata_state_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateLiability<- renderDT(datatable(LLL_selections(LLLdata_state_liability,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateLiabilitySelected<- renderDT(datatable(LLLdata_state_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateOtherAOP <- renderDT(datatable(LLLdata_state_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_state_otherAOP,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateOtherAOPSelected<- renderDT(datatable(LLLdata_state_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWeather <- renderDT(datatable(LLLdata_state_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWeather<- renderDT(datatable(LLL_selections(LLLdata_state_weather,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWeatherSelected<- renderDT(datatable(LLLdata_state_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
  }},
  priority = 2
  )
  
  observeEvent(input$LLLselectStateTotalSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_total_selected <<- editData(LLLdata_state_total_selected,input$LLLselectStateTotalSelected_cell_edit,'LLLselectStateTotalSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateFireSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_fire_selected <<- editData(LLLdata_state_fire_selected,input$LLLselectStateFireSelected_cell_edit,'LLLselectStateFireSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateWaterSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_water_selected <<- editData(LLLdata_state_water_selected,input$LLLselectStateWaterSelected_cell_edit,'LLLselectStateWaterSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateTheftSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_theft_selected <<- editData(LLLdata_state_theft_selected,input$LLLselectStateTheftSelected_cell_edit,'LLLselectStateTheftSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateLiabilitySelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_liability_selected <<- editData(LLLdata_state_liability_selected,input$LLLselectStateLiabilitySelected_cell_edit,'LLLselectStateLiabilitySelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateOtherAOPSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_otherAOP_selected <<- editData(LLLdata_state_otherAOP_selected,input$LLLselectStateOtherAOPSelected_cell_edit,'LLLselectStateOtherAOPSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateWeatherSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_weather_selected <<- editData(LLLdata_state_weather_selected,input$LLLselectStateWeatherSelected_cell_edit,'LLLselectStateWeatherSelect',rownames = TRUE) }},priority = 2) 
  
  
  observeEvent({c(input$State,input$Program,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState,input$capped,input$LLLstateweightTotal,
                  input$LLLselectCWTotalSelected_cell_edit,
                  input$LLLselectCWFireSelected_cell_edit,
                  input$LLLselectCWWaterSelected_cell_edit,
                  input$LLLselectCWTheftSelected_cell_edit,
                  input$LLLselectCWLiabilitySelected_cell_edit,
                  input$LLLselectCWOtherAOPSelected_cell_edit,
                  input$LLLselectCWWeatherSelected_cell_edit,
                  input$LLLselectStateTotalSelected_cell_edit,
                  input$LLLselectStateFireSelected_cell_edit,
                  input$LLLselectStateWaterSelected_cell_edit,
                  input$LLLselectStateTheftSelected_cell_edit,
                  input$LLLselectStateLiabilitySelected_cell_edit,
                  input$LLLselectStateOtherAOPSelected_cell_edit,
                  input$LLLselectStateWeatherSelected_cell_edit
  )},
  {
    if (input$searchIndication > searchIndication) {
    LLLTotal     <<-reactive({LLL_weighted(LLLdata_CW_total_selected    ,LLLdata_state_total_selected    ,input$LLLstateweightTotal)})
    LLLFire      <<-reactive({LLL_weighted(LLLdata_CW_fire_selected     ,LLLdata_state_fire_selected     ,input$LLLstateweightTotal)})
    LLLWater     <<-reactive({LLL_weighted(LLLdata_CW_water_selected    ,LLLdata_state_water_selected    ,input$LLLstateweightTotal)})
    LLLTheft     <<-reactive({LLL_weighted(LLLdata_CW_theft_selected    ,LLLdata_state_theft_selected    ,input$LLLstateweightTotal)})
    LLLLiability <<-reactive({LLL_weighted(LLLdata_CW_liability_selected,LLLdata_state_liability_selected,input$LLLstateweightTotal)})
    LLLOtherAOP  <<-reactive({LLL_weighted(LLLdata_CW_otherAOP_selected ,LLLdata_state_otherAOP_selected ,input$LLLstateweightTotal)})
    LLLWeather   <<-reactive({LLL_weighted(LLLdata_CW_weather_selected  ,LLLdata_state_weather_selected  ,input$LLLstateweightTotal)})
    
    output$LLLweightedTotal <- renderDT(datatable(LLLTotal(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedFire <- renderDT(datatable(LLLFire(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedWater <- renderDT(datatable(LLLWater(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedTheft <- renderDT(datatable(LLLTheft(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedLiability <- renderDT(datatable(LLLLiability(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedOtherAOP <- renderDT(datatable(LLLOtherAOP(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedWeather <- renderDT(datatable(LLLWeather(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
  }},priority = 1
  )
  
  #save selections to SQL
  observeEvent(input$ldfselectionToSQL,
               {
                 if (input$searchIndication > searchIndication) {
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Progress',LDFcw_selection_All,NA,input$selected_by[[1]],0,0)}},priority = 1)
  observeEvent(input$ldfselectionToSQLWeather,
               {
                 if (input$searchIndication > searchIndication) {save_selections(input$Program,input$IndicationDate,evaluation_use, input$State, 'CW','Weather','In Progress',LDFcw_selection_Weather,NA,input$selected_by[[1]],0,0)}},priority = 1)
  observeEvent(input$ldfselectionToSQLAttritional, 
               {
                 if (input$searchIndication > searchIndication) {save_selections(input$Program,input$IndicationDate,evaluation_use, input$State, 'CW','Attritional','In Progress',LDFcw_selection_Attritional,NA,input$selected_by[[1]],0,0)}},priority = 1)
  observeEvent(input$ldfselectionToSQLstate, 
               {
                 if (input$searchIndication > searchIndication) {save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Progress',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],0,0)}},priority = 1)
  observeEvent(input$ldfselectionToSQLstateWeather, 
               {
                 if (input$searchIndication > searchIndication) {save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Progress',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],0,0)}},priority = 1)
  observeEvent(input$ldfselectionToSQLstateAttritional, 
               {
                 if (input$searchIndication > searchIndication) {save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Progress',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],0,0)}},priority = 1)

  observeEvent({input$saveInputs},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  
  observeEvent({input$catLoadtoSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$stateLossTrendtoSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$LLLselectionsToSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$ldfselectionToSQLstate},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$PremiumSave},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$nonmodeledsave},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$includePerils,input$proposedEffective,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$cwLossTrendtoSQL},#input$catLoadtoSQL)},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_cw(input$Program,input$IndicationDate,evaluation_use, 'CW' ,'All Perils','In Progress',input$currentLossTrendCW,input$projLossTrendCW,input$cw_exclude,input$selected_by[[1]],0,0) 
               }})
  observe({
    if (input$searchIndication > searchIndication) {
    #pull the most recent LDF selections on upload, so you don't always have to click into the LDF page first!
    dummy <<- c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect,
                input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect,
                input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect,
                input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,
                input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,
                input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect,
                input$LDFstateweight,input$useCalcExpense,input$catLoadtoSQL,input$CATstateweight,input$cw_exclude,input$state_exclude
    )
    on_level_load <<- on_level_factors_load(input$Program,input$IndicationDate, input$State)
    coverage_report_data <<- coverage_report_load(input$IndicationDate,evaluation_use, input$State,input$Program)
    losses_claims <<- rate_level_losses(input$Program, input$IndicationDate, evaluation_use, input$State)
    #data from the rate level indication, 
    total_data <<- rate_level_indication(input$Program,
                                         on_level_load,
                                         coverage_report_data,
                                         targit_EP_load(input$Program,input$IndicationDate,evaluation_use, input$State),
                                         'N',
                                         "All Perils",
                                         input$currentPremiumTrend,
                                         input$projPremiumTrend,
                                         input$proposedEffective,
                                         input$IndicationDate,
                                         evaluation_use,
                                         input$State,
                                         LDF_selection,
                                         input$currentLossTrendState,
                                         input$projLossTrendState,
                                         as.numeric(LLLTotal()['Selected','Weighted LLL'])#place holder for LL loads. Need to build out the selection still
    )
    
    #separate function for the perils rate level tabs because they look different. 
    fireLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLFire()['Selected','Weighted LLL']),
                                               coverage_report_data,'Fire')
    
    firePremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                     coverage_report_data, 'Fire',input$currentPremiumTrend,
                                                     input$projPremiumTrend,
                                                     input$proposedEffective,
                                                     input$IndicationDate,
                                                     evaluation_use,
                                                     input$State,
                                                     'Y')
    
    output$FireIndicationLosses <- renderDT(datatable(fireLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    output$FireIndicationPremium <- renderDT(datatable(firePremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4), digits = 3))
    
    fireSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,fireLosses, firePremium,expense_ratios)
    output$FireIndicationSummary<- renderDT(datatable(fireSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    waterLosses <<- rate_level_indication_peril(on_level_load, 
                                                input$proposedEffective,
                                                input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                                input$currentLossTrendState,
                                                input$projLossTrendState, as.numeric(LLLWater()['Selected','Weighted LLL']),
                                                coverage_report_data,'Water')
    
    output$WaterIndicationLosses <- renderDT(datatable(waterLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4,5), digits = 3))
    
    waterPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'Water',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      'Y')
    output$WaterIndicationPremium <- renderDT(datatable(waterPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    waterSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,waterLosses, waterPremium,expense_ratios)
    output$WaterIndicationSummary<- renderDT(datatable(waterSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                               formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    theftLosses <<- rate_level_indication_peril(on_level_load, 
                                                input$proposedEffective,
                                                input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                                input$currentLossTrendState,
                                                input$projLossTrendState, as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                                coverage_report_data,'TheftVMM')
    
    output$TheftIndicationLosses <- renderDT(datatable(theftLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4,5), digits = 3))
    theftPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'TheftVMM',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      'Y')
    output$TheftIndicationPremium <- renderDT(datatable(theftPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    theftSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,theftLosses, theftPremium,expense_ratios)
    output$TheftIndicationSummary<- renderDT(datatable(theftSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                               formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    OtherAOPLosses <<- rate_level_indication_peril(on_level_load, 
                                                   input$proposedEffective,
                                                   input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                                   input$currentLossTrendState,
                                                   input$projLossTrendState, as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                                   coverage_report_data,'OtherAOP')
    
    output$OtherAOPIndicationLosses <- renderDT(datatable(OtherAOPLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                  formatRound(c(2,6,7), digits = 0)%>%
                                                  formatRound(c(3,4,5), digits = 3))
    OtherAOPPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                         coverage_report_data, 'OtherAOP',input$currentPremiumTrend,
                                                         input$projPremiumTrend,
                                                         input$proposedEffective,
                                                         input$IndicationDate,
                                                         evaluation_use,
                                                         input$State,
                                                         'Y')
    output$OtherAOPIndicationPremium <- renderDT(datatable(OtherAOPPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                   formatRound(c(2,6,7), digits = 0)%>%
                                                   formatRound(c(3,4), digits = 3))
    OtherAOPSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,OtherAOPLosses, OtherAOPPremium,expense_ratios)
    output$OtherAOPIndicationSummary<- renderDT(datatable(OtherAOPSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                  formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    liabilityLosses <<- rate_level_indication_peril(on_level_load, 
                                                    input$proposedEffective,
                                                    input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                                    input$currentLossTrendState,
                                                    input$projLossTrendState, as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                                    coverage_report_data,'Liability')
    
    output$LiabilityIndicationLosses <- renderDT(datatable(liabilityLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                   formatRound(c(2,6,7), digits = 0)%>%
                                                   formatRound(c(3,4,5), digits = 3))
    liabilityPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                          coverage_report_data, 'Liability',input$currentPremiumTrend,
                                                          input$projPremiumTrend,
                                                          input$proposedEffective,
                                                          input$IndicationDate,
                                                          evaluation_use,
                                                          input$State,
                                                          'Y')
    output$LiabilityIndicationPremium <- renderDT(datatable(liabilityPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                    formatRound(c(2,6,7), digits = 0)%>%
                                                    formatRound(c(3,4), digits = 3))
    liabilitySummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,liabilityLosses, liabilityPremium,expense_ratios)
    output$LiabilityIndicationSummary<- renderDT(datatable(liabilitySummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                   formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    NCWLosses <<- rate_level_indication_peril(on_level_load, 
                                              input$proposedEffective,
                                              input$IndicationDate,evaluation_use,input$State,LDF_selection_weather,
                                              input$currentLossTrendState,
                                              input$projLossTrendState, as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                              coverage_report_data,'NCW')
    
    output$NCWIndicationLosses <- renderDT(datatable(NCWLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                             formatRound(c(2,6,7), digits = 0)%>%
                                             formatRound(c(3,4,5), digits = 3))
    NCWPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                    coverage_report_data, 'NCW',input$currentPremiumTrend,
                                                    input$projPremiumTrend,
                                                    input$proposedEffective,
                                                    input$IndicationDate,
                                                    evaluation_use,
                                                    input$State,
                                                    'Y')
    output$NCWIndicationPremium <- renderDT(datatable(NCWPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4), digits = 3))
    NCWSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,NCWLosses, NCWPremium,expense_ratios)
    output$NCWIndicationSummary<- renderDT(datatable(NCWSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    HULosses <<- cat_peril_table('Hurricane',modeled_cat,input$HUexpFactor)
    HUsummary <<- cat_peril_summary(input$State, evaluation_use,input$Program,HULosses, expense_ratios,'Hurricane',input$HUexpFactor,input$HUyearExpAdj,modeled_cat)
    output$HUIndication <- renderDT(datatable(HULosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                      formatRound(c(2,3), digits = 0)%>%
                                      formatRound(c(4,6), digits = 3)%>%
                                      formatPercentage(c(5,7),digits = 1))
    output$HUIndicationSummary<- renderDT(datatable(HUsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    STSLosses <<- cat_peril_table('STS',modeled_cat,input$STSexpFactor)
    STSsummary <<- cat_peril_summary(input$State, evaluation_use,input$Program,STSLosses, expense_ratios,'STS',input$STSexpFactor,input$STSyearExpAdj,modeled_cat)
    output$STSIndication <- renderDT(datatable(STSLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                       formatRound(c(2,3), digits = 0)%>%
                                       formatRound(c(4,6), digits = 3)%>%
                                       formatPercentage(c(5,7),digits = 1))
    
    output$STSIndicationSummary<- renderDT(datatable(STSsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    #display the summary table
    output$TotalRateLevelIndication <- renderDT(datatable(total_data,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                                  formatRound(c(2,5,6,10),digits = 0)%>%
                                                  formatRound(c(3,4,7,8,9), digits = 3)%>%
                                                  formatPercentage(c(11),digits = 1))
    
    #display all the results
    TotalSummary <<-rate_level_summary(total_data,
                                       modeled_cat,
                                       expense_ratios,
                                       losses_claims,
                                       input$projPremiumTrend,
                                       input$projLossTrendState,
                                       input$STSexpFactor,
                                       input$HUexpFactor,
                                       input$includePerils)
    output$TotalRateLevelSummary <- renderDT(datatable(TotalSummary,colnames = ' ' ,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))))%>%
                                               formatPercentage(c(2), digits=1))
    indication_memo_data <<-indication_memo(TotalSummary, #only include selected perils in the indication memo
                                            if ('Fire' %in% input$includePerils) fireSummary else NA,
                                            if ('Water' %in% input$includePerils) waterSummary else NA,
                                            if ('Theft' %in% input$includePerils) theftSummary else NA,
                                            if ('Liability' %in% input$includePerils) liabilitySummary else NA,
                                            if ('Other' %in% input$includePerils) OtherAOPSummary else NA,
                                            if ('NCW' %in% input$includePerils) NCWSummary else NA,
                                            if ('STS' %in% input$includePerils) STSsummary else NA,
                                            if ('Hurricane' %in% input$includePerils) HUsummary else NA,
                                            coverage_report_data,non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),
                                            input$includePerils)
    
    output$memo <-  renderDT(datatable(indication_memo_data,selection = 'none',class = 'compact',rownames = F,options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))))%>%
                               formatPercentage(c(2,3,4), digits=1))
    
    output$FireRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Fire'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$WaterRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Water'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1))
    output$TheftRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Theft & VMM'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1))
    output$LiabilityRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Liability'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                  formatPercentage(c(3), digits = 1))
    output$OtherAOPRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'All Other Perils'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                 formatPercentage(c(3), digits = 1))
    output$NCWRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Non-Cat Weather'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    output$STSRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'STS'),class = 'compact',selection = 'none',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    output$HURateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Hurricane'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                           formatPercentage(c(3), digits = 1))
    
    
    #load the territorial CAT experience adjustment factors
    TerSTSexpAdj <<- ExperienceFactor(input$Program,input$IndicationDate, evaluation_use, input$State, 'STSexpFactor')
    TerHUexpAdj  <<- ExperienceFactor(input$Program,input$IndicationDate, evaluation_use, input$State, 'HUexpFactor')
    
    LossesCappedTable <<- LossesCapped(input$Program,input$IndicationDate, evaluation_use, input$State)
    EHY_PremTable <<- EHY_Prem(input$Program,input$IndicationDate, evaluation_use, input$State)
    InforceAALTable <<- InforceAAL(input$Program,input$IndicationDate, evaluation_use, input$State)
    
    SelectionTrendData <<- total_data[c(1:5), c(1,4,7,8)]
    colnames(SelectionTrendData) <- c('Adj', 'PremTrend','LDF','LossTrend')
    
    SelectionTrendDataAtt <<- data.frame(Adj = unlist(fireLosses[1]), LDF = unlist(fireLosses[3]))
    SelectionTrendDataWeather <<- data.frame(Adj = unlist(NCWLosses[1]), LDF = unlist(NCWLosses[3]))
    # LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
    # TargetLossRatio,TargetIndicatedChange,nonPeril
    TerritorialExhibitData <<- TerritorialExhibit(LossesCappedTable,EHY_PremTable,InforceAALTable,SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTotal()['Selected','Weighted LLL']),
                                                  SelectionTrendData[,c(1,3)],TerHUexpAdj,TerSTSexpAdj,selected_expense_data_selected,as.numeric(modeled_cat$`Modeled Hurricane Loss & LAE Ratio`) *  input$HUexpFactor,
                                                  as.numeric(modeled_cat$`Modeled CS Loss & LAE Ratio`) *  input$STSexpFactor,
                                                  reinsurance(input$State,evaluation_use,input$Program,'Hurricane'),reinsurance(input$State,evaluation_use,input$Program,'STS'),1082,
                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                  as.numeric(TotalSummary[8 + ifelse('Hurricane' %in% input$includePerils,1,0) +ifelse('STS' %in% input$includePerils,1,0),2]),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State))###STOP
    
    output$TerritorialExhibit <- renderDT(datatable(TerritorialExhibitData%>%select(-InforceCount),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(3,11,12)),list(className = 'dt-right',targets = c(0:12)))),rownames=F)%>%
                                            formatRound(c(2:5),digits = 0)%>%
                                            formatPercentage(c(6:13), digits = 1)%>%
                                            formatStyle(
                                              1,
                                              target = "row",
                                              fontWeight = styleEqual("Total", "bold")
                                            ))
    #LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
    #TargetLossRatio,TargetIndicatedChange,nonPeril,peril
    output$TerritorialExhibitSnapshot <- renderDT(datatable(TerritorialExhibitTop10(TerritorialExhibitData),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(3,11,12)),list(className = 'dt-right',targets = c(0:12)))),rownames=F)%>%
                                                    formatRound(c(2:5),digits = 0)%>%
                                                    formatPercentage(c(6:13), digits = 1)%>%
                                                    formatStyle(
                                                      1,
                                                      target = "row",
                                                      fontWeight = styleEqual("Total", "bold")
                                                    ))
    
    TerritorialExhibitFireData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Fire'),EHY_PremTable,InforceAALTable,
                                                                   SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLFire()['Selected','Weighted LLL']),
                                                                   SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                   as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                   as.numeric(memoToTables(indication_memo_data,'Fire')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'Fire')
    
    output$TerritorialExhibitFire <- renderDT(datatable(TerritorialExhibitFireData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                formatRound(c(2:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1)%>%
                                                formatStyle(
                                                  1,
                                                  target = "row",
                                                  fontWeight = styleEqual("Total", "bold")
                                                ))
    TerritorialExhibitWaterData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Water'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWater()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Water')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'Water')
    
    output$TerritorialExhibitWater <- renderDT(datatable(TerritorialExhibitWaterData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(2:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1)%>%
                                                 formatStyle(
                                                   1,
                                                   target = "row",
                                                   fontWeight = styleEqual("Total", "bold")
                                                 ))
    
    TerritorialExhibitTheftData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'TheftVMM'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Theft & VMM')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'Theft')
    
    output$TerritorialExhibitTheft <- renderDT(datatable(TerritorialExhibitTheftData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(2:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1)%>%
                                                 formatStyle(
                                                   1,
                                                   target = "row",
                                                   fontWeight = styleEqual("Total", "bold")
                                                 ))
    
    if ('Liability' %in% input$includePerils) {
      TerritorialExhibitLiabilityData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Liability'),EHY_PremTable,InforceAALTable,
                                                                          SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                                                          SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                          as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                          as.numeric(memoToTables(indication_memo_data,'Liability')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'Liability')
    } else {
      TerritorialExhibitLiabilityData<<-NULL
    }
    
    output$TerritorialExhibitLiab <- renderDT(datatable(TerritorialExhibitLiabilityData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                formatRound(c(2:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1)%>%
                                                formatStyle(
                                                  1,
                                                  target = "row",
                                                  fontWeight = styleEqual("Total", "bold")
                                                ))
    
    TerritorialExhibitOtherAOPData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'OtherAOP'),EHY_PremTable,InforceAALTable,
                                                                       SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                                                       SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                       as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                       as.numeric(memoToTables(indication_memo_data,'All Other Perils')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'OtherAOP')
    
    output$TerritorialExhibitAOP <- renderDT(datatable(TerritorialExhibitOtherAOPData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:5,7),digits = 0)%>%
                                               formatPercentage(c(6,8:11), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))
    
    TerritorialExhibitNCWData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'NCW'),EHY_PremTable,InforceAALTable,
                                                                  SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                                                  SelectionTrendDataWeather[,c(1,2)],selected_expense_data_selected,1082,
                                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                  as.numeric(memoToTables(indication_memo_data,'Non-Cat Weather')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),'NCW')
    
    output$TerritorialExhibitNCW <- renderDT(datatable(TerritorialExhibitNCWData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:5,7),digits = 0)%>%
                                               formatPercentage(c(6,8:11), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))
    
    
    TerritorialExhibitHUData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')),
                                                                  as.numeric(memoToTables(indication_memo_data,'Hurricane')),'Hurricane','HU',TerHUexpAdj,as.numeric(HULosses[7]), as.numeric(reinsurance_exhibit_table[1,5]),input$HUyearExpAdj,20)
    
    output$TerritorialExhibitHU <- renderDT(datatable(TerritorialExhibitHUData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                              formatRound(c(2:4),digits = 0)%>%
                                              formatRound(6,digits = 2)%>%
                                              formatPercentage(c(5,7:12), digits = 1)%>%
                                              formatStyle(
                                                1,
                                                target = "row",
                                                fontWeight = styleEqual("Total", "bold")
                                              ))
    
    
    TerritorialExhibitSTSData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                                                   as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')),
                                                                   as.numeric(memoToTables(indication_memo_data,'STS')),'STS','STS',TerSTSexpAdj,as.numeric(STSLosses[7]), as.numeric(reinsurance_exhibit_table[2,5]), input$STSyearExpAdj,20)
    
    output$TerritorialExhibitSTS <- renderDT(datatable(TerritorialExhibitSTSData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:4),digits = 0)%>%
                                               formatRound(6,digits = 2)%>%
                                               formatPercentage(c(5,7:12), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))

  }},priority = 0)
  
  
  ###################CVA Analysis
  
  observeEvent({input$ProgramvariableOptions},
               
               {
                 if (input$searchIndication > searchIndication) {
                   updateSelectInput(session, input = "selectVariable",
                                  choices = input$ProgramvariableOptions)
                 
               }}
  )
  
  observe({
    if (input$searchIndication > searchIndication) {
    updateTextInput(session, input = 'variableTitle', value = cvaDisplayName(input$Program,input$selectVariable))
    
  }})
  
  
  observe({ 
    
    if (input$searchIndication > searchIndication) {
    Peril <- c('Total','TotalModeledHU','ExCat',input$includePerils)
    if ('Hurricane' %in% input$includePerils) {
      Peril <- c(Peril,'ModeledHU')
    }
    CVAPerils <- data.frame(Peril = Peril)
    
    updateSelectInput(session, input = "selectPeril",choices = CVAPerils)
    
  }}
  )
  
  observeEvent({c(input$Program, input$State, input$selectVariable, input$selectPeril)},
               {
                 if (input$searchIndication > searchIndication) {
                 counter <<- 0}})
  observeEvent({c(input$binSize, input$binNumber)},
               {
                 if (input$searchIndication > searchIndication) {
                 counter <<- counter + 1
               }})
  
  observe({ 
    if (input$searchIndication > searchIndication) {
    options(warn = -1) #temporarily suppress warnings
    variableData <- cvaPull(input$Program,input$IndicationDate, input$State, unlist(input$selectVariable),input$HUexpFactor,as.numeric(selected_expense_data_selected))
    variableClean <- cvaClean(variableData, input$selectPeril)
    condition <- T
    while (condition) { 
      if ((ifelse(is.null(input$binNumber),0,input$binNumber) < 1 | is.null(input$binSize))) { 
        break
      } 
      
      variableClean <- CVAvalueMapping(input$Program,input$State,input$selectVariable,variableClean, input$selectPeril)
      
      
      
      # tryNum <- is.na(as.numeric((variableClean%>%filter(variableValue!='Total'))$variableValue))
      # if (length(unique(tryNum))==1) {
      #   if (as.vector(unique(tryNum))==F) {
      #     numericData <- variableClean%>%
      #       mutate(variableValue = as.numeric(variableValue))%>%
      #       arrange(variableValue)
      #     
      #     if (counter == 0) {
      #       binMax <- max(numericData$variableValue, na.rm = T)
      #       updateAutonumericInput(session, input = 'binSize', value = max(binMax/defaultBinNumber, 1))
      #     }
      #     numericData <- numericData%>% 
      #       mutate(new_bin = cut_format(variableValue+1, breaks=seq(0, (input$binNumber)*input$binSize, by =input$binSize), paren = c("", "", "", ""), sep= '-'))%>%
      #       mutate(new_bin = ifelse(variableValue >= (input$binNumber)*input$binSize, paste0(input$maxBin,'+'),as.character(new_bin)))
      #     
      #     for (i in c(1:nrow(numericData))) {
      #       firstPart  <- format(round(as.numeric(unlist(strsplit(as.character(numericData$new_bin[i]),'-'))[1]),0),  scientific = F,big.mark = ',')
      #       secondPart <- format(round(as.numeric(unlist(strsplit(as.character(numericData$new_bin[i]),'-'))[2])-1,0),scientific = F,big.mark = ',')
      #       numericData$new_bin[i] <- ifelse(firstPart == secondPart, firstPart,paste0(firstPart,'-',secondPart))
      #     }
      #     
      #     numericDataRerun <- numericData%>%
      #       mutate(new_bin = ifelse(variableValue >=  (input$binNumber)*input$binSize, paste0(format(round((input$binNumber)*input$binSize,0),scientific = F,big.mark = ','),'+'),new_bin))%>%
      #       mutate(variableValue = new_bin)%>%
      #       select(-new_bin)
      #     
      #     variableClean <- cvaClean(numericDataRerun, input$selectPeril)
      #     axisOrder <-unlist(unique(numericDataRerun%>%
      #                                 select(variableValue)))
      #   } else {
      #     axisOrder <- unique(variableClean$variableValue)
      #   }
      # } else {
      #   axisOrder <- unique(variableClean$variableValue)
      # } 
      axisOrder <- unique(variableClean$variableValue)
      variableCleanTable <- variableClean%>%
        select(-Peril)
      
      
      colnames(variableCleanTable) <- c('Class', 'Rerated Premium','Earned House Years','Average Premium','Capped Loss + LAE','Claim Count',
                                        'Loss Ratio','Frequency (peril 100 EHY)','Severity','Loss Cost','Indicated Change','Credibility',
                                        'Credibility Weighted Indicated Change','Frequency Relativity','Severity Relativity','Loss Ratio Relativity')
      
      
      output$table <- renderDT(datatable(variableCleanTable,selection = 'none',class = 'compact',rownames = F,options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '80px',className = 'dt-right',targets = c(1,15)),list(width = '500px',className = 'dt-left',targets = c(0)))))%>%
                                 formatRound(c(3,6), digits=0)%>%
                                 formatPercentage(c(7,11,12),digits = 1)%>%
                                 formatRound(c(8,14:16),digits = 2)%>%
                                 formatPercentage(c(13),digits = 0)%>%
                                 formatStyle(
                                   1,
                                   target = "row",
                                   fontWeight = styleEqual("Total", "bold")
                                 )%>%
                                 formatCurrency(c(2,4:5,9:10),digits = 0))
      
      variableCleanPlot <- variableClean%>%
        filter(variableValue != 'Total')%>%
        mutate(`Earned House Years` = EHY, `Frequency Relativity`=FreqRel, `Severity Relativity` = SevRel, `Loss Ratio Relativity` = LossRel)%>%
        select(variableValue, EHY, `Frequency Relativity`, `Severity Relativity`, `Loss Ratio Relativity`)%>%
        gather("Ratios", 'Values', 3:5)%>%
        arrange(variableValue) 
      
      secondlimitsdenom <<- max((variableClean%>%filter(variableValue!='Total'))$EHY,na.rm = T)
      secondlimitsnum <<- max(variableCleanPlot$Values, 1, na.rm = T)*1.25
      
      options(warn = 0) #turn warnings back on
      if (nrow(variableCleanPlot) > 0) {
        output$distPlot <- renderPlot({
          ggplot(variableCleanPlot) + 
            geom_bar(aes(x=variableValue, y=EHY/3*secondlimitsnum/secondlimitsdenom),stat = "identity",color='grey',fill='grey',width = .4) +
            geom_point(aes(x=variableValue, y=Values,color=Ratios, shape = Ratios,size=Ratios))+
            geom_line(aes(x=variableValue, y=Values ,color=Ratios, shape = Ratios, group = Ratios, linetype = Ratios) )+
            geom_line(aes(x=variableValue, y=1, group =1),colour = 'black', size = 1)+
            scale_y_continuous(sec.axis=sec_axis(~.*secondlimitsdenom/secondlimitsnum,name="EHY")) +
            theme(panel.background = element_rect(fill = 'transparent', color = 'transparent'),panel.grid.major.y = element_line(color = "grey85",
                                                                                                                                 size = 0.5))+
            scale_color_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'='grey','Loss Ratio Relativity'="gold",'Severity Relativity'="darkred",'Frequency Relativity'="green4" ))+
            scale_linetype_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'='blank','Loss Ratio Relativity'="solid",'Severity Relativity'="dotted",'Frequency Relativity'="dashed" ))+
            scale_shape_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'=15,'Loss Ratio Relativity'=17,'Severity Relativity'=15,'Frequency Relativity'=16 ))+
            scale_size_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'=6,'Loss Ratio Relativity'=3,'Severity Relativity'=3,'Frequency Relativity'=3 ))+
            theme(#text = element_text(family = "Calibri"),
              legend.key = element_rect(colour = NA, fill = NA),legend.position="bottom",plot.title = element_text(hjust = 0.5,color = 'grey40'),
              plot.background = element_rect(colour = "grey", fill=NA,size = .75),
              legend.key.size = unit(3,"line"))+
            ggtitle(paste0(input$State,': ',input$variableTitle))+
            ylab('')+xlab('')+
            scale_x_discrete(limits = c(as.character(axisOrder[axisOrder != 'Total' & !is.na(axisOrder)])))
          
          
        })
      }
      
      condition <- F
    } }
  })
  

  observeEvent({input$saveSelectionsForReview},
               {
                 if (input$searchIndication > searchIndication) { 
                   
                   if (length(input$SelectorChecklist)==length(selectorChecklist_list)) {
                   save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                        input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                        as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                        input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,input$includePerils,input$proposedEffective,
                                        input$selected_by[[1]],0,0)
 
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],0,0)
                   } else {
                     showNotification('Not all items have been check on the Selector Checklist')
                   }}})
  
  observeEvent({input$saveTechnicalReview},
               {
                 if (input$searchIndication > searchIndication) {
                   if (length(input$TechnicalreviewChecklist)==length(technicalChecklist_list)) {
                   save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                        input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                        as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                        input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,input$includePerils,input$proposedEffective,
                                        input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],0) 
                 } else {
                   showNotification('Not all items have been check on the Technical Review Checklist')
                 }}})
  
  observeEvent({input$savePeerReview},
               {
                 
                 if (input$searchIndication > searchIndication) {
                   if (length(input$PeerReviewChecklist)==length(peerChecklist_list)) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                      input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,input$includePerils,input$proposedEffective,
                                      input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                   } else {
                     showNotification('Not all items have been check on the Peer Review Checklist')
                 }}
                })
  
  observeEvent({input$PublishSelections},
               {
                 if (input$searchIndication > searchIndication) {
                   if (nrow(ReviewProgressDataFilter)==3) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','Published',
                                      input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,input$includePerils,input$proposedEffective,
                                      input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','Published',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','Published',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','Published',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','Published',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','Published',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','Published',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                   } else {
                     showNotification('Not Review Steps Have Been Completed')
                   }
               }})
  #generate a html report based on the selections made which can easily be printed to pdf in your browser. HTML is much easier to style than pdf.
  #territorial_report
  output$report <- downloadHandler(
    filename = paste(input$State,' ' ,input$Program," Indication ",year(as.Date(input$IndicationDate) - 1) %% 100 , month(as.Date(input$IndicationDate) -1),".html",sep = ''),
    content = function(file) {
      
      rmarkdown::render("Indication Report.Rmd", output_file = file,
                        params = list(
                          IndicationDate= input$IndicationDate,
                          EvaluationDate= evaluation_use,
                          proposedEffectiveDate= input$proposedEffective,
                          LOB = input$Program,
                          LOB_Full = table_name(input$Program),
                          State = input$State,
                          State_Full = state_name_full(input$State),
                          ldfallLoss = LDF_display(LDFdata,'Losses','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatio = LDF_display(LDFdata,'Loss Ratios','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAverages =LDF_display_averages(LDFallAverages,LDFallAveragesState,input$LDFstateweight),
                          ldfallSelections = LDF_selections_choose(LDF_selection,weighted_plot_all,input$LDFstateweight),
                          ldfallLossWeather = LDF_display(LDFdata,'Losses','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatioWeather = LDF_display(LDFdata,'Loss Ratios','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAveragesWeather = LDF_display_averages(LDFallAveragesWeather,LDFallAveragesStateWeather,input$LDFstateweight),
                          ldfallSelectionsWeather =  LDF_selections_choose(LDF_selection_weather,weighted_plot_weather,input$LDFstateweight),
                          ldfallLossAttritional = LDF_display(LDFdata,'Losses','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatioAttritional = LDF_display(LDFdata,'Loss Ratios','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAveragesAttritional = LDF_display_averages(LDFallAveragesAttritional,LDFallAveragesStateAttritional,input$LDFstateweight),
                          ldfallSelectionsAttritional =  LDF_selections_choose(LDF_selection_attritional,weighted_plot_attritional,input$LDFstateweight),
                          profit= as.numeric(state_profit),
                          TotalRateTable= total_data,
                          TotalRateCalc= TotalSummary,
                          FireLosses= fireLosses,
                          FirePrem= firePremium,
                          FireCalc= fireSummary,
                          WaterLosses= waterLosses,
                          WaterPrem= waterPremium,
                          WaterCalc= waterSummary,
                          TheftLosses= theftLosses,
                          TheftPrem= theftPremium,
                          TheftCalc= theftSummary,
                          LiabilityLosses= liabilityLosses,
                          LiabilityPrem= liabilityPremium,
                          LiabilityCalc= liabilitySummary,
                          OtherAOPLosses= OtherAOPLosses,
                          OtherAOPPrem= OtherAOPPremium,
                          OtherAOPCalc= OtherAOPSummary,
                          NCWLosses= NCWLosses,
                          NCWPrem= NCWPremium,
                          NCWCalc= NCWSummary,
                          STSLosses= STSLosses,
                          STSCalc= STSsummary,
                          HurricaneLosses= HULosses,
                          HurricaneCalc= HUsummary,
                          BalancedChange = indication_memo(TotalSummary, fireSummary, waterSummary, theftSummary, liabilitySummary, OtherAOPSummary, NCWSummary, STSsummary, HUsummary,coverage_report_data,non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State),input$includePerils),
                          PremiumTable= PremiumData_state%>%select(-Date),
                          PremiumFitting=premium_trend_fitting(PremiumData_state,0),
                          CurrentPremiumTrend= input$currentPremiumTrend,
                          ProjectedPremiumTrend=input$projPremiumTrend,
                          LossTable= lossTrendstateData%>%select(-Year,-Quarter),
                          LossFitting= loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),
                          CurrentLossTrend= input$currentLossTrendState,
                          ProjectedLossTrend= input$projLossTrendState,
                          LLLStateTotal= LLLdata_state_total,
                          LLLStateTotalCalc= LLL_selections(LLLdata_state_total,'Calculated'),
                          LLLStateTotalSelected= LLLdata_state_total_selected,
                          LLLCWTotal= LLLdata_CW_total,
                          LLLCWTotalCalc= LLL_selections(LLLdata_CW_total,'Calculated'),
                          LLLCWTotalSelected= LLLdata_CW_total_selected,
                          LLLTotalFinal = LLLTotal(),
                          LLLStateFire= LLLdata_state_fire,
                          LLLStateFireCalc= LLL_selections(LLLdata_state_fire,'Calculated'),
                          LLLStateFireSelected= LLLdata_state_fire_selected,
                          LLLCWFire= LLLdata_CW_fire,
                          LLLCWFireCalc= LLL_selections(LLLdata_CW_fire,'Calculated'),
                          LLLCWFireSelected= LLLdata_CW_fire_selected,
                          LLLFireFinal = LLLFire(),
                          LLLStateWater= LLLdata_state_water,
                          LLLStateWaterCalc= LLL_selections(LLLdata_state_water,'Calculated'),
                          LLLStateWaterSelected= LLLdata_state_water_selected,
                          LLLCWWater= LLLdata_CW_water,
                          LLLCWWaterCalc= LLL_selections(LLLdata_CW_water,'Calculated'),
                          LLLCWWaterSelected= LLLdata_CW_water_selected,
                          LLLWaterFinal = LLLWater(),
                          LLLStateTheft= LLLdata_state_theft,
                          LLLStateTheftCalc= LLL_selections(LLLdata_state_theft,'Calculated'),
                          LLLStateTheftSelected= LLLdata_state_theft_selected,
                          LLLCWTheft= LLLdata_CW_theft,
                          LLLCWTheftCalc= LLL_selections(LLLdata_CW_theft,'Calculated'),
                          LLLCWTheftSelected= LLLdata_CW_theft_selected,
                          LLLTheftFinal = LLLTheft(),
                          LLLStateLiability= LLLdata_state_liability,
                          LLLStateLiabilityCalc= LLL_selections(LLLdata_state_liability,'Calculated'),
                          LLLStateLiabilitySelected= LLLdata_state_liability_selected,
                          LLLCWLiability= LLLdata_CW_liability,
                          LLLCWLiabilityCalc= LLL_selections(LLLdata_CW_liability,'Calculated'),
                          LLLCWLiabilitySelected= LLLdata_CW_liability_selected,
                          LLLLiabilityFinal = LLLLiability(),
                          LLLStateOtherAOP= LLLdata_state_otherAOP,
                          LLLStateOtherAOPCalc= LLL_selections(LLLdata_state_otherAOP,'Calculated'),
                          LLLStateOtherAOPSelected= LLLdata_state_otherAOP_selected,
                          LLLCWOtherAOP= LLLdata_CW_otherAOP,
                          LLLCWOtherAOPCalc= LLL_selections(LLLdata_CW_otherAOP,'Calculated'),
                          LLLCWOtherAOPSelected= LLLdata_CW_otherAOP_selected,
                          LLLOtherAOPFinal = LLLOtherAOP(),
                          LLLStateWeather= LLLdata_state_weather,
                          LLLStateWeatherCalc= LLL_selections(LLLdata_state_weather,'Calculated'),
                          LLLStateWeatherSelected= LLLdata_state_weather_selected,
                          LLLCWWeather= LLLdata_CW_weather,
                          LLLCWWeatherCalc= LLL_selections(LLLdata_CW_weather,'Calculated'),
                          LLLCWWeatherSelected= LLLdata_CW_weather_selected,
                          LLLWeatherFinal = LLLWeather(),
                          LLLWeight= input$LLLstateweightTotal,
                          Capping= input$capped,
                          ModeledCatLoad = modeled_cat,
                          ExpenseRatio = expense_ratios,
                          Credibility = credibility_exhibit(losses_claims),
                          Cumulative = on_level_cumulative(input$IndicationDate,input$Program,input$State),
                          OnLevelFactors = on_level_load,
                          HUreinsurance = reinsurance(input$State,evaluation_use,input$Program,'Hurricane'),
                          STSreinsurance = reinsurance(input$State,evaluation_use,input$Program,'STS'),
                          CostOfReinsurance = reinsurance(input$State,evaluation_use,input$Program,'All Perils'),
                          Peril = input$includePerils
                        ),
                        envir = new.env(parent = globalenv())
      )
      
    }
  )#
  output$territorial_report <- downloadHandler(
    filename = paste(input$State, input$Program,"Territorial Analysis.html",sep = ' '),
    content = function(file) {
      
      rmarkdown::render("Territorial Analysis Report.Rmd", output_file = file,
                        params = list(
                          IndicationDate= input$IndicationDate,
                          EvaluationDate= evaluation_use,
                          proposedEffectiveDate= input$proposedEffective,
                          LOB = input$Program,
                          LOB_Full = table_name(input$Program),
                          State = input$State,
                          State_Full = state_name_full(input$State),
                          TerritorialTotal = TerritorialExhibitData%>%select(-InforceCount),
                          TerritorialSnapshot = TerritorialExhibitTop10(TerritorialExhibitData),
                          TerritorialFire = TerritorialExhibitFireData,
                          TerritorialWater = TerritorialExhibitWaterData,
                          TerritorialTheft = TerritorialExhibitTheftData,
                          TerritorialLiab = TerritorialExhibitLiabilityData,
                          TerritorialOther = TerritorialExhibitOtherAOPData,
                          TerritorialNCW = TerritorialExhibitNCWData ,
                          TerritorialSTS = TerritorialExhibitSTSData ,
                          TerritorialHurricane = TerritorialExhibitHUData,
                          Peril = input$includePerils
                        ),
                        envir = new.env(parent = globalenv())
      )
      
    }
  )
  
  }})
    
}

# Run the application 

shinyApp(ui = ui, server = server)
