#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
######################################################
############ Actuarial Indication ####################
############ Author: Ian Starkey  ####################
######################################################


#Install Packages if Necessary
if (!require(DBI)) install.packages('DBI')
if (!require(lubridate)) install.packages('lubridate')
if (!require(openxlsx)) install.packages('openxlsx')
if (!require(shiny)) install.packages('shiny')
if (!require(shinyWidgets)) install.packages('shinyWidgets')
if (!require(dplyr)) install.packages('dplyr')
if (!require(DT)) install.packages('DT')
if (!require(miscTools)) install.packages('miscTools')
if (!require(tidyr)) install.packages('tidyr')
if (!require(shinythemes)) install.packages('shinythemes')
if (!require(markdown)) install.packages('markdown')
if (!require(shinyjs)) install.packages('shinyjs')
if (!require(shinycssloaders)) install.packages('shinycssloaders')
if (!require(odbc)) install.packages('odbc')
if (!require(sjmisc)) install.packages('sjmisc')
if (!require(ggplot2)) install.packages('ggplot2')
if (!require(kimisc)) install.packages('kimisc')
if (!require(mailtoR)) install.packages('mailtoR')
if (!require(digest)) install.packages('digest')
if (!require(stringr)) install.packages('stringr')
if (!require(ExcelFunctionsR)) install.packages('ExcelFunctionsR')
if (!require(excelR)) install.packages('excelR')

#load packages
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(ExcelFunctionsR)
library(excelR)



#define input options
LOB <- data.frame(matrix(ncol = 4,nrow=0))
colnames(LOB) <- c('HO','DF','RE','CO')
default <- 99

#define Perils

#defin Checklists
peerChecklist_list <- c('Expense Load',
  'Experience Adjustment Factors',
  'Total Years for Experience Adjustment',
  'LDFs',
  'Loss Trends ',
  'LLL',
  'Premium Trend',
  'Class Variable Analysis')

technicalChecklist_list <- c('Modeled Cat Load',
                             'LDFs',
                             'Loss Trend',
                             'LLL',
                             'Premium Trend',
                             'Expense Ratios',
                             'Rate Level Indication',
                             'Territorial Analysis',
                             'Class Variable Analysis')

selectorChecklist_list <- c('Modeled Cat Load',
                            'Non-Modeled Results',
                            'LDFs - State',
                            'LDFs - CW',
                            'Loss Trend - State',
                            'Loss Trend - CW',
                            'LLL',
                            'Premium Trend',
                            'Expense Ratios',
                            'Rate Level Indication',
                            'Territorial Analysis',
                            'Class Variable Analysis',
                            'Endorsement Analysis')

#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')

conSand <-  dbConnect(odbc::odbc(),
                      Driver='SQL Server', # SQLServer   #SQL Server
                      server=server,
                      database=databaseSandbox,
                      trusted_connection='yes')


#JavaScript function to allow drop down boxes inside of a LDF data table
js <- c(
  "function(settings){",
  "  $('#mselect').selectize()",
  "}"
)

#get current state options with a SQL rater
state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select distinct state from 
      actuarialsandbox.",program,".modeledCatLoad 
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}

#get a list of indication dates available in SQL
date_options <- function(program) {
  dframe <- dbGetQuery(con,paste0(
    "select distinct indicationdate
    from actuarialsandbox.[",program,"].modeledCatLoad 
    group by indicationdate
    order by indicationdate desc "
  ))%>%
    mutate(IndicationName = as.character(as.numeric(substr(as.character( year(as.Date(indicationdate) %m-% months(1))),3,4))*100+ month(as.Date(indicationdate) %m-% months(1))))
  
  out <- list()
  for (i in 1:nrow(dframe)) {
    out <- append(out, list(dframe$indicationdate[i]))
  }
  names(out) <- dframe[['IndicationName']]
  return(out)
}

ratingVersionID <- function(Program, State, IndicationDate, EvaluationDate,data.source) {
  dframe <- dbGetQuery(con, paste0("
                                   select distinct  ratingVersionID
                                   from ActuarialSandbox.",Program,".modeledCatLoad
                                   where State ='",State,"'
                                   and IndicationDate = '",IndicationDate,"'
                                   and EvaluationDate ='",EvaluationDate,"'
                                   and source = '",data.source,"'
                                   
                                   "))
  return(unlist(dframe))
}

#Used to attach Actuary names to indication Selections
selections_id <- function(IndicationDate, EvaluationDate, State, Program) {
  dframe <- dbGetQuery(con,paste0(
    "
    select selected_by, FirstName+ ' ' + LastName as Name
    from ActuarialSandbox.dbo.TeamId a
    left join (
    SELECT min(selected_by) as selected_by
    from ActuarialSandbox.",Program,".indicationSelections
      where region= '",State,"'
      and IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      group by region) b on b.selected_by=a.teamID
      where selected_by is not null
    "
  ))
  df_out <- as.data.frame(dframe$selected_by)
  
  if (nrow(df_out) > 0) {
    colnames(df_out) <- c(dframe[['Name']])
    return(df_out)
  } else {
    other <- data.frame(matrix(ncol=1,nrow=1))
    other[1] <- c(1)
    colnames(other) <- c('Donte Riddick')
    return(other)
  }
}
#list of actuary names
actuaryNames <- function(except) {
  dframe <- dbGetQuery(con,"
                    select teamID,
                    FirstName,
                    LastName
                    from ActuarialSandbox.dbo.TeamId
                    where status = 'Active'
                    and Role = 'Actuarial'
                   ")%>%
    mutate(FullName = paste(FirstName, LastName, sep = ' '))
  out <- list()
  for (i in 1:nrow(dframe)){
    out <- append(out, list(dframe$teamID[i]))
  }
  names(out) <- dframe$FullName
  return(out[!(out %in% except)])
}

actuaryReturn <- function(id) {
  dframe <- dbGetQuery(con,paste0("
                    select
                    FirstName,
                    LastName
                    from ActuarialSandbox.dbo.TeamId
                    where teamID = ",id,"
                    
                   "))
  return(dframe)
}

eval_date_options <- function(IndicationDateIn, Program,State) { #create list of evaluation dates saved in SQL with the selected Indication Date, prevent app from crashing when any date selections is available. 
  IndicationDateIn <- as.Date(IndicationDateIn)
  dframe <- dbGetQuery(con, paste0(
    "select distinct indicationdate, evaluationdate
    from actuarialsandbox.[",Program,"].modeledCatLoad
    where state = '",State,"'
    group by indicationdate, evaluationdate"
  ))
  options <- dframe[as.Date(dframe$indicationdate)==IndicationDateIn,]
  out <- list()
  for (i in 1:nrow(options)) {
    out <- append(out, list(options$evaluationdate[i]))
  }
  
  names(out) <- options[['evaluationdate']]
  return(out)
}
#Program Full
table_name <- function(LOB_short) { #define the long names for each programs
  LOB_full <- ifelse(LOB_short=='HO', 'Homeowners',
                     ifelse(LOB_short=='DF', 'Dwelling Fire',
                            ifelse(LOB_short=='CO', 'Condo',
                                   ifelse(LOB_short=='TE' | LOB_short == 'RE','Tenant','LOB Error'))))
  return(LOB_full)
}

state_name_full <- function(state_short) { #full state name assignments from abreviation
  state_full <- state.name[match(c(state_short),state.abb)]
  return(as.character(state_full))
}
#end display funcitons

data.source.options <- function(Program, IndicationDate, EvaluationDate, State) {
  dframe <- dbGetQuery(con, paste0("
              select distinct source
              from ActuarialSandbox.",Program,".modeledCatLoad
              where state = '",State,"'
              and IndicationDate='",IndicationDate,"'
              and EvaluationDate='",EvaluationDate,"'
                                   "))
  
  out <- list('ActuarialDataMart' = if ('ADM' %in% dframe$source) 'ADM' else NA,
              'ActuarialSandBox'  = if ('ActuarialSandBox' %in% dframe$source) 'ActuarialSandBox' else NA)
  out <- out[!is.na(out)]
  return(out)
}

peril_list <- function(Program, State, IndicationDate, EvaluationDate) { 
  dframe <- dbGetQuery(con, paste0(
    "    select  right(columnName,len(columnName) - len('IncludePeril'))
    from ActuarialSandbox.",Program,".indicationSelections
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and region = '",State,"'
      and lower(columnName) like '%includeperil%'
      and columnValue='1'
    "
  )) 
  vector.out <- if (nrow(dframe) > 0 ) {
    unlist(as.vector(dframe))
  } else {
    if (Program == 'HO') {
      c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane')
    }else if (Program == 'DF') {
      c('Fire', 'Water', 'Theft', 'Explosion', 'Other' ,'NCW', 'STS', 'Hurricane')
    } else {
      c('')
    }
  }
  return(vector.out)
}

expense_cw<- function(Program, As_Of_Date,Rolling_Year_End) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
  dframe <- dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Program,".[claim] 
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep=""))
  dframe%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(dframe$`Loss Reserve`),`Expense Reserve` = sum(dframe$`Expense Reserve`),`Legal Expense Reserve` = sum(dframe$`Legal Expense Reserve`),
            `Expense Load`=coalesce((sum(dframe$`Loss Reserve`)+sum(dframe$`Expense Reserve`)+sum(dframe$`Legal Expense Reserve`))/sum(dframe$`Loss Reserve`),0))
} #cw expense load table

expense_state<- function(Program, As_Of_Date,Rolling_Year_End,State) {
  As_Of_Date <- as.Date(As_Of_Date)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  dframe<-dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Program,".[claim]
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and state = '",State,"'
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep="")) 
  dframe<-dframe%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(dframe$`Loss Reserve`),`Expense Reserve` = sum(dframe$`Expense Reserve`),`Legal Expense Reserve` = sum(dframe$`Legal Expense Reserve`),
            `Expense Load`=coalesce((sum(dframe$`Loss Reserve`)+sum(dframe$`Expense Reserve`)+sum(dframe$`Legal Expense Reserve`))/sum(dframe$`Loss Reserve`),0))
  
} #state expense load table

expense_select <- function(Program, As_Of_Date,Rolling_Year_End,State, StateWeight,cw_exclude,state_exclude) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
  cw <- expense_cw(Program, As_Of_Date,Rolling_Year_End)%>%
    filter(!Year %in% c(cw_exclude,"Total"))
  cw_load<-(sum(cw$`Loss Reserve`)+sum(cw$`Expense Reserve`)+sum(cw$`Legal Expense Reserve`))/sum(cw$`Loss Reserve`)
  state <- expense_state(Program, As_Of_Date,Rolling_Year_End,State)%>%
    filter(!Year %in% c(state_exclude,"Total"))
  state_load<-(sum(state$`Loss Reserve`)+sum(state$`Expense Reserve`)+sum(state$`Legal Expense Reserve`))/sum(state$`Loss Reserve`)
  dframe<-data.frame() 
  dframe["Calculated Expense Load",' '] <-coalesce(cw_load,1)*(1-StateWeight) + coalesce(state_load,1)*StateWeight
  dframe
} #selected expense Load table with exclude years for state and cw

#figure out status on Targit, spatial key, and AAL

#Modeled cat load
modeled_cat_load <- function(Program,EvaluationDate,IndicationDate,State,FillOutDate,data.source) {
  dframe <-dbGetQuery(con, paste0("
          select top 1 a.*,
          case when a.rowStartDate not between b.rowStartDate and b.rowEndDate then 'More Recent SpatialKey Data is available' else 'SpatialKey Data is Current' end as SpatialMessage,
          case when a.rowStartDate not between c.rowStartDate and c.rowEndDate then 'More Recent AAL Data is available' else 'AAL Data is Current' end as AALMessage
          from ActuarialSandbox.",Program,".modeledCatLoad a
          left join (
          select top 1 rowStartDate, rowEndDate
          from ActuarialSandbox.",Program,".policySpatialKey
          where '",FillOutDate,"' between rowStartDate and rowEndDate
          order by rowStartDate desc
          ) b on 1=1
          left join (
          select top 1 rowStartDate, rowEndDate
          from ActuarialSandbox.",Program,".AAL_upload
          where '",FillOutDate,"' between rowStartDate and rowEndDate
          order by rowStartDate desc
          ) c on 1=1
          where  IndicationDate = '",IndicationDate,"'
          and EvaluationDate =  '",EvaluationDate,"'
          and state =  '",State,"'
          and source = '",data.source,"'
          order by a.rowStartDate desc

                       
                       "))
  df_out <- dframe %>%
    select(-`In Force Policy Charge`)
  
  return(df_out)
}
modeled_cat_load_calc <- function(data,cat_load) {
  data%>%
    mutate(`CAT LAE Load` = cat_load, `Modeled Hurricane Loss & LAE Ratio` = `Modeled HU CAT Loss Ratio` * cat_load, `Modeled CS Loss & LAE Ratio` = `Modeled CS CAT Loss Ratio` * cat_load)%>%
    mutate(`Total Modeled Cat Loss & LAE Ratio` = `Modeled Hurricane Loss & LAE Ratio` + `Modeled CS Loss & LAE Ratio`)%>%
    select(-SpatialMessage,-AALMessage,-ratingVersionID, -IndicationDate, -EvaluationDate, -state, -currentRow, -rowStartDate,-rowEndDate,-source)
    
}

####Non Modeled Cat Load

nonModeledPull <- function(Program, IndicationDate, EvaluationDate, State) {
  dframe <- dbGetQuery(con, paste0(
    "
    select t.*, coalesce(Zone, 'No Mapping') as Zone
    from ActuarialSandbox.",Program,".TerritorialNonModeled t
    left join (
       select * from
       ActuarialSandbox.",Program,".NonModeledZoneMapping
       where currentRow = 1
    )  m on t.state = m.state and t.territoryCode=m.territoryCode
    where IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"' 
    and t.state = '",State,"'

    "
  ))%>%
    group_by(Loss_Rolling_Year,Zone)%>%
    summarise(TotalPaid_Non_Cat = sum(TotalPaid_Non_Cat), TotalPaid_Cat = sum(TotalPaid_Cat), .groups = 'drop')%>%
    filter((TotalPaid_Non_Cat + TotalPaid_Cat) >0)%>%
    arrange(desc(Zone))
  
  return(dframe)
}

inforceSummary <- function(Program, IndicationDate, EvaluationDate, State,data.source) {
  inforce <- dbGetQuery(con, paste0(
    "
 select coalesce(Zone, 'All Other') as Zone, sum(inforceCount) as inforceCount
  from ActuarialSandbox.",Program,".TerritorialInforceAAL a
  left join ActuarialSandbox.",Program,".NonModeledZoneMapping m on m.state=a.state and m.territoryCode=a.territoryCode
  where a.state = '",State,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and source = '",data.source,"'
  group by coalesce(Zone, 'All Other') 
    "
  ))
  inforce <- inforce %>%
    mutate(Selected = 0)%>%
    arrange(desc(Zone))
  return(inforce)
}

NonModeledSummary <- function(IndicationDate,data.in, LossTrend) {
  zone.list <- unique(data.in$Zone)
  trendTo <- year(as.Date(IndicationDate)-1)
  store <- list()
  for (zone in zone.list) {
    dframe <- data.in[data.in$Zone == zone,]%>%
      mutate(Trend = (1+LossTrend)^(trendTo-Loss_Rolling_Year))%>%
      mutate(TrendedNonCat = coalesce(Trend*TotalPaid_Non_Cat,0),
             TrendedCat = coalesce(Trend*TotalPaid_Cat,0))%>%
      mutate(EstimatedCatLoad = coalesce(TrendedCat/TrendedNonCat,0),
             Loss_Rolling_Year = as.character(Loss_Rolling_Year))%>%
      select(-Trend)
    straight.avg <- mean(dframe$EstimatedCatLoad)
    weighted.avg <- sum(dframe$TrendedCat)/sum(dframe$TrendedNonCat)
    dframe <- dframe%>%
      add_row(
        Loss_Rolling_Year = 'Total',
        Zone = max(dframe$Zone),
        TotalPaid_Non_Cat = sum(dframe$TotalPaid_Non_Cat),
        TotalPaid_Cat = sum(dframe$TotalPaid_Cat),
        TrendedNonCat = sum(dframe$TrendedNonCat),
        TrendedCat = sum(dframe$TrendedCat),
        EstimatedCatLoad = weighted.avg
        
      )
    store[[length(store)+1]] <-  list(dframe,data.frame(Name = c('Weighted Average','Straight Average'),Average = c(weighted.avg,straight.avg)))
    
  }
  return(store)
}

NonModeledAverage.Calc <- function(dframe, criteria) {
  dframe <- dframe%>% #filter out exclude rows
    filter( !(Loss_Rolling_Year %in% criteria) )
  
  straight.avg <- mean(dframe$EstimatedCatLoad)
  weighted.avg <- sum(dframe$TrendedCat)/sum(dframe$TrendedNonCat)
 dframe.out <- data.frame(Name = c('Weighted Average','Straight Average'),Average = c(weighted.avg,straight.avg))
 return(dframe.out)
}


column_names <- function(dframe,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  if (table == 'Losses') {
    c(
      ifelse(month(Rolling_Year_End %m-% months(1))==12,
             'Accident Year',
             paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 12*c(1:(length(dframe)-1)))
  }
  else {
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(dframe)))) {
      if (i == length(colnames(dframe))) {
        names <- c(names,paste(as.character((i-1)*12+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*12+adder),':',as.character((i-1)*12+adder+12),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
} #rename to the 12,24,... or the 15,27... name

############New LDF Code


LDF_Excel_Pull <- function(Program,Rolling_Year_End,AsOfDate,state) {
  AsOfDate<- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  losses <- dbGetQuery(con,paste0("SELECT [IndicationDate]
      ,[EvaluationDate]
      ,[TableName]
      ,[Class]
      ,[Years]
      ,[Region]
	  ,	colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ, colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ
  FROM [ActuarialSandbox].[",Program,"].[ldfTriangles]
  pivot (avg(columnValue) for columnName in (colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ) ) as PivotTable 
  where indicationDate = '",Rolling_Year_End,"'
                             and EvaluationDate = '",AsOfDate,"'
                             
  "))%>%
    filter(Region == state | Region == 'CW')
  return(losses)
} #working to create tabels on LDF tabs for CW, state, weighted

LDF_Tables <- function(dframe, Data.Region, Peril.Class) {
  dframe <- dframe%>%
    filter(Class == Peril.Class & Region == Data.Region)%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
  LDF_data <- dframe%>%
    filter(TableName == 'Averages')%>%
    select(-TableName)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','5 Yr. Wtd Avg','3 Yr. Wtd Avg')))
  
  LDF_data.fil <- LDF_data[,c(1,12:ncol(LDF_data))]
  LDF_data.filter <- LDF_data.fil[colSums(!is.na(LDF_data.fil)) > 0]
  LDF_data.filter[6,] <- ''
  LDF_data.filter[7,] <- c('Selections', paste0('=',toupper(letters)[2:(length(LDF_data.filter))],2))
  LDF_data.filter[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:(length(LDF_data.filter))],7,':',toupper(letters)[length(LDF_data.filter)],7,'),1)'))
  LDF_data.filter[7,4:ncol(LDF_data.filter)] <- 1
  columns <- jsonlite::fromJSON(paste0(c('[',paste0('{"type": ',c('"text"',rep('"number"',length(LDF_data.filter)-1)),' , "title":"',toupper(letters)[1:(length(LDF_data.filter))],'", "width": "100"}',c(rep(',',length(LDF_data.filter)-1),'')),']'), collapse = ' '))
  colnames(LDF_data.filter) <- toupper(letters)[1:(length(LDF_data.filter))]
  
  
  
  updateTable <- "function(instance, cell, col, row, val, label, cellName) {
          if (col >0 & row < 10 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0)
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row < 31 ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
        }
}"
  
  out.table <- excelTable(data = LDF_data.filter,columns = columns,updateTable = htmlwidgets::JS(updateTable),
                          allowDeleteColumn = F,
                          allowInsertRow = F,
                          allowInsertColumn = F,
                          allowDeleteRow = F,
                          autoWidth = F,columnSorting = F,columnResize = F)
  
  return(list(out.table, LDF_data.filter))
}

LDF_Translate <- function(dframe) { #The averages table is always 8 rows long
  
  for (i in colnames(dframe)) {
    if (i != "A" & i != "M" & !is.numeric(tryCatch(as.numeric(dframe[[i]][34]),warning = function(w){}, error = function(e) {})) ) {
      if (grepl('AVERAGE',dframe[[i]][34])) {
        dframe[[i]][34] <- Excel.Translate(dframe,i)
      } else {
        filter.string <- str_replace(paste0(str_replace_all(dframe[[i]][34],i,paste0("dframe[['",i,"']][")),']'),'=','')
        tryString <- tryCatch(as.numeric(eval(parse(text = filter.string))),warning = function(w){}, error = function(e) {})
        dframe[[i]][34] <- if (is.null(tryString)) 1 else tryString 
      }
    }
  }
  
  dframe[41,14:23] <- coalesce(as.numeric(dframe[34,2:11]) *as.numeric(dframe[39,22]) + as.numeric(dframe[34,14:23]) *(1-as.numeric(dframe[39,22])),1)
  for (i in 2:ncol(dframe)) {
    if(i <= 11) {
      dframe[35,i] <- prod(unlist(as.numeric(dframe[34,i:11]))) 
    } else if (i >=14) {
      dframe[35,i] <- prod(unlist(as.numeric(dframe[34,i:ncol(dframe)])))
      dframe[42,i] <- prod(unlist(as.numeric(dframe[41,i:ncol(dframe)]))) 
    }
  }
  
  return(dframe)
}

Excel.Translate <- function(dframe,i) {
  i.dframe <- dframe[[i]]
  ii <- i.dframe[34]
  i.filter <- ii
  for (j in unlist(gregexpr(paste0(':',i),ii)))  {
    i.filter <- str_replace(i.filter,substr(ii,j,j+2),paste0(substr(ii,j,j),substr(ii,j+2,j+2),']'))
  }
  i.filter <- str_replace_all(str_replace(i.filter,'=',''),i,paste0(i,'['))
  
  
  for (k in unlist(gregexpr('\\d)',i.filter))) {
    if (k >0) {
      i.filter <- str_replace(i.filter,paste0(substr(i.filter,k-1,k),']'),paste0(substr(i.filter,k,k),']'))
    }
  }
  for (j in unlist(gregexpr('\\d,',i.filter))) {
    if (j >0) {
      i.filter  <- str_replace(i.filter,paste0(substr(i.filter,j-1,j),']'),paste0(substr(i.filter,j,j),']'))
    }
  }
  
  i.dframe <- as.numeric(i.dframe[1:5])
  i.out <- tryCatch(as.numeric(eval(parse(text = str_replace_all(i.filter,i,'i.dframe')))),warning = function(w){}, error = function(e) {})
  i.out <- if (is.null(i.out)) dframe[[i]][33] else i.out
  
  return(i.out)
}

pull_ldfs <- function(Program, IndicationDate, EvaluationDate, Region,Class,CW=NA) {
  CW <- ifelse(is.na(CW), '', CW)
  
  dframe <- dbGetQuery(con, paste0("
    select * from ActuarialSandbox.",Program,".indicationSelections
    where columnName like '%LDF%Formula",CW,"'
    and Region = '",Region,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and class = '",Class,"'
    order by columnName
    "
  ))
  
  dframe <- dframe%>%
    filter(Status == ifelse('Published' %in% dframe$Status,'Published',
                            ifelse('In Review' %in% dframe$Staus, 'In Review', 'In Progress')))%>%
    select(columnValue)
  return(dframe[[1]])
}

column_names_ldf <- function(dframe,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  dframe <- dframe[colSums(!is.na(dframe)) > 0]
  if (table == 'Losses') {
    c(
      ifelse(month(Rolling_Year_End %m-% months(1))==12,
             'Accident Year',
             paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 12*c(1:(length(dframe)-1)))
  }
  else {
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(dframe)))) {
      if (i == length(colnames(dframe))) {
        names <- c(names,paste(as.character((i-1)*12+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*12+adder),':',as.character((i-1)*12+adder+12),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
}

LDF_Tables_All <- function(data,IndicationDate, EvaluationDate, class,State, LDFweight, state.formulas, cw.formulas) {
  dframe.state <- data%>%
    filter(Class == class & Region != 'CW')%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  print(1)
  LDF_data_Losses.State <- dframe.state[,1:12]%>%
    filter(TableName == 'Losses')%>% 
    select(-TableName)%>%   
    mutate(add2 = NA)%>%
    arrange(Years)
  print(2)
  LDF_data_LossRatio.State <- dframe.state[,c(1:2,13:ncol(dframe.state))]%>%
    filter(TableName == 'Loss Ratios')%>%  
    mutate(add = NA,add2 = NA)%>%
    arrange(Years)%>% 
    select(-TableName)
  print(3)
  LDF_data_Averages.State <- dframe.state[,c(1:2,13:ncol(dframe.state))]%>%
    filter(TableName == 'Averages')%>% 
    mutate(add = NA,add2 = NA)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','3 Yr. Wtd Avg','5 Yr. Wtd Avg')))%>% 
    select(-TableName)
  state.cols <- ncol(LDF_data_Averages.State)
  
  if (nrow(LDF_data_Losses.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Losses.State)))
    colnames(dummy) <- colnames(LDF_data_Losses.State)
    LDF_data_Losses.State <- dummy
    LDF_data_Losses.State[1,1] <- 'Not Enough Data'
  }  
  if (nrow(LDF_data_LossRatio.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_LossRatio.State)))
    colnames(dummy) <- colnames(LDF_data_LossRatio.State)
    LDF_data_LossRatio.State <- dummy
    LDF_data_LossRatio.State[1,1] <- 'Not Enough Data'
  }
  
  print(4)
  form.fill.state <- max(ncol(LDF_data_Averages.State[colSums(!is.na(LDF_data_Averages.State)) > 0]),1)
  if (nrow(LDF_data_Averages.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Averages.State)))
    colnames(dummy) <- colnames(LDF_data_Averages.State)
    LDF_data_Averages.State <- dummy
    LDF_data_Averages.State[1,1] <- 'Not Enough Data'
    LDF_data_Averages.State[6,1] <- NA
    LDF_data_Averages.State[7,1:2] <- c('Selections', NA)
    LDF_data_Averages.State[8,1:2] <-c('Cumulative', NA)
    
  } else {
    LDF_data_Averages.State[6,] <- NA
    fill.state.formulas <- if (length(state.formulas) > 0) state.formulas else paste0('=',toupper(letters)[2:form.fill.state],30)
    LDF_data_Averages.State[7,] <- c('Selections',fill.state.formulas, rep(NA,state.cols-form.fill.state))
    LDF_data_Averages.State[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:form.fill.state],34,':',toupper(letters)[form.fill.state],34,'),1)'), rep(NA,state.cols-form.fill.state))
    LDF_data_Averages.State[7,min(4,form.fill.state):form.fill.state] <- 1
  }
  
  colnames(LDF_data_Losses.State) <- colnames(LDF_data_LossRatio.State) <- colnames(LDF_data_Averages.State) <- toupper(letters)[1:state.cols]
  print(5)
  ###CW data
  dframe.CW <- data%>%
    filter(Class == class & Region == 'CW')%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
  LDF_data_Losses.CW <- dframe.CW[,1:12]%>%
    filter(TableName == 'Losses')%>%
    select(-TableName)%>%
    arrange(Years)
  
  LDF_data_LossRatio.CW <- dframe.CW[,c(1:2,13:ncol(dframe.CW))]%>%
    filter(TableName == 'Loss Ratios')%>%
    select(-TableName)%>%
    mutate(add = NA)%>%
    arrange(Years)
  
  LDF_data_Averages.CW <- dframe.CW[,c(1:2,13:ncol(dframe.CW))]%>%
    filter(TableName == 'Averages')%>%
    select(-TableName)%>%
    mutate(add = NA)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','3 Yr. Wtd Avg','5 Yr. Wtd Avg')))
  
  cw.cols <- ncol(LDF_data_Averages.CW)
  LDF_data_Averages.CW[6,] <- NA
  fill.cw.formulas <- if (length(cw.formulas) > 0) cw.formulas else  paste0('=',toupper(letters)[(state.cols+2):(state.cols + cw.cols-1)],30)
  LDF_data_Averages.CW[7,] <- c('Selections', fill.cw.formulas ,NA)
  LDF_data_Averages.CW[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[(state.cols+2):(state.cols + cw.cols-1)],34,':',toupper(letters)[(state.cols + cw.cols-1)],34,'),1)'),NA)
  LDF_data_Averages.CW[7,4:(ncol(LDF_data_Averages.CW)-1)] <- 1
  
  colnames(LDF_data_Losses.CW) <- colnames(LDF_data_LossRatio.CW) <- colnames(LDF_data_Averages.CW) <- toupper(letters)[(state.cols+1):(state.cols + cw.cols)]
  
  LDF_Table_All <- rbind(NA,NA,
                         merge(LDF_data_Losses.State%>%mutate(Join = A),LDF_data_Losses.CW%>%mutate(Join = M),by = 'Join', all = T)%>%select(-Join),NA,NA,NA,
                         merge(LDF_data_LossRatio.State%>%mutate(Join = A),LDF_data_LossRatio.CW%>%mutate(Join = M),by = 'Join', all = T)%>%select(-Join),NA,NA,NA,
                         cbind(LDF_data_Averages.State,LDF_data_Averages.CW),NA,NA,NA,NA,NA,NA,NA,NA)
  
  state.bold <- nrow(LDF_data_Losses.CW)-nrow(LDF_data_Losses.State)
  state.losses.colname <- column_names_ldf(LDF_data_Losses.State, 'Losses',IndicationDate, EvaluationDate)
  state.lossRatio.colname <- column_names_ldf(LDF_data_Losses.State, 'Loss Ratios',IndicationDate, EvaluationDate)
  
  cw.losses.colname <- column_names_ldf(LDF_data_Losses.CW, 'Losses', IndicationDate, EvaluationDate)
  cw.lossRatio.colname <- column_names_ldf(LDF_data_Losses.CW, 'Loss Ratios', IndicationDate, EvaluationDate)
  print(6)
  

  
  LDF_Table_All[(state.bold+2),1:length(state.losses.colname)] <-  state.losses.colname
  print(length(cw.losses.colname)+12)
  LDF_Table_All[2,13:(length(cw.losses.colname)+12)] <-  cw.losses.colname
  LDF_Table_All[(state.bold+1),1] <- LDF_Table_All[1,13] <- if (state.losses.colname[1] != 'Accident Year') 'Rolling Year' else NA
  LDF_Table_All[(state.bold+2),1] <- LDF_Table_All[2,13] <- if (state.losses.colname[1] != 'Accident Year')  paste0('Ending in ',month(as.Date('2022-07-01')-1),'/',day(as.Date('2022-07-01')-1)) else 'Accident Year'
  
  
  LDF_Table_All[(state.bold+15),1:length(state.lossRatio.colname)] <-  state.lossRatio.colname
  LDF_Table_All[15,13:(length(cw.lossRatio.colname)+12)] <-  cw.lossRatio.colname
  LDF_Table_All[(state.bold)+14,1] <- LDF_Table_All[14,13] <- if (state.losses.colname[1] != 'Accident Year') 'Rolling Year' else NA
  LDF_Table_All[(state.bold)+15,1] <- LDF_Table_All[15,13] <- if (state.losses.colname[1] != 'Accident Year')  paste0('Ending in ',month(as.Date('2022-07-01')-1),'/',day(as.Date('2022-07-01')-1)) else 'Accident Year'
  print(6.5)
  LDF_Table_All[41,13:23] <- c('Selections', paste0('=IF(ISBLANK(',toupper(letters)[2:10],34,'),1,',toupper(letters)[2:10],34,')* V39 + ',toupper(letters)[14:22],'34* (1-V39)'),NA)
  LDF_Table_All[42,13:23] <- c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[14:22],41,':',toupper(letters)[22],41,'),1)'),NA)
  
  LDF_Table_All[39,21:22] <- c(paste0(State,' Weight:'), LDFweight)
  print(7)
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"110"},
  { "type": "number", "title": "B" ,"width":"80"},
  { "type": "number", "title": "C" ,"width":"80"},
  { "type": "number", "title": "D" ,"width":"80"},
  { "type": "number", "title": "E" ,"width":"80"},
  { "type": "number", "title": "F" ,"width":"80"},
  { "type": "number", "title": "G" ,"width":"80"},
  { "type": "number", "title": "H" ,"width":"80"},
  { "type": "number", "title": "I" ,"width":"80"},
  { "type": "number", "title": "J" ,"width":"80"},
  { "type": "number", "title": "K" ,"width":"80"},
  { "type": "text",  "title": "L" ,"width":"50"},
  { "type": "text",  "title": "M" ,"width":"110"},
  { "type": "number", "title": "N" ,"width":"85"},
  { "type": "number", "title": "O" ,"width":"85"},
  { "type": "number", "title": "P" ,"width":"85"},
  { "type": "number", "title": "Q" ,"width":"85"},
  { "type": "number", "title": "R" ,"width":"85"},
  { "type": "number", "title": "S" ,"width":"85"},
  { "type": "number", "title": "T" ,"width":"85"},
  { "type": "number", "title": "U" ,"width":"85"},
  { "type": "number", "title": "V" ,"width":"85"},
  { "type": "number", "title": "W" ,"width":"85"}
  ]')
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if (col < 11 & (row == ",state.bold," | row == ",state.bold+1," |  row == ",state.bold + 13,"  | row == ",state.bold + 14," ))  {
            txt = cell.innerText;
            cell.innerHTML = txt.bold();
            if ( (row == ",state.bold+1," | row == ",state.bold + 14,") & col <=",form.fill.state," ) {
            cell.style.borderBottomColor = 'black';
            }
        } else if (col > 11 & (row == 0 | row == 1 | row == 13 | row ==14) ) {
            txt = cell.innerText;
            cell.innerHTML = txt.bold();
            if (row == 1 | row == 14 ) {
            cell.style.borderBottomColor = 'black';
            }
        } else if (col >0 & row < 15 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0);
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row < 43 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
          }
        
        if ( (col == 11 & row <= 36) | row == 36) {
            cell.style.backgroundColor = 'lightgrey';
        }
        if (col == 21 & row == 38) {
             cell.style.outline = 'thin solid';
        }
        if (col <= 21 & col >=20 & row == 38 ) {
            cell.style.backgroundColor = 'lightblue';
        }
        if (row >= 40 & row <= 41) {
            txt2 = cell.innerText;
            cell.innerHTML = txt2.bold();
        }
        
}")
  out.table <- excelTable(data = LDF_Table_All,columns = columns,updateTable = htmlwidgets::JS(updateTable),
                          allowDeleteColumn = F,
                          allowInsertRow = F,
                          allowInsertColumn = F,
                          allowDeleteRow = F,
                          autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = F
  )
  return(list(out.table, LDF_Table_All))
}

save_selections_LDF <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,
                                LDF.state.formulas,
                                LDF.cw.formulas,
                                LDF.final.cumulative,
                                weight,selected_by,technicalReviewer, PeerReviewer){
  
  
  saveLDF <- function(variable, number, subregion) {
    dbGetQuery(con,paste0("
select
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
'LDF",paste0(number,deparse(substitute(variable)),subregion),"' as columnName,
cast('",variable,"' as nvarchar(50)) as columnValue, 
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
into #load

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
  }
  
  
  for (i in 1:length(LDF.final.cumulative)) { 
    CumulativeFinal <- LDF.final.cumulative[[i]]
    saveLDF(CumulativeFinal,i,'') 
  }
  
  for (i in 1:length(LDF.state.formulas)) { 
    SelectFormula <- LDF.state.formulas[i]
    saveLDF(SelectFormula,i,'')
  }
  for (i in 1:length(LDF.cw.formulas)) { 
    SelectFormula <- LDF.cw.formulas[i]
    saveLDF(SelectFormula,i,'CW')
  }
  saveLDF(weight,'','')
}

#Premium Trend
#Premium On-Level Factors > absorb calculation into premium trend SP
#Targit Data
premium_trend_data <- function(Program,IndicationDate, EvaluationDate, State) {
  Evalutionadjust <- ifelse(as.Date(EvaluationDate)<as.Date('2022-06-01'),'2022-06-01', EvaluationDate)
  dframe <- dbGetQuery(con,paste0("
        select top (24) Date, EHY, EP, AdjustedEP
        from ActuarialSandbox.",Program,".PremiumTrend 
        where IndicationDate = '",IndicationDate,"'
        and EvaluationDate = '",Evalutionadjust,"'
        and state = '",State,"'
        order by Date desc
        ")
  )%>%
    arrange(Date)
  return(dframe)
}

premium_trend <- function(dframe) {
  df_out <- data.frame(matrix(ncol=6,nrow=1))
  colnames(df_out) <- c('Index', 'Date','Year Ending Quarter - X', 'Earned Exposures', 'Earned Premium', 'Adjusted Earned Premium') #, 'Frequency','Severity','Pure Premium')
  
  if (nrow(dframe) > 4) {
  for (row in (nrow(dframe)):4) {
    df_out <- df_out%>%
      add_row(Index = row,
              Date = as.Date(dframe[["Date"]][row]),
              `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(dframe[["Date"]][row])),' - ', year( as.Date(dframe[["Date"]][row]))),  #paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['EHY']][max((row-3),0):row]),
              `Earned Premium`=sum(dframe[['EP']][max((row-3),0):row]),
              `Adjusted Earned Premium`=sum(dframe[['AdjustedEP']][max((row-3),0):row]))
  }
  } else {
    df_out <- df_out%>%
      add_row(Index = nrow(dframe),
              Date = as.Date(dframe[["Date"]][nrow(dframe)]),
              `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(dframe[["Date"]][nrow(dframe)])),' - ', year( as.Date(dframe[["Date"]][nrow(dframe)]))),  #paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['EHY']]),
              `Earned Premium`=sum(dframe[['EP']]),
              `Adjusted Earned Premium`=sum(dframe[['AdjustedEP']]))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(`Average Earned Premium at CRL` = `Adjusted Earned Premium`/`Earned Exposures`)%>%
    arrange(Index)%>%
    select (-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
}

logest <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  exp(coef(result))
}

premium_trend_fitting <- function(data,lagtime){
  print('enter')
  dframe <- data%>%
    mutate(day_num = as.numeric(lubridate::ceiling_date(as.Date(Date),'month')-1)/365)%>%
    select(day_num,`Average Earned Premium at CRL`)
  df_out <- data.frame(matrix(ncol = 2,nrow=1))
  colnames(df_out) <- c('Exponential Trend','Pure Premium')
  fill_range <- if (nrow(data) > 20) {c(24,20,16,12,8,4)}
                else if (nrow(data) > 12) {c(20,16,12,8,6,4)}
                else if (nrow(data) > 8) {c(16,12,8,6,4)}
                else {c(8,6,4,2)}
  
  for (pt in fill_range) {
    print(nrow(data)-pt-lagtime+1)
    print(nrow(data)-lagtime)
    if ((nrow(data)-pt-lagtime+1)>0) {
      print('premium fitting!!!!!!!!!!!!!')
      print(dframe[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                `Pure Premium`=logest(dframe[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}


loss_trend_cw <- function(program,IndicationDate,EvaluationDate) {
  dframe <- dbGetQuery(con, paste0(
    "SELECT *
  FROM [ActuarialSandbox].[",program,"].[LossTrend]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
    "
  ))%>%
    arrange(state,Accident_Year, Accident_Year_Quarter)%>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index','Year','Quarter', 'Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(dframe)):4) {
    df_out <- df_out%>%
      add_row(Index=row,
              Year = dframe[["Accident_Year"]][row],
              Quarter = dframe[["Accident_Year_Quarter"]][row],
              `Year Ending Quarter - X` = paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['Earned Exposures']][(row-3):row]),
              `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']][(row-3):row]),
              `Incurred Claims`=sum(dframe[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(dframe$Accident_Year_Quarter[row]),' - ',as.character(dframe$AccidentYear[row])))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(Frequency = `Incurred Claims`/`Earned Exposures`*100,
           Severity = `Capped Incurred Loss & LAE`/`Incurred Claims`)%>%
    mutate(`Pure Premium` =Frequency*Severity/100)%>%
    arrange(Index)%>%
    select(-Index)
  
  data_clean <- na.omit(df_out)
  return(data_clean)
}

loss_trend_state <- function(program,IndicationDate,EvaluationDate,input_state) {
  print('in')
  dframe <- dbGetQuery(con, paste0(
    "SELECT *
  FROM [ActuarialSandbox].[",program,"].[LossTrend]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and state = '",input_state,"'  
  and dateadd(day, 1,EOMONTH(DATEFROMPARTS(Accident_Year,Accident_Year_Quarter*3,1))) > dateadd(quarter, 1,dateadd(year,-7,'",IndicationDate,"'))
  and concat(Accident_Year,Accident_Year_Quarter) >= (
    select  min(concat(year, quarter)) 
    from ActuarialSandbox.ho.targitPolicyMonth
    where state = '",input_state,"' )
    "
  ))%>%
    arrange(state,Accident_Year, Accident_Year_Quarter)%>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  print('loaded')
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index', 'Year','Quarter','Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  
  if (nrow(dframe) > 4) {
    for (row in (nrow(dframe)):4) {
      df_out <- df_out%>%
        add_row(Index=row,
                Year = dframe[["Accident_Year"]][row],
                Quarter = dframe[["Accident_Year_Quarter"]][row],
                `Year Ending Quarter - X`=paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
                `Earned Exposures`=sum(dframe[['Earned Exposures']][(row-3):row]),
                `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']][(row-3):row]),
                `Incurred Claims`=sum(dframe[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(dframe$Accident_Year_Quarter[row]),' - ',as.character(dframe$AccidentYear[row])))
    }
  } else {
    df_out <- df_out%>%
      add_row(Index=nrow(dframe),
              Year = dframe[["Accident_Year"]][nrow(dframe)],
              Quarter = dframe[["Accident_Year_Quarter"]][nrow(dframe)],
              `Year Ending Quarter - X`=paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][nrow(dframe)]),' - ',as.character(dframe[["Accident_Year"]][nrow(dframe)])),
              `Earned Exposures`=sum(dframe[['Earned Exposures']]),
              `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']]),
              `Incurred Claims`=sum(dframe[['Incurred Claims']]))
  }
  
  #name the columns for display order based on above
  
  df_out <- df_out%>%
    mutate(Frequency = coalesce(`Incurred Claims`/`Earned Exposures`*100,0),
           Severity = coalesce(`Capped Incurred Loss & LAE`/`Incurred Claims`,0))%>%
    mutate(`Pure Premium` =coalesce(Frequency*Severity/100,0))%>%
    arrange(Index)%>%
    select(-Index)
  
  return(na.omit(df_out))
  
}


loss_trend_fitting <- function(data,lagtime) { 
  dframe <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365,0))%>%
    select(day_num,Frequency, Severity, `Pure Premium`)
  df_out <- data.frame(matrix(ncol = 4,nrow=1))
  colnames(df_out) <- c('Exponential Trend', 'Frequency','Severity','Pure Premium')
  
  fill_range <- if (nrow(data) > 20) {c(24,20,16,12,8,4)}
                else if (nrow(data) > 12) {c(20,16,12,8,6,4)}
                else if (nrow(data) > 8) {c(16,12,8,6,4)}
                else {c(8,6,4,2)}
  
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                Frequency=logest(dframe[['Frequency']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1, #select the right rows accounting for lag time
                Severity=logest(dframe[['Severity']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1,
                `Pure Premium`=logest(dframe[['Pure Premium']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#Loss Trend Plots functions
logest_fit <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  #exp(coef(result))
}

loss_trend_fitting_plot <- function(data,pt,name) {
  data$varChoose <- data[[name]]
  
  data1 <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365.25,0),
           YearQuarter = `Year Ending Quarter - X`)%>%
    separate(YearQuarter,into = c('one', 'two'), sep = ' - ')%>%
    unite('YearQuarter',c('two', 'one'), sep = ' - ')%>%
    select(YearQuarter,day_num,varChoose)
  
  data2 <- na.omit(data1)
  
  data2$Index <- 1:nrow(data2)

  chosenName=logest_fit(data2$varChoose[(nrow(data2)-pt+1):(nrow(data2))],data2[['day_num']][(nrow(data2)-pt+1):(nrow(data2))])
  
  data2 <- data2%>%
    mutate(IndexA = ifelse(Index > nrow(data2)-pt,1,NA))%>%
    select(YearQuarter, IndexA)
  
  data3 <- na.omit(data2)
  
  data1 <- data1%>%
    left_join(data2, by = c('YearQuarter'='YearQuarter'))%>%
    mutate(plotName = ifelse(YearQuarter >= min(data3$YearQuarter), exp(chosenName$coefficients['(Intercept)'] + chosenName$coefficients['x'] * day_num) ,NA),
           day_num = as.Date(day_num*365.25, origin = "1970-01-01"))
  
  return(list(data1,chosenName, summary(chosenName)))
}


#LLL 

LLL_pull <- function(Program, IndicationDate, EvaluationDate, proposedEffective, State, currentLoss, projLoss, capped, peril) {
  IndicationDate<- as.Date(IndicationDate)
  lossTrendPeriod <- round(((as.numeric(as.Date(proposedEffective))+365.25) - (as.numeric(as.Date(IndicationDate)-1)-(365.25/2)))/365.25,2)
  
  dframe <- dbGetQuery(con, paste0("
Declare @Rolling_Year_End varchar(10) = '",IndicationDate,"', 
        @As_Of_Date varchar(10) ='",EvaluationDate,"',
        @state varchar(2)='",State,"',
        @current decimal(16,10)=",currentLoss,",
        @proj decimal(16,10)=",projLoss,",
        @loss_trend_period decimal(16,10)=",lossTrendPeriod,",
        @capped int=",capped,",
        @peril varchar(20) = '",peril,"'
 DECLARE @Indication_Year varchar(4) = year(DATEADD(month,-1,@Rolling_Year_End))
;
 with #CW as (select claimIncidentNum, Loss_Rolling_Year,sum(total_incurred) as total_incurred
				from ActuarialSandbox.",Program,".LLLperilData 
				where state like case when @state = 'CW' then '%%' else @state end
				and IndicationDate = @Rolling_Year_End
				and EvaluationDate = @As_Of_Date
				and peril like case when @peril = 'All Perils' then '%%' else @peril end
				group by claimIncidentNum, Loss_Rolling_Year),
	 #CW1 as ( select Loss_Rolling_Year, 
				 count(Total_Incurred) as [Number of Excess Claims],
				 sum(Total_Incurred) * ROUND(POWER(1+@current,@Indication_Year - Loss_Rolling_Year)*POWER(1+@proj,@loss_trend_period),6) as [Ground Up Excess Losses],
				 sum(Total_Incurred) * ROUND(POWER(1+@current,@Indication_Year - Loss_Rolling_Year)*POWER(1+@proj,@loss_trend_period),6) - @capped*count(Total_Incurred) as [Losses Excess of Cap]
				 from
				 #CW 
				 where Total_Incurred*ROUND(POWER(1+@current,@Indication_Year - Loss_Rolling_Year)*POWER(1+@proj,@loss_trend_period),6) > 250000
				 group by Loss_Rolling_Year),
	#CW2 as (select Loss_Rolling_Year, 
			 sum(Total_Incurred) * ROUND(POWER(1+@current,@Indication_Year - Loss_Rolling_Year)*POWER(1+@proj,@loss_trend_period),6) as [Trended Incurred]
			 from #CW
			 group by Loss_Rolling_Year)
 select 
      b.Loss_Rolling_Year,
      coalesce([Trended Incurred],0) as [Trended Incurred],
      coalesce([Number of Excess Claims],0) as [Number of Excess Claims],
      coalesce([Ground Up Excess Losses],0) as [Ground Up Excess Losses],
       coalesce([Losses Excess of Cap],0) as [Losses Excess of Cap] ,
      coalesce([Trended Incurred] - coalesce([Losses Excess of Cap],0),0) as [Non-Excess Losses], 
      coalesce([Losses Excess of Cap] / ( [Trended Incurred] - [Losses Excess of Cap]),0) as [Excess Ratio]
 from
 #CW2 b
 left join #CW1 a on a.Loss_Rolling_Year=b.Loss_Rolling_Year
 order by b.Loss_Rolling_Year
                                 "))
  colnames(dframe)[1] <- ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))) ,'/', as.character(day(IndicationDate %m-% days(1)))))
  colnames(dframe)[2] <- paste0('Incurred Losses Trended to ', year(IndicationDate %m-% months(1)))
  dframe[nrow(dframe)+1,] <-c('Total',sum(dframe[2]),sum(dframe[3]),sum(dframe[4]),sum(dframe[5]),sum(dframe[6]),coalesce(sum(dframe[5])/sum(dframe[6]),0)) #add totals row here
  
  return(dframe)
  
}

LLL_selections <- function(data,name) {#function that outputs dframe with the calculated Large Loss Load, and defaults the selected to the calculated
  out <- data.frame()
  out[name,'Large Loss Load']<- 1+as.numeric(data[data[1]== 'Total',]$`Excess Ratio`)
  return(out)
}
#expense exhibit

LLL_weighted <- function(cw_data, state_data, weight){
  out <- data.frame()
  out['Selected','Weighted LLL'] <-coalesce(as.numeric(cw_data['Selected','Large Loss Load']) * (1-weight) + coalesce(as.numeric(state_data['Selected','Large Loss Load']),1) * weight,1)
  return(out)
}

profit <- function(state, IndicationDate,Program) {
  dframe <- dbGetQuery(con, paste0(
    "select [profitLoad]
        from [ActuarialSandbox].[",Program,"].[profitContingency]
        where State = '",state,"'
        and '",IndicationDate,"' between rowStartDate and rowEndDate
        "
  ))
  if (nrow(dframe)<1) {
    dframe[1,1] <- 0.05 #do not have profit target stored for all states yet
  }
  return(dframe)
}
reinsurance <- function(state, EvaluationDate,Program,peril) {
  dframe <- dbGetQuery(con, paste0(
    "select [Premium Rate Current]
        from [ActuarialSandbox].[",Program,"].[CostOfReinsurance]
        where State = '",state,"'
        and '",EvaluationDate,"' between rowStartDate and rowEndDate
        and peril = '",peril,"'
        "
  )) 
  dreturn <- if(nrow(dframe)==0) data.frame(0) else dframe
 
  return(dreturn)
}

df_transpose <- function(dframe) {
  dframe <- sjmisc::rotate_df(dframe)
  colnames(dframe) <- as.character(unlist(dframe[1,]))
  dframe[-1,]
}

expense_load <- function(IndicationDate, EvaluationDate, state,Program) {
  dframe <- dbGetQuery(con,paste0(
    "DECLARE @IndicationDate varchar(10) = '",IndicationDate,"'
      DECLARE @IndicationYear varchar(4) = year(@IndicationDate)
      SELECT 
        Year
        ,[Written Premium]/1000 as [Written Premium]
        ,[Earned Premium]/1000 as [Earned Premium]
        ,[Commission]/1000 as [Commission]
        ,[Other Acquisition]/1000 as [Other Acquisition]
        ,[General Expenses]/1000 as [General Expenses]
        ,[Taxes Licenses & Fees]/1000 as [Taxes Licenses & Fees]
    FROM [ActuarialSandbox].[",Program,"].[ExpenseIEE]
    where Year between @IndicationYear-3 and @IndicationYear-1"
  ))%>%
    arrange(Year)

  df_out <- df_transpose(dframe)
  
  save_names <- colnames(df_out)
  
  colnames(df_out) <- c('year3','year2','year1')
  
  df_next <- df_out%>%
    mutate(year3per=NA,year2per=NA,year1per=NA, average=NA, selected=NA)
  
  df_next['Commission','year3per']<- as.numeric(df_next['Commission','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Commission','year2per']<- as.numeric(df_next['Commission','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Commission','year1per']<- as.numeric(df_next['Commission','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['Other Acquisition','year3per']<- as.numeric(df_next['Other Acquisition','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Other Acquisition','year2per']<- as.numeric(df_next['Other Acquisition','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Other Acquisition','year1per']<- as.numeric(df_next['Other Acquisition','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['General Expenses','year3per']<- as.numeric(df_next['General Expenses','year3'])/as.numeric(df_next['Earned Premium','year3'])
  df_next['General Expenses','year2per']<- as.numeric(df_next['General Expenses','year2'])/as.numeric(df_next['Earned Premium','year2'])
  df_next['General Expenses','year1per']<- as.numeric(df_next['General Expenses','year1'])/as.numeric(df_next['Earned Premium','year1'])
  df_next['Taxes Licenses & Fees','year3per']<- as.numeric(df_next['Taxes Licenses & Fees','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Taxes Licenses & Fees','year2per']<- as.numeric(df_next['Taxes Licenses & Fees','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Taxes Licenses & Fees','year1per']<- as.numeric(df_next['Taxes Licenses & Fees','year1'])/as.numeric(df_next['Written Premium','year1'])
  
  df_next['Commission','average']<- (as.numeric(df_next['Commission','year1'])+
                                       as.numeric(df_next['Commission','year2'])+
                                       as.numeric(df_next['Commission','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['Other Acquisition','average']<- (as.numeric(df_next['Other Acquisition','year1'])+
                                              as.numeric(df_next['Other Acquisition','year2'])+
                                              as.numeric(df_next['Other Acquisition','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['General Expenses','average']<- (as.numeric(df_next['General Expenses','year1'])+
                                             as.numeric(df_next['General Expenses','year2'])+
                                             as.numeric(df_next['General Expenses','year3']))/sum(as.numeric(df_next['Earned Premium',]),na.rm=T)
  df_next['Taxes Licenses & Fees','average']<- (as.numeric(df_next['Taxes Licenses & Fees','year1'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year2'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next$selected <- df_next$average
  df_table <- df_next[c('year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  df_table['','selected']<- NA
  df_table['Reinsurance Provision', 'selected'] <- reinsurance(state,EvaluationDate,Program,'All Perils')
  df_table[' ','selected']<- NA
  df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected'] <- df_next['Commission','selected']+
    df_next['Other Acquisition','selected']+
    df_next['General Expenses','selected']+
    df_next['Taxes Licenses & Fees','selected']+
    df_table['Reinsurance Provision', 'selected']
  df_table['  ','selected']<- NA
  df_table['Profit Load','selected'] <- profit(state,IndicationDate,Program)
  df_table['Total Expenses & Profit = (8) + (9)', 'selected'] <- df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected']+df_table['Profit Load','selected']
  df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected'] <- 1-df_table['Total Expenses & Profit = (8) + (9)', 'selected']
  df_table['Fixed Expense Ratio = (4) + (5)','selected'] <- df_next['Other Acquisition','selected']+df_next['General Expenses','selected']
  df_table['   ','selected']<- NA
  df_table['Permissible Loss, LAE, & Fixed Expense Ratio = (11) + (12)','selected'] <- df_table['Fixed Expense Ratio = (4) + (5)','selected']+df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected']
  df_table$names <- rownames(df_table)
  df_table$ids <- c('(1)','(2)','(3)','(4)','(5)','(6)','','(7)','','(8)','','(9)','(10)','(11)','(12)','','(13)')
  df_table <- df_table[c('ids','names','year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  
  colnames(df_table)<-c('','',save_names[1],'',save_names[2],'',save_names[3],'','3 Yr Average', 'Selected')
  return(df_table)
}
#reinsurance table
#add to Sandbox

#indication
#parts of all previous tabs as inputs
#by peril tabs 
on_level_factors_load <- function(Program,IndicationDate, State) {
  dframe <- dbGetQuery(con,paste0("
  select * from ActuarialSandbox.",Program,".onLevelFactors
  where IndicationDate = '",IndicationDate,"' and state = '",State,"'
  order by CalenderYear
  "))%>%
    mutate(CalenderYear = as.character(CalenderYear))
  return(dframe)
}

coverage_report_load <- function(IndicationDate, EvaluationDate, State,Program,data.source) {
  dframe <- dbGetQuery(con, paste0("
      select RollingYear, ReratedEP ,ptsEHY, policyCharge , Peril,TotalIncurred,CappedTotalIncurred, claimCount from ActuarialSandbox.",Program,".coveragereport
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and state = '",State,"'
      and source = '",data.source,"'
      order by Peril, RollingYear
                               "))
  return(dframe)
}

targit_EP_load <- function(Program,IndicationDate, EvaluationDate, State){
  dframe <- dbGetQuery(con, paste0("
  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  EP decimal(16,6))
  Insert @T Exec ActuarialSandbox.",Program,".sp_IndicationEP  '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T
  "
  ))
  return(dframe)
}

rate_level_losses <- function (Program,IndicationDate,EvaluationDate,State) {
  dframe <- dbGetQuery(con,paste0(
    "  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  [Capped Incurred Loss & LAE] decimal(16,6),
  				  [Incurred Claims] int)
  Insert @T Exec ActuarialSandbox.",Program,".sp_IndicationLossSummary '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T"
  ))
  
  return(dframe)
}

rate_level_indication <- function(Program,on_level, coverageReport, targitPrem, Policyfee, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect) {
  IndicationDate <- as.Date(IndicationDate)
  print(1)
  dframe <- on_level
  print(1.5)
  #if we include policy fee then use the pts EP with the policyCharge
  if (Policyfee == 'Y' & perilTab == 'All Perils') {
    dframe <- dframe%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP + policyCharge)%>%
      select(CalenderYear,EP, OnLevelFactor)
  } 
  else if (Policyfee == 'N' & perilTab == 'All Perils') { #otherwise use the EP stored in Targit for total tab
    print(1.51)
    print(targitPrem)
    dframe <- dframe%>%
      left_join(targitPrem, by = c('CalenderYear' = 'Year'))%>%
      select(CalenderYear,EP, OnLevelFactor)
  } else { #use rerated EP for each of the perils
    dframe <- dframe%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP)%>%
      select (-ReratedEP , -policyCharge, -Peril)%>%
      select(CalenderYear,EP, OnLevelFactor)
  }
  print(2)
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate)-1)-365.25/2))/365.25,2)
  print(premium_trend_period)
  print(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25)
  print(3)
  dframe <- dframe %>%
    filter(EP >0)%>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(TrendedPremium = EP * OnLevelFactor * PremTrend)
  
  print(4)
  #add in the Capped Incurred Losses
  losses <- rate_level_losses(Program,IndicationDate, EvaluationDate, state)%>%
    mutate(Year = as.character(Year))
  
  print(5)
  losses2 <- coverageReport%>%
    filter(Peril==perilTab)%>%
    mutate(`Capped Incurred Loss & LAE` = CappedTotalIncurred)%>%
    select(RollingYear, `Capped Incurred Loss & LAE`)
  
  print(6)
  dframe <- dframe%>%
    #left_join(losses, by = c('CalenderYear' = 'Year'))%>%
    #select(-`Incurred Claims`)%>%
    left_join(losses2, by = c('CalenderYear' = 'RollingYear'))%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(`Capped Incurred Loss & LAE`),0,`Capped Incurred Loss & LAE`))
  
  print(7)
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  # colnames(LDFselect)[1:6] <- c('Name', IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)
  # LDFselect.mutate <- LDFselect[LDFselect$Name == 'Cumulative',][1:6]%>%
  #   pivot_longer(!Name, names_to = 'Year', values_to = 'LDF')%>%
  #   select(-Name)%>%
  #   mutate(LDF = as.numeric(LDF)) 
  # 
  # print(LDFselect.mutate)
  LDFselect.mutate <- data.frame(Year = as.character(c(IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)), LDF = as.numeric(LDFselect[,2:6]))
  
  
  print(8)
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate)-1)-365.25/2))/365.25,2)
  dframe <- dframe %>%
    left_join(LDFselect.mutate, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL)%>%
    mutate(LAERatio = AdjustedLosses/TrendedPremium)
  dframe <- dframe%>% 
    add_row(CalenderYear = 'Total',
            EP = sum(dframe$EP),
            OnLevelFactor = NA,
            PremTrend = NA,
            TrendedPremium = sum(dframe$TrendedPremium,na.rm=T),
            `Capped Incurred Loss & LAE` = sum(dframe$`Capped Incurred Loss & LAE`,na.rm=T),
            LDF = NA,
            LossTrend = NA,
            LLL = NA,
            AdjustedLosses = sum(dframe$AdjustedLosses,na.rm=T),
            LAERatio = sum(dframe$AdjustedLosses,na.rm=T)/sum(dframe$TrendedPremium,na.rm=T))
  
  #dframe$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(dframe$CalenderYear)-1) ,dframe$CalenderYear) 
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Earned Premium', 'On-Level Factor', 'Premium Trend', 'Trended On-Level Premium', 'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', 'Projected Loss & LAE Ratio (ex Cat)')
  
  return(dframe)
}

rate_level_summary<- function(rate_df, cat_df,expense_ratios,rate_level_losses,projPrem, projLoss,sts_adj,hu_adj, peril) {
  out <- data.frame(matrix(ncol = 2,nrow = 0))
  colnames(out) <- c('',' ')
  hurr_add <- 0
  sts_add <- 0
  hur_LAE <- 0
  sts_LAE <- 0
  if ('Hurricane' %in% peril) {
    hurr_add <- 1
    hur_LAE <- cat_df$`Modeled Hurricane Loss & LAE Ratio`*hu_adj
    out['(11)',] <- c('Projected Hurricane Loss & LAE Ratio',cat_df$`Modeled Hurricane Loss & LAE Ratio` * hu_adj)
  } 
  if ('STS' %in% peril) {
    sts_add <- 1
    sts_LAE <- cat_df$`Modeled CS Loss & LAE Ratio`*sts_adj
    out[paste0('(',11+hurr_add,')'),] <- c('Projected Wind/Hail Loss & LAE Ratio',cat_df$`Modeled CS Loss & LAE Ratio` * sts_adj)
  }
  
  out[paste0('(',11+hurr_add+sts_add,')'),] <- c('Projected Loss & LAE Ratio',rate_df[rate_df[1]=='Total',]$`Projected Loss & LAE Ratio (ex Cat)`+hur_LAE+sts_LAE)
  out[paste0('(',12+hurr_add+sts_add,')'),] <- c('Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  out[paste0('(',13+hurr_add+sts_add,')'),] <- c('Projected Loss, LAE, & Fixed Expense Ratio',as.numeric(out[paste0('(',12+hurr_add+sts_add,')'),' '])+as.numeric(out[paste0('(',11+hurr_add+sts_add,')'), ' ']))
  out[paste0('(',14+hurr_add+sts_add,')'),] <- c('Permissible Loss, LAE, & Fixed Expense Ratio',as.numeric(out[paste0('(',12+hurr_add+sts_add,')'),' '])+(1-expense_ratios['Total Expenses & Profit','Selected']))
  out[paste0('(',15+hurr_add+sts_add,')'),] <- c('Raw Indicated Rate Level Change',as.numeric(out[paste0('(',13+hurr_add+sts_add,')'),' '])/as.numeric(out[paste0('(',14+hurr_add+sts_add,')'),' '])-1)
  out[paste0('(',16+hurr_add+sts_add,')'),] <- c('Credibility',min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1))
  out[paste0('(',17+hurr_add+sts_add,')'),] <- c('Compliment of Credibility',(1+projLoss)/(1+projPrem)-1)
  out[paste0('(',18+hurr_add+sts_add,')'),] <- c('Credibility-weighted Indicated Rate Level Change',as.numeric(out[paste0('(',15+hurr_add+sts_add,')'), ' '])*as.numeric(out[paste0('(',16+hurr_add+sts_add,')'),' '])+as.numeric(out[paste0('(',17+hurr_add+sts_add,')'),' '])*(1-as.numeric(out[paste0('(',16+hurr_add+sts_add,')'),' '])))
  
  return(out)
}

credibility_exhibit <- function(rate_level_losses) {
  dframe <- data.frame(matrix(ncol=3,nrow=0))
  dframe[1,] <- c(format(sum(round(rate_level_losses$`Incurred Claims`),0),big.mark = ','),format(round(1082,0),big.mark = ','),paste0(format(round(100*min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1),0)),'%'))
  colnames(dframe) <- c('Earned Exposures','Full Credibility Standard', 'Credibility')
  return(dframe)
}

on_level_cumulative <- function(IndicationDate,Program,State) {
  dframe <- dbGetQuery(con, paste0(
    "select EffectiveDate as [Eff. Date Renewal], RateChange as [Rate Change], Cumulative
    from ActuarialSandbox.",Program,".cumulativeRateChanges
    where IndicationDate = '",IndicationDate,"'
    and state = '",State,"'
    "
  ))
  return(dframe)
}

rate_level_indication_peril <- function(on_level, proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect,coverageReport,peril) {
  IndicationDate <- as.Date(IndicationDate) 
  dframe <- on_level%>%
    select(CalenderYear)
  #if we include policy fee then use the pts EP with the policyCharge
  #add in the Capped Incurred Losses 
  losses <- coverageReport%>%
    filter(Peril == peril)%>%
    select(RollingYear, CappedTotalIncurred, claimCount, ReratedEP)%>%
    mutate(RollingYear = as.character(RollingYear)) 
  dframe <- dframe%>%
    left_join(losses, by = c('CalenderYear' = 'RollingYear'))%>%
    filter(ReratedEP>0)%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(CappedTotalIncurred),0,CappedTotalIncurred)) 
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  print(LDFselect)
  print(LDFselect[,2:6])
  LDFselect.mutate <- data.frame(Year = as.character(c(IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)), 
                                 LDF = as.numeric(LDFselect[,2:6]))
  
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate)-1)-365.25/2))/365.25,2) 
  dframe <- dframe %>%
    left_join(LDFselect.mutate, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL,claimCount = ifelse(is.na(claimCount),0,claimCount))%>%
    select(CalenderYear, `Capped Incurred Loss & LAE`, LDF,LossTrend, LLL,AdjustedLosses,claimCount) 
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', '# of Claims')
   
  return(dframe)
}

rate_level_indication_prem_peril <- function(on_level, coverageReport, perilTab,currentPrem, projPrem,proposedEffectiveDate,
                                             IndicationDate,EvaluationDate,state,byperil) {
  IndicationDate <- as.Date(IndicationDate)
  dframe <- on_level
  dframe <- dframe%>%
    left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
    filter(Peril == perilTab)%>%
    mutate(EP = ReratedEP,EHY = ptsEHY)%>%
    select(CalenderYear,EP, OnLevelFactor,EHY)
  
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate)-1)-365.25/2))/365.25,2)
  dframe <- dframe %>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(dframe$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(OnLevelFactor = ifelse(byperil == 'Y',1,OnLevelFactor))%>%
    mutate(spacer = NA,TrendedPremium = EP * OnLevelFactor * PremTrend)%>%
    select(CalenderYear,EP, OnLevelFactor,PremTrend,spacer,TrendedPremium,EHY)
  
  
  
  #dframe$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(dframe$CalenderYear)-1) ,dframe$CalenderYear) 
  colnames(dframe) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Rerated Premium', 'On-Level Factor', 'Premium Trend','                ' ,'Trended On-Level Premium', 'Earned House Years')
  
  return(dframe)
}

by_peril_indication_summary <- function(state, EvaluationDate, Program,losses, prem,expense_ratios) {
  dframe <- data.frame(matrix(ncol=3, nrow=0))
  dframe[1,] <- c('(14)', 'Projected Loss & LAE Ratio', sum(losses$`Adjusted Ultimate Loss & LAE`)/sum(prem$`Trended On-Level Premium`))
  dframe[2,] <- c('(15)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  dframe[3,] <- c('(16)','Projected Loss, LAE & Fixed Expense Ratio',as.numeric(dframe[1,3])+as.numeric(dframe[2,3]))
  dframe[4,] <- c('(17)','Permissible Loss, LAE & Fixed Expense Ratio',as.numeric(dframe[2,3])+(1-expense_ratios['Total Expenses & Profit','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils'))
  dframe[5,] <- NA
  dframe[6,] <- c('(18)','Raw Indicated Rate Level Change',as.numeric(dframe[3,3])/as.numeric(dframe[4,3])-1)
  dframe[7,] <- c('(19)', 'Claim Count', sum(losses$`# of Claims`))
  dframe[8,] <- c('(20)','Credibility', min((as.numeric(dframe[7,3])/1082)^.5,1))
  dframe[9,] <- NA
  dframe[10,]<- c('(21)','Compliment of Credibility',0)
  dframe[11,]<- c('(22)','Credibility-weighted Indicated Rate Level Change', as.numeric(dframe[6,3])*as.numeric(dframe[8,3])+(1-as.numeric(dframe[8,3]))*as.numeric(dframe[10,3]))
  
  return(dframe)
}

cat_peril_table <- function(peril,inforce,experienceAdj){
  if (peril == 'Hurricane') {
    dframe <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level` = `Hurricane In Force Premium @ CRL`, `Peril Modeled Gross AAL` = `Hurricane Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else if (peril == 'STS') {
    dframe <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level`=`STS In Force Premium @ CRL`, `Peril Modeled Gross AAL`=`Convective Storm Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else {
    break
  }
  print(dframe$`Peril Modeled Gross AAL`)
  print(dframe$`CAT LAE Load`)
  print(dframe$`Inforce Premium @ Current Rate Level`)
  dframe <- dframe%>%
    mutate(`Modeled Loss & LAE Ratio`=coalesce(`Peril Modeled Gross AAL`*`CAT LAE Load`/`Inforce Premium @ Current Rate Level`,0),
           `Experience Adjustment Factor` = experienceAdj)%>%
    mutate(`Selected Loss & LAE Ratio` = `Experience Adjustment Factor` * `Modeled Loss & LAE Ratio`)
  
  return(dframe)
  
}
cat_peril_summary <- function(state,EvaluationDate,Program,catTable, expense_ratios,peril,experience_adj,experience_years,modeled_cat){
  dframe <- data.frame(matrix(ncol=3, nrow=0))
  dframe[1,] <- c('(8)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  dframe[2,] <- c('(9)','Selected Loss, LAE & Fixed Expense Ratio', as.numeric(dframe[1,3]) + catTable$`Selected Loss & LAE Ratio`)
  dframe[3,] <- c('(10','Permissible Loss & LAE Ratio',(expense_ratios['Permissible Loss, LAE, & Fixed Expense Ratio','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils') - 
                coalesce(as.numeric(modeled_cat$`In Force Premium @ Current Level` * reinsurance(state,EvaluationDate,Program,peril) / modeled_cat[[paste(peril,'In Force Premium @ CRL',sep=' ')]]),0)
  )#peril cost of reinsurance
  dframe[4,] <- NA
  dframe[5,] <- c('(11)', 'Raw Indicated Rate Level Change', as.numeric(dframe[2,3])/as.numeric(dframe[3,3])-1)
  dframe[6,] <- NA
  dframe[7,] <- c('(12)','Credibility',ifelse(experience_adj ==1, 1, min(experience_years/20,1))) #if the years of experience are more than 20 then keep at 100% credibility
  dframe[8,] <- NA
  dframe[9,] <- c('(13)','Compliment of Credibility',0)
  dframe[10,]<- c('(14)','STS Credibility-weighted Indicated Rate Level Change',as.numeric(dframe[5,3])*as.numeric(dframe[7,3])+(1-as.numeric(dframe[7,3]))*as.numeric(dframe[9,3]))
  
  return(dframe)
}

non_peril_pull <- function(Program,IndicationDate, EvaluationDate, state,data.source) {
  dframe <- dbGetQuery(con, paste0(
    "
    select nonPerilPremium
    from ActuarialSandbox.",Program,".nonPerilPremium
    where IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and source = '",data.source,"'
    and state = '",state,"'
    "
  ))
  return(as.numeric(dframe))
}

indication_memo <- function(total, fire, water, theft, liability, otherAOP, NCW, STS, HU,coverageReport,nonperil, peril) {
  dframe <- data.frame(matrix(ncol = 5, nrow = 0))
  if (is.data.frame(fire)) {
    dframe['1',] <- c('Fire','Fire',fire[3,3],fire[8,3],fire[11,3])
  }
  if (is.data.frame(water)) {
    dframe['2',] <- c('Water','Water',water[3,3],water[8,3],water[11,3])
  }
  if (is.data.frame(theft)) {
    dframe['3',] <- c('TheftVMM','Theft & VMM',theft[3,3],theft[8,3],theft[11,3])
  }
  if (is.data.frame(liability)) {
    dframe['4',] <- c('Liability','Liability',liability[3,3],liability[8,3],liability[11,3])
  }
  if (is.data.frame(otherAOP)) {
    dframe['5',] <- c('OtherAOP','All Other Perils',otherAOP[3,3],otherAOP[8,3],otherAOP[11,3])
  }
  if (is.data.frame(NCW)) {
    dframe['6',] <- c('NCW','Non-Cat Weather',NCW[3,3],NCW[8,3],NCW[11,3])
  }
  if (is.data.frame(STS)) {
    dframe['7',] <- c('STS','STS',STS[2,3],STS[7,3],STS[10,3])
  }
  if (is.data.frame(HU)) {
    dframe['8',] <- c('Hurricane','Hurricane',HU[2,3],HU[7,3],HU[10,3])
  }
  colnames(dframe) <- c('joiner','Peril','LAE','Cred','RateChange')
  
  sts_add <- if ('STS'       %in% peril) 1 else 0
  hur_add <- if ('Hurricane' %in% peril) 1 else 0
  if (nrow(dframe) > 0) {
    
    
    coverageReport_clean <- coverageReport%>%
      group_by(Peril)%>%
      summarise(Prem = sum(ReratedEP))
    df_out <- dframe%>%
      left_join(coverageReport_clean, by = c('joiner'='Peril'))%>%
      select(-joiner)
    sumprod <- df_out%>%
      group_by()%>%
      summarise(sumProduct = sum(as.numeric(RateChange)*as.numeric(Prem),na.rm=T))
    balanced <- (1-nonperil)*(1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1
    df_out['9',] <- c('Total', total[3+sts_add + hur_add,2],total[6+sts_add + hur_add,2],total[8+sts_add + hur_add,2],(1-nonperil)*(1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1)
    
    sumProd_adj <- (1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))-1
    cred_adj <- ((1+as.numeric(total[8+sts_add + hur_add,2]))-nonperil)/(1-nonperil)-1
    
    df_final <- df_out%>%
      mutate(balanced = ifelse(Peril=='Total',NA,
                               (1+as.numeric(RateChange))*(1+cred_adj)/(1+sumProd_adj)-1))
    sumprodBalance <- df_final%>%
      group_by()%>%
      summarise(sum(as.numeric(Prem)*as.numeric(balanced),na.rm=T))
    
    df_final['9',6] <- (1-nonperil)*(1+(as.numeric(sumprodBalance)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1
    
    df_final <- df_final%>%
      select(Peril, LAE,Cred,balanced)
    
  } else {#if the indication is not by any perils
    df_out <- data.frame(matrix(ncol = 4, nrow = 0)) 
    df_out['1',] <- c('Total', total[3+sts_add + hur_add,2],total[6+sts_add + hur_add,2],total[8+sts_add + hur_add,2]) 
    df_final <- df_out
  }
  colnames(df_final) <- c('Peril', 'Projected Loss, LAE & Fixed Expense Ratio','Credibility','Balanced Credibility-weighted Indicated Rate Level Change')
  return(df_final)
}

memoToTables <- function(memo,peril){ 
  
  dframe <- na.omit(memo[memo$Peril == peril,]) 
  if (nrow(dframe) > 0) {
    out <- as.numeric(dframe[4])
  } else {
    out <- 1
  }
  df_out <- data.frame(matrix(ncol=3,nrow=0))
  df_out[1,]<- c(ifelse(peril == 'STS' | peril == 'Hurricane','(15)','(23)'),'Balanced Cred-weighted Indicated Rate Level Change',out)
  return(df_out)
}


reinsurance_exhibit <- function(State_Full, LOB_Full, HUreinsurance, STSreinsurance,CostOfReinsurance,modeled_cat) {
  dframe <- data.frame(matrix(ncol=5, nrow=0))
  colnames(dframe) <- c('Peril', paste('Inforce Premium at CRL',State_Full,LOB_Full,sep=' '),'Premium Rated Cost of Reinsurance Margin', 'Net Cost of Reinsurance','Cost of Reinsurance')
  dframe[3,] <- c('Hurricane',format(round(modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
              paste0(format(round(HUreinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * HUreinsurance,0),big.mark = ','),
              modeled_cat$`In Force Premium @ Current Level` * HUreinsurance / modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]]
  )
  dframe[4,] <- c('STS',format(round(modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
              paste0(format(round(STSreinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * STSreinsurance,0),big.mark = ','),
              modeled_cat$`In Force Premium @ Current Level` * STSreinsurance / modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]]
  )
  dframe[5,] <- c('Total',format(round(modeled_cat$`In Force Premium @ Current Level`,0),big.mark = ','),
              paste0(format(round(CostOfReinsurance*100,1),nsmall=1),'%'),
              format(round(modeled_cat$`In Force Premium @ Current Level` * CostOfReinsurance,0),big.mark = ','),
              CostOfReinsurance)
  dframe <- na.omit(dframe)
  return(dframe)
}

#pull selections based on variable name
pull_variable <- function(Program,IndicationDate,EvaluationDate,state,Classes,variable_name,default) {
  dframe <- dbGetQuery(con,paste0("	
	select
	columnValue,status
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	where IndicationDate = '",IndicationDate,"' 
	and EvaluationDate = '",EvaluationDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	and columnName = '",variable_name,"'
      "
  ))

  dframe <- dframe%>%
    filter(status == ifelse('Published' %in% dframe$status,'Published',
                            ifelse('In Review' %in% dframe$staus, 'In Review', 'In Progress')))%>%
    select(-status) 
  

  
  if (variable_name == 'catLoadSelection') {
    if (nrow(dframe)>0) {
      catLoad <- as.data.frame(dframe)
    } else {
      catLoad <- as.data.frame(default)
    }
    row.names(catLoad) <- c('Selected Expense Load')
    return(catLoad)
  }else if (variable_name == 'proposedEffective') {
    if (nrow(dframe) > 0) {
      return(dframe[[1]])
    } else {
      d <- ymd(EvaluationDate)
      d <- d %m+% months (8)
      return(d)
    }
  } else if (variable_name == 'fillOutDate'){
    if (nrow(dframe) > 0) {
      return(dframe[[1]])
    } else {
      return(Sys.Date())
    }
  }
  if (nrow(dframe)>0) {
    if (variable_name == 'catExclude' & nchar(dframe) >=4 ) {
      string <- as.character(round(as.numeric(dframe),0))
      out <- sapply(seq(from=1, to=nchar(string), by=4), function(i) substr(string, i, i+3))
      return(out)
    } else {
      return(as.numeric(dframe))
    }
  } else {
    return(default)
  }
}

#save 

save_selections_rest <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,
                                 catLoadWeight,catLoadExclude,catLoadExcludeCW,catLoadSelection,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearExpAdj,includePerils,proposedEffective,fillOutDate,useNonModeled,NonModeledAvgWeight,NonModeledStateWeight,
                                 selected_by,technicalReviewer,PeerReviewer) { 
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)

  catLoadExcludeSaveCW <- ''
  for (i in 1:length(catLoadExcludeCW)) {
    catLoadExcludeSaveCW <- paste0(catLoadExcludeSaveCW,catLoadExcludeCW[i])
  }
  
  catLoadExcludeSaveCW <- ifelse(catLoadExcludeSaveCW == '', 0, catLoadExcludeSaveCW)
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
technicalReviewer,
PeerReviewer,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
cast(",catLoadWeight," as nvarchar(50)) as catLoadWeight,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",catLoadExcludeSaveCW," as nvarchar(50)) as catExcludeCW,
cast(",catLoadSelection," as nvarchar(50)) as catLoadSelection, 
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
cast(",LLLweight," as nvarchar(50)) as LLLweight,
cast(",LLLfire," as nvarchar(50)) as LLLfire,
cast(",LLLwater," as nvarchar(50)) as LLLwater,
cast(",LLLtheft," as nvarchar(50)) as LLLtheft,
cast(",LLLliability," as nvarchar(50)) as LLLliability,
cast(",LLLotherAOP," as nvarchar(50)) as LLLotherAOP,
cast(",LLLweather," as nvarchar(50)) as LLLweather,
cast(",curPremTrend," as nvarchar(50)) as curPremTrend,
cast(",projPremTrend," as nvarchar(50)) as projPremTrend,
cast(",HUexpFactor," as nvarchar(50)) as HUexpFactor,
cast(",HUyearsAdjFactor," as nvarchar(50)) as HUyearsAdjFactor,
cast(",STSexpFactor," as nvarchar(50)) as STSexpFactor,
cast(",STSyearExpAdj," as nvarchar(50)) as STSyearExpAdj,
cast(",if ('Fire' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilFire,
cast(",if ('Water' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilWater,
cast(",if ('Theft' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilTheft,
cast(",if ('Liability' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilLiability,
cast(",if ('Explosion' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilExplosion,
cast(",if ('Other' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilOther,
cast(",if ('NCW' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilNCW,
cast(",if ('STS' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilSTS,
cast(",if ('Hurricane' %in% includePerils) 1 else 0," as nvarchar(50)) as IncludePerilHurricane,
cast('",proposedEffective,"' as nvarchar(50)) as proposedEffective,
cast('",fillOutDate,"' as nvarchar(50)) as fillOutDate,
cast('",useNonModeled,"' as nvarchar(50)) as useNonModeled,
cast('",NonModeledAvgWeight,"' as nvarchar(50)) as NonModeledAvgWeight,
cast('",NonModeledStateWeight,"' as nvarchar(50)) as NonModeledStateWeight,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catLoadWeight,catExclude,catExcludeCW,catLoadSelection,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearExpAdj,
                                 IncludePerilFire,IncludePerilWater,IncludePerilTheft,IncludePerilLiability,IncludePerilExplosion,IncludePerilOther,IncludePerilNCW,IncludePerilSTS,IncludePerilHurricane,
                                 proposedEffective,fillOutDate,useNonModeled,NonModeledAvgWeight,NonModeledStateWeight)
	) as unpvt2

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
  print(2)
}

save_selections_cw <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,curLossTrend,projLossTrend,catLoadExclude,
                               selected_by, technicalReviewer,PeerReviewer) {
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)
  #selections <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][-1])
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
technicalReviewer,
PeerReviewer,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catExclude,curLossTrend,projLossTrend)
	) as unpvt2

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer		

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
}



########################################################################################
######################## Territorial Analysis Functions ################################
########################################################################################

LossesCapped <- function(Program,IndicationDate, EvaluationDate, state) {
  dframe <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCapped
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))
}

LossesCappedByPeril <- function(Program,IndicationDate, EvaluationDate, state,peril) {
  dframe <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode,Peril, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCappedByPeril
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and peril = '",peril,"'
      "
  ))
}

EHY_Prem <- function(Program,IndicationDate, EvaluationDate, state,data.source) {
  dframe <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".Territorial_EHY_Prem
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and source = '",data.source,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


InforceAAL <- function(Program,IndicationDate, EvaluationDate, state, FillOutDate,data.source) {
  dframe <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".TerritorialInforceAAL
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and source = '",data.source,"'
    and '",FillOutDate,"' between rowStartDate and rowEndDate
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


ExperienceFactor <- function(Program,IndicationDate, EvaluationDate, state, name) {
  dframe <- dbGetQuery(con, paste0("
                               SELECT Territory, columnValue as ",name,"
  FROM [ActuarialSandbox].[",Program,"].[TerritorialExperienceAdjustmentFactor]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and Region = '",state,"'
  and columnName = '",name,"'
                               
                               "))
  if (nrow(dframe)>0) {
    return(dframe)
  } else {
    return(dframe)
  }
  
}

TerritorialExhibit <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
                               TargetLossRatio,TargetIndicatedChange,nonPeril){
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumatCRL*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode), EHY = as.numeric(EHY))
  
  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHY)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHY = sum(EHY,na.rm = T))%>% #ENDING adding InforceCount as a column so that I can show Snapshot Tab
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(STSexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    left_join(HUexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHY = coalesce(EHY,0), InforceCount = coalesce(InforceCount,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0),
           ModeledHUloss = coalesce(as.numeric(`HU AAL Total`) * as.numeric(ExpenseLAE) * coalesce(as.numeric(HUexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           ModeledSTSloss=  coalesce(as.numeric(`STS AAL Total`)* as.numeric(ExpenseLAE) * coalesce(as.numeric(STSexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           HU_Re_Load = coalesce(as.numeric((HUprojLossLAE+HURe)/HUprojLossLAE),0),
           TO_Re_Load = coalesce(as.numeric((STSprojLossLAE+STSRe)/STSprojLossLAE),0))%>%
    mutate(HU_Cost_Re = ModeledHUloss*(HU_Re_Load-1),
           TO_Cost_Re = ModeledSTSloss*(TO_Re_Load-1))%>%
    select(-state,-`HU AAL Total`, -`STS AAL Total`,-`HU Premium`,-`STS Premium`)%>%
    mutate(AdjLossLAEcost = round(ModeledHUloss + ModeledSTSloss + HU_Cost_Re + TO_Cost_Re + ProjLossTotal,3),
           Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = AdjLossLAEcost/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange)-1)*basePremTotal)%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  print(Main[Main$territoryCode==10,])
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange)-1,
           AveragePremium = coalesce(TrendedReratedEP/EHY,1),
           CatLossRatio = ModeledHUloss+ModeledSTSloss,
           CostOfReinsurance = HU_Cost_Re+TO_Cost_Re)%>%
    mutate(AdjTotalLoss = CatLossRatio+CostOfReinsurance+ProjLossTotal,CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange))  )%>%
    select(territoryCode,EHY,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,CatLossRatio,CostOfReinsurance,
           AdjLossLAEcost,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange,InforceCount)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Cat Loss Ratio',
                         'Cost of Reinsurance','Adj Total Loss, LAE, & Cost of Reinsurance','Indicated Changed','Credibility',
                         'Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change', 'InforceCount')
  
  
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `Average Premium` = sum(Exhibit$`Trended Earned Rerated Premium at CRL`)/sum(Exhibit$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(Exhibit$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(Exhibit$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`= NA , `Cat Loss Ratio` = NA,`Cost of Reinsurance`=NA,`Adj Total Loss, LAE, & Cost of Reinsurance`=NA,`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange, InforceCount = NA)#TargetIndicatedChange
  
  
  
  return(Exhibit)
}

TerritorialExhibitTop10 <- function(dframe) {
  dframe.filter <- dframe%>%
    filter(!is.na(InforceCount))%>%
    arrange(desc(InforceCount), desc(`Earned Exposures`))%>% #arrange by inforce count, and the EHY for case when there are ties in inforce count.
    head(10)%>%
    select(-InforceCount)
  
  
  dframe.out <- dframe.filter%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(dframe.filter$`Earned Exposures`),
            `Average Premium` = sum(dframe.filter$`Trended Earned Rerated Premium at CRL`)/sum(dframe.filter$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(dframe.filter$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(dframe.filter$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`= NA , `Cat Loss Ratio` = NA,`Cost of Reinsurance`=NA,`Adj Total Loss, LAE, & Cost of Reinsurance`=NA,`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=NA,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=NA)
}

TerritorialExhibitAttritionalNCW <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
                                             TargetLossRatio,TargetIndicatedChange,nonPeril,peril){

  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',ifelse(peril=='Theft', 'TheftVMM',peril))]]
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumUse*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))

  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>% #right join before adding on the premium columns, prevent data loss when low expereince and no losses
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHYUse = coalesce(EHYUse,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0))%>%
    mutate(Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = ProjLossTotal/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange[3])-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1,
           AveragePremium = coalesce(TrendedReratedEP/EHYUse,1))%>%
    mutate(CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange)))%>%
    select(territoryCode,EHYUse,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,Claim_Count,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Claim Count'
                         ,'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `Average Premium` = sum(Exhibit$`Trended Earned Rerated Premium at CRL`)/sum(Exhibit$`Earned Exposures`),
            `Trended Earned Rerated Premium at CRL`=sum(Exhibit$`Trended Earned Rerated Premium at CRL`),
            `Capped Ultimate Losses Ex-Cat` = sum(Exhibit$`Capped Ultimate Losses Ex-Cat`),
            `Ex Cat Loss Ratio`=  coalesce(sum(Exhibit$`Capped Ultimate Losses Ex-Cat`)/sum(Exhibit$`Trended Earned Rerated Premium at CRL`),0),
            `Claim Count`=sum(Exhibit$`Claim Count`),`Indicated Changed`=NA,`Credibility`=NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange[3])

  
  return(Exhibit)
}

TerritorialExhibitAttritionalCAT <- function(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                             TargetLossRatio,TargetIndicatedChange,peril,peril_short,catExpAdj,perilLossLAE, CostRe, catYearsAdj,catCredStandard){
 
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',peril)]]
  InforceAALTable$CatPrem <- InforceAALTable[[paste(peril_short,'Premium',sep = ' ')]]
  InforceAALTable$CatAAL <- InforceAALTable[[paste(peril_short,'AAL Total',sep = ' ')]]
  catExpAdj$expFactor <- as.numeric(catExpAdj[[paste0(peril_short,'expFactor')]])
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    select(territoryCode,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  print(CostRe)
  print('CostRe')
  Main <- EHY_PremTableJoin%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(catExpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(ModeledLossRatio = ifelse(CatPrem > 0,CatAAL*ExpenseLAE/CatPrem ,0),
           ReinsLoad = `In Force Premium @ CRL`* CostRe,
           expFactor = coalesce(expFactor,1))%>%
    mutate(TerritoryCostRe = coalesce(ifelse(CatPrem != 0,ReinsLoad/CatPrem,0),0)  )%>%
    mutate(ProjectedLoss = ModeledLossRatio * expFactor + TerritoryCostRe,
           Credibility = coalesce(ifelse(EHYUse==0, 0, 
                                         ifelse(expFactor==1, 1, catYearsAdj/catCredStandard)),0),
           EHYUse = coalesce(EHYUse, 0))%>%
    mutate(IndicatedChange = ProjectedLoss/TargetLossRatio - 1)%>%
    mutate(CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+as.numeric(TargetIndicatedChange[3]))-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1)%>%
    mutate(CredibilityWeightedChange = as.numeric(unlist(CredibilityWeightedChange)),
           BalancedIndicatedChange = as.numeric(unlist(BalancedIndicatedChange)))%>%
    select(territoryCode,EHYUse,CatPrem,CatAAL,ModeledLossRatio,expFactor,TerritoryCostRe,ProjectedLoss,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'In Force Premium @ Currend Rate Level','Peril Modeled Gross AAL','Modeled Loss & LAE Ratio','Experience Adjustment Factor','Cost of Reinsurance','Adj Loss, LAE, & Cost of Reinsurance',
                         'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  Exhibit <- Exhibit%>%
    mutate(Territory = as.character(Territory))%>%
    add_row(Territory = 'Total',
            `Earned Exposures` = sum(Exhibit$`Earned Exposures`),
            `In Force Premium @ Currend Rate Level`=sum(Exhibit$`In Force Premium @ Currend Rate Level`),
            `Peril Modeled Gross AAL` = sum(Exhibit$`Peril Modeled Gross AAL`),`Modeled Loss & LAE Ratio` = NA,`Experience Adjustment Factor` = NA,
            `Cost of Reinsurance` = NA,`Adj Loss, LAE, & Cost of Reinsurance` = NA,`Indicated Changed` = NA,`Credibility` = NA,
            `Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change`=credWeightTotal,
            `Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change`=TargetIndicatedChange[3])
  return(Exhibit)
}


##########################Class Variable Analysis Functions##########################

variableOptions <- function(program,data.source) {
  print(program)
  dframe <- dbGetQuery(con, paste0(
    "
    select distinct variableName as [Variable Names]
    from ActuarialSandbox.",program,".CVAraw
    where source = '",data.source,"'
    order by variableName

    "
  ))
  print('exti variable options')
  return(head(dframe$`Variable Names`,-1))
}

cvaPull <- function(Program,IndicationDate, state, variableName,HUadj,LAE,data.source) { 
  dframe <- dbGetQuery(con, paste0(
    "select variableValue ,EarnedPremiumatCRL, EHY, Total_Capped_Incurred, Total_Claim_Count,Peril
    from actuarialSandbox.",Program,".CVAraw
    where IndicationDate = '",IndicationDate,"'
    and state = '",state,"' 
    and source = '",data.source,"'
    and lower(variableName) = lower('",variableName,"')
    "
  )) %>%
    filter(variableValue !='-1')%>%
    mutate(Total_Capped_Incurred = coalesce(Total_Capped_Incurred,0),
           Total_Claim_Count = coalesce(Total_Claim_Count,0))%>%
    mutate(Total_Capped_Incurred=ifelse(Peril == 'ModeledHU', Total_Capped_Incurred*HUadj*LAE, Total_Capped_Incurred))
  #recalculate the Total_Capped_Incurred using HUadj and LAE
  dftotal <-  dframe%>%
    filter(Peril == 'Total')%>%
    mutate(All_Capped_Incurred=Total_Capped_Incurred)%>%
    select(variableValue, All_Capped_Incurred)
  
  dfHU <-  dframe%>%
    filter(Peril == 'Hurricane')%>%
    mutate(HU_Capped_Incurred=Total_Capped_Incurred )%>%
    select(variableValue, HU_Capped_Incurred)
  
  dfTotalModeled <- dframe%>%
    filter(Peril ==  'TotalModeledHU')%>%
    left_join(dftotal, by = c('variableValue'='variableValue'))%>%
    left_join(dfHU, by = c('variableValue'='variableValue'))%>%
    mutate(Total_Capped_Incurred=All_Capped_Incurred-HU_Capped_Incurred+Total_Capped_Incurred*HUadj*LAE)%>%
    select(-All_Capped_Incurred,-HU_Capped_Incurred)
  
  return(dframe)
}

cvaDisplayName <- function(Program,variableName) {
  dframe <- dbGetQuery(con,paste0("
  select DisplayName
  from ActuarialSandbox.",Program,".CVAnameMapping
  where lower(SQLname) = lower('",variableName,"')
"
  ))
  
  df2 <- ifelse(as.character(dframe)!="character(0)",as.character(dframe),'Enter Title...')
  
  return(df2)
  
}

cvaClean <- function(data, peril, HUadj , LAE){
  
  dframe <- data%>%
    filter(Peril == peril)%>%
    group_by(variableValue,Peril)%>%
    summarise(EarnedPremiumatCRL = sum(EarnedPremiumatCRL), EHY = sum(EHY),Total_Capped_Incurred=sum(Total_Capped_Incurred),Total_Claim_Count=sum(Total_Claim_Count), .groups = 'drop')
  dframe$order <- NA
  for (i in 1:nrow(dframe)) {
    dframe$order[i] <- tryCatch(as.numeric(gsub('[+]','',gsub(',','',unlist(strsplit(as.character(dframe$variableValue[i]),'[-]'))[1]))), warning = function(w) {NA})
  }
  
  df1 <- dframe%>%
    arrange(order)%>%
    mutate(AveragePrem = coalesce(EarnedPremiumatCRL/EHY,0),
           Loss_Ratio = Total_Capped_Incurred/EarnedPremiumatCRL,
           Frequency = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Total_Claim_Count/EHY *100,0)),
           Severity = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Total_Capped_Incurred/Total_Claim_Count,0)),
           Loss_Cost = coalesce(Total_Capped_Incurred/EHY,0))%>%
    select(Peril,variableValue, EarnedPremiumatCRL, EHY, AveragePrem,Total_Capped_Incurred,Total_Claim_Count,Loss_Ratio,Frequency, Severity, Loss_Cost)
  TotalLossRatio <- sum(dframe$Total_Capped_Incurred)/sum(dframe$EarnedPremiumatCRL)
  TotalFrequency <- sum(dframe$Total_Claim_Count)/sum(dframe$EHY) *100
  TotalSeverity <- sum(dframe$Total_Capped_Incurred)/sum(dframe$Total_Claim_Count)
  df2 <-df1%>%
    mutate(IndicatedChange = Loss_Ratio/TotalLossRatio-1,
           Credibility= ifelse(Peril == 'Total' | Peril == 'TotalModeledHU' | Peril == 'ExCat', ifelse((EHY/40000)^.5 < 1, (EHY/40000)^.5,1), ifelse((Total_Claim_Count/1082)^0.5<1, (Total_Claim_Count/1082)^0.5,1)))%>%
    mutate(CredWeighted = IndicatedChange * Credibility,
           FreqRel = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Frequency/TotalFrequency,0)),
           SevRel = ifelse(Peril == 'ModeledHU' | Peril == 'TotalModeledHU',NA,coalesce(Severity/TotalSeverity,0)),
           LossRel = Loss_Ratio/TotalLossRatio)
  CredTotal <- df2%>%
    group_by()%>%
    summarise(CredTotal = sum(EarnedPremiumatCRL*CredWeighted))%>%
    mutate(CredTotal = CredTotal/sum(dframe$EarnedPremiumatCRL))
  df3 <- df2%>%
    add_row(Peril = '',variableValue = 'Total',EarnedPremiumatCRL = sum(dframe$EarnedPremiumatCRL),EHY = sum(dframe$EHY),AveragePrem = coalesce(sum(dframe$EarnedPremiumatCRL)/sum(EHY),0),
            Total_Capped_Incurred  = sum(dframe$Total_Capped_Incurred), Total_Claim_Count = sum(dframe$Total_Claim_Count),
            Loss_Ratio = sum(dframe$Total_Capped_Incurred)/sum(dframe$EarnedPremiumatCRL),
            Frequency = ifelse(peril == 'ModeledHU' | peril == 'TotalModeledHU',NA,sum(dframe$Total_Claim_Count)/sum(dframe$EHY) *100),
            Severity = ifelse(peril == 'ModeledHU' | peril == 'TotalModeledHU',NA,sum(dframe$Total_Capped_Incurred)/sum(dframe$Total_Claim_Count)),
            Loss_Cost = sum(dframe$Total_Capped_Incurred)/sum(dframe$EHY),
            IndicatedChange = NA, Credibility=NA,CredWeighted=as.numeric(CredTotal),FreqRel=NA,SevRel=NA,LossRel=NA
    )
  
  return(df3)
  
}

CVAvalueMapping <- function(Program,State,variableName,Data,peril){ 
  dframe <- dbGetQuery(con, paste0("
        select variableValue, DisplayValue
                               
        from ActuarialSandbox.",Program,".CVAvalueMapping
        where lower(variableName) = lower('",variableName,"')
        and state = '",State,"'"))
  
  
  if (nrow(dframe) > 0) {
    Data2 <- Data%>%
      left_join(dframe, by = c("variableValue" = "variableValue"))%>%
      mutate(variableValue = DisplayValue)%>%
      select(-DisplayValue) 
    df2 <- dframe%>%
      group_by(DisplayValue)%>%
      summarise(variableValueAlter = min(variableValue))
    Data2 <- cvaClean(Data2,peril)%>%
      left_join(df2, by = c(c("variableValue" = "DisplayValue")))%>%
      arrange(variableValueAlter)%>%
      select(-variableValueAlter) 
    Data <- Data2
  }
  return(Data)
  
  
}

searchRaters <- function(Program, State,data.source){
  print('enter search rater')
  print(State)
  print(Program)
  dframe <- dbGetQuery(con, paste0("
declare @state varchar(2) = '",State,"',
@Program varchar(2) = '",Program,"'

SELECT 
	'ActuarialDataMart' as DB,
  SCHEMA_NAME(schema_id) AS [Schema],
  right(name, len(name)- 9) as ratingVersion,
  name 
FROM ActuarialDataMart.sys.objects
WHERE type = 'P'
and name like concat('%rate%',@state,'%')
and SCHEMA_NAME(schema_id) = @Program
union
SELECT 
	'ActuarialSandbox' as DB,
  SCHEMA_NAME(schema_id+1) AS [Schema],
  right(name, len(name)- 9) as ratingVersion,
  name
FROM ActuarialSandbox.sys.objects
WHERE type = 'P'
and name like concat('%rate%',@state,'%')
and SCHEMA_NAME(schema_id+1) = @Program
  "
  ))
  dframe <- dframe%>%
    arrange(desc(as.numeric(ratingVersion)))
  dframe <- head(dframe,1)
  print(dframe)
  databaseUse <- dframe$DB
  currentRater <- paste0(dframe$DB,'.',dframe$Schema,'.',dframe$name)
  print(currentRater)
  
  
  var.options <- variableOptions(Program,data.source)
  
  if (databaseUse == 'ActuarialSandbox') {  
    print('new connection')
    raterText <- dbGetQuery(conSand,
                            paste0("
                  exec sp_helptext '",currentRater,"'
                                 "))
    print('sucess')
  } else {
    print('connect to the ADM') 
    
    raterText <- dbGetQuery(con,
                            paste0("
                  exec sp_helptext '",currentRater,"'
                                 "))
  }
  print(con)
  print('connect sucessful')
  
  
  var.rater <- c()
  for (var.orig in var.options) {
    
    var <- tolower(var.orig)
    var <- if (grepl( 'ageofhome', var, fixed = TRUE) ) {
      'ageofhome'
    } else if (grepl( 'cova', var, fixed = TRUE)) {
      'covalmt'
    } else if (grepl( 'claimfreerendis', var, fixed = TRUE)) {
      'claimfreerendis'
    } else if (grepl( 'new_roof', var, fixed = TRUE)) {
      'newroofind'
    } else if (grepl( 'advanced_shopper', var, fixed = TRUE)) {
      'advancedshopper'
    } else if (grepl( 'new_purchase', var, fixed = TRUE)) {
      'newpurchaseind'
    } else {
      var
    }
    
    if (sum(str_detect(tolower(raterText$Text), var)) > 0) {
      var.rater <- c(var.rater,var.orig)
    }
  }
  
  return(var.rater)
}

#Review Progress
review_progress <- function(Program, State, IndicationDate, EvaluationDate) { #pulling in whether the technical and/or peer review have been completed
  dframe <- dbGetQuery(con, paste0("
                                   SELECT distinct
                                      max(selected_by) as [selector],
                                      max(TechnicalReviewer) as [Technical Review],
                                      max(PeerReviewer) as [Peer Review] 
                                      FROM [ActuarialSandbox].[",Program,"].[indicationSelections]
                                    where IndicationDate = '",IndicationDate,"'
                                    and EvaluationDate = '",EvaluationDate,"'
                                    and Region = '",State,"'
                                    and (Status = 'In Review' or Status = 'Published')
                                    group by Region, IndicationDate, EvaluationDate
                                   "))
  if (nrow(dframe) > 0 ) {
    dframe <- data.frame(Step = c('Confirm Selections','Technical Review', 'Peer Review'),Status = c(
                                                                                if (dframe$selector > 0)           {'Complete'} else  {'Incomplete'}, 
                                                                                if (dframe$`Technical Review` > 0) {'Complete'} else  {'Incomplete'}, 
                                                                                if (dframe$`Peer Review` > 0)      {'Complete'} else  {'Incomplete'}))
  } else {
    dframe <- data.frame(Step = c('Confirm Selections','Technical Review', 'Peer Review'), Status = c('Incomplete','Incomplete', 'Incomplete'))
  }
 
  return(dframe)
}



####################### ISO Trends #########################

ISOdata <- function(Program,state,fillOutDate) {
  dframe <- dbGetQuery(con, paste0("
            select 'Current' as ISO, concat(curPremTrend,'%') as [Premium Trend], concat(curLossTrend,'%') as [Loss Trend]
            from (select columnName, columnValue from ActuarialSandbox.",Program,".indicationSelections_Trend
            where region= '",state,"' and '",fillOutDate,"' between rowStartDate and rowEndDate) as a
            pivot (max(columnValue) for columnName in (curPremTrend, curLossTrend) ) as b
            union all 
            select 'Projected' as ISO, concat(projPremTrend,'%') as [Premium Trend], concat(projLossTrend,'%') as [Loss Trend]
            from (select columnName, columnValue from ActuarialSandbox.",Program,".indicationSelections_Trend
            where region= '",state,"' and '",fillOutDate,"' between rowStartDate and rowEndDate) as a
            pivot (max(columnValue) for columnName in (projPremTrend, projLossTrend) ) as b
                                 "))
  return(dframe)
}

###################### Reonciliation Tab ###################

reconcilation_tab.fun <- function(coverageReport.data, Targit.data) {
  print(coverageReport.data)
  reconciliationData <- coverageReport.data%>%
    filter(Peril == 'All Perils')%>%
    select(RollingYear, ReratedEP, ptsEHY, TotalIncurred, claimCount)
  print(reconciliationData)
  
  
  dframe <- data.frame(matrix(ncol = 18, nrow = 22))
  
  #define the catergory labels!
  
  dframe[5,1:17] <- c('Rolling Year',  #define the reconcilation headers!
                      'Financial Earned Premium (Rerated for Perils)',
                      'House Years',
                      'Uncapped Total Incurred',
                      'Claim Count',NA,
                      'Rolling Year',
                      'Targit Financial Earned Premium',
                      'House Years',
                      'Uncapped Incurred Loss & LAE (ex Cat)',
                      'Claim Count',NA,
                      'Rolling Year',
                      'Financial Earned Premium (Rerated for Perils)',
                      'House Years',
                      'Uncapped Incurred Loss & LAE (ex Cat)',
                      'Claim Count')
  
  dframe[6:(nrow(reconciliationData)+5), 1:5] <- reconciliationData
  dframe[6:(nrow(reconciliationData)+5),7] <- reconciliationData$RollingYear
  dframe[6:(nrow(reconciliationData)+5),13] <- reconciliationData$RollingYear
  print(1)
  for (i in 6:(nrow(reconciliationData)+5)) {
    dframe[i,14:17] <- c(paste0('=',toupper(letters)[8:11],i,'/',toupper(letters)[2:5],i,'-1'))
  }
  
  dframe[3,3] <- 'SQL Data'
  dframe[3,9] <- 'Input Targit Data'
  dframe[3,15] <- 'Difference'
  dframe[14,3] <- 'Rerated Premium'
  dframe[14,8] <- 'Notes:'
  
  print(2)
  if (nrow(Targit.data) > 0) {
    dframe[6:(nrow(Targit.data)+5),8:11] <- Targit.data%>%select(-RollingYear)
  }
  
  
  summaryPremium <- coverageReport.data%>%
    filter(Peril != 'All Perils')%>%
    group_by(RollingYear)%>%
    summarise(Rerated = sum(ReratedEP, na.rm = T))
  
  if (nrow(summaryPremium) > 0 ){
  dframe[16,2:5] <- c('Rolling Year', 'Rerated', 'Trended/On-Leveled', 'Difference')
  dframe[17:(nrow(summaryPremium)+16), 2:3] <- summaryPremium
  for (i in 17:(nrow(summaryPremium)+16)) {
    dframe[i,5] <- c(paste0('=',toupper(letters)[4],i,'/',toupper(letters)[3],i,'-1'))
  }
  }
  print(3)
  
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"60"},
  { "type": "number", "title": "B" ,"width":"120"},
  { "type": "number", "title": "C" ,"width":"120"},
  { "type": "number", "title": "D" ,"width":"100"},
  { "type": "number", "title": "E" ,"width":"120"},
  { "type": "number", "title": "F" ,"width":"20"},
  { "type": "text", "title": "G" ,"width":"60"},
  { "type": "number", "title": "H" ,"width":"120"},
  { "type": "number", "title": "I" ,"width":"100"},
  { "type": "number", "title": "J" ,"width":"120"},
  { "type": "number", "title": "K" ,"width":"100"},
  { "type": "text",  "title": "L" ,"width":"20"},
  { "type": "text",  "title": "M" ,"width":"60"},
  { "type": "number", "title": "N" ,"width":"120"},
  { "type": "number", "title": "O" ,"width":"100"},
  { "type": "number", "title": "P" ,"width":"120"},
  { "type": "number", "title": "Q" ,"width":"100"},
  { "type": "number", "title": "R" ,"width":"100"}
  ]')
  
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if ( (row >= 4 & row < ",nrow(reconciliationData)+5," & col != 0 & col != 6 &  col != 5 & col < 11) | (col > 0 & col < 4 & row > 14 & row < ",nrow(summaryPremium)+16," ) ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0)
              if ( ((col == 1 | col ==3 | col ==7 | col ==9)& row < 10) | ( (col == 2 | col == 3) & row > 14 & row < ",nrow(summaryPremium)+16," )) {
                cell.innerHTML = '$' + numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
              } else if (col != 1) {
                cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
              }
            }
          } else if ( (col < 17 & col > 12 & row >= 4 & row < ",nrow(reconciliationData)+5,") | (col == 4 & row > 14 & row < ",nrow(summaryPremium)+16,") ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              scale = Number(txt) * 100
              scaleRound = scale.toFixed(2)
              cell.innerHTML = scaleRound + '%' ;
            }
          } else if ( (row <4 | row > ",nrow(reconciliationData)+4," | col == 5 | col == 11 | col == 17) & !(col >=7 & col <= 16 & row >= 15 & row <= 20)) {
            cell.style.backgroundColor = 'lightgrey';
          }
          
          if (row ==2 | (row ==13 & col ==2) | (row ==13 & col == 7)) {
            cell.innerHTML = cell.innerText.bold();
          }
         if ( row >= 4 & row <=9 & col >=6 & col <= 10) {
            cell.style.backgroundColor = '#FFFACD';
         }
         if (col >=7 & col <= 16 & row >= 13 & row <= 20) {
            cell.style.textAlign = 'left';
            cell.style.verticalAlign = 'top';
         }
          
}")
  print(4)
  return(list(dframe, columns, updateTable))
  
}

manualTargitInput.pull <- function(Program, IndicationDate, EvaluationDate, State) {
  dframe <- dbGetQuery(con, paste0("
              select *
              from ActuarialSandbox.",Program,".ManualTargitInput 
              where IndicationDate ='",IndicationDate,"'
              and EvaluationDate = '",EvaluationDate,"'
              and state ='",State,"'
              and currentRow = 1
                                   "))
  dframe <- dframe%>%
    filter(status == ifelse('Published' %in% dframe$status,'Published',
                            ifelse('In Review' %in% dframe$status, 'In Review', 'In Progress')))%>%
    select(-status, -IndicationDate, -EvaluationDate, -state)
  return(dframe)
}

#####################################################################################
############################# RShiny User Interface #################################
#####################################################################################

ui <- fluidPage(#align='center',#theme = shinytheme('sandstone'),
  tags$script("
    Shiny.addCustomMessageHandler('EvaluationDate', function(value) {
    Shiny.setInputValue('EvaluationDate', value);
    });"),
  shinyjs::useShinyjs(),
  titlePanel(title=div(img(src='HOA Pic.jpg', height = 50, width = 225))),
  titlePanel("Actuarial Indication"),
  tabsetPanel(
    tabPanel('Choose Indication',
             fluidRow(
               column(width = 4,
                      br(),
                      varSelectInput("Program", "Line Of Buisness", LOB, colnames(LOB)[1]),
                      varSelectInput("State", "State", state_options('HO'),'GA'),
                      selectInput("IndicationDate", 'Indication Name / Experience Date (YYMM)', choices = date_options('HO'),date_options('HO')[2] ),
                      selectInput("EvaluationDate", 'Evaluated As Of:', choices = eval_date_options(date_options('HO')[[1]],'HO','GA'), selected =eval_date_options(date_options('HO')[[1]],'HO','GA')[1]),
                      selectInput("DataSource", 'PolicyRate Table Source:', choices = NULL),
                      uiOutput('ratingVersionID'),
                      br(),
                      actionButton('searchIndication', 'Load Indication', icon = NULL)
               ),
               column(2,br(),br(),
                      verbatimTextOutput('startLoad'),
                      verbatimTextOutput('inputLoad'),
                      verbatimTextOutput('LossTrendLoad'),
                      verbatimTextOutput('PremiumTrendLoad'),
                      verbatimTextOutput('OLFLoad'),
                      verbatimTextOutput('ModeledCatLoadLoad'),
                      verbatimTextOutput('LLLLoad'),
                      verbatimTextOutput('LDFLoad'),
                      verbatimTextOutput('SQLLoad'),
                      verbatimTextOutput('StartExhibits'), 
                      verbatimTextOutput('CompleteExhibits')
                      )
             )
    ),
    tabPanel("Inputs",
             fluidRow(
               column(4,
                      br(),
                      dateInput("proposedEffective",'Proposed Renewal Effective Date','2022-01-01') #old default
               ),
               column(8)
             ),
             fluidRow(
               column(4,
                      dateInput("fillOutDate","Fill Out Date (Used to get current SpatialKey, AAL, ISO data)",'2022-01-01')),
               column(8,br(),
                      DTOutput('SpatialAALmessage'))
               ),
             fluidRow(
               column(4,
                      selectInput('selected_by', 'Selections Made By:',choices = actuaryNames('All')),
                      selectInput('technical_reviewed_by', 'Technical Review Completed By:',choices = actuaryNames(actuaryNames('All')[1])),
                      selectInput('peer_reviewed_by', 'Peer Review Completed By:',choices = actuaryNames(actuaryNames('All')[1])),
                      numericInput('capped', 'Cap Losses at:', 250000),
                      checkboxGroupInput('includePerils', 'Peril List:', choices = c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane'), selected = 1),
                      #checkboxGroupInput('includeIndicationParts', 'Include List:', choices = c('Non-Modeled Cat Load', 'Territorial Analysis', 'Class Variable Analysis'), selected = 1),
                      actionButton('saveInputs','Save Inputs' , icon = NULL)),
               column(8)
             )
    ),
    tabPanel('Indication',
             tabsetPanel(
               tabPanel('Rate Level Indication',
                        tabsetPanel(
                          tabPanel('Memo Exhibit',
                                   fluidRow(
                                     column(3),
                                     column(6,br(),
                                            DTOutput('memo')),
                                     column(3)
                                   )),
                          tabPanel('Total',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state9'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('TotalLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('TotalProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            br(),
                                            withSpinner(DTOutput('TotalRateLevelIndication'))
                                     ),
                                     column(3)),
                                   fluidRow(
                                     column(4),
                                     column(5,
                                            br(),
                                            br(),
                                            withSpinner(DTOutput('TotalRateLevelSummary'))),
                                     column(3)
                                   )),
                          tabPanel(title = 'Fire',value = 'Fire',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state15'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('FireLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('FireProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Fire')),
                                            br(),
                                            withSpinner(DTOutput('FireIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('FireIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('FireIndicationSummary')),br(),
                                            withSpinner(DTOutput('FireRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Water',value = 'Water',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state16'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('WaterLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('WaterProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Water')),
                                            br(),
                                            withSpinner(DTOutput('WaterIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('WaterIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('WaterIndicationSummary')),br(),
                                            withSpinner(DTOutput('WaterRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Theft VMM',value = 'Theft',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state17'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('TheftLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('TheftProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Theft & VMM')),
                                            br(),
                                            withSpinner(DTOutput('TheftIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('TheftIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('TheftIndicationSummary')),br(),
                                            withSpinner(DTOutput('TheftRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Other AOP',value = 'OtherAOP',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state18'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('OtherAOPLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('OtherAOPProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Other AOP')),
                                            br(),
                                            withSpinner(DTOutput('OtherAOPIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('OtherAOPIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('OtherAOPIndicationSummary')),br(),
                                            withSpinner(DTOutput('OtherAOPRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Liability',value = 'Liability',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state20'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('LiabilityLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('LiabilityProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Liability')),
                                            br(),
                                            withSpinner(DTOutput('LiabilityIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('LiabilityIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('LiabilityIndicationSummary')),br(),
                                            withSpinner(DTOutput('LiabilityRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Non-Cat Weather',value = 'NCW',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state21'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('NCWLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('NCWProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Non-Cat Weather')),
                                            br(),
                                            withSpinner(DTOutput('NCWIndicationLosses')),br(),br(),
                                            withSpinner(DTOutput('NCWIndicationPremium')),br(),br(),
                                            withSpinner(DTOutput('NCWIndicationSummary')),br(),
                                            withSpinner(DTOutput('NCWRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='STS', value = 'STS',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state22'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('STSLOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('STSProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('STS')),
                                            br(),
                                            withSpinner(DTOutput('STSIndication')),br(),
                                            withSpinner(DTOutput('STSIndicationSummary')),br(),
                                            withSpinner(DTOutput('STSRateLevelChange')),br()
                                     ))),
                          tabPanel(title ='Hurricane', value = 'Hurricane',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('state23'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('HULOBheader'),
                                            h4(strong('Rate Level Indication')),
                                            uiOutput('HUProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                            br(),
                                            h5(strong('Hurricane')),
                                            br(),
                                            withSpinner(DTOutput('HUIndication')),br(),
                                            withSpinner(DTOutput('HUIndicationSummary')),br(),
                                            withSpinner(DTOutput('HURateLevelChange')),br()
                                     ))),
                          id = 'Indication'
                        )
               ),
               tabPanel('On Level Factors',
                        fluidRow(
                          column(4,
                                 align = 'center',
                                 h4(strong('On-Level Factors')),
                                 tableOutput('onLevelFactors')),
                          column(4,
                                 align = 'center',
                                 h4(strong('Cumulative Rate Changes')),
                                 tableOutput('OnLevelRateChanges'))
                        )
                        ),
               tabPanel('Premium Trend',
                        fluidRow(
                          column(4),
                          column(4,align = 'center',
                                 uiOutput('state8'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('PremiumTrendLOBheader'),
                                 h5(strong('Premium Trend Selection')),
                                 withSpinner(DTOutput('premiumTrend')),
                                 br(),
                                 br()
                          ),
                          column(4
                          ),
                          fluidRow(
                            column(5),
                            column(3,
                                   DTOutput('PremiumTrendfitting'),
                                   br()),
                            column(4)
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(1,
                                 currencyInput("currentPremiumTrend", 'Current Selection',0,format = "percentageUS2dec"),
                                 currencyInput("projPremiumTrend", 'Projected Selection',0,format = "percentageUS2dec"),br(),br(),
                                 tableOutput('ISOpremTrend')),
                          column(4,
                                 actionButton('PremiumSave','Save Selection', icon = NULL))
                        )
               ),
               tabPanel('LDFs',
                        tabsetPanel(
                          tabPanel('All Perils',
                                   fluidRow(column(12, align = 'center', 
                                                   h4(strong('Homeowners of America Insurance Company')),
                                                   h5(strong('Loss Development Factors')))
                                            ),
                                   fluidRow(column(6, h4(strong('State Triangles'))),
                                                         column(6, h4(strong('Countrywide Triangles')))),
                                   fluidRow(
                                     column(12,align = 'center',
                                            excelOutput("LDFAveragesAllTable", width = '100%', height = '100%'))),
                                   fluidRow(column(11),
                                            column(1,actionButton('LDFall.save', 'Save Selections')))),
                          tabPanel('Weather',
                                   fluidRow(column(12, align = 'center', 
                                                   h4(strong('Homeowners of America Insurance Company')),
                                                   h5(strong('Loss Development Factors')))
                                   ),
                                   fluidRow(column(6, h4(strong('State Triangles'))),
                                            column(6, h4(strong('Countrywide Triangles')))),
                                   fluidRow(
                                     column(12,align = 'center',
                                            excelOutput("LDFAveragesWeatherTable", width = '100%', height = '100%'))),
                                   fluidRow(column(11),
                                            column(1,actionButton('LDFweather.save', 'Save Selections')))),
                          tabPanel('Attritional',
                                   fluidRow(column(12, align = 'center', 
                                                   h4(strong('Homeowners of America Insurance Company')),
                                                   h5(strong('Loss Development Factors')))
                                   ),
                                   fluidRow(column(6, h4(strong('State Triangles'))),
                                            column(6, h4(strong('Countrywide Triangles')))),
                                   fluidRow(
                                     column(12,align = 'center',
                                            excelOutput("LDFAveragesAttritionalTable", width = '100%', height = '100%'))),
                                   fluidRow(column(11),
                                            column(1,actionButton('LDFattritional.save', 'Save Selections'))))
                        )),
               tabPanel('Loss Trend',
                        tabsetPanel(
                          tabPanel('State',
                                   fluidRow(
                                     column(4),
                                     column(4,align = 'center',
                                            uiOutput('state7'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('lossTrendLOBheader'),
                                            h5(strong('Loss Trend Selections')),
                                            withSpinner(DTOutput('lossTrendstate')),
                                            br(),
                                            br()
                                     ),
                                     column(4, 
                                     ),
                                     fluidRow(
                                       column(5),
                                       column(3,
                                              DTOutput('lossTrendstatefitting'),
                                              br()),
                                       column(4,
                                              radioButtons("LosstrendstateLag", label = "Number of Quarters to Lag to allow for full development",
                                                           choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                                           selected = 0)
                                       ))
                                   ),
                                   fluidRow(
                                     column(7),
                                     column(1,
                                            currencyInput("currentLossTrendState", 'Current Selection',default,format = "percentageUS2dec"), # default to 0.01 but it gets updated to either 0 or the saved value 
                                            currencyInput("projLossTrendState", 'Projected Selection',default,format = "percentageUS2dec"),br(),br(), # need to default this way due to the loading logic
                                            tableOutput('ISOlossTrend')),
                                     column(4,
                                            actionButton('stateLossTrendtoSQL', 'Save Selection',icon=NULL))
                                   ),
                                   fluidRow(
                                     column(3),
                                     column(6,
                                            sliderInput('LossTrendSlider', 'How many points?', min = 2, max = 2, value = 2, ticks = T)
                                            )
                                   ),
                                   fluidRow(
                                     column(3),
                                     column(6,
                                            plotOutput("StateLossPlot"),
                                            plotOutput("StateFrequencyPlot"),
                                            plotOutput("StateSeverityPlot")),
                                     column(2,
                                            checkboxGroupInput("LossTrendExclude", 
                                                               'Exclude Data Points:', 
                                                               choices = NULL,
                                                               selected = 1))
                                   )
                          ),
                          tabPanel('Countrywide',
                                   fluidRow(
                                     column(4),
                                     column(4,align = 'center',
                                            h4(strong('Countrywide')),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('lossTrendLOBheaderCW'),
                                            h5(strong('Loss Trend Selections')),
                                            withSpinner(DTOutput('lossTrendCW')),
                                            br(),
                                            br()
                                     ),
                                     column(4)
                                   ),
                                   fluidRow(
                                     column(5),
                                     column(3,
                                            withSpinner(DTOutput('lossTrendCWfitting')),
                                            br()),
                                     column(4
                                            #,
                                            # radioButtons("LosstrendCWLag", label = "Number of Quarters to Lag to allow for full development",
                                            #              choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                            #              selected = 0)
                                     )
                                   ),
                                   fluidRow(
                                     column(7),
                                     column(1,
                                            currencyInput("currentLossTrendCW", 'Current Selection',default,format = "percentageUS2dec"),
                                            currencyInput("projLossTrendCW", 'Projected Selection',default,format = "percentageUS2dec")),
                                     column(4,
                                            actionButton('cwLossTrendtoSQL', 'Save Selection',icon=NULL))
                                   )
                          )
                        )),
               tabPanel('LLL',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                        currencyInput("LLLstateweightTotal", uiOutput("state10"),default,format = "percentageUS2dec"),
                                        actionButton('LLLselectionsToSQL','Save Selection')
                                        ),
                          mainPanel(
                        tabsetPanel(id = 'LLL',
                                    tabPanel('Total',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLL'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load'),
                                                      withSpinner(DTOutput('LLLTotalTablestate')),
                                                      br()
                                               ),
                                               column(3)
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateTotal'),
                                                      DTOutput('LLLselectStateTotalSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load'),
                                                      withSpinner(DTOutput('LLLTotalTableCW')),
                                                      br(),
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWTotal'),
                                                      DTOutput('LLLselectCWTotalSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedTotal')
                                               )
                                             )),
                                    tabPanel(title = 'Fire', value = 'Fire',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLFire'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Fire'),
                                                      withSpinner(DTOutput('LLLTotalTablestateFire')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateFire'),
                                                      DTOutput('LLLselectStateFireSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Fire'),
                                                      withSpinner(DTOutput('LLLTotalTableCWFire')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWFire'),
                                                      DTOutput('LLLselectCWFireSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedFire'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Water',value = 'Water',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLWater'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Water'),
                                                      withSpinner(DTOutput('LLLTotalTablestateWater')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateWater'),
                                                      DTOutput('LLLselectStateWaterSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Water'),
                                                      withSpinner(DTOutput('LLLTotalTableCWWater')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWWater'),
                                                      DTOutput('LLLselectCWWaterSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedWater'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Theft',value = 'Theft',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLTheft'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Theft'),
                                                      withSpinner(DTOutput('LLLTotalTablestateTheft')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateTheft'),
                                                      DTOutput('LLLselectStateTheftSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Theft'),
                                                      withSpinner(DTOutput('LLLTotalTableCWTheft')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWTheft'),
                                                      DTOutput('LLLselectCWTheftSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedTheft'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Liability',value = 'Liability',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLLiability'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Liability'),
                                                      withSpinner(DTOutput('LLLTotalTablestateLiability')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateLiability'),
                                                      DTOutput('LLLselectStateLiabilitySelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Liability'),
                                                      withSpinner(DTOutput('LLLTotalTableCWLiability')))
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWLiability'),
                                                      DTOutput('LLLselectCWLiabilitySelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedLiability'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Other AOP',value = 'OtherAOP',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLOtherAOP'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Other AOP'),
                                                      withSpinner(DTOutput('LLLTotalTablestateOtherAOP')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateOtherAOP'),
                                                      DTOutput('LLLselectStateOtherAOPSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Other AOP'),
                                                      withSpinner(DTOutput('LLLTotalTableCWOtherAOP')))
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWOtherAOP'),
                                                      DTOutput('LLLselectCWOtherAOPSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedOtherAOP'),
                                                      br(),
                                                      br()
                                               )
                                             )),
                                    tabPanel(title = 'Weather', value = 'Weather',
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      uiOutput('stateLLLWeather'),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Weather'),
                                                      withSpinner(DTOutput('LLLTotalTablestateWeather')),
                                                      br()
                                               )
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectStateWeather'),
                                                      DTOutput('LLLselectStateWeatherSelected')
                                               )
                                             ),
                                             fluidRow(
                                               column(3),
                                               column(6,align='center',
                                                      br(),
                                                      br(),
                                                      h4(strong('Countrywide')),
                                                      h4(strong('Homeowners of America Insurance Company')),
                                                      h5('Large Loss Load - Weather'),
                                                      withSpinner(DTOutput('LLLTotalTableCWWeather')))
                                               
                                             ),
                                             fluidRow(
                                               column(7),
                                               column(2,
                                                      DTOutput('LLLselectCWWeather'),
                                                      DTOutput('LLLselectCWWeatherSelected'),
                                                      br(),
                                                      br(),
                                                      br(),
                                                      DTOutput('LLLweightedWeather'),
                                                      br(),
                                                      br()
                                               )
                                             ))
                        )
               ))),
               tabPanel("Cat Load",
                        tabsetPanel(
                          tabPanel("Expense Load",
                                   fluidRow(
                                     column(width = 6,br(),
                                            tableOutput("cw_expense")
                                     ),    
                                     column(2, br(),
                                            checkboxGroupInput("cw_exclude", 
                                                               "CW Exclude Year", 
                                                               choices = NULL,
                                                               selected = 1)),
                                     column(1,
                                            currencyInput("CATstateweight", uiOutput("state1"),default,format = "percentageUS2dec"),
                                            DTOutput("expense_load_output"),
                                            DTOutput('expense_load_output_selected'),
                                            br(),
                                            actionButton('catLoadtoSQL','Save Selection' , icon = NULL)),
                                     column(1),
                                     column(1,br(),br(),br(),
                                            actionButton('useCalcExpense','Use Calculated',icon=NULL)) 
                                   ),
                                   fluidRow(
                                     column(6,
                                            tableOutput("state_expense")),
                                     column(2,br(),
                                            checkboxGroupInput("state_exclude", 
                                                               uiOutput('state2'), 
                                                               choices = NULL,
                                                               selected = 1)),
                                     column(1)
                                   )
                          ),
                          tabPanel("Modeled Results",
                                   fluidRow(
                                     column(1),
                                     column(width = 10,align = 'center',
                                            uiOutput("state6"),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('LOB_header'),
                                            h5('Modeled Catastrophe (CAT) Load'),
                                            withSpinner(DTOutput('ModeledCatLoad'))
                                     ),
                                     column(1)
                                   )
                          ),
                          tabPanel('Non-Modeled Results',
                                   sidebarLayout(
                                     sidebarPanel(width = 2,
                                       selectInput('useNonModeled', 'Use Non-Modeled Results?', choices = list('Yes' = 1, 'No' = 0), selected = 0),
                                       currencyInput('NonModeledAvgWeight', 'Weighted Average Weight (to Straight Average)',default,format = "percentageUS2dec"),
                                       currencyInput('NonModeledStateWeight', 'State Experience Weight',default,format = "percentageUS2dec"),
                                       textOutput('STSExpFactorText'),
                                       textOutput('STSExpFactorYearsText'),br(),br(),
                                       actionButton('nonModeledSave','Save Selection')
                                       
                                     ),
                                     mainPanel(width=10,
                                       tabsetPanel(id = 'NonModeled')
                                     )
                                   ))
                        ) #Close inner tabsetPanel
               ),
               tabPanel('Expense Ratios',
                        tabsetPanel(
                          tabPanel('Expense Exhibit',
                                   fluidRow(
                                     column(3),
                                     column(6,align = 'center',
                                            uiOutput('state30'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('ExpenseLOBheader'),
                                            h4('Expense Provisions'),
                                            br(),
                                            withSpinner(DTOutput('expenseExhibit'))),
                                     column(3)
                                   )
                          ),
                          tabPanel('CAT Reinsurance Provision By Peril',
                                   fluidRow(
                                     column(3),
                                     column(6,align='center',
                                            uiOutput('stateReinsurance'),
                                            h4(strong('Homeowners of America Insurance Company')),
                                            uiOutput('ReinsuranceLOB'),
                                            h4('Reinsurance Exhibit'),
                                            withSpinner(DTOutput('reinsuranceExhibit'))
                                     ),
                                     column(3)
                                   ))
                        )),
               tabPanel('Reconciliation',
                        fluidRow(
                          column(12,align='center',
                        excelOutput("IndicationReconciliation", width = '100%', height = '100%')
                        ))
                    )
               )),
    tabPanel('Territorial Analysis',
             tabsetPanel(id = 'TerritorialAnalysis',
                         tabPanel('Exhibit',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibit'))
                                  )),
                         tabPanel('Exhibit Snapshot',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitSnapshot'))
                                  )),
                         tabPanel(title = 'Exhibit Fire', value = 'ExhibitFire',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitFire'))
                                  )),
                         tabPanel(title = 'Exhibit Water', value = 'ExhibitWater', 
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitWater'))
                                  )),
                         tabPanel(title = 'Exhibit Theft', value = 'ExhibitTheft',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitTheft'))
                                  )),
                         tabPanel(title ='Exhibit Liab', value = 'ExhibitLiab',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitLiab'))
                                  )),
                         tabPanel(title ='Exhibit AOP', value = 'ExhibitAOP',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitAOP'))
                                  )),
                         tabPanel(title ='Exhibit NCW', value = 'ExhibitNCW',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitNCW'))
                                  )),
                         tabPanel(title ='Exhibit STS', value = 'ExhibitSTS',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitSTS'))
                                  )),
                         tabPanel(title ='Exhibit HU', value = 'ExhibitHU',
                                  fluidRow(
                                    column(2),
                                    column(8, align = 'center',
                                           DTOutput('TerritorialExhibitHU'))
                                  ))
             )),
    tabPanel('Class Variable Analysis',
             tabsetPanel(
               # Show a plot of the generated distribution
               tabPanel('Review Plots',
                 fluidRow(
                   column(3,
                          selectInput('selectVariable', label = 'Class Variable SQL Name:',choices = NULL)),
                   column(3,
                          selectInput('selectPeril', label = 'Peril:',choices = NULL)),
                   column(3,
                          textInput("variableTitle", label = "Class Variable Display Name:", value = "Enter Title..."),
                          actionButton('saveTitle', label ='Save New Display Name'))
                 ),
                 fluidRow(br(),br(),
                          column(12,
                                 withSpinner(plotOutput("distPlot")),br(),
                                 withSpinner(DTOutput('table'))
                          )
                 )
               ),
               tabPanel('Choose CVA Variables',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       checkboxGroupInput('ProgramvariableOptions', label = 'Homeowners Variable Options') #searchRaters
                          ), 
                          mainPanel()
                        ))
             )),
    # tabPanel('Endorsement Analysis',   #remove the endorsemnt analysis for now since have not yet started!
    #          tabsetPanel(
    #            tabPanel('Inc Liability and Inc Med'),
    #            tabPanel('Other Endorsements')
    #          )),
    tabPanel('Review Selections',
             tabsetPanel(
               tabPanel('Confirm Selections',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       h3('Selector Checklist:'),
                                       h5('Confirm that each selection has been made.'),br(),
                                       checkboxGroupInput('SelectorChecklist', label = 'Confirm Selections and Data for:',
                                                          choices = selectorChecklist_list),
                                       h5('Once you have checked all of the 
                             boxes, then you will be able to send for Technical Review.'),
                                       br(),
                                       actionButton('saveSelectionsForReview','Selections Complete'),br(),br(),br(),
                                       uiOutput('EmailReviewToTechnical'), #send to Peer reviewer if all things check out and cc the Indication selector
                                       #if there is a problem with reconciliation, then send a different email to just Ian so he can track down the error and cc the indication selector
                                       use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )
                        ),
               tabPanel('Technical Review',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                          h3('Technical Review Checklist:'),
                          h5('Confirm that Premium and Losses reconcile to each other in the shiny app and that they are consistent with our expectations.'),br(),
                          checkboxGroupInput('TechnicalreviewChecklist', label = 'Premium and Losses Reconcile for:',
                                             choices = technicalChecklist_list),
                          h5('Once you have checked all of the 
                             boxes, then you will be able to notify Peer review to begin their evaluation.'),
                          br(),
                          actionButton('saveTechnicalReview','Techincal Review Complete'),br(),br(),br(),
                          uiOutput('EmailReviewToPeer'), #send to Peer reviewer if all things check out and cc the Indication selector
                          #if there is a problem with reconciliation, then send a different email to just Ian so he can track down the error and cc the indication selector
                          use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )),
               tabPanel('Peer Review',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       h3('Peer Review Checklist:'),
                                       h5('Review each of the selections made in the indication.'),br(),
                                       checkboxGroupInput('PeerReviewChecklist', label = 'Approve the following Selections:',
                                                          choices = peerChecklist_list),
                                       h5('Once you have checked all of the 
                             boxes, then you will be able to notify that the indication is ready to be published and sent out.'),
                                       
                             br(),
                             actionButton('savePeerReview','Peer Review Complete'),br(),br(),br(),
                             uiOutput('EmailReviewToSelector'), 
                             use_mailtoR()
                          ),
                          mainPanel(
                          )
                        )),
               tabPanel('Publish',
                        sidebarLayout(
                          sidebarPanel(width = 2,
                                       tableOutput('ReviewProgress'),
                                       h5('Once each step has been completed. Then selections can be published.'),
                                       
                                       br(),
                                       actionButton('PublishSelections','Publish')
                          ),
                          mainPanel(
                          )
                        ))
             )),
    tabPanel('Download',
             column(6,align = 'center',
                    downloadButton("report", "Download Indication Exhibits")
             ), 
             column(6,align = 'center',
                    downloadButton("territorial_report", "Download Territorial Analysis Exhibits")
             )
             
    )
  ) #Close outer tabsetPanel
) #Close FluidPage

server <- function(input, output,session) {
  #define all data frames as empty. then update them with observe event when indication, asOFdate, state, LOB change. reduce the number of times that data is reloaded into the server. Better practice
  cw_expense = data.frame()
  evaluation_date_proxy <- NULL
  indication_change <- FALSE
  searchIndication <- 0
  emailCount<-0
  nonModeledCount <- 0
  STSexpFactor <- reactiveValues(Value = 1)
  STSyearExpAdj <- reactiveValues(Value = 0) 
  HUexpFactor <- reactiveValues(Value = 1) 
  HUyearsAdjFactor <- reactiveValues(Value = 0) 
  
  LDF_selection <- reactiveValues(All = c(),
                                  Weather = c(),
                                  Attritional = c())
  LDFcumulative <- reactiveValues(All = c(),
                                  Weather = c(),
                                  Attritional = c())
  LDF_weight <- reactiveValues(All = c(), #fill these with the excel table inputs
                              Weather = c(),
                              Attritional = c())
  
  test <- reactiveValues(x = 0)
  zoneYearExclude <- reactiveValues(z1=0,
                                    z2=0,
                                    z3=0,
                                    z4=0,
                                    z5=0,
                                    z6=0,
                                    z7=0,
                                    z8=0,
                                    z9=0,
                                    z10=0)
  
  NonModeledInputs <- c()
  #start of expense display function
  
  rv <- reactiveValues(outputText = '')
  
  observeEvent({input$searchIndication},{
    
   
    searchIndication <<- 0
    searchIndicationInput <<- input$searchIndication
    
    
  }, priority = 1000000)
  
  
  observeEvent(input$searchIndication, {
    withCallingHandlers({
      shinyjs::html("startLoad", "")
      message('Starting Load')
    },
    message = function(m) {
      shinyjs::html(id = "startLoad", html = m$message, add = TRUE)
    })
  },priority =  1000000)
  
  observeEvent({c(input$selected_by)},
               { 
                  
                 updateSelectInput(session, input = 'technical_reviewed_by',
                                   choices = actuaryNames(input$selected_by))
                 
                 updateSelectInput(session, input = 'peer_reviewed_by',
                                   choices = actuaryNames(c(input$selected_by,input$technical_reviewed_by))) 
                 
               })
  observeEvent({c(input$technical_reviewed_by)},
               { 
                
                 updateSelectInput(session, input = 'peer_reviewed_by',
                                   choices = actuaryNames(c(input$selected_by,input$technical_reviewed_by))) 
                 
               })

  
  observeEvent({c(input$selected_by,input$technical_reviewed_by,input$peer_reviewed_by,input$IndicationDate, input$State, input$Program, input$SelectorChecklist,input$TechnicalreviewChecklist,input$PeerReviewChecklist)}, #prep the review email to send out
               { 
                   
                 
                 selector <- actuaryReturn(input$selected_by)
                 techreviewer <- actuaryReturn(input$technical_reviewed_by)
                 peerreviewer <- actuaryReturn(input$peer_reviewed_by)
                 emailCount <<- emailCount+1
                 sendToTech = paste0(tolower(substr(techreviewer$FirstName, start=1, stop = 1)),tolower(techreviewer$LastName),"@hoaic.com")
                 sendToPeer = paste0(tolower(substr(peerreviewer$FirstName, start=1, stop = 1)),tolower(peerreviewer$LastName),"@hoaic.com")
                 sendToSelector = paste0(tolower(substr(selector$FirstName, start=1, stop = 1)),tolower(selector$LastName),"@hoaic.com")
                 support = 'istarkey@hoaic.com'
 
                 IndicationName <- strftime(as.Date(input$IndicationDate)-1, format = "%y%m")
                 
                 if (length(input$SelectorChecklist) == length(selectorChecklist_list) ) {
                 output$EmailReviewToTechnical <- renderUI({mailtoR(email = sendToTech,
                                                                     cc = c(" "),
                                                                     bcc = c(" "),
                                                                     text = "Send Email for Technical Review", 
                                                                     subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                     body = glue::glue(
                                                                       
                                                                     paste0("
                                                     Hi ",techreviewer$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," is ready for the technical review. Let me know if there are any discrepancies in the data!
                                                                  
                                                     Thanks,
                                                     ",selector$FirstName)))
                 })
                 } else {
                   output$EmailReviewToTechnical <- renderUI({mailtoR(email = sendToTech,
                                                                      cc = c(" "),
                                                                      bcc = c(" "),
                                                                      text = "", 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(""))
                   })
                 }
                 
                 if (length(input$TechnicalreviewChecklist) == length(technicalChecklist_list) ) {
                   output$EmailReviewToPeer <- renderUI({mailtoR(email = sendToPeer,
                                                                      cc = c(sendToSelector),
                                                                      bcc = c(" "),
                                                                      text = "Send Email for Peer Review", 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(
                                                                        
                                                                      paste0("
                                                     Hi ",peerreviewer$FirstName,",
                                                                
                                                     The Technical Review is complete for ",selector$FirstName,"'s selections for ",input$State," ", input$Program," Indication ",IndicationName," and is ready for Peer Review.
                                                                  
                                                     Thanks,
                                                     ",techreviewer$FirstName)))
                   })
                   
                 } else {
                   output$EmailReviewToPeer <- renderUI({mailtoR(email = support,
                                                                 cc = c(sendToSelector),
                                                                 bcc = c(" "),
                                                                 text = "Report an issue with the data", 
                                                                 subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                 body = glue::glue(
                                                                   
                                                                   paste0("
                                                     Hi Ian,
                                                                
                                                     There is a data error in the ",input$State," ", input$Program," Indication ",IndicationName," for the following tables:
                                                                  
                                                     Thanks,
                                                     ",techreviewer$FirstName)))
                   })
                 }
                 
                 if (length(input$PeerReviewChecklist) == length(peerChecklist_list) ) {
                   output$EmailReviewToSelector <- renderUI({mailtoR(email = sendToSelector,
                                                                      cc = c(" "),
                                                                      bcc = c(" "),
                                                                      text = paste("Notify",selector$FirstName,'selections are ready to Publish.', sep = ' '), 
                                                                      subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                      body = glue::glue(
                                                                        
                                                                      paste0("
                                                     Hi ",selector$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," peer review is complete. The selections are ready to be published.
                                                                  
                                                     Thanks,
                                                     ",peerreviewer$FirstName)))
                   })
                 } else {
                   output$EmailReviewToSelector <- renderUI({mailtoR(email = sendToSelector,
                                                                     cc = c(" "),
                                                                     bcc = c(" "),
                                                                     text = paste("Notify",selector$FirstName,'selections need revision.', sep = ' '), 
                                                                     subject = paste(input$State, input$Program,"Indication",IndicationName,"Review",sep = ' '), 
                                                                     body = glue::glue(
                                                                       
                                                                       paste0("
                                                     Hi ",selector$FirstName,",
                                                                
                                                     The ",input$State," ", input$Program," Indication ",IndicationName," peer review is in progress. 
                                                     The following selections need revision:
                                                                  
                                                     Thanks,
                                                     ",peerreviewer$FirstName)))
                   })
                 }
               },priority = 9)
  

  
  observeEvent({c(input$saveTechnicalReview,input$savePeerReview, input$saveSelectionsForReview)},
               {
                 print('change')
                 #Sys.sleep(15)
                 ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)
                 ReviewProgressDataFilter <<- ReviewProgressData%>%
                   filter(Status == 'Complete')
                 
                 
                 output$ReviewProgress <- renderTable(ReviewProgressData)
                 
               },priority = 9)
  


  
  observeEvent({c(input$Program)},
               { print('update state')
                 updateVarSelectInput(session, input = 'State',
                                      data = state_options(input$Program), selected = colnames(state_options(input$Program))[1])#colnames(state_options(input$Program))[1])
                 print('1')
                 date_update <- date_options(input$Program)
                 print(2)
                 updateSelectInput(session,inputId='IndicationDate',
                                   choices = date_update)
                 print(3)
               },priority = 1000)
  
  observeEvent({c(input$IndicationDate,input$State)},{
    print('update eval')
    eval_update <- eval_date_options(input$IndicationDate, input$Program,input$State)
    print('work')
    print(eval_update)
    updateSelectInput(session,inputId='EvaluationDate',
                      choices = eval_update,selected = eval_update[[length(eval_update)]])
    evaluation_date_proxy <<- eval_update[[length(eval_update)]]
    indication_change <<- TRUE
    print('exit eval')
  },priority = 100
  )
  
  observeEvent({c(input$Program, input$State, input$IndicationDate, input$EvaluationDate)},
               {
                 
                 data.source.list <<- data.source.options(input$Program, input$IndicationDate, input$EvaluationDate,input$State)
                 updateSelectInput(session, inputId = 'DataSource',
                                   choices = data.source.list)
               }
  )
  
  observeEvent({c(input$Program, input$State, input$IndicationDate, input$EvaluationDate, input$DataSource)},
               {print('update ratingversionID')
                 ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)
                 output$ReviewProgress <- renderTable(ReviewProgressData)
                 output$ratingVersionID <- renderUI(h5(strong('Rating Version ID @ CRL: '), ratingVersionID(input$Program, input$State, input$IndicationDate, input$EvaluationDate,input$DataSource)))
                 
               },priority = 9)
  
  
  observe({
    #hide by peril tabs if no selected 
    if ('Fire' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Fire')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitFire')
      showTab(inputId = 'LLL', target = 'Fire')
    } else {
      hideTab(inputId = 'Indication', target = 'Fire')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitFire')
      hideTab(inputId = 'LLL', target = 'Fire')
    }
    if ('Water' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Water')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitWater')
      showTab(inputId = 'LLL', target = 'Water')
    } else {
      hideTab(inputId = 'Indication', target = 'Water')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitWater')
      hideTab(inputId = 'LLL', target = 'Water')
    }
    if ('Theft' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Theft')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitTheft')
      showTab(inputId = 'LLL', target = 'Theft')
    } else {
      hideTab(inputId = 'Indication', target = 'Theft')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitTheft')
      hideTab(inputId = 'LLL', target = 'Theft')
    }
    if ('Liability' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Liability')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitLiab')
      showTab(inputId = 'LLL', target = 'Liability')
    } else {
      hideTab(inputId = 'Indication', target = 'Liability')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitLiab')
      hideTab(inputId = 'LLL', target = 'Liability')
    }
    if ('Other' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'OtherAOP')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitAOP')
      showTab(inputId = 'LLL', target = 'OtherAOP')
    } else {
      hideTab(inputId = 'Indication', target = 'OtherAOP')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitAOP')
      hideTab(inputId = 'LLL', target = 'OtherAOP')
    }
    # if ('Explosion' %in% input$includePerils) {
    #   showTab(inputId = 'Indication', target = 'Explosion')
    #   showTab(inputId = 'TerritorialAnalysis', target = 'Explosion')
    # } else {
    #   hideTab(inputId = 'Indication', target = 'Explosion')
    #   hideTab(inputId = 'TerritorialAnalysis', target = 'Explosion')
    # }
    if ('NCW' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'NCW')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitNCW')
      showTab(inputId = 'LLL', target = 'NCW')
    } else {
      hideTab(inputId = 'Indication', target = 'NCW')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitNCW')
      hideTab(inputId = 'LLL', target = 'NCW')
    }
    if ('STS' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'STS')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitSTS')
      showTab(inputId = 'LLL', target = 'STS')
    } else {
      hideTab(inputId = 'Indication', target = 'STS')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitSTS')
      hideTab(inputId = 'LLL', target = 'STS')
    }
    if ('Hurricane' %in% input$includePerils) {
      showTab(inputId = 'Indication', target = 'Hurricane')
      showTab(inputId = 'TerritorialAnalysis', target = 'ExhibitHU')
      showTab(inputId = 'LLL', target = 'Hurricane')
    } else {
      hideTab(inputId = 'Indication', target = 'Hurricane')
      hideTab(inputId = 'TerritorialAnalysis', target = 'ExhibitHU')
      hideTab(inputId = 'LLL', target = 'Hurricane')
    }
    
  }, priority = 98)
  observeEvent({input$IndicationDate
    input$EvaluationDate},
    {
      if (indication_change) {
        indication_change <<- FALSE
        evaluation_use <<- evaluation_date_proxy
      } else {
        evaluation_use <<- input$EvaluationDate
      }
      
    },priority = 99)
  
  
  
  observeEvent({c(input$Program, input$State, input$IndicationDate, input$EvaluationDate)},{
    
    searchIndication <<- input$searchIndication
    
  }, priority = 99)
  
  

  
  observe({
    
    if (input$searchIndication > searchIndication) {
      
  observeEvent({input$State
    input$Program
    input$EvaluationDate
    input$IndicationDate
  },
  {if (input$searchIndication > searchIndication) {

    #load in data based on inputs tab selections
    print(session$user) #will use this when we publish the App to shinyapps.io
    print('start cw_expense load')
    
    cw_expense <<- expense_cw(input$Program, evaluation_use,input$IndicationDate)

    
    #execute renderTable for tables that only depend on inputs tab
    output$LOB_header=output$LOB_header1=output$LOB_header2=output$LOB_header3=output$LOB_header4=output$LOB_header5=output$LOB_header6 <- renderUI({h4(strong(table_name(input$Program)))})
    output$state1 = output$state10<- renderUI(paste(state_name_full(input$State),'Weight',sep = ' '))
    output$state2 <- renderUI(paste(state_name_full(input$State),'Exclude Year',sep = ' '))
    output$state3=output$state4=output$state5=output$state6=output$state7=output$state8=output$state9=output$state15=output$state16=output$state17=output$state18=output$state20=output$state21=output$state22=output$state23=output$state30=output$stateReinsurance=output$stateLLL=output$stateLLLFire=output$stateLLLWater=output$stateLLLTheft=output$stateLLLLiability=output$stateLLLOtherAOP=output$stateLLLWeather <- renderUI(h4(strong(state_name_full(input$State))))
    output$lossTrendLOBheader = output$lossTrendLOBheaderCW <- renderUI(h4(strong(paste0(table_name(input$Program),' : All Forms Combined - Excluding Catastrophe'))))
    output$PremiumTrendLOBheader= output$TotalLOBheader= output$FireLOBheader= output$WaterLOBheader= output$TheftLOBheader= output$LiabilityLOBheader= output$OtherAOPLOBheader= output$NCWLOBheader= output$HULOBheader= output$STSLOBheader=output$ReinsuranceLOB <- renderUI(h4(strong(paste0(table_name(input$Program),' : All Forms Combined'))))
    state_profit <<- profit(input$State, input$IndicationDate,input$Program)
    output$TotalProfit=output$FireProfit=output$WaterProfit=output$TheftProfit=output$LiabilityProfit=output$OtherAOPProfit=output$NCWProfit=output$NCWProfit=output$STSProfit=output$HUProfit<- renderUI(h5(paste0('Priced to a ',(1-as.numeric(state_profit))*100,'% Combined Ratio')))
    ####
    output$cw_expense <- renderTable(cw_expense,width = '100%')
    output$state_expense <-renderTable(expense_state(input$Program, evaluation_use,input$IndicationDate, input$State),width = '100%')
    updateCheckboxGroupInput(session, input = "cw_exclude",
                             choices = head(expense_cw(input$Program, evaluation_use,input$IndicationDate)$Year,-1),
                             selected = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catExcludeCW',NULL))

    updateCheckboxGroupInput(session, input = "state_exclude",
                             choices = head(expense_state(input$Program, evaluation_use,input$IndicationDate, input$State)$Year,-1),
                             selected = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catExclude',NULL))
    
    updateCurrencyInput(session, input='LLLstateweightTotal',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','LLLweight',0))
    updateCurrencyInput(session, input='CATstateweight',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadWeight',0))
    
    updateCurrencyInput(session, input='currentLossTrendCW',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,'CW','All Perils','curLossTrend',0))
    
    updateCurrencyInput(session, input='projLossTrendCW',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,'CW','All Perils','projLossTrend',0))
    
      updateCurrencyInput(session, input='currentLossTrendState',
                          value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','curLossTrend',0))
    
      updateCurrencyInput(session, input='NonModeledAvgWeight',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','NonModeledAvgWeight',.5))
    updateCurrencyInput(session, input='NonModeledStateWeight',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','NonModeledStateWeight',1))
    
    updateCurrencyInput(session, input='projLossTrendState',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','projLossTrend',0))
    
    updateCurrencyInput(session, input='currentPremiumTrend',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','curPremTrend',0))
    
    updateCurrencyInput(session, input='projPremiumTrend',
                        value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','projPremTrend',0))
    
    updateSelectInput(session, input = 'selected_by',
                      selected = selections_id(input$IndicationDate, evaluation_use, input$State, input$Program))
    print('useNonModeled')
    updateSelectInput(session, input = 'useNonModeled',
                      selected = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','useNonModeled',0) )
    print('useNonModeled')
    
    print(input$proposedEffective)
    updateDateInput(session, input = 'proposedEffective',
                    value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','proposedEffective',Sys.Date() ))
    print(input$proposedEffective)
    updateDateInput(session, input = 'fillOutDate',
                    value = pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','fillOutDate',Sys.Date()))
    print(input$fillOutDate)
    updateCheckboxGroupInput(session,input = 'includePerils', 
                             choices = if (input$Program=='HO') {
                               c('Fire', 'Water', 'Theft', 'Liability', 'Other' ,'NCW', 'STS', 'Hurricane')
                             } else if (input$Program=='DF') {
                               c('Fire', 'Water', 'Theft', 'Explosion', 'Other' ,'NCW', 'STS', 'Hurricane')
                             } else {
                               c('No By Peril States in Program')
                             },
                             selected = peril_list(input$Program, input$State, input$IndicationDate, evaluation_use))
    
    withCallingHandlers({
      shinyjs::html("inputLoad", "")
      message('Inputs Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "inputLoad", html = m$message, add = TRUE)
    })
    
    ReviewProgressData <<- review_progress(input$Program, input$State, input$IndicationDate, evaluation_use)

    if (ReviewProgressData[3,2]=='Complete') updateCheckboxGroupInput(session,input = 'PeerReviewChecklist',selected = peerChecklist_list)
    if (ReviewProgressData[2,2]=='Complete') updateCheckboxGroupInput(session,input = 'TechnicalreviewChecklist',selected = technicalChecklist_list)
    if (ReviewProgressData[1,2]=='Complete') updateCheckboxGroupInput(session,input = 'SelectorChecklist',selected = selectorChecklist_list)
      
      
      selected_expense_data_selected<<- pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadSelection',0)
    
    
    print('state new LDFs')
    LDFDataPull <- LDF_Excel_Pull(input$Program,input$IndicationDate,input$EvaluationDate,input$State)
    print(LDFDataPull)
    state.formulas.All <<- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'All Perils')
    state.formulas.Weather <<- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Weather')
    state.formulas.Attritional <<- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Attritional')
    
    cw.formulas.All <- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'All Perils','CW')
    cw.formulas.Weather <- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Weather','CW')
    cw.formulas.Attritional <- pull_ldfs(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Attritional','CW')
    
    print('LDF formulas pulled')
    LDF_weight$All <- pull_variable(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'All Perils','LDFweight',0)
    LDF_weight$Weather <- pull_variable(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Weather','LDFweight',0)
    LDF_weight$Attritional <- pull_variable(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Attritional','LDFweight',0)
    print('create lDF tables')
    LDFDataAll <-LDF_Tables_All(LDFDataPull,input$IndicationDate,input$EvaluationDate,'All Perils',input$State,LDF_weight$All,state.formulas.All,cw.formulas.All)
    LDFDataWeather <-LDF_Tables_All(LDFDataPull,input$IndicationDate,input$EvaluationDate,'Weather',input$State,LDF_weight$Weather,state.formulas.Weather,cw.formulas.Weather)
    LDFDataAttritional <-LDF_Tables_All(LDFDataPull,input$IndicationDate,input$EvaluationDate,'Attritional',input$State,LDF_weight$Attritional,state.formulas.Attritional,cw.formulas.Attritional)
    
    print('create new LDF tables')
    #new Averages Tables, supper clean and concise !!!!!
    output$LDFAveragesAllTable <-renderExcel(LDFDataAll[[1]])
    output$LDFAveragesWeatherTable <-renderExcel(LDFDataWeather[[1]])
    output$LDFAveragesAttritionalTable <-renderExcel(LDFDataAttritional[[1]]) 
    
    print('save initial/saved LDF selections')
    #read in the initial/loaded selctions if there are any 
    LDFcumulative$All <- LDF_Translate(LDFDataAll[[2]])[42,13:22] 
    LDFcumulative$Weather <- LDF_Translate(LDFDataWeather[[2]])[42,13:22]
    LDFcumulative$Attritional <- LDF_Translate(LDFDataAttritional[[2]])[42,13:22]
    print('initial saved')
    #LDF_weight
    #save to reactive values
    
    withCallingHandlers({
      shinyjs::html("LDFLoad", "")
      message('LDF Data Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "LDFLoad", html = m$message, add = TRUE)
    })
    
    print('state reconcile load')
    manualTargitInput.data <<- manualTargitInput.pull(input$Program,input$IndicationDate,evaluation_use, input$State)
    coverage_report_data <<- coverage_report_load(input$IndicationDate,evaluation_use, input$State,input$Program,input$DataSource)
    print('reconciliation tab')
    reconciliation.data <<- reconcilation_tab.fun(coverage_report_data,manualTargitInput.data)
    
    reconciliation.update <<- reconciliation.data[[1]]
    print('end reconcil load')
    

    #LossTrendDate <<- loss_trend_data(input$Program, input$IndicationDate, evaluation_use)
    print('losstrend')
    lossTrendCWData <<-loss_trend_cw(input$Program, input$IndicationDate, evaluation_use)
    print('losstrend1')
    lossTrendstateData <<- loss_trend_state(input$Program, input$IndicationDate, evaluation_use,input$State)
    print('losstrend2')
    
    withCallingHandlers({
      shinyjs::html("LossTrendLoad", "")
      message('Loss Trend Data Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "LossTrendLoad", html = m$message, add = TRUE)
    })
    
    updateCheckboxGroupInput(session, input = "LossTrendExclude",
                             choices = head(lossTrendstateData$`Year Ending Quarter - X`, nrow(lossTrendstateData) ),
                             selected = NULL)
    
    
    output$lossTrendCW <- renderDT(datatable(lossTrendCWData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                     formatRound(c(2,3,4,6),digits=0)%>%
                                     formatRound(c(5,7),digits = 2))#,spacing='xs')
    output$lossTrendstate <- renderDT(datatable(lossTrendstateData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                        formatRound(c(2,3,4,6),digits=0)%>%
                                        formatRound(c(5,7),digits = 2))
   
    output$lossTrendCWfitting <- renderDT(datatable(loss_trend_fitting(lossTrendCWData,as.numeric(0)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                            formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
    if (nrow(lossTrendstateData) > 2) {
    output$lossTrendstatefitting <- renderDT(datatable(loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                               formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
    }
    
    print('start premium trend load')
    PremiumData <<- premium_trend_data(input$Program,input$IndicationDate, evaluation_use,input$State)
    PremiumData_state <<- premium_trend(PremiumData)
    
    output$premiumTrend <- renderDT(datatable(PremiumData_state%>%select(-Date),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatRound(c(2,3,4), digits = 0)%>%formatRound(c(5),digits = 2))

    if (nrow(PremiumData_state) > 2) {
    output$PremiumTrendfitting <- renderDT(datatable(premium_trend_fitting(PremiumData_state,0),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatPercentage(c(2), digits = 1))
    }
    
    
    withCallingHandlers({
      shinyjs::html("PremiumTrendLoad", "")
      message('Premium Trend Data Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "PremiumTrendLoad", html = m$message, add = TRUE)
    })
    
    print('start expense ratios load')
    expense_ratios <<- expense_load(input$IndicationDate, evaluation_use,input$State, input$Program)
 
    output$expenseExhibit <- renderDT(datatable(expense_ratios,selection = 'none',class = 'compact',
                                                options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                        formatCurrency(c(3,5,7), digits =0)%>%
                                        formatPercentage(c(4,6,8,9,10), digits=1)
    )

    
    
    print('start targit load')
    targit_EP_data <<- targit_EP_load(input$Program,input$IndicationDate,evaluation_use, input$State)
    
    print('start OLFs')
    
    OLFcumulative <<- on_level_cumulative(input$IndicationDate,input$Program,input$State)
    on_level_load <<- on_level_factors_load(input$Program,input$IndicationDate, input$State)
    
    
    output$onLevelFactors <- renderTable(on_level_load%>%
                                           arrange(CalenderYear)%>%
                                           mutate(`Calender Year` = CalenderYear,`On-Level Factor` = OnLevelFactor)%>%
                                           select(`Calender Year`,`On-Level Factor` )
                                           )
    output$OnLevelRateChanges <- renderTable(OLFcumulative%>%
                                               mutate(`Rate Change` = paste0(round(`Rate Change`*100,1),'%')))
    
    withCallingHandlers({
      shinyjs::html("OLFLoad", "")
      message('On Level Factor Data Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "OLFLoad", html = m$message, add = TRUE)
    })
    print('start CVA checkbox load')
     #searchRaters(input$Program, input$State)
    updateCheckboxGroupInput(session, input = "ProgramvariableOptions",
                             choices = variableOptions(input$Program,input$DataSource),
                             selected = searchRaters(input$Program, input$State,input$DataSource) )
    
    
    
    #Load in the data used in the Non-Modeled
    NonModeledZones <<- nonModeledPull(input$Program,input$IndicationDate,input$EvaluationDate,input$State)
    
    InforceSummary <<- inforceSummary(input$Program,input$IndicationDate,input$EvaluationDate,input$State,input$DataSource)
    
    print('end prioity 3') 
    
  }
  },priority = 3) 
  
  observeEvent({input$LDFAveragesAllTable},{ 
    LDFDataAll.updated <<- excel_to_R(input$LDFAveragesAllTable)
    LDFAveragesAll.Cumulative.Final <<- LDF_Translate(LDFDataAll.updated)[42,13:22] 
    state.formulas.All <<- LDFDataAll.updated[34,2:10][colSums(!is.na(LDFDataAll.updated[34,2:10])) > 0]
    cw.formulas.All <<- LDFDataAll.updated[34,14:22]
    if (!setequal(LDFAveragesAll.Cumulative.Final,LDFcumulative$All)) {  
      LDFcumulative$All <<- LDFAveragesAll.Cumulative.Final
    } 
    LDFweightAll <<- as.numeric(LDFDataAll.updated[39,22])
    if (LDFweightAll != LDF_weight$All) {
      LDF_weight$All <- LDFweightAll
      print('update LDF all')
    }
  },priority = 3)
  
  observeEvent({LDFcumulative$All},{
    print(LDFcumulative$All)
  },priority = 3)
  
  observeEvent({input$LDFAveragesWeatherTable},{ 
    LDFDataWeather.updated <<- excel_to_R(input$LDFAveragesWeatherTable)
    LDFAveragesWeather.Cumulative.Final <<- LDF_Translate(LDFDataWeather.updated)[42,13:22] 
    state.formulas.Weather <<- LDFDataWeather.updated[34,2:10][colSums(!is.na(LDFDataWeather.updated[34,2:10])) > 0]
    cw.formulas.Weather <<- LDFDataWeather.updated[34,14:22]
    if (!setequal(LDFAveragesWeather.Cumulative.Final,LDFcumulative$Weather)) {  
      LDFcumulative$Weather <<- LDFAveragesWeather.Cumulative.Final
    } 
    LDFweightWeather <<- as.numeric(LDFDataWeather.updated[39,22])
    if (LDFweightWeather != LDF_weight$Weather) {
      LDF_weight$Weather <- LDFweightWeather
    }
  },priority = 3)
  
  observeEvent({LDFcumulative$Weather},{
    print(LDFcumulative$Weather)
  },priority = 3)
  
  observeEvent({input$LDFAveragesAttritionalTable},{ 
    LDFDataAttritional.updated <<- excel_to_R(input$LDFAveragesAttritionalTable)
    print(LDF_Translate(LDFDataAttritional.updated)[41,13:22])
    print(LDF_Translate(LDFDataAttritional.updated)[42,13:22])
    LDFAveragesAttritional.Cumulative.Final <<- LDF_Translate(LDFDataAttritional.updated)[42,13:22] 
    state.formulas.Attritional <<- LDFDataAttritional.updated[34,2:10][colSums(!is.na(LDFDataAttritional.updated[34,2:10])) > 0]
    cw.formulas.Attritional <<- LDFDataAttritional.updated[34,14:22]
    if (!setequal(LDFAveragesAttritional.Cumulative.Final,LDFcumulative$Attritional)) {  
      LDFcumulative$Attritional <<- LDFAveragesAttritional.Cumulative.Final
    } 
    LDFweightAttritional <<- as.numeric(LDFDataAttritional.updated[39,22])
    if (LDFweightAttritional != LDF_weight$All) {
      LDF_weight$Attritional <- LDFweightAttritional
    }
  },priority = 3)
  
  observeEvent({LDFcumulative$Attritional},{
    print(LDFcumulative$Attritional)
  },priority = 3)
  
  
 
      
  observeEvent({c(input$State, input$Program, input$IndicationDate, input$EvaluationDate, input$LossTrendPoints, input$LossTrendExclude)},{
    print(input$LossTrendSlider)
    updateSliderInput(session, inputId = 'LossTrendSlider',
                      max = nrow(lossTrendstateData) - length(input$LossTrendExclude),
                      step = 1)
  }, priority = 3)
      
  
  observeEvent({  input$State
                  input$Program
                  input$EvaluationDate
                  input$IndicationDate
                  input$fillOutDate},
               {  
                 if (input$searchIndication > searchIndication  &  input$fillOutDate != '2022-01-01') {
                 print(pull_variable(input$Program,input$IndicationDate,evaluation_use,input$State,'All Perils','fillOutDate',0))
                 print('start ISO load')
                 ISOtrendData <- ISOdata(input$Program,input$State,input$fillOutDate)
                 
                 ISOpremium <- ISOtrendData%>%
                   select(-`Loss Trend`)
                 output$ISOpremTrend <- renderTable(ISOpremium)
                 ISOloss <- ISOtrendData%>%
                   select(-`Premium Trend`)
                 
                 output$ISOlossTrend <- renderTable(ISOloss)
                 }
                 },priority = 2)
  
  
  observeEvent({c(input$State, input$Program, input$IndicationDate, input$EvaluationDate, input$LossTrendSlider, input$LossTrendExclude)}, #add the year selections select all column that modeled cat load has!
               {
                 if (input$searchIndication > searchIndication) {
                   if (length(input$LossTrendExclude)<nrow(lossTrendstateData) & nrow(lossTrendstateData) >2 ) {
                   points <- input$LossTrendSlider
                   
                   print(input$LossTrendExclude)
                   print(length(input$LossTrendExclude))
                   print(points)
                   print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                   
                   lossTrendstateDataFilter <<- lossTrendstateData%>%
                     mutate(Frequency = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude, NA,Frequency),
                            Severity = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude, NA,Severity),
                            `Pure Premium` = ifelse(`Year Ending Quarter - X` %in% input$LossTrendExclude,NA, `Pure Premium`))
                   
                   
                   purePremiumPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Pure Premium') #fix the line when the eliminated data point is below the threshold
                   frequencyPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Frequency')
                   severityPlot <<- loss_trend_fitting_plot(lossTrendstateDataFilter,points,'Severity')

                   print('Loss trend plots')

                   output$StateFrequencyPlot <- renderPlot({ggplot(data.frame(frequencyPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Frequency')+
                       xlab('')+
                       ggtitle(paste0('Frequency Exponential Trend: ' , round((exp(frequencyPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(frequencyPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   output$StateSeverityPlot <- renderPlot({ggplot(data.frame(severityPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Severity')+
                       xlab('')+
                       ggtitle(paste0('Severity Exponential Trend: ' , round((exp(severityPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(severityPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   output$StateLossPlot <- renderPlot({ggplot(data.frame(purePremiumPlot[1]))+
                       geom_point(aes(x = day_num, y = varChoose))+
                       geom_line(aes(x = day_num, y=plotName ), linetype = 'dotted')+
                       ylab('Pure Premium')+
                       xlab('')+
                       ggtitle(paste0('Pure Premium Exponential Trend: ' , round((exp(purePremiumPlot[[2]]$coefficients['x'])-1)*100,1),'%'),
                               subtitle = bquote('R'^2 *' = '* .(round(purePremiumPlot[[3]]$r.squared,3)) )) +
                       theme(plot.title = element_text(hjust = 0.5),
                             plot.subtitle = element_text(hjust = 0.5),
                             axis.text.x = element_text(angle=-45))
                   })
                   print('end Loss Trend Plots')
                 }}
               },
               priority = 3)
  

  
  observeEvent( {c(input$Program, input$EvaluationDate,input$IndicationDate, input$State,  input$DataSource,
                   input$CATstateweight,input$cw_exclude,input$state_exclude,input$expense_load_output_selected_cell_edit,
                   input$useCalcExpense, input$includePerils,
                   input$fillOutDate)},
                { 
                  if (input$searchIndication > searchIndication & req(input$CATstateweight!=default)  & input$fillOutDate != '2022-01-01') {
                    print('Start Modeled CAT data load')
                    modeled_cat_data <<- modeled_cat_load(input$Program, evaluation_use,input$IndicationDate, input$State,input$fillOutDate,input$DataSource)
                    print(modeled_cat_data)
                    modeled_cat_Messages <<- modeled_cat_data%>%
                      select(SpatialMessage,AALMessage)
                    
                    output$SpatialAALmessage <- renderDT(datatable(modeled_cat_Messages,selection = 'none',class = 'compact',colnames='',rownames = F,options = list(dom='t',paging=F)))
                  
                                        print(input$fillOutDate)
                    print('modeledCat - expenses')
                  selected_expense_data <<- expense_select(input$Program, evaluation_use,input$IndicationDate, input$State, input$CATstateweight,input$cw_exclude,input$state_exclude)
                  if (as.numeric(selected_expense_data_selected)==as.numeric(selected_expense_data) | input$useCalcExpense | as.numeric(selected_expense_data_selected)==0) {
                    selected_expense_data_selected <<- selected_expense_data
                    row.names(selected_expense_data_selected) <<- c('Selected Expense Load')
                  }
                  print('mod1')
                  print(selected_expense_data_selected)
                  output$expense_load_output <- renderDT(datatable(selected_expense_data,selection = 'none',class = 'compact',colnames='',rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  
                  print('mod2')
                  
                  modeled_cat <<- modeled_cat_load_calc(modeled_cat_data,as.numeric(selected_expense_data_selected))
                  
                  
                  cat_sub <- 0
                  
                  if (!is.null(input$includePerils)) {
                    print(input$includePerils)
                    print(colnames(modeled_cat))
                    print(input$includePerils)
                    print(!('STS' %in% input$includePerils))
                  if (!('Hurricane' %in% input$includePerils)) { 
                      modeled_cat <- modeled_cat%>%
                        select(-`Hurricane Gross AAL`,
                               -`Modeled HU CAT Loss Ratio`,
                               -`Modeled Hurricane Loss & LAE Ratio`)
                    }
                    
                  if (!('STS' %in% input$includePerils)) {
                    modeled_cat <- modeled_cat%>%
                      select(-`Convective Storm Gross AAL`,
                             -`Modeled CS CAT Loss Ratio`
                             -`Modeled CS Loss & LAE Ratio`)
                  }
                  if (!('STS' %in% input$includePerils) | !('Hurricane' %in% input$includePerils)) {
                    cat_sub <- 1
                    modeled_cat <- modeled_cat%>%
                      select(-`Total Modeled Cat Loss & LAE Ratio`, 
                             -`Total Cat Loss`)
                    output$ModeledCatLoad <- renderDT(datatable(modeled_cat%>%
                                                                  select(-`Hurricane In Force Premium @ CRL`,
                                                                         -`STS In Force Premium @ CRL`)
                                                                ,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%
                                                        formatRound(c(1,2),digits = 0)%>%
                                                        formatPercentage(c(3,5),digits = 1)%>%
                                                        formatRound(c(4),digits = 2))
                  }
                    else {
                      output$ModeledCatLoad <- renderDT(datatable(modeled_cat%>%
                                                                    select(-`Hurricane In Force Premium @ CRL`,
                                                                           -`STS In Force Premium @ CRL`)
                                                                  ,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%
                                                          formatRound(c(1,2,4),digits = 0)%>%
                                                          formatPercentage(c(3,5,6,8,9,10),digits = 1)%>%
                                                          formatRound(c(7),digits = 2))
                    }
                  }
                  
                  
                  print('mod3')
                  withCallingHandlers({
                    shinyjs::html("ModeledCatLoadLoad", "")
                    message('Modeled Cat Data Loaded')
                  },
                  message = function(m) {
                    shinyjs::html(id = "ModeledCatLoadLoad", html = m$message, add = TRUE)
                  })
                  print(modeled_cat)
                  reinsurance_exhibit_table <<- reinsurance_exhibit(state_name_full(input$State), 
                                                                    table_name(input$Program), 
                                                                    reinsurance(input$State,evaluation_use,input$Program,'Hurricane'), 
                                                                    reinsurance(input$State,evaluation_use,input$Program,'STS'),
                                                                    reinsurance(input$State,evaluation_use,input$Program,'All Perils'),
                                                                    modeled_cat)
                  
                  output$reinsuranceExhibit <- renderDT(datatable(reinsurance_exhibit_table,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%
                                                          formatPercentage(5,digits = 1 ))
                  
                  print('mod4')
                }},priority = 2
  )
  
  observeEvent( {c(input$expense_load_output_selected_cell_edit)},
                { 
                  if (input$searchIndication > searchIndication) {
                    print('expense load')
                  selected_expense_data_selected <<- editData(selected_expense_data_selected,input$expense_load_output_selected_cell_edit,'expense_load_output_selected',rownames = T)
                  
                  output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  
                }},priority = 2
  )
  observeEvent( {
    c(input$Program,input$IndicationDate, input$EvaluationDate,input$currentLossTrendCW,input$proposedEffective, input$projLossTrendCW,input$capped)
  },
  {
    print('CW LLL.......')
    print(input$currentLossTrendCW)
    print(input$projLossTrendCW)
    if (input$searchIndication > searchIndication & input$proposedEffective != '2022-01-01'& 
        req(input$currentLossTrendCW!=default, input$projLossTrendCW!=default,input$capped)
        ) { #load in all the LLL data tables for each tab
      print('start CW LLL')
    print('CW LLL data loaded')
    LLLdata_CW_total <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'All Perils')
    LLLdata_CW_fire <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'FIRE')
    LLLdata_CW_water <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'WATER')
    LLLdata_CW_theft <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'THEFTVMM')
    LLLdata_CW_liability <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'LIABILITY')
    LLLdata_CW_otherAOP <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'OTHERAOP')
    LLLdata_CW_weather <<- LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped,'NCW')
    print('CW LLL 1')
    LLLdata_CW_total_selected <<- LLL_selections(LLLdata_CW_total,'Selected')
    LLLdata_CW_fire_selected <<- LLL_selections(LLLdata_CW_fire,'Selected')
    LLLdata_CW_water_selected <<- LLL_selections(LLLdata_CW_water,'Selected')
    LLLdata_CW_theft_selected <<- LLL_selections(LLLdata_CW_theft,'Selected')
    LLLdata_CW_liability_selected <<- LLL_selections(LLLdata_CW_liability,'Selected')
    LLLdata_CW_otherAOP_selected <<- LLL_selections(LLLdata_CW_otherAOP,'Selected')
    LLLdata_CW_weather_selected <<- LLL_selections(LLLdata_CW_weather,'Selected')
    
    print('CW LLL 2')
    output$LLLTotalTableCW <- renderDT(datatable(LLLdata_CW_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWTotal<- renderDT(datatable(LLL_selections(LLLdata_CW_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWTotalSelected<- renderDT(datatable(LLLdata_CW_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWFire <- renderDT(datatable(LLLdata_CW_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWFire<- renderDT(datatable(LLL_selections(LLLdata_CW_fire,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWFireSelected<- renderDT(datatable(LLLdata_CW_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWWater <- renderDT(datatable(LLLdata_CW_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWWater<- renderDT(datatable(LLL_selections(LLLdata_CW_water,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWWaterSelected<- renderDT(datatable(LLLdata_CW_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWTheft <- renderDT(datatable(LLLdata_CW_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWTheft<- renderDT(datatable(LLL_selections(LLLdata_CW_theft,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWTheftSelect<- renderDT(datatable(LLLdata_CW_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWLiability <- renderDT(datatable(LLLdata_CW_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWLiability<- renderDT(datatable(LLL_selections(LLLdata_CW_liability,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWLiabilitySelected<- renderDT(datatable(LLLdata_CW_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWOtherAOP <- renderDT(datatable(LLLdata_CW_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_CW_otherAOP,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWOtherAOPSelected<- renderDT(datatable(LLLdata_CW_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTableCWWeather <- renderDT(datatable(LLLdata_CW_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectCWWeather<- renderDT(datatable(LLL_selections(LLLdata_CW_weather,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectCWWeatherSelected<- renderDT(datatable(LLLdata_CW_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    print('end CW LLL')
  }},priority = 2
  )
  
  observeEvent(input$LLLselectCWTotalSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_total_selected <<- editData(LLLdata_CW_total_selected,input$LLLselectCWTotalSelected_cell_edit,'LLLselectCWTotalSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWFireSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_fire_selected <<- editData(LLLdata_CW_fire_selected,input$LLLselectCWFireSelected_cell_edit,'LLLselectCWFireSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWWaterSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_water_selected <<- editData(LLLdata_CW_water_selected,input$LLLselectCWWaterSelected_cell_edit,'LLLselectCWWaterSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWTheftSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_theft_selected <<- editData(LLLdata_CW_theft_selected,input$LLLselectCWTheftSelected_cell_edit,'LLLselectCWTheftSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWLiabilitySelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_liability_selected <<- editData(LLLdata_CW_liability_selected,input$LLLselectCWLiabilitySelected_cell_edit,'LLLselectCWLiabilitySelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWOtherAOPSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_otherAOP_selected <<- editData(LLLdata_CW_otherAOP_selected,input$LLLselectCWOtherAOPSelected_cell_edit,'LLLselectCWOtherAOPSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectCWWeatherSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_CW_weather_selected <<- editData(LLLdata_CW_weather_selected,input$LLLselectCWWeatherSelected_cell_edit,'LLLselectCWWeatherSelect',rownames = TRUE) }},priority = 2) 
  
  observeEvent( {
    c(input$State,input$Program,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState,input$capped)
  },
  { 
    print('state LLL.....')
    print(input$currentLossTrendState)
    print(input$projLossTrendState)
    print(input$capped)
    if (input$searchIndication > searchIndication & input$proposedEffective != '2022-01-01' & req(input$currentLossTrendState != default, input$projLossTrendState != default,input$capped) ) {
      print('start state LLL')
      print(input$currentLossTrendState)
    LLLdata_state_total    <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'All Perils')
    LLLdata_state_fire     <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'FIRE')
    LLLdata_state_water    <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'WATER')
    LLLdata_state_theft    <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'THEFTVMM')
    LLLdata_state_liability<<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'LIABILITY')
    LLLdata_state_otherAOP <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'OTHERAOP')
    LLLdata_state_weather  <<-LLL_pull(input$Program,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped,'NCW')
    
    LLLdata_state_total_selected<<-LLL_selections(LLLdata_state_total,'Selected')
    LLLdata_state_fire_selected<<-LLL_selections(LLLdata_state_fire,'Selected')
    LLLdata_state_water_selected<<-LLL_selections(LLLdata_state_water,'Selected')
    LLLdata_state_theft_selected<<-LLL_selections(LLLdata_state_theft,'Selected')
    LLLdata_state_liability_selected<<-LLL_selections(LLLdata_state_liability,'Selected')
    LLLdata_state_otherAOP_selected<<-LLL_selections(LLLdata_state_otherAOP,'Selected')
    LLLdata_state_weather_selected<<-LLL_selections(LLLdata_state_weather,'Selected')
    
    output$LLLTotalTablestate <- renderDT(datatable(LLLdata_state_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTotal<- renderDT(datatable(LLL_selections(LLLdata_state_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTotalSelected<- renderDT(datatable(LLLdata_state_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateFire <- renderDT(datatable(LLLdata_state_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateFire<- renderDT(datatable(LLL_selections(LLLdata_state_fire,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateFireSelected<- renderDT(datatable(LLLdata_state_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWater<- renderDT(datatable(LLLdata_state_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWater<- renderDT(datatable(LLL_selections(LLLdata_state_water,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWaterSelected<- renderDT(datatable(LLLdata_state_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateTheft <- renderDT(datatable(LLLdata_state_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTheft<- renderDT(datatable(LLL_selections(LLLdata_state_theft,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTheftSelected<- renderDT(datatable(LLLdata_state_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateLiability <- renderDT(datatable(LLLdata_state_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateLiability<- renderDT(datatable(LLL_selections(LLLdata_state_liability,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateLiabilitySelected<- renderDT(datatable(LLLdata_state_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateOtherAOP <- renderDT(datatable(LLLdata_state_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_state_otherAOP,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateOtherAOPSelected<- renderDT(datatable(LLLdata_state_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWeather <- renderDT(datatable(LLLdata_state_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWeather<- renderDT(datatable(LLL_selections(LLLdata_state_weather,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWeatherSelected<- renderDT(datatable(LLLdata_state_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    print('end state LLL')
    withCallingHandlers({
      shinyjs::html("LLLLoad", "")
      message('LLL Data Loaded')
    },
    message = function(m) {
      shinyjs::html(id = "LLLLoad", html = m$message, add = TRUE)
    })
  }},
  priority = 2
  )
  
  observeEvent(input$LLLselectStateTotalSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_total_selected <<- editData(LLLdata_state_total_selected,input$LLLselectStateTotalSelected_cell_edit,'LLLselectStateTotalSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateFireSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_fire_selected <<- editData(LLLdata_state_fire_selected,input$LLLselectStateFireSelected_cell_edit,'LLLselectStateFireSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateWaterSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {
                   LLLdata_state_water_selected <<- editData(LLLdata_state_water_selected,input$LLLselectStateWaterSelected_cell_edit,'LLLselectStateWaterSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateTheftSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_theft_selected <<- editData(LLLdata_state_theft_selected,input$LLLselectStateTheftSelected_cell_edit,'LLLselectStateTheftSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateLiabilitySelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_liability_selected <<- editData(LLLdata_state_liability_selected,input$LLLselectStateLiabilitySelected_cell_edit,'LLLselectStateLiabilitySelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateOtherAOPSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_otherAOP_selected <<- editData(LLLdata_state_otherAOP_selected,input$LLLselectStateOtherAOPSelected_cell_edit,'LLLselectStateOtherAOPSelect',rownames = TRUE) }},priority = 2) 
  observeEvent(input$LLLselectStateWeatherSelected_cell_edit,
               {
                 if (input$searchIndication > searchIndication) {LLLdata_state_weather_selected <<- editData(LLLdata_state_weather_selected,input$LLLselectStateWeatherSelected_cell_edit,'LLLselectStateWeatherSelect',rownames = TRUE) }},priority = 2) 
  
  
  observeEvent({c(input$State,input$Program,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState, input$currentLossTrendCW, input$projLossTrendCW,input$capped,input$LLLstateweightTotal,
                  input$LLLselectCWTotalSelected_cell_edit,
                  input$LLLselectCWFireSelected_cell_edit,
                  input$LLLselectCWWaterSelected_cell_edit,
                  input$LLLselectCWTheftSelected_cell_edit,
                  input$LLLselectCWLiabilitySelected_cell_edit,
                  input$LLLselectCWOtherAOPSelected_cell_edit,
                  input$LLLselectCWWeatherSelected_cell_edit,
                  input$LLLselectStateTotalSelected_cell_edit,
                  input$LLLselectStateFireSelected_cell_edit,
                  input$LLLselectStateWaterSelected_cell_edit,
                  input$LLLselectStateTheftSelected_cell_edit,
                  input$LLLselectStateLiabilitySelected_cell_edit,
                  input$LLLselectStateOtherAOPSelected_cell_edit,
                  input$LLLselectStateWeatherSelected_cell_edit
  )},
  {
    if (input$searchIndication > searchIndication & input$proposedEffective != '2022-01-01' & 
        req(input$currentLossTrendState!=default, input$projLossTrendState!=default,input$capped, input$currentLossTrendCW!=default, input$projLossTrendCW!=default,input$LLLstateweightTotal!=default)) {
    LLLTotal     <<-reactive({LLL_weighted(LLLdata_CW_total_selected    ,LLLdata_state_total_selected    ,input$LLLstateweightTotal)}) 
    LLLFire      <<-reactive({LLL_weighted(LLLdata_CW_fire_selected     ,LLLdata_state_fire_selected     ,input$LLLstateweightTotal)})
    LLLWater     <<-reactive({LLL_weighted(LLLdata_CW_water_selected    ,LLLdata_state_water_selected    ,input$LLLstateweightTotal)})
    LLLTheft     <<-reactive({LLL_weighted(LLLdata_CW_theft_selected    ,LLLdata_state_theft_selected    ,input$LLLstateweightTotal)})
    LLLLiability <<-reactive({LLL_weighted(LLLdata_CW_liability_selected,LLLdata_state_liability_selected,input$LLLstateweightTotal)})
    LLLOtherAOP  <<-reactive({LLL_weighted(LLLdata_CW_otherAOP_selected ,LLLdata_state_otherAOP_selected ,input$LLLstateweightTotal)})
    LLLWeather   <<-reactive({LLL_weighted(LLLdata_CW_weather_selected  ,LLLdata_state_weather_selected  ,input$LLLstateweightTotal)})
    
    output$LLLweightedTotal <- renderDT(datatable(LLLTotal(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedFire <- renderDT(datatable(LLLFire(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedWater <- renderDT(datatable(LLLWater(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedTheft <- renderDT(datatable(LLLTheft(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedLiability <- renderDT(datatable(LLLLiability(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedOtherAOP <- renderDT(datatable(LLLOtherAOP(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLweightedWeather <- renderDT(datatable(LLLWeather(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
  }},priority = 2
  )
  
  #save selections to SQL
  observeEvent(input$LDFall.save,
               {
                 if (input$searchIndication > searchIndication) {
                   print(cw.formulas.All)
                   print(state.formulas.All)
                   save_selections_LDF(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'All Perils','In Progress',
                                       state.formulas.All,
                                       cw.formulas.All,
                                       LDFcumulative$All,
                                       LDF_weight$All,input$selected_by[[1]],0,0)
                   }},priority = 1)
  observeEvent(input$LDFweather.save,
               {
                 if (input$searchIndication > searchIndication) {
                   save_selections_LDF(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Weather','In Progress',
                                       state.formulas.Weather,
                                       cw.formulas.Weather,
                                       LDFcumulative$Weather,
                                       LDF_weight$Weather,input$selected_by[[1]],0,0)
                 }},priority = 1)
  observeEvent(input$LDFattritional.save, 
               {
                 if (input$searchIndication > searchIndication) {
                   save_selections_LDF(input$Program,input$IndicationDate,input$EvaluationDate,input$State,'Attritional','In Progress',
                                       state.formulas.Attritional,
                                       cw.formulas.Attritional,
                                       LDFcumulative$Attritional,
                                       LDF_weight$Attritional,input$selected_by[[1]],0,0)
                 }},priority = 1)

  
  observeEvent({input$saveInputs},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$nonModeledSave},
               {
                 if (input$searchIndication > searchIndication) {
                   save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                        input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
                 }}
  )
  
  observeEvent({input$catLoadtoSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$stateLossTrendtoSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$LLLselectionsToSQL},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$ldfselectionToSQLstate},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )
  observeEvent({input$PremiumSave},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,
                                      input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,input$selected_by[[1]],0,0)
               }}
  )

  observeEvent({input$cwLossTrendtoSQL},#input$catLoadtoSQL)},
               {
                 if (input$searchIndication > searchIndication) {
                 save_selections_cw(input$Program,input$IndicationDate,evaluation_use, 'CW' ,'All Perils','In Progress',input$currentLossTrendCW,input$projLossTrendCW,input$cw_exclude,input$selected_by[[1]],0,0) 
               }})
  observe({
    if (input$searchIndication > searchIndication &
        req(input$currentLossTrendState!=default, input$projLossTrendState!=default,input$capped, 
            input$currentLossTrendCW!=default, input$projLossTrendCW!=default,input$CATstateweight!=default)

        & input$proposedEffective != '2022-01-01'
        ) {
    #pull the most recent LDF selections on upload, so you don't always have to click into the LDF page first!
    dummy <<- c(input$useCalcExpense,input$catLoadtoSQL,input$CATstateweight,input$cw_exclude,input$state_exclude,input$expense_load_output_selected_cell_edit
    )
    losses_claims <<- rate_level_losses(input$Program, input$IndicationDate, evaluation_use, input$State)
    #data from the rate level indication, 
    print('load rate level indication') 
    total_data <<- rate_level_indication(input$Program,
                                         on_level_load,
                                         coverage_report_data,
                                         targit_EP_data,
                                         'N',
                                         "All Perils",
                                         input$currentPremiumTrend,
                                         input$projPremiumTrend,
                                         input$proposedEffective,
                                         input$IndicationDate,
                                         evaluation_use,
                                         input$State,
                                         LDFcumulative$All,
                                         input$currentLossTrendState,
                                         input$projLossTrendState,
                                         as.numeric(LLLTotal()['Selected','Weighted LLL'])#place holder for LL loads. Need to build out the selection still
    ) #make this reactive so that I can call it in the Non Modeled Results

    
    print('load rate level data by Peril')
    #separate function for the perils rate level tabs because they look different. 
    print(LDF_selection$Attritional)
    fireLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDFcumulative$Attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLFire()['Selected','Weighted LLL']),
                                               coverage_report_data,'Fire')
    
    firePremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                     coverage_report_data, 'Fire',input$currentPremiumTrend,
                                                     input$projPremiumTrend,
                                                     input$proposedEffective,
                                                     input$IndicationDate,
                                                     evaluation_use,
                                                     input$State,
                                                     'Y')
    
    output$FireIndicationLosses <- renderDT(datatable(fireLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    output$FireIndicationPremium <- renderDT(datatable(firePremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4), digits = 3))
    
    fireSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,fireLosses, firePremium,expense_ratios)
    output$FireIndicationSummary<- renderDT(datatable(fireSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    waterLosses <<- rate_level_indication_peril(on_level_load, 
                                                input$proposedEffective,
                                                input$IndicationDate,evaluation_use,input$State,LDFcumulative$Attritional,
                                                input$currentLossTrendState,
                                                input$projLossTrendState, as.numeric(LLLWater()['Selected','Weighted LLL']),
                                                coverage_report_data,'Water')
    
    output$WaterIndicationLosses <- renderDT(datatable(waterLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4,5), digits = 3))
    
    waterPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'Water',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      'Y')
    output$WaterIndicationPremium <- renderDT(datatable(waterPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    waterSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,waterLosses, waterPremium,expense_ratios)
    output$WaterIndicationSummary<- renderDT(datatable(waterSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                               formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    theftLosses <<- rate_level_indication_peril(on_level_load, 
                                                input$proposedEffective,
                                                input$IndicationDate,evaluation_use,input$State,LDFcumulative$Attritional,
                                                input$currentLossTrendState,
                                                input$projLossTrendState, as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                                coverage_report_data,'TheftVMM')
    
    output$TheftIndicationLosses <- renderDT(datatable(theftLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4,5), digits = 3))
    theftPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'TheftVMM',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      'Y')
    output$TheftIndicationPremium <- renderDT(datatable(theftPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    theftSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,theftLosses, theftPremium,expense_ratios)
    output$TheftIndicationSummary<- renderDT(datatable(theftSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                               formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    OtherAOPLosses <<- rate_level_indication_peril(on_level_load, 
                                                   input$proposedEffective,
                                                   input$IndicationDate,evaluation_use,input$State,LDFcumulative$Attritional,
                                                   input$currentLossTrendState,
                                                   input$projLossTrendState, as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                                   coverage_report_data,'OtherAOP')
    
    output$OtherAOPIndicationLosses <- renderDT(datatable(OtherAOPLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                  formatRound(c(2,6,7), digits = 0)%>%
                                                  formatRound(c(3,4,5), digits = 3))
    OtherAOPPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                         coverage_report_data, 'OtherAOP',input$currentPremiumTrend,
                                                         input$projPremiumTrend,
                                                         input$proposedEffective,
                                                         input$IndicationDate,
                                                         evaluation_use,
                                                         input$State,
                                                         'Y')
    output$OtherAOPIndicationPremium <- renderDT(datatable(OtherAOPPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                   formatRound(c(2,6,7), digits = 0)%>%
                                                   formatRound(c(3,4), digits = 3))
    OtherAOPSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,OtherAOPLosses, OtherAOPPremium,expense_ratios)
    output$OtherAOPIndicationSummary<- renderDT(datatable(OtherAOPSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                  formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    liabilityLosses <<- rate_level_indication_peril(on_level_load, 
                                                    input$proposedEffective,
                                                    input$IndicationDate,evaluation_use,input$State,LDFcumulative$Attritional,
                                                    input$currentLossTrendState,
                                                    input$projLossTrendState, as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                                    coverage_report_data,'Liability')
    
    output$LiabilityIndicationLosses <- renderDT(datatable(liabilityLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                   formatRound(c(2,6,7), digits = 0)%>%
                                                   formatRound(c(3,4,5), digits = 3))
    liabilityPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                          coverage_report_data, 'Liability',input$currentPremiumTrend,
                                                          input$projPremiumTrend,
                                                          input$proposedEffective,
                                                          input$IndicationDate,
                                                          evaluation_use,
                                                          input$State,
                                                          'Y')
    output$LiabilityIndicationPremium <- renderDT(datatable(liabilityPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                    formatRound(c(2,6,7), digits = 0)%>%
                                                    formatRound(c(3,4), digits = 3))
    liabilitySummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,liabilityLosses, liabilityPremium,expense_ratios)
    output$LiabilityIndicationSummary<- renderDT(datatable(liabilitySummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                   formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    NCWLosses <<- rate_level_indication_peril(on_level_load, 
                                              input$proposedEffective,
                                              input$IndicationDate,evaluation_use,input$State,LDFcumulative$Weather,
                                              input$currentLossTrendState,
                                              input$projLossTrendState, as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                              coverage_report_data,'NCW')
    
    output$NCWIndicationLosses <- renderDT(datatable(NCWLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                             formatRound(c(2,6,7), digits = 0)%>%
                                             formatRound(c(3,4,5), digits = 3))
    NCWPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                    coverage_report_data, 'NCW',input$currentPremiumTrend,
                                                    input$projPremiumTrend,
                                                    input$proposedEffective,
                                                    input$IndicationDate,
                                                    evaluation_use,
                                                    input$State,
                                                    'Y')
    output$NCWIndicationPremium <- renderDT(datatable(NCWPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4), digits = 3))
    NCWSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Program,NCWLosses, NCWPremium,expense_ratios)
    output$NCWIndicationSummary<- renderDT(datatable(NCWSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    print('load rate level data CAT')
    print(modeled_cat)
    HULosses <<- cat_peril_table('Hurricane',modeled_cat,HUexpFactor$Value)
    HUsummary <<- cat_peril_summary(input$State, evaluation_use,input$Program,HULosses, expense_ratios,'Hurricane',HUexpFactor$Value,HUyearsAdjFactor$Value,modeled_cat)
    output$HUIndication <- renderDT(datatable(HULosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                      formatRound(c(2,3), digits = 0)%>%
                                      formatRound(c(4,6), digits = 3)%>%
                                      formatPercentage(c(5,7),digits = 1))
    output$HUIndicationSummary<- renderDT(datatable(HUsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    STSLosses <<- cat_peril_table('STS',modeled_cat,STSexpFactor$Value)
    STSsummary <<- cat_peril_summary(input$State, evaluation_use,input$Program,STSLosses, expense_ratios,'STS',STSexpFactor$Value,STSyearExpAdj$Value,modeled_cat)
    output$STSIndication <- renderDT(datatable(STSLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                       formatRound(c(2,3), digits = 0)%>%
                                       formatRound(c(4,6), digits = 3)%>%
                                       formatPercentage(c(5,7),digits = 1))
    
    output$STSIndicationSummary<- renderDT(datatable(STSsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    #display the summary table
    output$TotalRateLevelIndication <- renderDT(datatable(total_data,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                                  formatRound(c(2,5,6,10),digits = 0)%>%
                                                  formatRound(c(3,4,7,8,9), digits = 3)%>%
                                                  formatPercentage(c(11),digits = 1)%>%
                                                  formatStyle(
                                                    1,
                                                    target = "row",
                                                    fontWeight = styleEqual("Total", "bold")
                                                  ))
    print('total summary')
    #display all the results
    TotalSummary <<-rate_level_summary(total_data,
                                       modeled_cat,
                                       expense_ratios,
                                       losses_claims,
                                       input$projPremiumTrend,
                                       input$projLossTrendState,
                                       STSexpFactor$Value,
                                       HUexpFactor$Value,
                                       input$includePerils)
    output$TotalRateLevelSummary <- renderDT(datatable(TotalSummary,colnames = ' ' ,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))))%>%
                                               formatPercentage(c(2), digits=1))
    indication_memo_data <<-indication_memo(TotalSummary, #only include selected perils in the indication memo
                                            if ('Fire' %in% input$includePerils) fireSummary else NA,
                                            if ('Water' %in% input$includePerils) waterSummary else NA,
                                            if ('Theft' %in% input$includePerils) theftSummary else NA,
                                            if ('Liability' %in% input$includePerils) liabilitySummary else NA,
                                            if ('Other' %in% input$includePerils) OtherAOPSummary else NA,
                                            if ('NCW' %in% input$includePerils) NCWSummary else NA,
                                            if ('STS' %in% input$includePerils) STSsummary else NA,
                                            if ('Hurricane' %in% input$includePerils) HUsummary else NA,
                                            coverage_report_data,non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),
                                            input$includePerils)
    
    output$memo <-  renderDT(datatable(indication_memo_data,selection = 'none',class = 'compact',rownames = F,options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))))%>%
                               formatPercentage(c(2,3,4), digits=1))
    
    output$FireRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Fire'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$WaterRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Water'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1))
    output$TheftRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Theft & VMM'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1))
    output$LiabilityRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Liability'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                  formatPercentage(c(3), digits = 1))
    output$OtherAOPRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'All Other Perils'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                                 formatPercentage(c(3), digits = 1))
    output$NCWRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Non-Cat Weather'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    output$STSRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'STS'),class = 'compact',selection = 'none',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                            formatPercentage(c(3), digits = 1))
    output$HURateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Hurricane'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                           formatPercentage(c(3), digits = 1))
    
    trendedOnlevel <<- total_data[total_data[1] != 'Total',]%>%
                          select(`Earned Premium`)
    
    reconciliation.update[17:(nrow(trendedOnlevel)+16),4] <- trendedOnlevel
    
    output$IndicationReconciliation <- renderExcel(excelTable(data =reconciliation.update,columns = reconciliation.data[[2]],updateTable = htmlwidgets::JS(reconciliation.data[[3]]),
                                                              allowDeleteColumn = F,
                                                              allowInsertRow = F,
                                                              allowInsertColumn = F,
                                                              allowDeleteRow = F,
                                                              autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = T,mergeCells = list(H16 = c(10,6))
    ))
    
    print('Start Territorial Analysis Load')
    #load the territorial CAT experience adjustment factors
    TerSTSexpAdj <<- ExperienceFactor(input$Program,input$IndicationDate, evaluation_use, input$State, 'STSexpFactor')
    TerHUexpAdj  <<- ExperienceFactor(input$Program,input$IndicationDate, evaluation_use, input$State, 'HUexpFactor')
    print(total_data)
    LossesCappedTable <<- LossesCapped(input$Program,input$IndicationDate, evaluation_use, input$State)
    EHY_PremTable <<- EHY_Prem(input$Program,input$IndicationDate, evaluation_use, input$State,input$DataSource)
    InforceAALTable <<- InforceAAL(input$Program,input$IndicationDate, evaluation_use, input$State,input$FillOutDate,input$DataSource)
    
    SelectionTrendData <<- total_data[c(1:5), c(1,4,7,8)]
    colnames(SelectionTrendData) <- c('Adj', 'PremTrend','LDF','LossTrend')
    
    SelectionTrendDataAtt <<- data.frame(Adj = unlist(fireLosses[1]), LDF = unlist(fireLosses[3]))
    SelectionTrendDataWeather <<- data.frame(Adj = unlist(NCWLosses[1]), LDF = unlist(NCWLosses[3]))
    print('working')
    # LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
    # TargetLossRatio,TargetIndicatedChange,nonPeril
    TerritorialExhibitData <<- TerritorialExhibit(LossesCappedTable,EHY_PremTable,InforceAALTable,SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTotal()['Selected','Weighted LLL']),
                                                  SelectionTrendData[,c(1,3)],TerHUexpAdj,TerSTSexpAdj,selected_expense_data_selected,as.numeric(modeled_cat$`Modeled Hurricane Loss & LAE Ratio`) *  HUexpFactor$Value,
                                                  as.numeric(modeled_cat$`Modeled CS Loss & LAE Ratio`) *  STSexpFactor$Value,
                                                  reinsurance(input$State,evaluation_use,input$Program,'Hurricane'),reinsurance(input$State,evaluation_use,input$Program,'STS'),1082,
                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                  as.numeric(TotalSummary[8 + ifelse('Hurricane' %in% input$includePerils,1,0) +ifelse('STS' %in% input$includePerils,1,0),2]),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource))###STOP
    
    output$TerritorialExhibit <- renderDT(datatable(TerritorialExhibitData%>%select(-InforceCount),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(3,11,12)),list(className = 'dt-right',targets = c(0:12)))),rownames=F)%>%
                                            formatRound(c(2:5),digits = 0)%>%
                                            formatPercentage(c(6:13), digits = 1)%>%
                                            formatStyle(
                                              1,
                                              target = "row",
                                              fontWeight = styleEqual("Total", "bold")
                                            ))
    #LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
    #TargetLossRatio,TargetIndicatedChange,nonPeril,peril
    output$TerritorialExhibitSnapshot <- renderDT(datatable(TerritorialExhibitTop10(TerritorialExhibitData),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(3,11,12)),list(className = 'dt-right',targets = c(0:12)))),rownames=F)%>%
                                                    formatRound(c(2:5),digits = 0)%>%
                                                    formatPercentage(c(6:13), digits = 1)%>%
                                                    formatStyle(
                                                      1,
                                                      target = "row",
                                                      fontWeight = styleEqual("Total", "bold")
                                                    ))
    
    TerritorialExhibitFireData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Fire'),EHY_PremTable,InforceAALTable,
                                                                   SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLFire()['Selected','Weighted LLL']),
                                                                   SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                   as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                   as.numeric(memoToTables(indication_memo_data,'Fire')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'Fire')
    
    output$TerritorialExhibitFire <- renderDT(datatable(TerritorialExhibitFireData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                formatRound(c(2:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1)%>%
                                                formatStyle(
                                                  1,
                                                  target = "row",
                                                  fontWeight = styleEqual("Total", "bold")
                                                ))
    TerritorialExhibitWaterData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Water'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWater()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Water')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'Water')
    
    output$TerritorialExhibitWater <- renderDT(datatable(TerritorialExhibitWaterData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(2:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1)%>%
                                                 formatStyle(
                                                   1,
                                                   target = "row",
                                                   fontWeight = styleEqual("Total", "bold")
                                                 ))
    
    TerritorialExhibitTheftData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'TheftVMM'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Theft & VMM')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'Theft')
    
    output$TerritorialExhibitTheft <- renderDT(datatable(TerritorialExhibitTheftData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(2:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1)%>%
                                                 formatStyle(
                                                   1,
                                                   target = "row",
                                                   fontWeight = styleEqual("Total", "bold")
                                                 ))
    
    if ('Liability' %in% input$includePerils) {
      TerritorialExhibitLiabilityData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'Liability'),EHY_PremTable,InforceAALTable,
                                                                          SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                                                          SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                          as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                          as.numeric(memoToTables(indication_memo_data,'Liability')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'Liability')
    } else {
      TerritorialExhibitLiabilityData<<-NULL
    }
    
    output$TerritorialExhibitLiab <- renderDT(datatable(TerritorialExhibitLiabilityData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                formatRound(c(2:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1)%>%
                                                formatStyle(
                                                  1,
                                                  target = "row",
                                                  fontWeight = styleEqual("Total", "bold")
                                                ))
    
    TerritorialExhibitOtherAOPData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'OtherAOP'),EHY_PremTable,InforceAALTable,
                                                                       SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                                                       SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                       as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                       as.numeric(memoToTables(indication_memo_data,'All Other Perils')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'OtherAOP')
    
    output$TerritorialExhibitAOP <- renderDT(datatable(TerritorialExhibitOtherAOPData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:5,7),digits = 0)%>%
                                               formatPercentage(c(6,8:11), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))
    
    TerritorialExhibitNCWData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Program,input$IndicationDate, evaluation_use, input$State,'NCW'),EHY_PremTable,InforceAALTable,
                                                                  SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                                                  SelectionTrendDataWeather[,c(1,2)],selected_expense_data_selected,1082,
                                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils')) ,
                                                                  as.numeric(memoToTables(indication_memo_data,'Non-Cat Weather')),non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),'NCW')
    
    output$TerritorialExhibitNCW <- renderDT(datatable(TerritorialExhibitNCWData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:5,7),digits = 0)%>%
                                               formatPercentage(c(6,8:11), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))
    
    All.costRr <<- as.numeric(reinsurance(input$State,evaluation_use,input$Program,'All Perils'))
    HU.costRr <<- as.numeric(reinsurance(input$State,evaluation_use,input$Program,'Hurricane'))
    STS.costRr <<- as.numeric(reinsurance(input$State,evaluation_use,input$Program,'STS'))
    
    TerritorialExhibitHUData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + All.costRr,
                                                                  as.numeric(memoToTables(indication_memo_data,'Hurricane')),'Hurricane','HU',TerHUexpAdj,as.numeric(HULosses[7]), HU.costRr,HUyearsAdjFactor$Value,20)
    
    output$TerritorialExhibitHU <- renderDT(datatable(TerritorialExhibitHUData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                              formatRound(c(2:4),digits = 0)%>%
                                              formatRound(6,digits = 2)%>%
                                              formatPercentage(c(5,7:12), digits = 1)%>%
                                              formatStyle(
                                                1,
                                                target = "row",
                                                fontWeight = styleEqual("Total", "bold")
                                              ))
    
    TerritorialExhibitSTSData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                                                   as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + All.costRr,
                                                                   as.numeric(memoToTables(indication_memo_data,'STS')),'STS','STS',TerSTSexpAdj,as.numeric(STSLosses[7]), STS.costRr, STSyearExpAdj$Value,20)
    
    output$TerritorialExhibitSTS <- renderDT(datatable(TerritorialExhibitSTSData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(2:4),digits = 0)%>%
                                               formatRound(6,digits = 2)%>%
                                               formatPercentage(c(5,7:12), digits = 1)%>%
                                               formatStyle(
                                                 1,
                                                 target = "row",
                                                 fontWeight = styleEqual("Total", "bold")
                                               ))
    
    output$CompleteExhibits <- renderText('Exhibits are Created')

  }},priority = 1)
  
  observeEvent({input$IndicationReconciliation},{
    IndicationReconciliation.update <<- excel_to_R(input$IndicationReconciliation)
    ReconcileNote <<- IndicationReconciliation.update[16,8]
    TargetReconcile <<- IndicationReconciliation.update[6:(nrow(trendedOnlevel)+5),7:11]
    print(ReconcileNote)
    print(TargetReconcile)
    
  }, priority = 1)
  
  ### Non-Modeled Cat Results
  
  observeEvent({input$Program
                input$EvaluationDate
                input$IndicationDate
                input$State
                input$currentLossTrendState
                input$NonModeledAvgWeight
                input$NonModeledStateWeight    
                input$currentPremiumTrend
                input$projPremiumTrend
                input$proposedEffective
                input$projLossTrendState
                input$currentLossTrendCW
                input$projLossTrendCW 
                input$LLLstateweightTotal
                input$useNonModeled
                },
               {
                 if (input$searchIndication > searchIndication & req(input$currentLossTrendState!=default,
                                                                     input$LLLstateweightTotal!=default,
                                                                     input$NonModeledAvgWeight!=default,
                                                                     input$NonModeledStateWeight!=default)
                     & input$proposedEffective != '2022-01-01') {
                   print('start Non Modeled Load')
                   
                   ModCatYearsExpAdj <- length(unique(NonModeledZones$Loss_Rolling_Year)) #save the number of years in the experience Adjustment
                   
                   NonModeledResults <<- NonModeledSummary(input$IndicationDate,NonModeledZones,input$currentLossTrendState)
                  
              
                   
                   if (length(NonModeledResults) > 0 & 'STS' %in% input$includePerils) {
                     if (nonModeledCount == 0) {
                       if (length(NonModeledResults) > 1) {
                       insertTab(inputId = "NonModeled", ##need to only add the tabs when they are not present
                                 tabPanel('Total', ##Right now I am adding the tabs every time. Likely need to separtate the insertTab from the rest of the code in separate observe event chunks!
                                          fluidRow(
                                            column(2),
                                            column(6,
                                                   align = 'center',
                                                   h4(strong(state_name_full(input$State))),
                                                   h4(strong('Homeowners of America Insurance Company')),
                                                   h4(strong('Homeowners: All Forms Combined')),
                                                   h5('Experience Based Catastrophe Load'),br(),br(),br(),
                                                   DTOutput('ZoneSummary')),
                                            column(2)),
                                          fluidRow(
                                            column(4),
                                            column(4,br(),br(),
                                                   DTOutput('ZoneSelectTotal'),
                                                   br(),
                                                   DTOutput('TotalLossLAE'),
                                                   br(),
                                                   DTOutput('STSmodeledCat'),
                                                   br(),
                                                   DTOutput('SelectedSTS')
                                            ),
                                            column(2)
                                          )
                                 )
                       )
                       }
                       print('non modeled counter')
                       nonModeledCount <<-  1 #reassign the counter to 1 so that the tabs above are only created once per state/program
                     }
                     for (zone in 1:length(NonModeledResults)) { 
                       
                       local({ #use the local value to the data frame and zones 
                         NonModeledDF <- as.data.frame(NonModeledResults[[zone]][[1]])  
                         NonModeledDF_CheckBox <- NonModeledDF%>%
                           filter(Loss_Rolling_Year != 'Total')
                         #pull in the saved checkbox things
                         if (nonModeledCount == 1) {
                           insertTab(inputId = "NonModeled", ##need to only add the tabs when they are not present
                                     tabPanel( paste('Experience Cat Load Zone', ifelse((length(NonModeledResults) > 1),zone,''), sep=' '), ##Right now I am adding the tabs every time. Likely need to separtate the insertTab from the rest of the code in separate observe event chunks!
                                              fluidRow(
                                                column(2),
                                                column(6,
                                                       align = 'center',
                                                       h4(strong(state_name_full(input$State))),
                                                       h4(strong('Homeowners of America Insurance Company')),
                                                       h4(strong('Homeowners: All Forms Combined')),
                                                       h5('Experience Based Catastrophe Load'),
                                                       h5(if (length(NonModeledResults) > 1) paste('Zone', zone, '-',unique(NonModeledDF$Zone) ) else ''),br(),br(),br(),
                                                       DTOutput(paste0('Zone',zone))),
                                                column(2,br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
                                                       checkboxGroupInput(inputId = paste0("zoneYearExclude",zone), 
                                                                          label = 'Exclude Year', 
                                                                          choices = NonModeledDF_CheckBox[['Loss_Rolling_Year']], 
                                                                          selected = NULL))
                                                ),
                                              fluidRow(
                                                column(6),
                                                column(2,
                                                       DTOutput(paste0('ZoneAverages',zone))
                                                ),
                                                column(2)
                                              ),
                                              fluidRow(
                                                column(6),
                                                column(2,
                                                       DTOutput(paste0('ZoneSelect',zone))),
                                                column(2)
                                              ),
                                              fluidRow(column(4),
                                                       column(4,
                                                              br(),
                                                              if (length(NonModeledResults) == 1) DTOutput('TotalLossLAE'),
                                                              br(),
                                                              if (length(NonModeledResults) == 1) DTOutput('STSmodeledCat'),
                                                              br(),
                                                              if (length(NonModeledResults) == 1) DTOutput('SelectedSTS')
                                                              ))
                                     )
                           )
                           nonModeledCount <<- if (zone == length(NonModeledResults)) 2 else nonModeledCount #if creating the last experience page, then set counter to 2
                         }
                         colnames(NonModeledDF) <- c('Year', 
                                                     'Zone',
                                                     'Non CAT Paid Loss & LAE',
                                                     'CAT Paid Loss & LAE (ex. Hurricane)',
                                                     'Trended Non CAT Paid Loss & LAE',
                                                     'Trended Cat Paid Loss & LAE (ex. Hurricane',
                                                     'Estimated CAT Load (ex. Hurricane)')
                         
                         output[[paste0('Zone',zone)]] <- renderDT(datatable(NonModeledDF%>%
                                                                               select(-Zone),selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%
                                                                     formatRound(c(2:5), digits = 0)%>%
                                                                     formatPercentage(c(6),digits = 1)%>%
                                                                     formatStyle(
                                                                       1,
                                                                       target = "row",
                                                                       fontWeight = styleEqual("Exclude Year", "bold")
                                                                     ))
                        NonModeledInputs <- c(NonModeledInputs,eval(parse(text = paste0("input$zoneYearExclude",zone))))
                        print('Text variable from text')
                        print(NonModeledInputs)
                        zoneYearExclude[[paste0('z',zone)]] <<- input[[paste0("zoneYearExclude",zone)]]
                         NonModeledAvg <- NonModeledAverage.Calc(NonModeledDF_CheckBox,zoneYearExclude[[paste0('z',zone)]])
                         
                         colnames(NonModeledAvg) <- c('','')
                         output[[paste0('ZoneAverages',zone)]] <- renderDT(datatable(NonModeledAvg,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                                             formatPercentage(c(2),digits = 1))
                         NonModeledSelected <- data.frame(Name = c('Selected:'), Value = input$NonModeledAvgWeight*NonModeledAvg[1,2] + (1-input$NonModeledAvgWeight)*NonModeledAvg[2,2])
                         colnames(NonModeledSelected) <- c('','')
                         
                         InforceSummary[zone,3] <<- NonModeledSelected[1,2]
                         
                         output[[paste0('ZoneSelect',zone)]] <- renderDT(datatable(NonModeledSelected,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                                           formatPercentage(c(2),digits = 1))
                         
                       })
                     } 
                     colnames(InforceSummary) <- c('Zone','Inforce Count','Selected CAT Load (ex. Hurricane)')
                     output$ZoneSummary <- renderDT(datatable(InforceSummary,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                      formatPercentage(c(3),digits = 1))
                     InforceSummary.2 <<- InforceSummary%>%
                       mutate(Prod = `Inforce Count` * `Selected CAT Load (ex. Hurricane)`)
                     
                     ZoneSelectTotal <<- data.frame(Label = c('Weighted Average By Infrorce'), Selection = c(sum(InforceSummary.2$Prod)/sum(InforceSummary.2$`Inforce Count`)))
                     output$ZoneSelectTotal <- renderDT(datatable(ZoneSelectTotal,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                          formatPercentage(c(2),digits = 1))
                     
                     TotalIncurredFilter <<- total_data[total_data[1] == 'Total',]%>%
                       mutate(Name = 'Projected Non-Catastrophe Loss & LAE Ratio:',Value = `Projected Loss & LAE Ratio (ex Cat)`)%>%
                       select(Name, Value)
                     print('calc estimated cat incurred ratio')
                     EstimateTotalIncurred <<- data.frame(Name = c('Estimated Cat Loss & LAE Ratio (ex. Hurricane)'), Value = c(as.numeric(TotalIncurredFilter$Value)*as.numeric(ZoneSelectTotal$Selection)))
                     
                     ExperienceTotalIncurred <<- rbind(TotalIncurredFilter,EstimateTotalIncurred)
                     colnames(ExperienceTotalIncurred) <- c('','')
                     
                     output$TotalLossLAE <- renderDT(datatable(ExperienceTotalIncurred,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                       formatPercentage(c(2),digits = 1))
                     
                     STS_modeled_cat <<-  data.frame(Name = 'Modeled Cat Loss & LAE Ratio (ex. Hurricane):', Value = as.numeric(modeled_cat%>%select(`Modeled CS Loss & LAE Ratio`)))
                     colnames(STS_modeled_cat) <- c('','')
                     
                     output$STSmodeledCat <- renderDT(datatable(STS_modeled_cat,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                        formatPercentage(c(2),digits = 1))
                     
                     SelectedSTSload <<- data.frame(Name = 'Selected Cat Loss & LAE Ratio (ex. Hurricane):', Value = as.numeric(STS_modeled_cat[1,2])*(1-input$NonModeledStateWeight) + as.numeric(ExperienceTotalIncurred[2,2])*input$NonModeledStateWeight) 
                     colnames(SelectedSTSload) <- c('','')
                     
                     output$SelectedSTS <- renderDT(datatable(SelectedSTSload,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>% 
                                                      formatPercentage(c(2),digits = 1))
                     print(input$useNonModeled)
                    if (as.numeric(input$useNonModeled) == 1) {
                      STSexpFactor$Value <<- SelectedSTSload[1,2] / STS_modeled_cat[1,2]
                      STSyearExpAdj$Value <<- ModCatYearsExpAdj
                      test$x <- 1
                    } else {
                      STSexpFactor$Value <<- 1
                      STSyearExpAdj$Value <<- 0
                    }
                     
                     
                   }
                   message('Non Modeled')
                   
                   output$STSExpFactorYearsText <- renderText({paste0('STS Total Years for Experience Adj: ',STSyearExpAdj$Value)})
                   output$STSExpFactorText <- renderText({paste0('STS Exp Adj Factor: ',round(STSexpFactor$Value,2))})
                 }
               },priority = 0)
  
  observe({
    print(input$zoneYearExclude1)
    })
  
  
  
  
  ###################CVA Analysis
  
  observeEvent({input$ProgramvariableOptions},
               
               {
                 if (input$searchIndication > searchIndication) {
                   updateSelectInput(session, input = "selectVariable",
                                  choices = input$ProgramvariableOptions)
                 
               }}
  )
  
  observe({
    if (input$searchIndication > searchIndication) {
    updateTextInput(session, input = 'variableTitle', value = cvaDisplayName(input$Program,input$selectVariable))
    
  }})
  
  
  observe({ 
    
    if (input$searchIndication > searchIndication) {
    Peril <- c('Total','TotalModeledHU','ExCat',input$includePerils)
    if ('Hurricane' %in% input$includePerils) {
      Peril <- c(Peril,'ModeledHU')
    }
    CVAPerils <- data.frame(Peril = Peril)
    
    updateSelectInput(session, input = "selectPeril",choices = CVAPerils)
    
  }}
  )
  

  
  observe({ 
    if (input$searchIndication > searchIndication) {
    options(warn = -1) #temporarily suppress warnings
    variableData <- cvaPull(input$Program,input$IndicationDate, input$State, unlist(input$selectVariable),HUexpFactor$Value,as.numeric(selected_expense_data_selected),input$DataSource)
    variableClean <- cvaClean(variableData, input$selectPeril)
    condition <- T
    while (condition) { 
 
      
      variableClean <- CVAvalueMapping(input$Program,input$State,input$selectVariable,variableClean, input$selectPeril)

      axisOrder <- unique(variableClean$variableValue)
      variableCleanTable <- variableClean%>%
        select(-Peril)
      
      
      colnames(variableCleanTable) <- c('Class', 'Rerated Premium','Earned House Years','Average Premium','Capped Loss + LAE','Claim Count',
                                        'Loss Ratio','Frequency (peril 100 EHY)','Severity','Loss Cost','Indicated Change','Credibility',
                                        'Credibility Weighted Indicated Change','Frequency Relativity','Severity Relativity','Loss Ratio Relativity')
      
      
      output$table <- renderDT(datatable(variableCleanTable,selection = 'none',class = 'compact',rownames = F,options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '80px',className = 'dt-right',targets = c(1,15)),list(width = '500px',className = 'dt-left',targets = c(0)))))%>%
                                 formatRound(c(3,6), digits=0)%>%
                                 formatPercentage(c(7,11,12),digits = 1)%>%
                                 formatRound(c(8,14:16),digits = 2)%>%
                                 formatPercentage(c(13),digits = 0)%>%
                                 formatStyle(
                                   1,
                                   target = "row",
                                   fontWeight = styleEqual("Total", "bold")
                                 )%>%
                                 formatCurrency(c(2,4:5,9:10),digits = 0))
      
      variableCleanPlot <- variableClean%>%
        filter(variableValue != 'Total')%>%
        mutate(`Earned House Years` = EHY, `Frequency Relativity`=FreqRel, `Severity Relativity` = SevRel, `Loss Ratio Relativity` = LossRel)%>%
        select(variableValue, EHY, `Frequency Relativity`, `Severity Relativity`, `Loss Ratio Relativity`)%>%
        gather("Ratios", 'Values', 3:5)%>%
        arrange(variableValue) 
      
      secondlimitsdenom <<- max((variableClean%>%filter(variableValue!='Total'))$EHY,na.rm = T)
      secondlimitsnum <<- max(variableCleanPlot$Values, 1, na.rm = T)*1.25
      
      options(warn = 0) #turn warnings back on
      if (nrow(variableCleanPlot) > 0) {
        output$distPlot <- renderPlot({
          ggplot(variableCleanPlot) + 
            geom_bar(aes(x=variableValue, y=EHY/3*secondlimitsnum/secondlimitsdenom),stat = "identity",color='grey',fill='grey',width = .4) +
            geom_point(aes(x=variableValue, y=Values,color=Ratios, shape = Ratios,size=Ratios))+
            geom_line(aes(x=variableValue, y=Values ,color=Ratios, shape = Ratios, group = Ratios, linetype = Ratios) )+
            geom_line(aes(x=variableValue, y=1, group =1),colour = 'black', size = 1)+
            scale_y_continuous(sec.axis=sec_axis(~.*secondlimitsdenom/secondlimitsnum,name="EHY")) +
            theme(panel.background = element_rect(fill = 'transparent', color = 'transparent'),panel.grid.major.y = element_line(color = "grey85",
                                                                                                                                 size = 0.5))+
            scale_color_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'='grey','Loss Ratio Relativity'="gold",'Severity Relativity'="darkred",'Frequency Relativity'="green4" ))+
            scale_linetype_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'='blank','Loss Ratio Relativity'="solid",'Severity Relativity'="dotted",'Frequency Relativity'="dashed" ))+
            scale_shape_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'=15,'Loss Ratio Relativity'=17,'Severity Relativity'=15,'Frequency Relativity'=16 ))+
            scale_size_manual(name = '',breaks = c('Earned House Years','Loss Ratio Relativity','Severity Relativity','Frequency Relativity'),values = c('Earned House Years'=6,'Loss Ratio Relativity'=3,'Severity Relativity'=3,'Frequency Relativity'=3 ))+
            theme(#text = element_text(family = "Calibri"),
              legend.key = element_rect(colour = NA, fill = NA),legend.position="bottom",plot.title = element_text(hjust = 0.5,color = 'grey40'),
              plot.background = element_rect(colour = "grey", fill=NA,size = .75),
              legend.key.size = unit(3,"line"))+
            ggtitle(paste0(input$State,': ',input$variableTitle))+
            ylab('')+xlab('')+
            scale_x_discrete(limits = c(as.character(axisOrder[axisOrder != 'Total' & !is.na(axisOrder)])))
          
          
        })
      }
      
      condition <- F
    } }
  })
  

  observeEvent({input$saveSelectionsForReview},
               {
                 if (input$searchIndication > searchIndication) { 
                   
                   if (length(input$SelectorChecklist)==length(selectorChecklist_list)) {
                   save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                        input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                        as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                        input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,
                                        input$selected_by[[1]],0,0)
 
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],0,0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],0,0)
                   } else {
                     showNotification('Not all items have been check on the Selector Checklist')
                   }}})
  
  observeEvent({input$saveTechnicalReview},
               {
                 if (input$searchIndication > searchIndication) {
                   if (length(input$TechnicalreviewChecklist)==length(technicalChecklist_list)) {
                   save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                        input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected), input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                        as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                        input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,
                                        input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0)
                   save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],0) 
                 } else {
                   showNotification('Not all items have been check on the Technical Review Checklist')
                 }}})
  
  observeEvent({input$savePeerReview},
               {
                 
                 if (input$searchIndication > searchIndication) {
                   if (length(input$PeerReviewChecklist)==length(peerChecklist_list)) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                      input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,
                                      input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','In Review',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','In Review',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','In Review',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                   } else {
                     showNotification('Not all items have been check on the Peer Review Checklist')
                 }}
                })
  
  observeEvent({input$PublishSelections},
               {
                 if (input$searchIndication > searchIndication) {
                   if (nrow(ReviewProgressDataFilter)==3) {
                 save_selections_rest(input$Program,input$IndicationDate,evaluation_use, input$State,'All Perils','Published',
                                      input$CATstateweight,input$state_exclude,input$cw_exclude,as.numeric(selected_expense_data_selected),input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,HUexpFactor$Value,HUyearsAdjFactor$Value,STSexpFactor$Value,STSyearExpAdj$Value,input$includePerils,input$proposedEffective,input$fillOutDate,input$useNonModeled,input$NonModeledAvgWeight, input$NonModeledStateWeight,
                                      input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','All Perils','Published',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Weather','Published',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'','Attritional','Published',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','All Perils','Published',LDFstate_selection_All,LDF_selection$All,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Weather','Published',LDFstate_selection_Weather,LDF_selection$Weather,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                 save_selections(input$Program,input$IndicationDate,evaluation_use, input$State,'CW','Attritional','Published',LDFstate_selection_Attritional,LDF_selection$Attritional,input$LDFstateweight,input$selected_by[[1]],input$technical_reviewed_by[[1]],input$peer_reviewed_by[[1]])
                   } else {
                     showNotification('Not Review Steps Have Been Completed')
                   }
               }})
  #generate a html report based on the selections made which can easily be printed to pdf in your browser. HTML is much easier to style than pdf.
  #territorial_report
  output$report <- downloadHandler(
    filename = paste(input$State,' ' ,input$Program," Indication ",year(as.Date(input$IndicationDate) - 1) %% 100 , strftime(as.Date(input$IndicationDate) -1, format = "%m") ,".html",sep = ''),
    content = function(file) {
      
      rmarkdown::render("Indication Report.Rmd", output_file = file,
                        params = list(
                          IndicationDate= input$IndicationDate,
                          EvaluationDate= evaluation_use,
                          proposedEffectiveDate= input$proposedEffective,
                          LOB = input$Program,
                          LOB_Full = table_name(input$Program),
                          State = input$State,
                          State_Full = state_name_full(input$State),
                          ldfallLoss = LDF_display(LDFdata,'Losses','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,N,input$StateA),
                          ldfallRatio = LDF_display(LDFdata,'Loss Ratios','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA,input$State),
                          ldfallAverages =LDF_display_averages(LDFallAverages,LDFallAveragesState,input$LDFstateweight),
                          ldfallSelections = LDF_selections_choose(LDF_selection$All,weighted_plot_all,input$LDFstateweight),
                          ldfallLossWeather = LDF_display(LDFdata,'Losses','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA,input$State),
                          ldfallRatioWeather = LDF_display(LDFdata,'Loss Ratios','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA,input$State),
                          ldfallAveragesWeather = LDF_display_averages(LDFallAveragesWeather,LDFallAveragesStateWeather,input$LDFstateweight),
                          ldfallSelectionsWeather =  LDF_selections_choose(LDF_selection$Weather,weighted_plot_weather,input$LDFstateweight),
                          ldfallLossAttritional = LDF_display(LDFdata,'Losses','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA,input$State),
                          ldfallRatioAttritional = LDF_display(LDFdata,'Loss Ratios','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA,input$State),
                          ldfallAveragesAttritional = LDF_display_averages(LDFallAveragesAttritional,LDFallAveragesStateAttritional,input$LDFstateweight),
                          ldfallSelectionsAttritional =  LDF_selections_choose(LDF_selection$Attritional,weighted_plot_attritional,input$LDFstateweight),
                          profit= as.numeric(state_profit),
                          TotalRateTable= total_data,
                          TotalRateCalc= TotalSummary,
                          FireLosses= fireLosses,
                          FirePrem= firePremium,
                          FireCalc= fireSummary,
                          WaterLosses= waterLosses,
                          WaterPrem= waterPremium,
                          WaterCalc= waterSummary,
                          TheftLosses= theftLosses,
                          TheftPrem= theftPremium,
                          TheftCalc= theftSummary,
                          LiabilityLosses= liabilityLosses,
                          LiabilityPrem= liabilityPremium,
                          LiabilityCalc= liabilitySummary,
                          OtherAOPLosses= OtherAOPLosses,
                          OtherAOPPrem= OtherAOPPremium,
                          OtherAOPCalc= OtherAOPSummary,
                          NCWLosses= NCWLosses,
                          NCWPrem= NCWPremium,
                          NCWCalc= NCWSummary,
                          STSLosses= STSLosses,
                          STSCalc= STSsummary,
                          HurricaneLosses= HULosses,
                          HurricaneCalc= HUsummary,
                          BalancedChange = indication_memo(TotalSummary, fireSummary, waterSummary, theftSummary, liabilitySummary, OtherAOPSummary, NCWSummary, STSsummary, HUsummary,coverage_report_data,non_peril_pull(input$Program,input$IndicationDate,evaluation_use,input$State,input$DataSource),input$includePerils),
                          PremiumTable= PremiumData_state%>%select(-Date),
                          PremiumFitting=premium_trend_fitting(PremiumData_state,0),
                          CurrentPremiumTrend= input$currentPremiumTrend,
                          ProjectedPremiumTrend=input$projPremiumTrend,
                          LossTable= lossTrendstateData%>%select(-Year,-Quarter),
                          LossFitting= loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),
                          CurrentLossTrend= input$currentLossTrendState,
                          ProjectedLossTrend= input$projLossTrendState,
                          LLLStateTotal= LLLdata_state_total,
                          LLLStateTotalCalc= LLL_selections(LLLdata_state_total,'Calculated'),
                          LLLStateTotalSelected= LLLdata_state_total_selected,
                          LLLCWTotal= LLLdata_CW_total,
                          LLLCWTotalCalc= LLL_selections(LLLdata_CW_total,'Calculated'),
                          LLLCWTotalSelected= LLLdata_CW_total_selected,
                          LLLTotalFinal = LLLTotal(),
                          LLLStateFire= LLLdata_state_fire,
                          LLLStateFireCalc= LLL_selections(LLLdata_state_fire,'Calculated'),
                          LLLStateFireSelected= LLLdata_state_fire_selected,
                          LLLCWFire= LLLdata_CW_fire,
                          LLLCWFireCalc= LLL_selections(LLLdata_CW_fire,'Calculated'),
                          LLLCWFireSelected= LLLdata_CW_fire_selected,
                          LLLFireFinal = LLLFire(),
                          LLLStateWater= LLLdata_state_water,
                          LLLStateWaterCalc= LLL_selections(LLLdata_state_water,'Calculated'),
                          LLLStateWaterSelected= LLLdata_state_water_selected,
                          LLLCWWater= LLLdata_CW_water,
                          LLLCWWaterCalc= LLL_selections(LLLdata_CW_water,'Calculated'),
                          LLLCWWaterSelected= LLLdata_CW_water_selected,
                          LLLWaterFinal = LLLWater(),
                          LLLStateTheft= LLLdata_state_theft,
                          LLLStateTheftCalc= LLL_selections(LLLdata_state_theft,'Calculated'),
                          LLLStateTheftSelected= LLLdata_state_theft_selected,
                          LLLCWTheft= LLLdata_CW_theft,
                          LLLCWTheftCalc= LLL_selections(LLLdata_CW_theft,'Calculated'),
                          LLLCWTheftSelected= LLLdata_CW_theft_selected,
                          LLLTheftFinal = LLLTheft(),
                          LLLStateLiability= LLLdata_state_liability,
                          LLLStateLiabilityCalc= LLL_selections(LLLdata_state_liability,'Calculated'),
                          LLLStateLiabilitySelected= LLLdata_state_liability_selected,
                          LLLCWLiability= LLLdata_CW_liability,
                          LLLCWLiabilityCalc= LLL_selections(LLLdata_CW_liability,'Calculated'),
                          LLLCWLiabilitySelected= LLLdata_CW_liability_selected,
                          LLLLiabilityFinal = LLLLiability(),
                          LLLStateOtherAOP= LLLdata_state_otherAOP,
                          LLLStateOtherAOPCalc= LLL_selections(LLLdata_state_otherAOP,'Calculated'),
                          LLLStateOtherAOPSelected= LLLdata_state_otherAOP_selected,
                          LLLCWOtherAOP= LLLdata_CW_otherAOP,
                          LLLCWOtherAOPCalc= LLL_selections(LLLdata_CW_otherAOP,'Calculated'),
                          LLLCWOtherAOPSelected= LLLdata_CW_otherAOP_selected,
                          LLLOtherAOPFinal = LLLOtherAOP(),
                          LLLStateWeather= LLLdata_state_weather,
                          LLLStateWeatherCalc= LLL_selections(LLLdata_state_weather,'Calculated'),
                          LLLStateWeatherSelected= LLLdata_state_weather_selected,
                          LLLCWWeather= LLLdata_CW_weather,
                          LLLCWWeatherCalc= LLL_selections(LLLdata_CW_weather,'Calculated'),
                          LLLCWWeatherSelected= LLLdata_CW_weather_selected,
                          LLLWeatherFinal = LLLWeather(),
                          LLLWeight= input$LLLstateweightTotal,
                          Capping= input$capped,
                          ModeledCatLoad = modeled_cat,
                          ExpenseRatio = expense_ratios,
                          Credibility = credibility_exhibit(losses_claims),
                          Cumulative = OLFcumulative,
                          OnLevelFactors = on_level_load,
                          HUreinsurance = reinsurance(input$State,evaluation_use,input$Program,'Hurricane'),
                          STSreinsurance = reinsurance(input$State,evaluation_use,input$Program,'STS'),
                          CostOfReinsurance = reinsurance(input$State,evaluation_use,input$Program,'All Perils'),
                          Reinsurance = reinsurance_exhibit_table,
                          Peril = input$includePerils
                        ),
                        envir = new.env(parent = globalenv())
      )
      
    }
  )#
  output$territorial_report <- downloadHandler(
    filename = paste(input$State, input$Program,"Territorial Analysis.html",sep = ' '),
    content = function(file) {
      
      rmarkdown::render("Territorial Analysis Report.Rmd", output_file = file,
                        params = list(
                          IndicationDate= input$IndicationDate,
                          EvaluationDate= evaluation_use,
                          proposedEffectiveDate= input$proposedEffective,
                          LOB = input$Program,
                          LOB_Full = table_name(input$Program),
                          State = input$State,
                          State_Full = state_name_full(input$State),
                          TerritorialTotal = TerritorialExhibitData%>%select(-InforceCount),
                          TerritorialSnapshot = TerritorialExhibitTop10(TerritorialExhibitData),
                          TerritorialFire = TerritorialExhibitFireData,
                          TerritorialWater = TerritorialExhibitWaterData,
                          TerritorialTheft = TerritorialExhibitTheftData,
                          TerritorialLiab = TerritorialExhibitLiabilityData,
                          TerritorialOther = TerritorialExhibitOtherAOPData,
                          TerritorialNCW = TerritorialExhibitNCWData ,
                          TerritorialSTS = TerritorialExhibitSTSData ,
                          TerritorialHurricane = TerritorialExhibitHUData,
                          Peril = input$includePerils
                        ),
                        envir = new.env(parent = globalenv())
      )
      
    }
  )
  
  }})
    
}

# Run the application 

shinyApp(ui = ui, server = server)
