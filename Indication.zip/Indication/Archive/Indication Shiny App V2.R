#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
######################################################
############ Actuarial Indication ####################
######################################################

#Install Packages if Necessary
if (!require(DBI)) install.packages('DBI')
if (!require(lubridate)) install.packages('lubridate')
if (!require(openxlsx)) install.packages('openxlsx')
if (!require(shiny)) install.packages('shiny')
if (!require(shinyWidgets)) install.packages('shinyWidgets')
if (!require(dplyr)) install.packages('dplyr')
if (!require(DT)) install.packages('DT')
if (!require(miscTools)) install.packages('miscTools')
if (!require(tidyr)) install.packages('tidyr')
if (!require(shinythemes)) install.packages('shinythemes')
if (!require(markdown)) install.packages('markdown')
if (!require(shinyjs)) install.packages('shinyjs')
if (!require(shinycssloaders)) install.packages('shinycssloaders')
if (!require(odbc)) install.packages('odbc')
if (!require(sjmisc)) install.packages('sjmisc')

#load packages
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)

#define input options
LOB <- data.frame(matrix(ncol = 4,nrow=0))
colnames(LOB) <- c('HO','DF','RE','CO')

#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server',
                  server=server,
                  database=database,
                  trusted_connection='yes')

#JavaScript function to allow drop down boxes inside of a data table
js <- c(
  "function(settings){",
  "  $('#mselect').selectize()",
  "}"
)

#get current state options with a SQL rater
state_options <- function(program) {
  df <- dbGetQuery(con,paste0("
      select state from 
      ",program,".policyRate
      group by state
    "))
  state <- data.frame(matrix(ncol=length(df[['state']])+1,nrow=0))
  colnames(state) <- c(df[['state']],' ')
  return(state)
}

#get a list of indication dates available in SQL
date_options <- function() {
  df <- dbGetQuery(con,paste0(
    "select indicationdate
    from actuarialsandbox.ho.modeledCatLoad
    group by indicationdate
    order by indicationdate desc "
  ))%>%
    mutate(IndicationName = as.character(as.numeric(substr(as.character( year(as.Date(indicationdate) %m-% months(1))),3,4))*100+ month(as.Date(indicationdate) %m-% months(1))))
  
  out <- list()
  for (i in 1:nrow(df)) {
    out <- append(out, list(df$indicationdate[i]))
  }
  names(out) <- df[['IndicationName']]
  return(out)
}

#Used to attach Actuary names to indication Selections
selections_id <- function(IndicationDate, EvaluationDate, State, Program) {
  df <- dbGetQuery(con,paste0(
    "
    select selected_by, FirstName+ ' ' + LastName as Name
    from ActuarialSandbox.ho.TeamId a
    left join (
    SELECT min(selected_by) as selected_by
    from ActuarialSandbox.",Program,".indicationSelections
      where region= '",State,"'
      and IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      group by region) b on b.selected_by=a.teamID
      where selected_by is not null
    "
  ))
  df_out <- as.data.frame(df$selected_by)
  
  if (nrow(df_out) > 0) {
    colnames(df_out) <- c(df[['Name']])
    return(df_out)
  } else {
    other <- data.frame(matrix(ncol=1,nrow=1))
    other[1] <- c(1)
    colnames(other) <- c('Donte Riddick')
    return(other)
  }
}
actuaryNames <- function(except) {
  df <- dbGetQuery(con,"
                    select teamID,
                    FirstName,
                    LastName
                    from ActuarialSandbox.dbo.TeamId
                    where status = 'Active'
                    and Role = 'Actuarial'
                   ")%>%
    mutate(FullName = paste(FirstName, LastName, sep = ' '))
  out <- list()
  for (i in 1:nrow(df)){
    out <- append(out, list(df$teamID[i]))
  }
  names(out) <- df$FullName
  return(out[out != except[[1]]])
}

eval_date_options <- function(IndicationDateIn) {
  IndicationDateIn <- as.Date(IndicationDateIn)
  df <- dbGetQuery(con, paste0(
    "select indicationdate, evaluationdate
    from actuarialsandbox.ho.modeledCatLoad
    group by indicationdate, evaluationdate"
  ))
  options <- df[as.Date(df$indicationdate)==IndicationDateIn,]
  out <- list()
  for (i in 1:nrow(options)) {
    out <- append(out, list(options$evaluationdate[i]))
  }
  
  names(out) <- options[['evaluationdate']]
  return(out)
}
#Tablename Full
table_name <- function(LOB_short) {
  LOB_full <- ifelse(LOB_short=='HO', 'Homeowners',
                     ifelse(LOB_short=='DF', 'Dwelling Fire',
                            ifelse(LOB_short=='CO', 'Condo',
                                   ifelse(LOB_short=='TE' | LOB_short == 'RE','Tenant','LOB Error'))))
  return(LOB_full)
}

state_name_full <- function(state_short) {
  state_full <- state.name[match(c(state_short),state.abb)]
  return(as.character(state_full))
}
#end display funcitons

LDF_options <- function() {
  out<-data.frame(matrix(ncol=3,nrow = 0))
  colnames(out)<- c('All Countrywide', 'All State', 'Weighted Average')
  return(out)
}

expense_cw<- function(Tablename, As_Of_Date,Rolling_Year_End) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
    df <- dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Tablename,".[claim] 
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep=""))
    df%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(df$`Loss Reserve`),`Expense Reserve` = sum(df$`Expense Reserve`),`Legal Expense Reserve` = sum(df$`Legal Expense Reserve`),
                                                                                                                                                 `Expense Load`=(sum(df$`Loss Reserve`)+sum(df$`Expense Reserve`)+sum(df$`Legal Expense Reserve`))/sum(df$`Loss Reserve`))
} #cw expense load table

expense_state<- function(Tablename, As_Of_Date,Rolling_Year_End,State) {
  As_Of_Date <- as.Date(As_Of_Date)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  df<-dbGetQuery(con,paste("	select 
  		case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1
      		else year(dateOfLoss)
      		end as Year,
  		SUM(incurredLoss) - SUM(incurredRecovery) as 'Loss Reserve',
  		SUM(incurredExpense) as 'Expense Reserve',
  		SUM(incurredLegalExpense) as 'Legal Expense Reserve',
  		case when (SUM(incurredLoss) - SUM(incurredRecovery)) > 0 then
  		(SUM(incurredLoss) - SUM(incurredRecovery) + SUM(incurredExpense) + SUM(incurredLegalExpense)) / (SUM(incurredLoss) - SUM(incurredRecovery)) 
  		else 0 end as 'Expense Load'
  	from ActuarialDataMart.",Tablename,".[claim] 
  	where '",As_Of_Date,"' between rowStartDate and rowEndDate
  		and dateOfLoss < '",Rolling_Year_End,"'
  		and dateReported < '",As_Of_Date,"'
  		and catastropheID <> 0
  		and state = '",State,"'
  		and policynum <> 'AZ-002633-00'
  	group by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  	order by case when month(dateOfLoss) > ",month(Rolling_Year_End %m-% months(1))," then year(dateOfLoss) +1	else year(dateOfLoss) end
  ",sep=""))
  df%>% 
    mutate(Year = as.character(Year)) %>%
    add_row(`Year` = "Total",`Loss Reserve` = sum(df$`Loss Reserve`),`Expense Reserve` = sum(df$`Expense Reserve`),`Legal Expense Reserve` = sum(df$`Legal Expense Reserve`),
            `Expense Load`=(sum(df$`Loss Reserve`)+sum(df$`Expense Reserve`)+sum(df$`Legal Expense Reserve`))/sum(df$`Loss Reserve`))
} #state expense load table

expense_select <- function(Tablename, As_Of_Date,Rolling_Year_End,State, StateWeight,cw_exclude,state_exclude) {
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  As_Of_Date <- as.Date(As_Of_Date)
  cw <- expense_cw(Tablename, As_Of_Date,Rolling_Year_End)%>%
    filter(!Year %in% c(cw_exclude,"Total"))
  cw_load=(sum(cw$`Loss Reserve`)+sum(cw$`Expense Reserve`)+sum(cw$`Legal Expense Reserve`))/sum(cw$`Loss Reserve`)
  state <- expense_state(Tablename, As_Of_Date,Rolling_Year_End,State)%>%
    filter(!Year %in% c(state_exclude,"Total"))
  state_load=(sum(state$`Loss Reserve`)+sum(state$`Expense Reserve`)+sum(state$`Legal Expense Reserve`))/sum(state$`Loss Reserve`)
  df<-data.frame()
  df["Calculated Expense Load",' '] <-cw_load*(1-StateWeight) + coalesce(state_load*StateWeight,0)
  df
} #selected expense Load table with exclude years for state and cw

#figure out status on Targit, spatial key, and AAL

#Modeled cat load
modeled_cat_load <- function(Tablename,As_Of_Date,Rolling_Year_End,State,IncludePolicyFee,cat_load) {
  As_Of_Date <- as.Date(As_Of_Date)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  df <- dbGetQuery(con, paste0(
    "SELECT [In Force Premium @ Current Level]
    ,[In Force Policy Charge]
      ,[Hurricane In Force Premium @ CRL]
      ,[Hurricane Gross AAL]
      ,[Modeled HU CAT Loss Ratio]
      ,[STS In Force Premium @ CRL]
      ,[Convective Storm Gross AAL]
      ,[Modeled CS CAT Loss Ratio]
      ,[Total Cat Loss]
  FROM [ActuarialSandbox].[",Tablename,"].[modeledCatLoad]
  where state = '",State,"'
  and IndicationDate = '",Rolling_Year_End,"'
  and EvaluationDate = '",As_Of_Date  ,"'
    ")
  )
  df_out <- df %>%
    select(-`In Force Policy Charge`)%>%
    mutate(`CAT LAE Load` = cat_load, `Modeled Hurricane Loss & LAE Ratio` = `Modeled HU CAT Loss Ratio` * cat_load, `Modeled CS Loss & LAE Ratio` = `Modeled CS CAT Loss Ratio` * cat_load)%>%
    mutate(`Total Modeled Cat Loss & LAE Ratio` = `Modeled Hurricane Loss & LAE Ratio` + `Modeled CS Loss & LAE Ratio`)
  return(df_out)
}

column_names <- function(df,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  if (table == 'Losses') {
  c(
    ifelse(month(Rolling_Year_End %m-% months(1))==12,
           'Accident Year',
           paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 12*c(1:(length(df)-1)))
  }
  else {
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(df)))) {
      if (i == length(colnames(df))) {
        names <- c(names,paste(as.character((i-1)*12+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*12+adder),':',as.character((i-1)*12+adder+12),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
} #rename to the 12,24,... or the 15,27... name

LDF <- function(Tablename,Rolling_Year_End,AsOfDate,state) {
  AsOfDate<- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  losses <- dbGetQuery(con,paste0("SELECT [IndicationDate]
      ,[EvaluationDate]
      ,[TableName]
      ,[Class]
      ,[Years]
      ,[Region]
	  ,	colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ, colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ
  FROM [ActuarialSandbox].[ho].[ldfTriangles]
  pivot (avg(columnValue) for columnName in (colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ) ) as PivotTable 
  where indicationDate = '",Rolling_Year_End,"'
                             and EvaluationDate = '",AsOfDate,"'
                             
  "))%>%
    filter(Region == state | Region == 'CW')
  return(losses)
} #working to create tabels on LDF tabs for CW, state, weighted

LDF_display <- function(data,SQL_table,Classes,state,Rolling_Year_End,AsOfDate,prefix) {
  AsOfDate <- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  data <- data%>%
    filter(TableName == SQL_table & Class == Classes & Region == state)%>%
    select(-IndicationDate,-EvaluationDate, -Class,-Region,-TableName)
  data_clean <- data[,colSums(is.na(data))<nrow(data)]
  if (SQL_table != 'Losses') {
    if (nrow(data_clean) < 1) {
      return(data.frame(matrix(nrow=1,ncol=1)))
    }
    data_clean$add <- NA
    data_clean <- data_clean
  }
  save_new_rows <- c('')
  for (i in 2:length(data_clean$Years)) {save_new_rows <- c(save_new_rows,paste0(save_new_rows[i-1]," "))}
  row.names(data_clean) <- save_new_rows
  colnames(data_clean) <- column_names(data_clean,SQL_table,Rolling_Year_End,AsOfDate)
  if (SQL_table == 'Averages') {
    stored_selections <- dbGetQuery(con,paste0(
      "		select max(LDF1select),max(LDF2select),max(LDF3select),max(LDF4select),max(LDF5select),max(LDF6select),max(LDF7select),max(LDF8select),max(LDF9select)
	from [actuarialsandbox].[ho].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1select,LDF2select ,LDF3select,LDF4select,LDF5select,LDF6select,LDF7select,LDF8select,LDF9select)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
    ))
    stored_selections <- na.omit(stored_selections)
    if (nrow(stored_selections)>=1) {
      stored <- c()
      custom <- c('Custom')
      
      if (length(data_clean) < 11) {
        for (i in 1:(length(data_clean)-2)) {
          stored_value <- max(data_clean[data_clean[i+1] == as.numeric(stored_selections[i]),][[1]],na.rm=T)
          stored <- c(stored,ifelse(is.na(stored_value),'Custom',stored_value))
          custom <- c(custom, ifelse(is.na(stored_value),as.numeric(stored_selections[i]),1))
        }
      } else {
        for (i in 1:length(stored_selections)) {
          stored_value <- max(data_clean[data_clean[i+1] == as.numeric(stored_selections[i]),][[1]],na.rm=T)
          stored <- c(stored,ifelse(is.na(stored_value),'Custom',stored_value))
          custom <- c(custom, ifelse(is.na(stored_value),as.numeric(stored_selections[i]),1))
        }
      }
    } else {
      stored <- c('Averages')
      custom <- c('Custom',rep(1,length(data_clean)-2))
    }
    data_clean[nrow(data_clean)+1,] <- c(custom,NA)  
    data_clean[nrow(data_clean)+1,] <- selections_function(prefix,length(data_clean)-1,stored) 
  }
  return(data_clean)
}

LDF_display_averages <- function(cwData,stateData, indicator) {
  if (indicator > 0) {
    out <- stateData
  } else {
    out <- cwData
  }
  send <- data.frame(head(out,-1))%>%mutate(across(2:length(out),as.numeric))
  return(send)
}

LDF_Cumulative <- function(averagesDF,choices,dummy) {#in progress > interactive elements to make LDF selections
  selections <- c()
  for (col in 1:(length(averagesDF)-2)) {
    selections <- c(selections,as.numeric(averagesDF[averagesDF[1]==choices[col],][col+1]))
  }
  df <- data.frame(
    NAME = c('Selection','Cumulative'),
    OUTPUT1 = ifelse(c(is.na(selections[1]),is.na(selections[1])),c(NA,NA),c(selections[1],prod(selections[1:9],na.rm=T))),
    OUTPUT2 = ifelse(c(is.na(selections[2]),is.na(selections[2])),c(NA,NA),c(selections[2],prod(selections[2:9],na.rm=T))),
    OUTPUT3 = ifelse(c(is.na(selections[3]),is.na(selections[3])),c(NA,NA),c(selections[3],prod(selections[3:9],na.rm=T))),
    OUTPUT4 = ifelse(c(is.na(selections[4]),is.na(selections[4])),c(NA,NA),c(selections[4],prod(selections[4:9],na.rm=T))),
    OUTPUT5 = ifelse(c(is.na(selections[5]),is.na(selections[5])),c(NA,NA),c(selections[5],prod(selections[5:9],na.rm=T))),
    OUTPUT6 = ifelse(c(is.na(selections[6]),is.na(selections[6])),c(NA,NA),c(selections[6],prod(selections[6:9],na.rm=T))),
    OUTPUT7 = ifelse(c(is.na(selections[7]),is.na(selections[7])),c(NA,NA),c(selections[7],prod(selections[7:9],na.rm=T))),
    OUTPUT8 = ifelse(c(is.na(selections[8]),is.na(selections[8])),c(NA,NA),c(selections[8],prod(selections[8:9],na.rm=T))),
    OUTPUT9 = ifelse(c(is.na(selections[9]),is.na(selections[9])),c(NA,NA),c(selections[9],prod(selections[9:9],na.rm=T))),
    OUTPUT10 = c(NA,NA))
  row.names(df) <- c('',' ')
  colnames(df) <- c(' ',colnames(averagesDF)[-1])
  df_out <- df[!is.na(colnames(df))]
  return(df_out)
  
}
LDF_selections_choose <- function(data, data_weighted, weight) {
  if (weight == 0 | weight ==1) {
    return(data)
  } else {
    return(data_weighted)
  }
}
LDF_pull_selections <- function(Rolling_Year_End,AsOfDate,state,Classes) {
  #pull the most recent LDF selections
  df <- dbGetQuery(con,paste0("	
	select
	  'Cumulative' as Name,max(LDF1cumulative),max(LDF2cumulative),max(LDF3cumulative),max(LDF4cumulative),max(LDF5cumulative),max(LDF6cumulative),max(LDF7cumulative),max(LDF8cumulative),max(LDF9cumulative)
	from [actuarialsandbox].[ho].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1cumulative,LDF2cumulative ,LDF3cumulative,LDF4cumulative,LDF5cumulative,LDF6cumulative,LDF7cumulative,LDF8cumulative,LDF9cumulative)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
  ))
  df2 <- dbGetQuery(con,paste0("
	select
	  'Selection' as Name,max(LDF1select),max(LDF2select),max(LDF3select),max(LDF4select),max(LDF5select),max(LDF6select),max(LDF7select),max(LDF8select),max(LDF9select), NULL as x10
	from [actuarialsandbox].[ho].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1select,LDF2select,LDF3select,LDF4select,LDF5select,LDF6select,LDF7select,LDF8select,LDF9select)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"'
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published'
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end
	and currentRow = 1
	group by currentRow
      "
  ))
  df3 <- dbGetQuery(con,paste0("	
	select
	  'Cumulative' as Name,max(LDF1cumulativeFinal),max(LDF2cumulativeFinal),max(LDF3cumulativeFinal),max(LDF4cumulativeFinal),max(LDF5cumulativeFinal)
	from [actuarialsandbox].[ho].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1cumulativeFinal,LDF2cumulativeFinal ,LDF3cumulativeFinal,LDF4cumulativeFinal,LDF5cumulativeFinal)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
  ))
  df <- union_all(df2,df)
  df<-na.omit(df)
  if (nrow(df) > 0) {
    return(df)
  #} else if (nrow(df3)>0) {
  #  return(union_all(df3,df3))
  } else {
    return(data.frame(NAME = c('Selection','Cumulative'),x1=c(1,1),x2=c(1,1),x3=c(1,1),x4=c(1,1),x5=c(1,1),x6=c(1,1),x7=c(1,1),x8=c(1,1),x9=c(1,1),x10=c(NA,NA)))
  }
}

selections_function <- function(prefix,columns,order) {
  df <- data.frame(matrix(ncol = columns,nrow=1),stringsAsFactors = FALSE)
  names <- c('Name',toupper(letters[1:columns-1]))
  df[1][1] <- 'Choose'
  for (col in 2:length(df)) {
    string <- 'selected = "selected"'
    string_out <- list('Averages' =        list(string,'','','','',''),
                       'All Yr. Wtd Avg' = list('',string,'','','',''),
                       'Ex Hi/Low' =       list('','',string,'','',''),
                       '5 Yr. Wtd Avg' =   list('','','',string,'',''),
                       '3 Yr. Wtd Avg' =   list('','','','',string,''),
                       'Custom' =          list('','','','','',string))
    df[col][1]<- paste0('
                       <select id="',prefix,names[col],'select" class="form-control">
                       <option ',string_out[[order[col-1]]][[1]],' value="Averages">Averages</option>
                       <option ',string_out[[order[col-1]]][[2]],'value="All Yr. Wtd Avg">All Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[3]],'value="Ex Hi/Low">Ex Hi/Low</option>
                       <option ',string_out[[order[col-1]]][[4]],'value="5 Yr. Wtd Avg">5 Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[5]],'value="3 Yr. Wtd Avg">3 Yr. Wtd Avg</option>
                       <option ',string_out[[order[col-1]]][[6]],'value="Custom">Custom</option>
                    </select>
')
    removeUI(#remove the existing input elements in the session if the exist, allowing to make edits to different state without refreshing the page
      selector = paste0("#",prefix,names[col],"select")
    )
  }
  df$last <- NA
  return(df)
}


#Premium Trend
  #Premium On-Level Factors > absorb calculation into premium trend SP
  #Targit Data
premium_trend_data <- function(IndicationDate, EvaluationDate, State) {
  Evalutionadjust <- ifelse(as.Date(EvaluationDate)<as.Date('2022-06-01'),'2022-06-01', EvaluationDate)
  df <- dbGetQuery(con,paste0("SET NOCOUNT ON
        DECLARE @T Table (Date  varchar(10),
        				  EHY decimal(16,6),
        				  EP decimal(16,6),
        				  AdjustedEP decimal(16,6))
        INSERT @T Exec  ActuarialSandbox.[ho].[sp_PremiumTrend] '",IndicationDate,"', '",Evalutionadjust,"','",State,"'
        Select * from @T")
                   )
  return(df)
}

premium_trend <- function(df) {
  df_out <- data.frame(matrix(ncol=6,nrow=1))
  colnames(df_out) <- c('Index', 'Date','Year Ending Quarter - X', 'Earned Exposures', 'Earned Premium', 'Adjusted Earned Premium') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(df)):1) {
    #print(paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])))
    df_out <- df_out%>%
      add_row(Index = row,
              Date = as.Date(df[["Date"]][row]),
              `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(df[["Date"]][row])),' - ', year( as.Date(df[["Date"]][row]))),  #paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])),
              `Earned Exposures`=sum(df[['EHY']][max((row-3),0):row]),
              `Earned Premium`=sum(df[['EP']][max((row-3),0):row]),
              `Adjusted Earned Premium`=sum(df[['AdjustedEP']][max((row-3),0):row]))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(`Average Earned Premium at CRL` = `Adjusted Earned Premium`/`Earned Exposures`)%>%
    arrange(Index)%>%
    select (-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
}

logest <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  exp(coef(result))
}

premium_trend_fitting <- function(data,lagtime){
  df <- data%>%
    mutate(day_num = as.numeric(lubridate::ceiling_date(as.Date(Date),'month')-1)/365)%>%
    select(day_num,`Average Earned Premium at CRL`)
  df_out <- data.frame(matrix(ncol = 2,nrow=1))
  colnames(df_out) <- c('Exponential Trend','Pure Premium')
  fill_range <- c(24,20,16,12,8,6,4)
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                `Pure Premium`=logest(df[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],df[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#Loss Trend 
loss_trend_data <- function(program,IndicationDate,EvaluationDate) {
  df <- dbGetQuery(con, paste0(
    "SELECT *
  FROM [ActuarialSandbox].[",program,"].[LossTrend]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
    "
  ))%>%arrange(state,Accident_Year, Accident_Year_Quarter)
}

loss_trend_cw <- function(data) {
  df <- data %>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index','Year','Quarter', 'Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(df)):4) {
    #print(paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])))
    df_out <- df_out%>%
      add_row(Index=row,
              Year = df[["Accident_Year"]][row],
              Quarter = df[["Accident_Year_Quarter"]][row],
              `Year Ending Quarter - X` = paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])),
              `Earned Exposures`=sum(df[['Earned Exposures']][(row-3):row]),
              `Capped Incurred Loss & LAE`=sum(df[['Capped Incurred Loss & LAE']][(row-3):row]),
              `Incurred Claims`=sum(df[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(df$Accident_Year_Quarter[row]),' - ',as.character(df$AccidentYear[row])))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(Frequency = `Incurred Claims`/`Earned Exposures`*100,
           Severity = `Capped Incurred Loss & LAE`/`Incurred Claims`)%>%
    mutate(`Pure Premium` =Frequency*Severity/100)%>%
    arrange(Index)%>%
    select(-Index)
  
  data_clean <- na.omit(df_out)
  return(data_clean)
}

loss_trend_state <- function(data,input_state) {
  df <- data %>%
    filter(state == input_state)%>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index', 'Year','Quarter','Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  for (row in (nrow(df)):4) {
    #print(paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])))
    df_out <- df_out%>%
      add_row(Index=row,
              Year = df[["Accident_Year"]][row],
              Quarter = df[["Accident_Year_Quarter"]][row],
              `Year Ending Quarter - X`=paste0('Qrt',as.character(df[["Accident_Year_Quarter"]][row]),' - ',as.character(df[["Accident_Year"]][row])),
              `Earned Exposures`=sum(df[['Earned Exposures']][(row-3):row]),
              `Capped Incurred Loss & LAE`=sum(df[['Capped Incurred Loss & LAE']][(row-3):row]),
              `Incurred Claims`=sum(df[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(df$Accident_Year_Quarter[row]),' - ',as.character(df$AccidentYear[row])))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(Frequency = `Incurred Claims`/`Earned Exposures`*100,
           Severity = `Capped Incurred Loss & LAE`/`Incurred Claims`)%>%
    mutate(`Pure Premium` =Frequency*Severity/100)%>%
    arrange(Index)%>%
    select(-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
  
}


loss_trend_fitting <- function(data,lagtime) {
  df <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365,0))%>%
    select(day_num,Frequency, Severity, `Pure Premium`)
  df_out <- data.frame(matrix(ncol = 4,nrow=1))
  colnames(df_out) <- c('Exponential Trend', 'Frequency','Severity','Pure Premium')
  fill_range <- c(24,20,16,12,8,6,4,2)
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                Frequency=logest(df[['Frequency']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],df[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1, #select the right rows accounting for lag time
                Severity=logest(df[['Severity']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],df[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1,
                `Pure Premium`=logest(df[['Pure Premium']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],df[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#LLL 

LLL_data <- function(Tablename, IndicationDate, EvaluationDate,proposedEffective, state, current, proj,capped) {
  IndicationDate <- as.Date(IndicationDate)
  EvaluationDate <- as.Date(EvaluationDate)
  proposedEffective <- as.Date(proposedEffective)
  period <- round(((as.numeric(as.Date(proposedEffective))+365.25) - (as.numeric(as.Date(IndicationDate))-(365.25/2)))/365.25,2)
  df <- dbGetQuery(con,paste0("
          Set NOCOUNT ON
          Declare @T Table (peril varchar(50),
          				  Loss_Rolling_Year varchar(10),
          				  TrendedIncurred decimal(16,6),
          				  [Number of Excess Claims] decimal(16,6),
          				  [Ground Up Excess Losses] decimal(16,6),
          				  [Loss Excess of Cap] decimal(16,6),
          				  [Non-Excess Losses] decimal(16,6),
          				  [Excess Ratio] decimal(16,6))
          Insert @T Exec ActuarialSandbox.",Tablename,".[sp_LLL] '",IndicationDate,"','",EvaluationDate,"', '",state,"',",coalesce(current,0),",",coalesce(proj,0),",",coalesce(period,0),",",coalesce(capped,0),"
          Select * from @T
          "))
  colnames(df)[2] <- ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))) ,'/', as.character(day(IndicationDate %m-% days(1)))))
  colnames(df)[3] <- paste0('Incurred Losses Trended to ', year(IndicationDate %m-% months(1)))
  return(df)
}

LLL_select_data <- function(data,peril_choose) {
  df <- data %>%
    filter(peril == peril_choose)%>%
    select(-peril)
    df[nrow(df)+1,] <-c('Total',sum(df[2]),sum(df[3]),sum(df[4]),sum(df[5]),sum(df[6]),sum(df[5])/sum(df[6])) #add totals row here
 return(df)
}

LLL_selections <- function(data,name) {#function that outputs df with the calculated Large Loss Load, and defaults the selected to the calculated
  out <- data.frame()
  out[name,'Large Loss Load']<- 1+as.numeric(data[data[1]== 'Total',]$`Excess Ratio`)
  return(out)
}
#expense exhibit

LLL_weighted <- function(cw_data, state_data, weight){
  out <- data.frame()
  out['Selected','Weighted LLL'] <-coalesce(as.numeric(cw_data['Selected','Large Loss Load']) * (1-weight) + coalesce(as.numeric(state_data['Selected','Large Loss Load']),1) * weight,1)
  return(out)
}

profit <- function(state, IndicationDate,Program) {
  df <- dbGetQuery(con, paste0(
    "select [profitLoad]
        from [ActuarialSandbox].[",Program,"].[profitContingency]
        where State = '",state,"'
        and '",IndicationDate,"' between rowStartDate and rowEndDate
        "
  ))
  if (nrow(df)<1) {
    df[1,1] <- 0.05 #do not have profit target stored for all states yet
  }
  return(df)
}
reinsurance <- function(state, EvaluationDate,Program,peril) {
  df <- dbGetQuery(con, paste0(
    "select [Premium Rate Current]
        from [ActuarialSandbox].[",Program,"].[CostOfReinsurance]
        where State = '",state,"'
        and '",EvaluationDate,"' between rowStartDate and rowEndDate
        and peril = '",peril,"'
        "
  ))
  return(df)
}

expense_load <- function(IndicationDate, EvaluationDate, state,Program) {
  df <- dbGetQuery(con,paste0(
    "DECLARE @IndicationDate varchar(10) = '",IndicationDate,"'
      DECLARE @IndicationYear varchar(4) = year(@IndicationDate)
      SELECT 
        Year
        ,[Written Premium]/1000 as [Written Premium]
        ,[Earned Premium]/1000 as [Earned Premium]
        ,[Commission]/1000 as [Commission]
        ,[Other Acquisition]/1000 as [Other Acquisition]
        ,[General Expenses]/1000 as [General Expenses]
        ,[Taxes Licenses & Fees]/1000 as [Taxes Licenses & Fees]
    FROM [ActuarialSandbox].[",Program,"].[ExpenseIEE]
    where Year between @IndicationYear-3 and @IndicationYear-1"
  ))%>%
    arrange(Year)

  df_transpose <- function(df) {
    df <- sjmisc::rotate_df(df)
    colnames(df) <- as.character(unlist(df[1,]))
    df[-1,]
  }
  df_out <- df_transpose(df)
  save_names <- colnames(df_out)
  colnames(df_out) <- c('year3','year2','year1')
  
  df_next <- df_out%>%
    mutate(year3per=NA,year2per=NA,year1per=NA, average=NA, selected=NA)
  
  df_next['Commission','year3per']<- as.numeric(df_next['Commission','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Commission','year2per']<- as.numeric(df_next['Commission','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Commission','year1per']<- as.numeric(df_next['Commission','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['Other Acquisition','year3per']<- as.numeric(df_next['Other Acquisition','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Other Acquisition','year2per']<- as.numeric(df_next['Other Acquisition','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Other Acquisition','year1per']<- as.numeric(df_next['Other Acquisition','year1'])/as.numeric(df_next['Written Premium','year1'])
  df_next['General Expenses','year3per']<- as.numeric(df_next['General Expenses','year3'])/as.numeric(df_next['Earned Premium','year3'])
  df_next['General Expenses','year2per']<- as.numeric(df_next['General Expenses','year2'])/as.numeric(df_next['Earned Premium','year2'])
  df_next['General Expenses','year1per']<- as.numeric(df_next['General Expenses','year1'])/as.numeric(df_next['Earned Premium','year1'])
  df_next['Taxes Licenses & Fees','year3per']<- as.numeric(df_next['Taxes Licenses & Fees','year3'])/as.numeric(df_next['Written Premium','year3'])
  df_next['Taxes Licenses & Fees','year2per']<- as.numeric(df_next['Taxes Licenses & Fees','year2'])/as.numeric(df_next['Written Premium','year2'])
  df_next['Taxes Licenses & Fees','year1per']<- as.numeric(df_next['Taxes Licenses & Fees','year1'])/as.numeric(df_next['Written Premium','year1'])
  
  df_next['Commission','average']<- (as.numeric(df_next['Commission','year1'])+
                                       as.numeric(df_next['Commission','year2'])+
                                       as.numeric(df_next['Commission','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['Other Acquisition','average']<- (as.numeric(df_next['Other Acquisition','year1'])+
                                              as.numeric(df_next['Other Acquisition','year2'])+
                                              as.numeric(df_next['Other Acquisition','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next['General Expenses','average']<- (as.numeric(df_next['General Expenses','year1'])+
                                             as.numeric(df_next['General Expenses','year2'])+
                                             as.numeric(df_next['General Expenses','year3']))/sum(as.numeric(df_next['Earned Premium',]),na.rm=T)
  df_next['Taxes Licenses & Fees','average']<- (as.numeric(df_next['Taxes Licenses & Fees','year1'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year2'])+
                                                  as.numeric(df_next['Taxes Licenses & Fees','year3']))/sum(as.numeric(df_next['Written Premium',]),na.rm=T)
  df_next$selected <- df_next$average
  df_table <- df_next[c('year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  df_table['','selected']<- NA
  df_table['Reinsurance Provision', 'selected'] <- reinsurance(state,EvaluationDate,Program,'All Perils')
  df_table[' ','selected']<- NA
  df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected'] <- df_next['Commission','selected']+
    df_next['Other Acquisition','selected']+
    df_next['General Expenses','selected']+
    df_next['Taxes Licenses & Fees','selected']+
    df_table['Reinsurance Provision', 'selected']
  df_table['  ','selected']<- NA
  df_table['Profit Load','selected'] <- profit(state,IndicationDate,Program)
  df_table['Total Expenses & Profit = (8) + (9)', 'selected'] <- df_table['Total Expenses = (3) + (4) + (5) + (6) + (7)','selected']+df_table['Profit Load','selected']
  df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected'] <- 1-df_table['Total Expenses & Profit = (8) + (9)', 'selected']
  df_table['Fixed Expense Ratio = (4) + (5)','selected'] <- df_next['Other Acquisition','selected']+df_next['General Expenses','selected']
  df_table['   ','selected']<- NA
  df_table['Permissible Loss, LAE, & Fixed Expense Ratio = (11) + (12)','selected'] <- df_table['Fixed Expense Ratio = (4) + (5)','selected']+df_table['Permissible Loss & LAE Ratio = [100% - (10)]','selected']
  
  df_table$names <- rownames(df_table)
  df_table$ids <- c('(1)','(2)','(3)','(4)','(5)','(6)','','(7)','','(8)','','(9)','(10)','(11)','(12)','','(13)')
  df_table <- df_table[c('ids','names','year3', 'year3per','year2','year2per', 'year1', 'year1per','average','selected')]
  
  colnames(df_table)<-c('','',save_names[1],'',save_names[2],'',save_names[3],'','3 Yr Average', 'Selected')
  return(df_table)
}
#reinsurance table
  #add to Sandbox

#indication
  #parts of all previous tabs as inputs
  #by peril tabs 
on_level_factors_load <- function(Program,IndicationDate, State) {
    df <- dbGetQuery(con,paste0("
  select * from ActuarialSandbox.",Program,".onLevelFactors
  where IndicationDate = '",IndicationDate,"' and state = '",State,"'
  "))%>%
      mutate(CalenderYear = as.character(CalenderYear))
  return(df)
}

coverage_report_load <- function(IndicationDate, EvaluationDate, State,Tablename) {
  df <- dbGetQuery(con, paste0("
      select RollingYear, ReratedEP ,ptsEHY, policyCharge , Peril,CappedTotalIncurred, claimCount from ActuarialSandbox.",Tablename,".coveragereport
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and state = '",State,"'
                               "))
  return(df)
}

targit_EP_load <- function(IndicationDate, EvaluationDate, State){
  df <- dbGetQuery(con, paste0("
  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  EP decimal(16,6))
  Insert @T Exec ActuarialSandbox.ho.[sp_IndicationEP] '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T
  "
  ))
  return(df)
}

rate_level_losses <- function (IndicationDate,EvaluationDate,State) {
  df <- dbGetQuery(con,paste0(
    "  set NOCOUNT ON
  Declare @T Table (
  				  Year varchar(4),
  				  [Capped Incurred Loss & LAE] decimal(16,6),
  				  [Incurred Claims] int)
  Insert @T Exec ActuarialSandbox.[ho].[sp_IndicationLossSummary] '",IndicationDate,"','",EvaluationDate,"','",State,"'
  Select * from @T"
  ))
  
  return(df)
}

rate_level_indication <- function(on_level, coverageReport, targitPrem, Policyfee, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect) {
  IndicationDate <- as.Date(IndicationDate)
  df <- on_level
  #if we include policy fee then use the pts EP with the policyCharge
  if (Policyfee == 'Y' & perilTab == 'All Perils') {
    df <- df%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP + policyCharge)%>%
      select(CalenderYear,EP, OnLevelFactor)
  } 
  else if (Policyfee == 'N' & perilTab == 'All Perils') { #otherwise use the EP stored in Targit for total tab
    df <- df%>%
      left_join(targitPrem, by = c('CalenderYear' = 'Year'))%>%
      select(CalenderYear,EP, OnLevelFactor)
  } else { #use rerated EP for each of the perils
    df <- df%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP)%>%
      select (-ReratedEP , -policyCharge, -Peril)%>%
      select(CalenderYear,EP, OnLevelFactor)
  }
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  df <- df %>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(df$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(TrendedPremium = EP * OnLevelFactor * PremTrend)
  
  #add in the Capped Incurred Losses
  losses <- rate_level_losses(IndicationDate, EvaluationDate, state)%>%
    mutate(Year = as.character(Year))
  
  losses2 <- coverageReport%>%
    filter(Peril==perilTab)%>%
    mutate(`Capped Incurred Loss & LAE` = CappedTotalIncurred)%>%
    select(RollingYear, `Capped Incurred Loss & LAE`)
  
  df <- df%>%
    #left_join(losses, by = c('CalenderYear' = 'Year'))%>%
    #select(-`Incurred Claims`)%>%
    left_join(losses2, by = c('CalenderYear' = 'RollingYear'))%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(`Capped Incurred Loss & LAE`),0,`Capped Incurred Loss & LAE`))
  
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  colnames(LDFselect)[1:6] <- c('Name', IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)
  LDFselect <- LDFselect[LDFselect$Name == 'Cumulative',][1:6]%>%
    pivot_longer(!Name, names_to = 'Year', values_to = 'LDF')%>%
    select(-Name)
  
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  df <- df %>%
    left_join(LDFselect, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(df$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL)%>%
    mutate(LAERatio = AdjustedLosses/TrendedPremium)
  df <- df%>% 
    add_row(CalenderYear = 'Total',
            EP = sum(df$EP),
            OnLevelFactor = NA,
            PremTrend = NA,
            TrendedPremium = sum(df$TrendedPremium,na.rm=T),
            `Capped Incurred Loss & LAE` = sum(df$`Capped Incurred Loss & LAE`,na.rm=T),
            LDF = NA,
            LossTrend = NA,
            LLL = NA,
            AdjustedLosses = sum(df$AdjustedLosses,na.rm=T),
            LAERatio = sum(df$AdjustedLosses,na.rm=T)/sum(df$TrendedPremium,na.rm=T))

  #df$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(df$CalenderYear)-1) ,df$CalenderYear) 
  colnames(df) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Earned Premium', 'On-Level Factor', 'Premium Trend', 'Trended On-Level Premium', 'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', 'Projected Loss & LAE Ratio (ex Cat)')

  return(df)
}

rate_level_summary<- function(rate_df, cat_df,expense_ratios,rate_level_losses,projPrem, projLoss,sts_adj,hu_adj) {
  out <- data.frame(matrix(ncol = 2,nrow = 0))
  colnames(out) <- c('',' ')
  out['(11)',] <- c('Projected Hurricane Loss & LAE Ratio',cat_df$`Modeled Hurricane Loss & LAE Ratio` * hu_adj)
  out['(12)',] <- c('Projected Wind/Hail Loss & LAE Ratio',cat_df$`Modeled CS Loss & LAE Ratio` * sts_adj)
  out['(13)',] <- c('Projected Loss & LAE Ratio',rate_df[rate_df[1]=='Total',]$`Projected Loss & LAE Ratio (ex Cat)`+
                                                            cat_df$`Modeled Hurricane Loss & LAE Ratio`*hu_adj+
                                                            cat_df$`Modeled CS Loss & LAE Ratio`*sts_adj)
  out['(14)',] <- c('Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  out['(15)',] <- c('Projected Loss, LAE, & Fixed Expense Ratio',as.numeric(out['(14)',' '])+as.numeric(out['(13)', ' ']))
  out['(16)',] <- c('Permissible Loss, LAE, & Fixed Expense Ratio',as.numeric(out['(14)',' '])+(1-expense_ratios['Total Expenses & Profit','Selected']))
  out['(17)',] <- c('Raw Indicated Rate Level Change',as.numeric(out['(15)',' '])/as.numeric(out['(16)',' '])-1)
  out['(18)',] <- c('Credibility',min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1))
  out['(19)',] <- c('Compliment of Credibility',(1+projLoss)/(1+projPrem)-1)
  out['(20)',] <- c('Credibility-weighted Indicated Rate Level Change',as.numeric(out['(17)', ' '])*as.numeric(out['(18)',' '])+as.numeric(out['(19)',' '])*(1-as.numeric(out['(18)',' '])))

  return(out)
}

credibility_exhibit <- function(rate_level_losses) {
  df <- data.frame(matrix(ncol=3,nrow=0))
  df[1,] <- c(format(sum(round(rate_level_losses$`Incurred Claims`),0),big.mark = ','),format(round(1082,0),big.mark = ','),paste0(format(round(100*min((sum(rate_level_losses$`Incurred Claims`)/1082)^0.5,1),0)),'%'))
  colnames(df) <- c('Earned Exposures','Full Credibility Standard', 'Credibility')
  return(df)
}

on_level_cumulative <- function(IndicationDate,Program,State) {
  df <- dbGetQuery(con, paste0(
    "select EffectiveDate as [Eff. Date Renewal], RateChange as [Rate Change], Cumulative
    from ActuarialSandbox.",Program,".cumulativeRateChanges
    where IndicationDate = '",IndicationDate,"'
    and state = '",State,"'
    "
  ))
  return(df)
}

rate_level_indication_peril <- function(on_level, proposedEffectiveDate,IndicationDate,EvaluationDate,state,LDFselect ,currentLoss, projLoss, LLLselect,coverageReport,peril) {
  IndicationDate <- as.Date(IndicationDate)
  df <- on_level%>%
    select(CalenderYear)
  #if we include policy fee then use the pts EP with the policyCharge
  #add in the Capped Incurred Losses
  losses <- coverageReport%>%
    filter(Peril == peril)%>%
    select(RollingYear, CappedTotalIncurred, claimCount)%>%
    mutate(RollingYear = as.character(RollingYear))
  df <- df%>%
    left_join(losses, by = c('CalenderYear' = 'RollingYear'))%>%
    mutate(`Capped Incurred Loss & LAE` = ifelse(is.na(CappedTotalIncurred),0,CappedTotalIncurred))
  
  IndicationYear <- year(ymd(IndicationDate) - days(1))
  colnames(LDFselect)[1:6] <- c('Name', IndicationYear, IndicationYear-1,IndicationYear-2,IndicationYear-3,IndicationYear-4)
  LDFselect <- LDFselect[LDFselect$Name == 'Cumulative',][1:6]%>%
    pivot_longer(!Name, names_to = 'Year', values_to = 'LDF')%>%
    select(-Name)
  
  Loss_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  df <- df %>%
    left_join(LDFselect, by = c('CalenderYear' = 'Year'))%>%
    mutate(LossTrend = ((1+currentLoss)^(max(as.numeric(df$CalenderYear))-as.numeric(CalenderYear)))*(1+projLoss)^(Loss_trend_period))%>%
    mutate(LLL = LLLselect)%>%
    mutate(AdjustedLosses = `Capped Incurred Loss & LAE` * LDF * LossTrend * LLL,claimCount = ifelse(is.na(claimCount),0,claimCount))%>%
    select(CalenderYear, `Capped Incurred Loss & LAE`, LDF,LossTrend, LLL,AdjustedLosses,claimCount)
  
  
  colnames(df) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Capped Incurred Loss & LAE (ex Cat)',
                    'Loss Dev Factor', 'Loss Trend', 'Large Loss Load', 'Adjusted Ultimate Loss & LAE', '# of Claims')
 
  return(df)
}

rate_level_indication_prem_peril <- function(on_level, coverageReport, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,EvaluationDate,state,byperil) {
  IndicationDate <- as.Date(IndicationDate)
  df <- on_level
  df <- df%>%
      left_join(coverageReport, by = c('CalenderYear' = 'RollingYear'))%>%
      filter(Peril == perilTab)%>%
      mutate(EP = ReratedEP,EHY = ptsEHY)%>%
      select(CalenderYear,EP, OnLevelFactor,EHY)
  
  premium_trend_period <- round(((as.numeric(as.Date(proposedEffectiveDate))+365.25/2)-(as.numeric(as.Date(IndicationDate))-365.25/2))/365.25,2)
  df <- df %>%
    mutate(PremTrend = ((1+currentPrem)^(max(as.numeric(df$CalenderYear))-as.numeric(CalenderYear)))*(1+projPrem)^(premium_trend_period))%>%
    mutate(OnLevelFactor = ifelse(byperil == 'Y',1,OnLevelFactor))%>%
    mutate(spacer = NA,TrendedPremium = EP * OnLevelFactor * PremTrend)%>%
    select(CalenderYear,EP, OnLevelFactor,PremTrend,spacer,TrendedPremium,EHY)
  
  
  
  #df$CalenderYear <- ifelse(year(IndicationDate)!=year(IndicationDate %m-% days(1)), as.character(as.numeric(df$CalenderYear)-1) ,df$CalenderYear) 
  colnames(df) <- c(ifelse(month(IndicationDate %m-% months(1))==12,'Accident Year',
                           paste0('Rolling Year Ending In ' , as.character(month(IndicationDate %m-% months(1))),'/' , as.character(day(IndicationDate %m-% days(1))))),
                    'Rerated Premium', 'On-Level Factor', 'Premium Trend','                ' ,'Trended On-Level Premium', 'Earned House Years')
  
  return(df)
}

by_peril_indication_summary <- function(state, EvaluationDate, Program,losses, prem,expense_ratios) {
  df <- data.frame(matrix(ncol=3, nrow=0))
  df[1,] <- c('(14)', 'Projected Loss & LAE Ratio', sum(losses$`Adjusted Ultimate Loss & LAE`)/sum(prem$`Trended On-Level Premium`))
  df[2,] <- c('(15)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  df[3,] <- c('(16)','Projected Loss, LAE & Fixed Expense Ratio',as.numeric(df[1,3])+as.numeric(df[2,3]))
  df[4,] <- c('(17)','Permissible Loss, LAE & Fixed Expense Ratio',as.numeric(df[2,3])+(1-expense_ratios['Total Expenses & Profit','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils'))
  df[5,] <- NA
  df[6,] <- c('(18)','Raw Indicated Rate Level Change',as.numeric(df[3,3])/as.numeric(df[4,3])-1)
  df[7,] <- c('(19)', 'Claim Count', sum(losses$`# of Claims`))
  df[8,] <- c('(20)','Credibility', min((as.numeric(df[7,3])/1082)^.5,1))
  df[9,] <- NA
  df[10,]<- c('(21)','Compliment of Credibility',0)
  df[11,]<- c('(22)','Credibility-weighted Indicated Rate Level Change', as.numeric(df[6,3])*as.numeric(df[8,3])+(1-as.numeric(df[8,3]))*as.numeric(df[10,3]))
  
  return(df)
}
cat_peril_table <- function(peril,inforce,experienceAdj){
  if (peril == 'Hurricane') {
    df <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level` = `Hurricane In Force Premium @ CRL`, `Peril Modeled Gross AAL` = `Hurricane Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else if (peril == 'STS') {
    df <- inforce%>%
      mutate(`CAT Peril` = peril,`Inforce Premium @ Current Rate Level`=`STS In Force Premium @ CRL`, `Peril Modeled Gross AAL`=`Convective Storm Gross AAL`)%>%
      select(`CAT Peril`,`Inforce Premium @ Current Rate Level`, `Peril Modeled Gross AAL`,`CAT LAE Load`)
  } else {
    break
  }
  df <- df%>%
    mutate(`Modeled Loss & LAE Ratio`=`Peril Modeled Gross AAL`*`CAT LAE Load`/`Inforce Premium @ Current Rate Level`,
           `Experience Adjustment Factor` = experienceAdj)%>%
    mutate(`Selected Loss & LAE Ratio` = `Experience Adjustment Factor` * `Modeled Loss & LAE Ratio`)
  
  return(df)
  
}
cat_peril_summary <- function(state,EvaluationDate,Program,catTable, expense_ratios,peril,experience_adj,experience_years,modeled_cat){
  df <- data.frame(matrix(ncol=3, nrow=0))
  df[1,] <- c('(8)','Fixed Expense Ratio',expense_ratios['Fixed Expense Ratio =','Selected'])
  df[2,] <- c('(9)','Selected Loss, LAE & Fixed Expense Ratio', as.numeric(df[1,3]) + catTable$`Selected Loss & LAE Ratio`)
  df[3,] <- c('(10','Permissible Loss & LAE Ratio',(expense_ratios['Permissible Loss, LAE, & Fixed Expense Ratio','Selected'])+reinsurance(state,EvaluationDate,Program,'All Perils') - 
   modeled_cat$`In Force Premium @ Current Level` * reinsurance(state,EvaluationDate,Program,peril) / modeled_cat[[paste(peril,'In Force Premium @ CRL',sep=' ')]]
   )#peril cost of reinsurance
  df[4,] <- NA
  df[5,] <- c('(11)', 'Raw Indicated Rate Level Change', as.numeric(df[2,3])/as.numeric(df[3,3])-1)
  df[6,] <- NA
  df[7,] <- c('(12)','Credibility',ifelse(experience_adj ==1, 1, experience_years/20))
  df[8,] <- NA
  df[9,] <- c('(13)','Compliment of Credibility',0)
  df[10,]<- c('(14)','STS Credibility-weighted Indicated Rate Level Change',as.numeric(df[5,3])*as.numeric(df[7,3])+(1-as.numeric(df[7,3]))*as.numeric(df[9,3]))
  
  return(df)
}

non_peril_pull <- function(IndicationDate, EvaluationDate, state) {
  df <- dbGetQuery(con, paste0(
    "
    select nonPerilPremium
    from ActuarialSandbox.ho.nonPerilPremium
    where IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and state = '",state,"'
    "
  ))
  return(as.numeric(df))
}

indication_memo <- function(total, fire, water, theft, liability, otherAOP, NCW, STS, HU,coverageReport,nonperil) {
  df <- data.frame(matrix(ncol = 5, nrow = 0))
  df[1,] <- c('Fire','Fire',fire[3,3],fire[8,3],fire[11,3])
  df[2,] <- c('Water','Water',water[3,3],water[8,3],water[11,3])
  df[3,] <- c('TheftVMM','Theft & VMM',theft[3,3],theft[8,3],theft[11,3])
  df[4,] <- c('Liability','Liability',liability[3,3],liability[8,3],liability[11,3])
  df[5,] <- c('OtherAOP','All Other Perils',otherAOP[3,3],otherAOP[8,3],otherAOP[11,3])
  df[6,] <- c('NCW','Non-Cat Weather',NCW[3,3],NCW[8,3],NCW[11,3])
  df[7,] <- c('STS','STS',STS[2,3],STS[7,3],STS[10,3])
  df[8,] <- c('Hurricane','Hurricane',HU[2,3],HU[7,3],HU[10,3])
  colnames(df) <- c('joiner','Peril','LAE','Cred','RateChange')
  coverageReport_clean <- coverageReport%>%
    group_by(Peril)%>%
    summarise(Prem = sum(ReratedEP))
  df_out <- df%>%
    left_join(coverageReport_clean, by = c('joiner'='Peril'))%>%
    select(-joiner)
  sumprod <- df_out%>%
    group_by()%>%
    summarise(sumProduct = sum(as.numeric(RateChange)*as.numeric(Prem),na.rm=T))
  df_out[9,] <- c('Total', total[5,2],total[8,2],total[10,2],(1-nonperil)*(1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1)
  sumProd_adj <- (1+(as.numeric(sumprod)/sum(as.numeric(df_out$Prem),na.rm=T)))-1
  cred_adj <- ((1+as.numeric(total[10,2]))-nonperil)/(1-nonperil)-1
  df_final <- df_out%>%
    mutate(balanced = ifelse(Peril=='Total',NA,
                             (1+as.numeric(RateChange))*(1+cred_adj)/(1+sumProd_adj)-1))
  sumprodBalance <- df_final%>%
    group_by()%>%
    summarise(sum(as.numeric(Prem)*as.numeric(balanced),na.rm=T))
  df_final$balanced[9] <- (1-nonperil)*(1+(as.numeric(sumprodBalance)/sum(as.numeric(df_out$Prem),na.rm=T)))+nonperil-1
  df_final <- df_final%>%
    select(Peril, LAE,Cred,balanced)
  colnames(df_final) <- c('Peril', 'Projected Loss, LAE & Fixed Expense Ratio','Credibility','Balanced Credibility-weighted Indicated Rate Level Change')
  return(df_final)
}

memoToTables <- function(memo,peril){
  df <- memo[memo$Peril == peril,][4]
  df_out <- data.frame(matrix(ncol=3,nrow=0))
  df_out[1,]<- c(ifelse(peril == 'STS' | peril == 'Hurricane','(15)','(23)'),'Balanced Cred-weighted Indicated Rate Level Change', as.numeric(df))
  return(df_out)
}


reinsurance_exhibit <- function(State_Full, LOB_Full, HUreinsurance, STSreinsurance,CostOfReinsurance,modeled_cat) {
  df <- data.frame(matrix(ncol=5, nrow=0))
  colnames(df) <- c('Peril', paste('Inforce Premium at CRL',State_Full,LOB_Full,sep=' '),'Premium Rated Cost of Reinsurance Margin', 'Net Cost of Reinsurance','Cost of Reinsurance')
  df[3,] <- c('Hurricane',format(round(modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
                       paste0(format(round(HUreinsurance*100,1),nsmall=1),'%'),
                       format(round(modeled_cat$`In Force Premium @ Current Level` * HUreinsurance,0),big.mark = ','),
                       modeled_cat$`In Force Premium @ Current Level` * HUreinsurance / modeled_cat[[paste('Hurricane','In Force Premium @ CRL',sep=' ')]]
  )
  df[4,] <- c('STS',format(round(modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]],0),big.mark = ','),
                       paste0(format(round(STSreinsurance*100,1),nsmall=1),'%'),
                       format(round(modeled_cat$`In Force Premium @ Current Level` * STSreinsurance,0),big.mark = ','),
                       modeled_cat$`In Force Premium @ Current Level` * STSreinsurance / modeled_cat[[paste('STS','In Force Premium @ CRL',sep=' ')]]
  )
  df[5,] <- c('Total',format(round(modeled_cat$`In Force Premium @ Current Level`,0),big.mark = ','),
                       paste0(format(round(CostOfReinsurance*100,1),nsmall=1),'%'),
                       format(round(modeled_cat$`In Force Premium @ Current Level` * CostOfReinsurance,0),big.mark = ','),
                       CostOfReinsurance)
  df <- na.omit(df)
  return(df)
}

#pull selections based on variable name
pull_variable <- function(Program,IndicationDate,EvaluationDate,state,Classes,variable_name,default) {
  df <- dbGetQuery(con,paste0("	
	select
	columnValue,status
	from [actuarialsandbox].[",Program,"].[indicationSelections]
	where IndicationDate = '",IndicationDate,"' 
	and EvaluationDate = '",EvaluationDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	and columnName = '",variable_name,"'
      "
  ))
  df <- df%>%
    filter(status == ifelse('Published' %in% df$status,'Published',
                            ifelse('In Review' %in% df$staus, 'In Review', 'In Progress')))%>%
    select(-status)
  
  if (variable_name == 'catLoadSelection') {
    if (nrow(df)>0) {
      catLoad <- as.data.frame(df)
    } else {
      catLoad <- as.data.frame(default)
    }
    row.names(catLoad) <- c('Selected Expense Load')
    return(catLoad)
  }
  if (nrow(df)>0) {
    if (variable_name == 'catExclude' & nchar(df) >=4 ) {
      string <- as.character(round(as.numeric(df),0))
      out <- sapply(seq(from=1, to=nchar(string), by=4), function(i) substr(string, i, i+3))
      return(out)
    } else {
      return(as.numeric(df))
    }
  } else {
    return(default)
  }
}

#save 
save_selections <- function(IndicationDate,EvaluationDate, Region,Class,Status,LDFselections,LDFfinal,selected_by,reviewed_by){

  find_vector <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][2:(length(LDFselections[LDFselections[1] == 'Selection',])-1)])
  cumulative <-as.numeric(LDFselections[LDFselections[1] == 'Cumulative',][2:(length(LDFselections[LDFselections[1] == 'Cumulative',])-1)])
  if (length(LDFselections)<10) {
    selections <- c(find_vector,rep(1,10-length(find_vector)))
    cumulative <- c(cumulative,rep(1,10-length(cumulative)))
  } else {
    selections <- find_vector
  }
  
  if (Region == 'CW') {
    cw_condition <- " "
    cw_fill<-" "
  } else {
    finalselected <-   as.numeric(LDFfinal[LDFfinal[1] == 'Selection',][2:(length(LDFfinal[LDFfinal[1] == 'Selection',])-1)])
    finalcumulative <- as.numeric(LDFfinal[LDFfinal[1] == 'Cumulative',][2:(length(LDFfinal[LDFfinal[1] == 'Cumulative',])-1)])

    cw_condition<-paste0("
    cast(",finalselected[1]," as nvarchar(50)) as LDF1selectFinal,
    cast(",finalselected[2]," as nvarchar(50)) as LDF2selectFinal,
    cast(",finalselected[3]," as nvarchar(50)) as LDF3selectFinal,
    cast(",finalselected[4]," as nvarchar(50)) as LDF4selectFinal,
    cast(",finalselected[5]," as nvarchar(50)) as LDF5selectFinal,
    cast(",finalselected[6]," as nvarchar(50)) as LDF6selectFinal,
    cast(",finalselected[7]," as nvarchar(50)) as LDF7selectFinal,
    cast(",finalselected[8]," as nvarchar(50)) as LDF8selectFinal,
    cast(",finalselected[9]," as nvarchar(50)) as LDF9selectFinal,
    cast(",finalcumulative[1]," as nvarchar(50)) as LDF1cumulativeFinal,
    cast(",finalcumulative[2]," as nvarchar(50)) as LDF2cumulativeFinal,
    cast(",finalcumulative[3]," as nvarchar(50)) as LDF3cumulativeFinal,
    cast(",finalcumulative[4]," as nvarchar(50)) as LDF4cumulativeFinal,
    cast(",finalcumulative[5]," as nvarchar(50)) as LDF5cumulativeFinal,
    ")
    cw_fill<-",LDF1selectFinal,LDF2selectFinal,LDF3selectFinal,LDF4selectFinal,LDF5selectFinal,LDF6selectFinal,LDF7selectFinal,LDF8selectFinal,LDF9selectFinal,
		LDF1cumulativeFinal,LDF2cumulativeFinal,LDF3cumulativeFinal,LDF4cumulativeFinal,LDF5cumulativeFinal"
  }
  #selections <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][-1])
  print(selections)
  print(cumulative)
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
reviewed_by,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",reviewed_by," as reviewed_by,
cast(",selections[1]," as nvarchar(50)) as LDF1select,
cast(",selections[2]," as nvarchar(50)) as LDF2select,
cast(",selections[3]," as nvarchar(50)) as LDF3select,
cast(",selections[4]," as nvarchar(50)) as LDF4select,
cast(",selections[5]," as nvarchar(50)) as LDF5select,
cast(",selections[6]," as nvarchar(50)) as LDF6select,
cast(",selections[7]," as nvarchar(50)) as LDF7select,
cast(",selections[8]," as nvarchar(50)) as LDF8select,
cast(",selections[9]," as nvarchar(50)) as LDF9select,
cast(",cumulative[1]," as nvarchar(50)) as LDF1cumulative,
cast(",cumulative[2]," as nvarchar(50)) as LDF2cumulative,
cast(",cumulative[3]," as nvarchar(50)) as LDF3cumulative,
cast(",cumulative[4]," as nvarchar(50)) as LDF4cumulative,
cast(",cumulative[5]," as nvarchar(50)) as LDF5cumulative,
cast(",cumulative[6]," as nvarchar(50)) as LDF6cumulative,
cast(",cumulative[7]," as nvarchar(50)) as LDF7cumulative,
cast(",cumulative[8]," as nvarchar(50)) as LDF8cumulative,
cast(",cumulative[9]," as nvarchar(50)) as LDF9cumulative,
",cw_condition,"
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(LDF1select,LDF2select,LDF3select,LDF4select,LDF5select,LDF6select,LDF7select,LDF8select,LDF9select,
		LDF1cumulative,LDF2cumulative,LDF3cumulative,LDF4cumulative,LDF5cumulative,LDF6cumulative,LDF7cumulative,LDF8cumulative,LDF9cumulative ",cw_fill,")
	) as unpvt2

MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by 	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
}

save_selections_rest <- function(IndicationDate,EvaluationDate, Region,Class,Status,
                                 catLoadWeight,catLoadExclude,catLoadSelection,LDFweight,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearsAdjFactor,
                                 selected_by,reviewed_by) {
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)
  #selections <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][-1])
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
reviewed_by,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",reviewed_by," as reviewed_by,
cast(",catLoadWeight," as nvarchar(50)) as catLoadWeight,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",catLoadSelection," as nvarchar(50)) as catLoadSelection,
cast(",LDFweight," as nvarchar(50)) as LDFweight,
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
cast(",LLLweight," as nvarchar(50)) as LLLweight,
cast(",LLLfire," as nvarchar(50)) as LLLfire,
cast(",LLLwater," as nvarchar(50)) as LLLwater,
cast(",LLLtheft," as nvarchar(50)) as LLLtheft,
cast(",LLLliability," as nvarchar(50)) as LLLliability,
cast(",LLLotherAOP," as nvarchar(50)) as LLLotherAOP,
cast(",LLLweather," as nvarchar(50)) as LLLweather,
cast(",curPremTrend," as nvarchar(50)) as curPremTrend,
cast(",projPremTrend," as nvarchar(50)) as projPremTrend,
cast(",HUexpFactor," as nvarchar(50)) as HUexpFactor,
cast(",HUyearsAdjFactor," as nvarchar(50)) as HUyearsAdjFactor,
cast(",STSexpFactor," as nvarchar(50)) as STSexpFactor,
cast(",STSyearsAdjFactor," as nvarchar(50)) as STSyearsAdjFactor,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catLoadWeight,catExclude,catLoadSelection,LDFweight,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
                                 curPremTrend,projPremTrend,HUexpFactor,HUyearsAdjFactor,STSexpFactor,STSyearsAdjFactor)
	) as unpvt2

MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by 	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
}

save_selections_cw <- function(IndicationDate,EvaluationDate, Region,Class,Status,curLossTrend,projLossTrend,catLoadExclude,
                                 selected_by,reviewed_by) {
  catLoadExcludeSave <- ''
  for (i in 1:length(catLoadExclude)) {
    catLoadExcludeSave <- paste0(catLoadExcludeSave,catLoadExclude[i])
  }
  catLoadExcludeSave <- ifelse(catLoadExcludeSave == '', 0, catLoadExcludeSave)
  #selections <- as.numeric(LDFselections[LDFselections[1] == 'Selection',][-1])
  test <- dbGetQuery(con,paste0("
select
IndicationDate,
EvaluationDate,
Region,
Class,
Status,
selected_by,
reviewed_by,
columnName,columnValue,
rowStartDate,
rowEndDate,
currentRow
into #load
from (
SELECT 
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",reviewed_by," as reviewed_by,
cast(",catLoadExcludeSave," as nvarchar(50)) as catExclude,
cast(",curLossTrend," as nvarchar(50)) as curLossTrend,
cast(",projLossTrend," as nvarchar(50)) as projLossTrend,
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
) a
UNPIVOT(
	columnValue for columnName IN 
		(catExclude,curLossTrend,projLossTrend)
	) as unpvt2

MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by 	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[ho].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.reviewed_by = SOURCE.reviewed_by	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,reviewed_by,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.reviewed_by,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
}



########################################################################################
######################## Territorial Analysis Functions ################################
########################################################################################

LossesCapped <- function(Program,IndicationDate, EvaluationDate, state) {
  df <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCapped
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))
}

LossesCappedByPeril <- function(Program,IndicationDate, EvaluationDate, state,peril) {
  df <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode,Peril, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCappedByPeril
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and peril = '",peril,"'
      "
  ))
}

EHY_Prem <- function(Program,IndicationDate, EvaluationDate, state) {
  df <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".Territorial_EHY_Prem
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


InforceAAL <- function(Program,IndicationDate, EvaluationDate, state) {
  df <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".TerritorialInforceAAL
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


ExperienceFactor <- function(Program,IndicationDate, EvaluationDate, state, name) {
  df <- dbGetQuery(con, paste0("
                               SELECT Territory, columnValue as ",name,"
  FROM [ActuarialSandbox].[",Program,"].[TerritorialExperienceAdjustmentFactor]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and Region = '",state,"'
  and columnName = '",name,"'
                               
                               "))
  if (nrow(df)>0) {
    return(df)
  } else {
    return(df)
  }
  
}

TerritorialExhibit <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
                               TargetLossRatio,TargetIndicatedChange,nonPeril){

  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumatCRL*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
 
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(STSexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    left_join(HUexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0),
           ModeledHUloss = coalesce(as.numeric(`HU AAL Total`) * as.numeric(ExpenseLAE) * coalesce(as.numeric(HUexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           ModeledSTSloss=  coalesce(as.numeric(`STS AAL Total`)* as.numeric(ExpenseLAE) * coalesce(as.numeric(STSexpFactor),1) / as.numeric(`In Force Premium @ CRL`),0),
           HU_Re_Load = (HUprojLossLAE+HURe)/HUprojLossLAE,
           TO_Re_Load = (STSprojLossLAE+STSRe)/STSprojLossLAE)%>%
    mutate(HU_Cost_Re = ModeledHUloss*(HU_Re_Load-1),
           TO_Cost_Re = ModeledSTSloss*(TO_Re_Load-1))%>%
    select(-state,-`HU AAL Total`, -`STS AAL Total`,-`HU Premium`,-`STS Premium`)%>%
    mutate(AdjLossLAEcost = round(ModeledHUloss + ModeledSTSloss + HU_Cost_Re + TO_Cost_Re + ProjLossTotal,3),
           Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = AdjLossLAEcost/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange)-1)*basePremTotal)%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange)-1,
           AveragePremium = coalesce(TrendedReratedEP/Claim_Count,1),
           CatLossRatio = ModeledHUloss+ModeledSTSloss,
           CostOfReinsurance = HU_Cost_Re+TO_Cost_Re)%>%
    mutate(AdjTotalLoss = CatLossRatio+CostOfReinsurance+ProjLossTotal)%>%
    select(territoryCode,Claim_Count,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,CatLossRatio,CostOfReinsurance,
           AdjLossLAEcost,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  
  colnames(Exhibit) <- c('Territory', 'Claim Count', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Cat Loss Ratio',
                         'Cost of Reinsurance','Adj Total Loss, LAE, & Cost of Reinsurance','Indicated Changed','Credibility',
                         'Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}

TerritorialExhibitAttritionalNCW <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
                                             TargetLossRatio,TargetIndicatedChange,nonPeril,peril){
  
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',ifelse(peril=='Theft', 'TheftVMM',peril))]]
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumUse*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHYUse = coalesce(EHYUse,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0))%>%
    mutate(Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = ProjLossTotal/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange[3])-1)*as.numeric(basePremTotal))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1,
           AveragePremium = coalesce(TrendedReratedEP/EHYUse,1))%>%
    select(territoryCode,EHYUse,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,Claim_Count,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Claim Count'
                         ,'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}

TerritorialExhibitAttritionalCAT <- function(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                             TargetLossRatio,TargetIndicatedChange,peril,peril_short,catExpAdj,perilLossLAE, CostRe, catYearsAdj,catCredStandard){
  
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',peril)]]
  InforceAALTable$CatPrem <- InforceAALTable[[paste(peril_short,'Premium',sep = ' ')]]
  InforceAALTable$CatAAL <- InforceAALTable[[paste(peril_short,'AAL Total',sep = ' ')]]
  catExpAdj$expFactor <- as.numeric(catExpAdj[[paste0(peril_short,'expFactor')]])
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    select(territoryCode,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  Main <- EHY_PremTableJoin%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(catExpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(ModeledLossRatio = ifelse(CatPrem > 0,CatAAL*ExpenseLAE/CatPrem ,0),
           ReinsLoad = (perilLossLAE+CostRe)/perilLossLAE,
           expFactor = coalesce(expFactor,1))%>%
    mutate(TerritoryCostRe = ModeledLossRatio*expFactor*(ReinsLoad - 1))%>%
    mutate(ProjectedLoss = ModeledLossRatio * expFactor + TerritoryCostRe,
           Credibility = coalesce(ifelse(EHYUse==0, 0, 
                                ifelse(expFactor==1, 1, catYearsAdj/catCredStandard)),0))%>%
    mutate(IndicatedChange = ProjectedLoss/TargetLossRatio - 1)%>%
    mutate(CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+as.numeric(TargetIndicatedChange[3]))-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1)%>%
    select(territoryCode,EHYUse,CatPrem,CatAAL,ModeledLossRatio,expFactor,TerritoryCostRe,ProjectedLoss,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'In Force Premium @ Currend Rate Level','Peril Modeled Gross AAL','Modeled Loss & LAE Ratio','Experience Adjustment Factor','Cost of Reinsurance','Adj Loss, LAE, & Cost of Reinsurance',
                         'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}





#####################################################################################
############################# RShiny User Interface #################################
#####################################################################################

ui <- fluidPage(#align='center',#theme = shinytheme('sandstone'),
  tags$script("
    Shiny.addCustomMessageHandler('EvaluationDate', function(value) {
    Shiny.setInputValue('EvaluationDate', value);
    });"),
  titlePanel(title=div(img(src='HOA Pic.jpg', height = 50, width = 225))),
  titlePanel("Actuarial Indication"),
  tabsetPanel(
    tabPanel('Choose Indication',
             fluidRow(
               column(width = 4,
                      br(),
                      varSelectInput("Tablename", "Line Of Buisness", LOB[1]),
                      varSelectInput("State", "State", state_options('HO'),'AZ'),
                      selectInput("IndicationDate", 'Indication Name', choices = date_options())
               ),
               column(8)
             )
             ),
    tabPanel("Inputs",
             fluidRow(
               column(width = 4,
                      br(),
                selectInput("EvaluationDate", 'Evaluated As Of:', choices = eval_date_options(date_options()[[1]]), selected =eval_date_options(date_options()[[1]])[1]),
                dateInput("proposedEffective",'Proposed Effective Date','2022-09-01'),
                selectInput('selected_by', 'Selections Made By:',choices = actuaryNames('All')),
                numericInput('capped', 'Cap Losses at:', 250000),
                radioButtons("IncludePolicyFee", label ="Include Policy Fee in Premium Calculations?",
                             choices = list("Yes" = 'Y', "No" = 'N'), 
                             selected = 'N'),
                radioButtons("rateByPeril", label ="By Peril Indication?",
                             choices = list("Yes" = 'Y', "No" = 'N'), 
                             selected = 'Y')
              ),
              column(8)
             )
    ),
    tabPanel('Indication',
    tabsetPanel(
    tabPanel("Modeled Cat Load",
             tabsetPanel(
               tabPanel("Expense Load",
                        fluidRow(
                          column(width = 6,br(),
                                 tableOutput("cw_expense")
                          ),    
                          column(2, br(),
                                 checkboxGroupInput("cw_exclude", 
                                                    "CW Exclude Year", 
                                                    choices = NULL,
                                                    selected = 1)),
                          column(1,
                                 currencyInput("CATstateweight", uiOutput("state1"),1,format = "percentageUS2dec"),
                                 DTOutput("expense_load_output"),
                                 DTOutput('expense_load_output_selected'),
                                 br(),
                                 actionButton('catLoadtoSQL','Save Selection' , icon = NULL)),
                          column(1),
                          column(1,br(),br(),br(),
                                 actionButton('useCalcExpense','Use Calculated',icon=NULL)) 
                        ),
                        fluidRow(
                          column(6,
                                 tableOutput("state_expense")),
                          column(2,br(),
                                 checkboxGroupInput("state_exclude", 
                                                    uiOutput('state2'), 
                                                    choices = NULL,
                                                    selected = 1)),
                          column(1)
                        )
               ),
               tabPanel("Modeled Results",
                        fluidRow(
                          column(1),
                          column(width = 10,align = 'center',
                                 uiOutput("state6"),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('LOB_header'),
                                 h5('Modeled Catastrophe (CAT) Load'),
                                 withSpinner(DTOutput('ModeledCatLoad'))
                          ),
                          column(1)
                        )
               ),
               tabPanel('Non-Modeled Results',
                        fluidRow(
                          column(3),
                          column(3,align = 'center',
                                 h4('Hurricane'),
                                 ),
                          column(3,align = 'center',
                                 h4('STS'),
                                 ),
                          column(3,
                                 actionButton('nonmodeledsave','Save Selections',icon=NULL))
                        ),                      
                        fluidRow(
                          column(3,align = 'right',br(),
                                 h4('Exp Adj Factor')),
                          column(3,align = 'center',
                                 numericInput('HUexpFactor','',1.00)),
                          column(3,align = 'center',
                                 numericInput('STSexpFactor','',1.00)),
                          column(3)
                        ),
                        fluidRow(
                          column(3,align = 'right',br(),
                                 h4('Total Years for Exp Adj')),
                          column(3,align = 'center',
                                 numericInput('HUyearExpAdj','',0,step = 1)),
                          column(3,align = 'center',
                                 numericInput('STSyearExpAdj','',0,step = 1)),
                          column(3)
                        ))
             ) #Close inner tabsetPanel
    ),
    tabPanel("LDFs",
             tabsetPanel(

                tabPanel("State",
                         tabsetPanel(id = 'LDF',
                           tabPanel("All Perils",
                                    fluidRow(
                                      column(3),
                                      column(6,align = 'center',
                                             uiOutput('state3'),
                                             h4(strong('Homeowners of America Insurance Company')),
                                             uiOutput('LOB_header4'),
                                             h5(strong('Loss Development Factors')),
                                             withSpinner(DTOutput('LDFallstateloss')),
                                             withSpinner(DTOutput('LDFallstateratio')),
                                             br(),br(),
                                             withSpinner(DTOutput("LDFallstateaverages")),
                                             h4(strong('Selections'))
                                             
                                      ),
                                      column(3)
                                      
                                    ),
                                    fluidRow(
                                      column(3),
                                      column(6,
                                             withSpinner(DTOutput('LDFallstatecumulative')),
                                             br(),br(),br(),
                                             DTOutput('LDFshowCWselectionAllPerils'),
                                             br(),br(),br(),
                                             DTOutput('LDFweightedCumulativeAllPerils')
                                      ),
                                      column(1,
                                             currencyInput("LDFstateweight", "State Weight",.50,format = "percentageUS2dec"),
                                             br(),
                                             actionButton('ldfselectionToSQLstate','Save Selection',icon = NULL)
                                      ),
                                      column(2)
                                    )
                           ),
                           tabPanel(title = "Weather", value = 'Weather',
                                    fluidRow(
                                      column(3),
                                      column(6,align = 'center',
                                             uiOutput('state4'),
                                             h4(strong('Homeowners of America Insurance Company')),
                                             uiOutput('LOB_header5'),
                                             h5(strong('Loss Development Factors - Weather')),
                                             withSpinner(DTOutput('LDFallstatelossWeather')),
                                             withSpinner(DTOutput('LDFallstateratioWeather')),
                                             br(),br(),
                                             withSpinner(DTOutput("LDFallstateaveragesWeather")),
                                             h4(strong('Selections'))
                                             
                                      ),
                                      column(3)
                                      
                                    ),
                                    fluidRow(
                                      column(3),
                                      column(6,
                                             withSpinner(DTOutput('LDFallstatecumulativeWeather')),
                                             br(),br(),
                                             DTOutput('LDFshowCWselectionWeather'),
                                             br(),br(),br(),
                                             DTOutput('LDFweightedCumulativeWeather')
                                      ),
                                      column(3,
                                             actionButton('ldfselectionToSQLstateWeather','Save Selection',icon = NULL))
                                    )
                           ),
                           tabPanel(title = "Attritional", value = 'Attritional',
                                    fluidRow(
                                      column(3),
                                      column(6,align = 'center',
                                             uiOutput('state5'),
                                             h4(strong('Homeowners of America Insurance Company')),
                                             uiOutput('LOB_header6'),
                                             h5(strong('Loss Development Factors - Attritional')),
                                             withSpinner(DTOutput('LDFallstatelossAttritional')),
                                             withSpinner(DTOutput('LDFallstateratioAttritional')),
                                             br(),br(),
                                             withSpinner(DTOutput("LDFallstateaveragesAttritional")),
                                             h4(strong('Selections'))
                                             
                                      ),
                                      column(3)
                                      
                                    ),
                                    fluidRow(
                                      column(3),
                                      column(6,
                                             withSpinner(DTOutput('LDFallstatecumulativeAttritional')),
                                             br(),br(),
                                             DTOutput('LDFshowCWselectionAttritional'),
                                             br(),br(),br(),
                                             DTOutput('LDFweightedCumulativeAttritional')
                                      ),
                                      column(3,
                                             actionButton('ldfselectionToSQLstateAttritional','Save Selection',icon = NULL))
                                    )
                                    
                           )
                         )
                ),
                tabPanel("CW",
                         tabsetPanel(id = 'LDFCW',
                                     tabPanel("All Perils",
                                              fluidRow(
                                                column(3),
                                                column(6,align = 'center',
                                                       h4(strong('Countrywide')),
                                                       h4(strong('Homeowners of America Insurance Company')),
                                                       uiOutput('LOB_header1'),
                                                       h5(strong('Loss Development Factors')),
                                                       withSpinner(DTOutput('LDFallCWloss')),
                                                       withSpinner(DTOutput('LDFallCWratio')),
                                                       h4(strong('Summary')),
                                                       withSpinner(DTOutput("LDFallCWaverages")),
                                                       h4(strong('Selections'))
                                                       
                                                ),
                                                column(3,align = 'center',
                                                       h5(strong("Display Selected by and Reviewer for CW tabs")))
                                                
                                              ),
                                              fluidRow(
                                                column(3),
                                                column(6,
                                                       DTOutput('LDFallCWcumulative')
                                                ),
                                                column(3,
                                                       actionButton('ldfselectionToSQL','Save Selection',icon = NULL))
                                              )
                                              
                                     ),
                                     tabPanel(title = "Weather", value = 'Weather',
                                              fluidRow(
                                                column(3),
                                                column(6,align = 'center',
                                                       h4(strong('Countrywide')),
                                                       h4(strong('Homeowners of America Insurance Company')),
                                                       uiOutput('LOB_header2'),
                                                       h5(strong('Loss Development Factors - Weather')),
                                                       withSpinner(DTOutput('LDFallCWlossWeather')),
                                                       withSpinner(DTOutput('LDFallCWratioWeather')),
                                                       h4(strong('Summary')),
                                                       withSpinner(DTOutput("LDFallCWaveragesWeather")),
                                                       h4(strong('Selections'))
                                                       
                                                ),
                                                column(3,align = 'center',
                                                       h5(strong("Display Selected by and Reviewer for CW tabs")))
                                                
                                              ),
                                              fluidRow(
                                                column(3),
                                                column(6,
                                                       withSpinner(DTOutput('LDFallCWcumulativeWeather'))
                                                ),
                                                column(3,
                                                       actionButton('ldfselectionToSQLWeather','Save Selection',icon = NULL))
                                              )
                                     ),
                                     tabPanel(title = "Attritional", value = 'Attritional',
                                              fluidRow(
                                                column(3),
                                                column(6,align = 'center',
                                                       h4(strong('Countrywide')),
                                                       h4(strong('Homeowners of America Insurance Company')),
                                                       uiOutput('LOB_header3'),
                                                       h5(strong('Loss Development Factors - Attritional')),
                                                       withSpinner(DTOutput('LDFallCWlossAttritional')),
                                                       withSpinner(DTOutput('LDFallCWratioAttritional')),
                                                       h4(strong('Summary')),
                                                       withSpinner(DTOutput("LDFallCWaveragesAttritional")),
                                                       h4(strong('Selections'))
                                                       
                                                ),
                                                column(3,align = 'center',
                                                       h5(strong("Display Selected by and Reviewer for CW tabs")))
                                                
                                              ),
                                              fluidRow(
                                                column(3),
                                                column(6,
                                                       withSpinner(DTOutput('LDFallCWcumulativeAttritional'))
                                                ),
                                                column(3,
                                                       actionButton('ldfselectionToSQLAttritional','Save Selection',icon = NULL))
                                              )
                                     )
                         )
                )
             )
    ),
    tabPanel('Loss Trend',
             tabsetPanel(
               tabPanel('State',
                        fluidRow(
                          column(4),
                        column(4,align = 'center',
                               uiOutput('state7'),
                               h4(strong('Homeowners of America Insurance Company')),
                               uiOutput('lossTrendLOBheader'),
                               h5(strong('Loss Trend Selections')),
                               withSpinner(DTOutput('lossTrendstate')),
                               br(),
                               br()
                              ),
                        column(4
                        ),
                        fluidRow(
                          column(5),
                          column(3,
                                 withSpinner(DTOutput('lossTrendstatefitting')),
                                 br()),
                          column(4,
                                 radioButtons("LosstrendstateLag", label = "Number of Quarters to Lag to allow for full development",
                                              choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                              selected = 0)
                          ))
                        ),
                        fluidRow(
                          column(7),
                          column(1,
                                  currencyInput("currentLossTrendState", 'Current Selection',0,format = "percentageUS2dec"),
                                 currencyInput("projLossTrendState", 'Current Selection',0,format = "percentageUS2dec")),
                          column(4,
                                 actionButton('stateLossTrendtoSQL', 'Save Selection',icon=NULL))
                        )
                      ),
               tabPanel('Countrywide',
                        fluidRow(
                          column(4),
                          column(4,align = 'center',
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('lossTrendLOBheaderCW'),
                                 h5(strong('Loss Trend Selections')),
                                 withSpinner(DTOutput('lossTrendCW')),
                                 br(),
                                 br()
                          ),
                          column(4)
                        ),
                        fluidRow(
                          column(5),
                          column(3,
                                 withSpinner(DTOutput('lossTrendCWfitting')),
                                 br()),
                          column(4
                                 #,
                                 # radioButtons("LosstrendCWLag", label = "Number of Quarters to Lag to allow for full development",
                                 #              choices = list("0 Quarters" = 0, "4 Quarters" = 4), 
                                 #              selected = 0)
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(1,
                                 currencyInput("currentLossTrendCW", 'Current Selection',0,format = "percentageUS2dec"),
                                 currencyInput("projLossTrendCW", 'Projected Selection',0,format = "percentageUS2dec")),
                          column(4,
                                 actionButton('cwLossTrendtoSQL', 'Save Selection',icon=NULL))
                        )
               )
             )),
    tabPanel('LLL',
             tabsetPanel(id = 'LLL',
               tabPanel('Total',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLL'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load'),
                                 withSpinner(DTOutput('LLLTotalTablestate')),
                                 br()
                                 ),
                          column(3,
                                 currencyInput("LLLstateweightTotal", uiOutput("state10"),0,format = "percentageUS2dec"),
                                 actionButton('LLLselectionsToSQL','Save Selection'))
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateTotal'),
                                 DTOutput('LLLselectStateTotalSelected')
                                 )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load'),
                                 withSpinner(DTOutput('LLLTotalTableCW')),
                                 br(),
                                 )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWTotal'),
                                 DTOutput('LLLselectCWTotalSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedTotal')
                                 )
                        )),
               tabPanel(title = 'Fire', value = 'Fire',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLFire'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Fire'),
                                 withSpinner(DTOutput('LLLTotalTablestateFire')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateFire'),
                                 DTOutput('LLLselectStateFireSelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Fire'),
                                 withSpinner(DTOutput('LLLTotalTableCWFire')))
                          
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWFire'),
                                 DTOutput('LLLselectCWFireSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedFire'),
                                 br(),
                                 br()
                          )
                        )),
               tabPanel(title = 'Water',value = 'Water',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLWater'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Water'),
                                 withSpinner(DTOutput('LLLTotalTablestateWater')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateWater'),
                                 DTOutput('LLLselectStateWaterSelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Water'),
                                 withSpinner(DTOutput('LLLTotalTableCWWater')))
                          
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWWater'),
                                 DTOutput('LLLselectCWWaterSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedWater'),
                                 br(),
                                 br()
                          )
                        )),
               tabPanel(title = 'Theft',value = 'Theft',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLTheft'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Theft'),
                                 withSpinner(DTOutput('LLLTotalTablestateTheft')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateTheft'),
                                 DTOutput('LLLselectStateTheftSelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Theft'),
                                 withSpinner(DTOutput('LLLTotalTableCWTheft')))
                          
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWTheft'),
                                 DTOutput('LLLselectCWTheftSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedTheft'),
                                 br(),
                                 br()
                          )
                        )),
               tabPanel(title = 'Liability',value = 'Liability',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLLiability'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Liability'),
                                 withSpinner(DTOutput('LLLTotalTablestateLiability')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateLiability'),
                                 DTOutput('LLLselectStateLiabilitySelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Liability'),
                                 withSpinner(DTOutput('LLLTotalTableCWLiability')))
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWLiability'),
                                 DTOutput('LLLselectCWLiabilitySelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedLiability'),
                                 br(),
                                 br()
                          )
                        )),
               tabPanel(title = 'Other AOP',value = 'OtherAOP',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLOtherAOP'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Other AOP'),
                                 withSpinner(DTOutput('LLLTotalTablestateOtherAOP')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateOtherAOP'),
                                 DTOutput('LLLselectStateOtherAOPSelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Other AOP'),
                                 withSpinner(DTOutput('LLLTotalTableCWOtherAOP')))
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWOtherAOP'),
                                 DTOutput('LLLselectCWOtherAOPSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedOtherAOP'),
                                 br(),
                                 br()
                          )
                        )),
               tabPanel(title = 'Weather', value = 'Weather',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('stateLLLWeather'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Weather'),
                                 withSpinner(DTOutput('LLLTotalTablestateWeather')),
                                 br()
                          )
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectStateWeather'),
                                 DTOutput('LLLselectStateWeatherSelected')
                          )
                        ),
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 br(),
                                 br(),
                                 h4(strong('Countrywide')),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 h5('Large Loss Load - Weather'),
                                 withSpinner(DTOutput('LLLTotalTableCWWeather')))
                          
                        ),
                        fluidRow(
                          column(7),
                          column(2,
                                 DTOutput('LLLselectCWWeather'),
                                 DTOutput('LLLselectCWWeatherSelected'),
                                 br(),
                                 br(),
                                 br(),
                                 DTOutput('LLLweightedWeather'),
                                 br(),
                                 br()
                          )
                        ))
                    )
             ),
    tabPanel('Premium Trend',
             fluidRow(
               column(4),
               column(4,align = 'center',
                      uiOutput('state8'),
                      h4(strong('Homeowners of America Insurance Company')),
                      uiOutput('PremiumTrendLOBheader'),
                      h5(strong('Premium Trend Selection')),
                      withSpinner(DTOutput('premiumTrend')),
                      br(),
                      br()
               ),
               column(4
               ),
               fluidRow(
                 column(5),
                 column(3,
                        withSpinner(DTOutput('PremiumTrendfitting')),
                        br()),
                 column(4)
                 )
             ),
             fluidRow(
               column(7),
               column(1,
                      currencyInput("currentPremiumTrend", 'Current Selection',0,format = "percentageUS2dec"),
                      currencyInput("projPremiumTrend", 'Projected Selection',0,format = "percentageUS2dec")),
               column(4,
                      actionButton('PremiumSave','Save Selection', icon = NULL))
             )
             ),
    tabPanel('Expense Ratios',
             tabsetPanel(
               tabPanel('Expense Exhibit',
             fluidRow(
               column(3),
               column(6,align = 'center',
                      uiOutput('state30'),
                      h4(strong('Homeowners of America Insurance Company')),
                      uiOutput('ExpenseLOBheader'),
                      h4('Expense Provisions'),
                      br(),
                      withSpinner(DTOutput('expenseExhibit'))),
               column(3)
                     )
                    ),
             tabPanel('CAT Reinsurance Provision By Peril',
                      fluidRow(
                        column(3),
                        column(6,align='center',
                               uiOutput('stateReinsurance'),
                               h4(strong('Homeowners of America Insurance Company')),
                               uiOutput('ReinsuranceLOB'),
                               h4('Reinsurance Exhibit'),
                               withSpinner(DTOutput('reinsuranceExhibit'))
                               ),
                        column(3)
                      ))
             )),
    tabPanel('Indication',
             tabsetPanel(
               tabPanel('Memo Exhibit',
                        fluidRow(
                          column(3),
                          column(6,br(),
                                 DTOutput('memo')),
                          column(3)
                        )),
               tabPanel('Total',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state9'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('TotalLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('TotalProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 br(),
                                 withSpinner(DTOutput('TotalRateLevelIndication'))
                                 ),
                          column(3)),
                      fluidRow(
                        column(4),
                        column(5,
                               br(),
                               br(),
                               withSpinner(DTOutput('TotalRateLevelSummary'))),
                        column(3)
                      )),
               tabPanel(title = 'Fire',value = 'Fire',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state15'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('FireLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('FireProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Fire')),
                                 br(),
                                 withSpinner(DTOutput('FireIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('FireIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('FireIndicationSummary')),br(),
                                 withSpinner(DTOutput('FireRateLevelChange')),br()
                          ))),
               tabPanel(title ='Water',value = 'Water',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state16'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('WaterLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('WaterProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Water')),
                                 br(),
                                 withSpinner(DTOutput('WaterIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('WaterIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('WaterIndicationSummary')),br(),
                                 withSpinner(DTOutput('WaterRateLevelChange')),br()
                          ))),
               tabPanel(title ='Theft VMM',value = 'Theft',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state17'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('TheftLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('TheftProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Theft & VMM')),
                                 br(),
                                 withSpinner(DTOutput('TheftIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('TheftIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('TheftIndicationSummary')),br(),
                                 withSpinner(DTOutput('TheftRateLevelChange')),br()
                          ))),
               tabPanel(title ='Other AOP',value = 'OtherAOP',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state18'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('OtherAOPLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('OtherAOPProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Other AOP')),
                                 br(),
                                 withSpinner(DTOutput('OtherAOPIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('OtherAOPIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('OtherAOPIndicationSummary')),br(),
                                 withSpinner(DTOutput('OtherAOPRateLevelChange')),br()
                          ))),
               tabPanel(title ='Liability',value = 'Liability',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state20'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('LiabilityLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('LiabilityProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Liability')),
                                 br(),
                                 withSpinner(DTOutput('LiabilityIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('LiabilityIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('LiabilityIndicationSummary')),br(),
                                 withSpinner(DTOutput('LiabilityRateLevelChange')),br()
                          ))),
               tabPanel(title ='Non-Cat Weather',value = 'NCW',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state21'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('NCWLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('NCWProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Non-Cat Weather')),
                                 br(),
                                 withSpinner(DTOutput('NCWIndicationLosses')),br(),br(),
                                 withSpinner(DTOutput('NCWIndicationPremium')),br(),br(),
                                 withSpinner(DTOutput('NCWIndicationSummary')),br(),
                                 withSpinner(DTOutput('NCWRateLevelChange')),br()
                          ))),
               tabPanel(title ='STS', value = 'STS',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state22'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('STSLOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('STSProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('STS')),
                                 br(),
                                 withSpinner(DTOutput('STSIndication')),br(),
                                 withSpinner(DTOutput('STSIndicationSummary')),br(),
                                 withSpinner(DTOutput('STSRateLevelChange')),br()
                          ))),
               tabPanel(title ='Hurricane', value = 'HU',
                        fluidRow(
                          column(3),
                          column(6,align='center',
                                 uiOutput('state23'),
                                 h4(strong('Homeowners of America Insurance Company')),
                                 uiOutput('HULOBheader'),
                                 h4(strong('Rate Level Indication')),
                                 uiOutput('HUProfit'), #change this to be an interactive UI pulling in the profit load from SQL
                                 br(),
                                 h5(strong('Hurricane')),
                                 br(),
                                 withSpinner(DTOutput('HUIndication')),br(),
                                 withSpinner(DTOutput('HUIndicationSummary')),br(),
                                 withSpinner(DTOutput('HURateLevelChange')),br()
                          ))),
               id = 'Indication'
             )
    ),
    tabPanel('Review Selections',
             tabsetPanel(
             tabPanel('State',
               fluidRow(
               column(3),
               column(3,br(),br(),br(),
                      selectInput('reviewed_by', 'Review Completed By:',choices = actuaryNames(actuaryNames('All')[1]))), #add all team names minus the selector
               column(3,br(),br(),br(),br(),
                      actionButton('sendForReview','Mark Selections for Review'))
                      
             ),
             fluidRow(
               column(3),
               column(3),
               column(3,br(),br(),br(),br(),br(),
                      actionButton('publish','Publish Selections')
                      )
             )),
             tabPanel('Countrywide',
                      fluidRow(
                        column(3,br(),br(),br(),
                               selectInput('cw_selected_by', 'Selections Made By:',choices = actuaryNames('All')) #add all team names minus the selector
                      ),
                        column(3,br(),br(),br(),
                               selectInput('cw_reviewed_by', 'Review Completed By:',choices = actuaryNames(actuaryNames('All')[1]))), #add all team names minus the selector
                        column(3,br(),br(),br(),br(),
                               actionButton('cw_sendForReview','Send Selections for Review'))
                        
                      ),
                      fluidRow(
                        column(3),
                        column(3),
                        column(3,br(),br(),br(),br(),br(),
                               actionButton('cw_publish','Publish Selections')
                        )
                      ))
             )))),
    tabPanel('Territorial Analysis',
             tabsetPanel(
               tabPanel('Exhibit',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibit'))
                        )),
               tabPanel('Exhibit Snapshot',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitSnapshot'))
                        )),
               tabPanel('Exhibit Fire',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitFire'))
                        )),
               tabPanel('Exhibit Water',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitWater'))
                        )),
               tabPanel('Exhibit Theft',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitTheft'))
                        )),
               tabPanel('Exhibit Liab',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitLiab'))
                        )),
               tabPanel('Exhibit AOP',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitAOP'))
                        )),
               tabPanel('Exhibit NCW',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitNCW'))
                        )),
               tabPanel('Exhibit STS',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitSTS'))
                        )),
               tabPanel('Exhibit HU',
                        fluidRow(
                          column(2),
                          column(8, align = 'center',
                                 DTOutput('TerritorialExhibitHU'))
                        ))
             )),
    tabPanel('Download',
             column(6,align = 'center',
                    h3('Work In Progress'),
                    downloadButton("report", "Download Exhibits")
                    )
             
    )
  ) #Close outer tabsetPanel
) #Close FluidPage

server <- function(input, output,session) {
  #define all data frames as empty. then update them with observe event when indication, asOFdate, state, LOB change. reduce the number of times that data is reloaded into the server. Better practice
  cw_expense =LDFdata = data.frame()
  LDFchoices = data.frame(matrix(nrow = 0, ncol = 11))
  evaluation_date_proxy <- NULL
  indication_change <- FALSE
  #start of expense display function
  observeEvent({input$selected_by},
               { 
                 updateSelectInput(session, input = 'reviewed_by',
                                   choices = actuaryNames(input$selected_by))
               })
  observeEvent({input$cw_selected_by},
               { 
                 updateSelectInput(session, input = 'cw_reviewed_by',
                                   choices = actuaryNames(input$cw_selected_by))
               })
  observeEvent({input$Tablename},
               { 
                 print(1)
                 updateVarSelectInput(session, input = 'State',
                                           data = state_options(input$Tablename), selected = 'AZ')#colnames(state_options(input$Tablename))[1])
                 },priority = 1000)
  observeEvent({input$IndicationDate},{
                print(2)
               eval_update <- eval_date_options(input$IndicationDate)
               updateSelectInput(session,inputId='EvaluationDate',
                                   choices = eval_update,selected = eval_update[[1]])
               evaluation_date_proxy <<- eval_update[[1]]
               indication_change <<- TRUE
               },priority = 100
               )
  observeEvent({input$rateByPeril}, {
        #hide by peril tabs if no selected
        if (input$rateByPeril == 'N') {
          hideTab(inputId = 'Indication', target = 'Fire')
          hideTab(inputId = 'Indication', target = 'Water')
          hideTab(inputId = 'Indication', target = 'Theft')
          hideTab(inputId = 'Indication', target = 'OtherAOP')
          hideTab(inputId = 'Indication', target = 'Liability')
          hideTab(inputId = 'Indication', target = 'NCW')
          hideTab(inputId = 'Indication', target = 'STS')
          hideTab(inputId = 'Indication', target = 'HU')
          hideTab(inputId = 'LLL', target = 'Fire')
          hideTab(inputId = 'LLL', target = 'Water')
          hideTab(inputId = 'LLL', target = 'Theft')
          hideTab(inputId = 'LLL', target = 'OtherAOP')
          hideTab(inputId = 'LLL', target = 'Liability')
          hideTab(inputId = 'LLL', target = 'Weather')
          hideTab(inputId = 'LDF', target = 'Weather')
          hideTab(inputId = 'LDF', target = 'Attritional')
          hideTab(inputId = 'LDFCW', target = 'Weather')
          hideTab(inputId = 'LDFCW', target = 'Attritional')
        } else {
          showTab(inputId = 'Indication', target = 'Fire')
          showTab(inputId = 'Indication', target = 'Water')
          showTab(inputId = 'Indication', target = 'Theft')
          showTab(inputId = 'Indication', target = 'OtherAOP')
          showTab(inputId = 'Indication', target = 'Liability')
          showTab(inputId = 'Indication', target = 'NCW')
          showTab(inputId = 'Indication', target = 'STS')
          showTab(inputId = 'Indication', target = 'HU')
          showTab(inputId = 'LLL', target = 'Fire')
          showTab(inputId = 'LLL', target = 'Water')
          showTab(inputId = 'LLL', target = 'Theft')
          showTab(inputId = 'LLL', target = 'OtherAOP')
          showTab(inputId = 'LLL', target = 'Liability')
          showTab(inputId = 'LLL', target = 'Weather')
          showTab(inputId = 'LDF', target = 'Weather')
          showTab(inputId = 'LDF', target = 'Attritional')
          showTab(inputId = 'LDFCW', target = 'Weather')
          showTab(inputId = 'LDFCW', target = 'Attritional')
        }
  })
  observeEvent({input$IndicationDate
    input$EvaluationDate},
    {print('evaluationDate')
      if (indication_change) {
        indication_change <<- FALSE
        evaluation_use <<- evaluation_date_proxy
      } else {
        evaluation_use <<- input$EvaluationDate
      }
      print(evaluation_use)
    },priority = 99)
  observeEvent({input$State
    input$Tablename
    input$EvaluationDate
    input$IndicationDate
    },
    {#load in data based on inputs tab selections
      LDF_selection <<-  LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils')
      LDF_selection_weather <<-  LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Weather')
      LDF_selection_attritional <<-  LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Attritional')
      LDFstate_selection_All <<-LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils')
      LDFcw_selection_All<<-LDF_pull_selections(input$IndicationDate,input$EvaluationDate,'CW','All Perils')
      LDFcw_selection_Weather <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,'CW','Weather')
      LDFstate_selection_Weather <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Weather')
      LDFcw_selection_Attritional <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,'CW','Attritional')
      LDFstate_selection_Attritional <<- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'Attritional')
      # LDFstate_selection_All_react <<- reactive({
      #   LDF_saved <- LDF_pull_selections(input$IndicationDate,input$EvaluationDate,input$State,'All Perils')
      # if (nrow(LDF_saved) > 0) {
      #   return(LDF_saved)
      # } else {
      #   return(data.frame(NAME = 'Cumulative',x1=1,x2=1,x3=1,x4=1,x5=1))00
      #   }
      # })
      cw_expense <<- expense_cw(input$Tablename, evaluation_use,input$IndicationDate)
      LossTrendDate <<- loss_trend_data(input$Tablename, input$IndicationDate, evaluation_use)
      LDFdata <<- LDF(input$Tablename, input$IndicationDate, evaluation_use,input$State)
      PremiumData <<- premium_trend_data(input$IndicationDate, evaluation_use,input$State)
      LDFallAverages <<- LDF_display(LDFdata,'Averages','All Perils','CW',input$IndicationDate, evaluation_use,'LDF')
      LDFallAveragesState <<- LDF_display(LDFdata,'Averages','All Perils',input$State,input$IndicationDate, evaluation_use,'LDFstate')
      LDFallAveragesWeather <<- LDF_display(LDFdata,'Averages','Weather','CW',input$IndicationDate, evaluation_use,'LDFWeather')
      LDFallAveragesStateWeather <<- LDF_display(LDFdata,'Averages','Weather',input$State,input$IndicationDate, evaluation_use,'LDFstateWeather')
      LDFallAveragesAttritional <<- LDF_display(LDFdata,'Averages','Attritional','CW',input$IndicationDate, evaluation_use,'LDFAttritional')
      LDFallAveragesStateAttritional <<- LDF_display(LDFdata,'Averages','Attritional',input$State,input$IndicationDate, evaluation_use,'LDFstateAttritional')
      #execute renderTable for tables that only depend on inputs tab

      output$LOB_header=output$LOB_header1=output$LOB_header2=output$LOB_header3=output$LOB_header4=output$LOB_header5=output$LOB_header6 <- renderUI({h4(strong(table_name(input$Tablename)))})
      output$state1 = output$state10<- renderUI(paste(state_name_full(input$State),'Weight',sep = ' '))
      output$state2 <- renderUI(paste(state_name_full(input$State),'Exclude Year',sep = ' '))
      output$state3=output$state4=output$state5=output$state6=output$state7=output$state8=output$state9=output$state15=output$state16=output$state17=output$state18=output$state20=output$state21=output$state22=output$state23=output$state30=output$stateReinsurance=output$stateLLL=output$stateLLLFire=output$stateLLLWater=output$stateLLLTheft=output$stateLLLLiability=output$stateLLLOtherAOP=output$stateLLLWeather <- renderUI(h4(strong(state_name_full(input$State))))
      output$lossTrendLOBheader = output$lossTrendLOBheaderCW <- renderUI(h4(strong(paste0(table_name(input$Tablename),' : All Forms Combined - Excluding Catastrophe'))))
      output$PremiumTrendLOBheader= output$TotalLOBheader= output$FireLOBheader= output$WaterLOBheader= output$TheftLOBheader= output$LiabilityLOBheader= output$OtherAOPLOBheader= output$NCWLOBheader= output$HULOBheader= output$STSLOBheader=output$ReinsuranceLOB <- renderUI(h4(strong(paste0(table_name(input$Tablename),' : All Forms Combined'))))
      state_profit <<- profit(input$State, input$IndicationDate,input$Tablename)
      output$TotalProfit=output$FireProfit=output$WaterProfit=output$TheftProfit=output$LiabilityProfit=output$OtherAOPProfit=output$NCWProfit=output$NCWProfit=output$STSProfit=output$HUProfit<- renderUI(h5(paste0('Priced to a ',(1-as.numeric(state_profit))*100,'% Combined Ration')))
      ####
      output$cw_expense <- renderTable(cw_expense,width = '100%')
      output$state_expense <-renderTable(expense_state(input$Tablename, evaluation_use,input$IndicationDate, input$State),width = '100%')
      
      updateCheckboxGroupInput(session, input = "cw_exclude",
                               choices = head(expense_cw(input$Tablename, evaluation_use,input$IndicationDate)$Year,-1),
                               selected = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,'CW','All Perils','catExclude',NULL))
      
      
      updateCheckboxGroupInput(session, input = "state_exclude",
                               choices = head(expense_state(input$Tablename, evaluation_use,input$IndicationDate, input$State)$Year,-1),
                               selected = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','catExclude',NULL))
      
      updateCurrencyInput(session, input='LLLstateweightTotal',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','LLLweight',0))
      updateCurrencyInput(session, input='CATstateweight',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadWeight',0))
      
      updateCurrencyInput(session, input='LDFstateweight',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','LDFweight',0))
      
      updateCurrencyInput(session, input='currentLossTrendCW',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,'CW','All Perils','curLossTrend',0))
      
      updateCurrencyInput(session, input='projLossTrendCW',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,'CW','All Perils','projLossTrend',0))
      
      updateCurrencyInput(session, input='currentLossTrendState',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','curLossTrend',0))
      
      updateCurrencyInput(session, input='projLossTrendState',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','projLossTrend',0))
      
      
      updateCurrencyInput(session, input='currentPremiumTrend',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','curPremTrend',0))
      
      updateCurrencyInput(session, input='projPremiumTrend',
                          value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','projPremTrend',0))
      
      updateSelectInput(session, input = 'selected_by',
                        selected = selections_id(input$IndicationDate, evaluation_use, input$State, input$Tablename))
      #input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
      updateNumericInput(session, input = 'HUexpFactor',
                         value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','HUexpFactor',1))
      updateNumericInput(session, input = 'STSexpFactor',
                         value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','STSexpFactor',1))
      updateNumericInput(session, input = 'HUyearExpAdj',
                         value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','HUyearsAdjFactor',0))
      updateNumericInput(session, input = 'STSyearExpAdj',
                         value = pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','STSyearsAdjFactor',0))
      selected_expense_data_selected<<- pull_variable(input$Tablename,input$IndicationDate,evaluation_use,input$State,'All Perils','catLoadSelection',0)
      
      output$LDFallCWloss  <- renderDT(datatable(LDF_display(LDFdata,'Losses','All Perils','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:10,digits = 0))
      output$LDFallCWratio  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','All Perils','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(2:11)),list(width='5%',targets = c(1)))))%>%formatRound(2:10,digits = 3))
      output$LDFallCWaverages <<- renderDataTable(datatable(LDFallAverages, escape = FALSE,editable = list(target = 'cell'),selection = 'none',class = 'compact',
        options = list(dom = 't', 
                       initComplete = JS(js),
                       preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                       drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                       autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAverages)-1))
      )
      
      output$LDFallCWlossWeather  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Weather','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:10,digits = 0))
      output$LDFallCWratioWeather  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Weather','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:10,digits = 3))
      output$LDFallCWaveragesWeather <<- renderDataTable(datatable(LDFallAveragesWeather,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
         options = list(dom = 't', 
                        initComplete = JS(js),
                        preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                        drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                        autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAveragesWeather)-1))
      )
      
      output$LDFallCWlossAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Attritional','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:10,digits = 0))
      output$LDFallCWratioAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Attritional','CW',input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(1:11)))))%>%formatRound(2:10,digits = 3))
      output$LDFallCWaveragesAttritional <<- renderDataTable(datatable(LDFallAveragesAttritional,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                           options = list(dom = 't', 
                                                                          initComplete = JS(js),
                                                                          preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                          drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                          autoWidth = TRUE, columnDefs = list(list(width = '9%',className = 'dt-right', targets = c(0:10)))), rownames = FALSE)%>%formatRound(2:10,digits = 3,rows = 1:(nrow(LDFallAveragesAttritional)-1))
      )
 
      #initialize the state tables
      spacing <<- paste0(as.character(100/length(LDFallAveragesState)),'%')
      output$LDFallstateloss  <-             renderDT(datatable(LDF_display(LDFdata,'Losses','All Perils',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
      output$LDFallstatelossWeather  <-         renderDT(datatable(LDF_display(LDFdata,'Losses','Weather',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
      output$LDFallstatelossAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Losses','Attritional',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 0))
      
      output$LDFallstateratio  <-             renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','All Perils',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))
      output$LDFallstateratioWeather  <-         renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Weather',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))
      output$LDFallstateratioAttritional  <- renderDT(datatable(LDF_display(LDFdata,'Loss Ratios','Attritional',input$State,input$IndicationDate, evaluation_use,NA),selection = 'none',class = 'compact',options = list(dom = 't',autoWidth = TRUE, columnDefs = list(list(width =spacing,className = 'dt-right', targets = c(1:(length(LDFallAveragesState)))))))%>%formatRound(2:length(LDFallAveragesState),digits = 3))

      output$LDFallstateaverages <<- renderDataTable(datatable(LDFallAveragesState,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                           options = list(dom = 't', 
                                                                          initComplete = JS(js),
                                                                          preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                          drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                          autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
      ) 
      
      output$LDFallstateaveragesWeather <<- renderDataTable(datatable(LDFallAveragesStateWeather,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                              options = list(dom = 't', 
                                                                          initComplete = JS(js),
                                                                          preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                          drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                          autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
  )
      output$LDFallstateaveragesAttritional <<- renderDataTable(datatable(LDFallAveragesStateAttritional,class = 'compact', escape = FALSE,editable = list(target = 'cell'),selection = 'none',
                                                              options = list(dom = 't', 
                                                                             initComplete = JS(js),
                                                                             preDrawCallback = JS('function() { Shiny.unbindAll(this.api().table().node()); }'),
                                                                             drawCallback = JS('function() { Shiny.bindAll(this.api().table().node()); } '),
                                                                             autoWidth = TRUE, columnDefs = list(list(width = spacing,className = 'dt-right', targets = c(0:(length(LDFallAveragesState)-1))))), rownames = FALSE)%>%formatRound(2:(length(LDFallAveragesState)-1),digits = 3,rows = 1:(nrow(LDFallAveragesState)-1))
      )
      lossTrendCWData <<-loss_trend_cw(LossTrendDate)
      lossTrendstateData <<- loss_trend_state(LossTrendDate,input$State)
      
      output$lossTrendCW <- renderDT(datatable(lossTrendCWData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                       formatRound(c(2,3,4,6),digits=0)%>%
                                       formatRound(c(5,7),digits = 2))#,spacing='xs')
      output$lossTrendstate <- renderDT(datatable(lossTrendstateData%>%select(-Year,-Quarter),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                        formatRound(c(2,3,4,6),digits=0)%>%
                                        formatRound(c(5,7),digits = 2))
      output$lossTrendCWfitting <- renderDT(datatable(loss_trend_fitting(lossTrendCWData,as.numeric(0)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                              formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
      output$lossTrendstatefitting <- renderDT(datatable(loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                                 formatPercentage(c(2,3,4),digits = 1)) #replace 0 witht the lag months input. Default to 0 forcing user to change based on observation
      
 
      PremiumData_state <<- premium_trend(PremiumData)
      output$premiumTrend <- renderDT(datatable(PremiumData_state%>%select(-Date),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatRound(c(2,3,4), digits = 0)%>%formatRound(c(5),digits = 2))
      output$PremiumTrendfitting <- renderDT(datatable(premium_trend_fitting(PremiumData_state,0),selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%formatPercentage(c(2), digits = 1))
      print('eval')
      print(evaluation_use)
      expense_ratios <<- expense_load(input$IndicationDate, evaluation_use,input$State, input$Tablename)
      output$expenseExhibit <- renderDT(datatable(expense_ratios,selection = 'none',class = 'compact',
                                                  options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                           formatCurrency(c(3,5,7), digits =0)%>%
                                           formatPercentage(c(4,6,8,9,10), digits=1)
                                        )

      

},priority = 3) 
      
  
  observeEvent(input$LDFallCWaverages_cell_edit,
               {LDFallAverages <<- editData(LDFallAverages,input$LDFallCWaverages_cell_edit,'LDFallCWaverages',rownames = FALSE) },priority = 2) 
  observeEvent(input$LDFallCWaveragesWeather_cell_edit,
               {LDFallAveragesWeather <<- editData(LDFallAveragesWeather,input$LDFallCWaverages_cell_edit,'LDFallCWaveragesWeather',rownames = FALSE) },priority = 2)
  observeEvent(input$LDFallCWaveragesAttritional_cell_edit,
               {LDFallAveragesAttritional <<- editData(LDFallAveragesAttritional,input$LDFallCWaveragesAttritional_cell_edit,'LDFallCWaveragesAttritional',rownames = FALSE) },priority = 2)
  observeEvent(input$LDFallstateaverages_cell_edit,
               {LDFallAveragesState <<- editData(LDFallAveragesState,input$LDFallstateaverages_cell_edit,'LDFallstateaverages',rownames = FALSE) },priority = 2) 
  observeEvent(input$LDFallstateaveragesWeather_cell_edit,
               {LDFallAveragesStateWeather <<- editData(LDFallAveragesStateWeather,input$LDFallstateaveragesWeather_cell_edit,'LDFallstateaveragesWeather',rownames = FALSE) },priority = 2) 
  observeEvent(input$LDFallstateaveragesAttritional_cell_edit,
               {LDFallAveragesStateAttritional <<- editData(LDFallAveragesStateAttritional,input$LDFallstateaveragesAttritional_cell_edit,'LDFallstateaveragesAttritional',rownames = FALSE) },priority = 2)
  
  observeEvent({c(input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFHselect,input$State)},
               { 
                LDFcw_choose_All<<- c(input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect)
               if (!is.null(LDFcw_choose_All)) {
                LDFcw_selection_All <<- LDF_Cumulative(LDFallAverages,LDFcw_choose_All)
               output$LDFallCWcumulative <- renderDataTable(datatable(LDFcw_selection_All,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
                              }},priority = 2)
  observeEvent({c(input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,input$State)},
               { LDFcw_choose_Weather<- c(input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect)
               if (!is.null(LDFcw_choose_Weather)) {
               LDFcw_selection_Weather <<- LDF_Cumulative(LDFallAveragesWeather,LDFcw_choose_Weather)
               output$LDFallCWcumulativeWeather <- renderDataTable(datatable(LDFcw_selection_Weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
               }},priority = 2)
  observeEvent({c(input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,input$State)},
               { LDFcw_choose_Attritional<- c(input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect)
               if (!is.null(LDFcw_choose_Attritional)) {
               LDFcw_selection_Attritional <<- LDF_Cumulative(LDFallAveragesAttritional,LDFcw_choose_Attritional)
               output$LDFallCWcumulativeAttritional <- renderDataTable(datatable(LDFcw_selection_Attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:10,digits = 3))
               }},priority = 2)
  

    #state LDF selections tables
  observeEvent({c(input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect)},
               {LDFstate_choose_All<- c(input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect)
               LDFstate_selection_All <<- LDF_Cumulative(LDFallAveragesState,LDFstate_choose_All)
               output$LDFallstatecumulative <- renderDataTable(datatable(LDFstate_selection_All,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
               },priority = 2)
  observeEvent({c(input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect)},
               { LDFstate_choose_Weather<- c(input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect)
               LDFstate_selection_Weather <<- LDF_Cumulative(LDFallAveragesStateWeather,LDFstate_choose_Weather)
               output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDFstate_selection_Weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
               },priority = 2)
  observeEvent({c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect)},
               { LDFstate_choose_Attritional<- c(input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect)
               LDFstate_selection_Attritional <<- LDF_Cumulative(LDFallAveragesStateAttritional,LDFstate_choose_Attritional)
               output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDFstate_selection_Attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
               },priority = 2)

#LDF selections , bulky work around, not the best haha
  observe(
    {
      dummy <<- c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect,
                  input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect,
                  input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect,
                  input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,
                  input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,
                  input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect)
      if (input$LDFstateweight == 0) {
        
        LDF_selection <<- LDFcw_selection_All
        LDF_selection_weather <<- LDFcw_selection_Weather
        LDF_selection_attritional <<- LDFcw_selection_Attritional
        LDF_selection_display <<- LDF_selection[1:length(LDFstate_selection_All)]
        LDF_selection_display[length(LDF_selection_display)] <- NA
        LDF_selection_display_weather <<- LDF_selection_weather[1:length(LDFstate_selection_Weather)]
        LDF_selection_display_weather[length(LDF_selection_display_weather)] <- NA
        LDF_selection_display_attritional <<- LDF_selection_attritional[1:length(LDFstate_selection_Attritional)]
        LDF_selection_display_attritional[length(LDF_selection_display_attritional)] <- NA
        

        
        colnames(LDF_selection_display) <- colnames(LDFstate_selection_All)
        colnames(LDF_selection_display_weather) <- colnames(LDFstate_selection_Weather)
        colnames(LDF_selection_display_attritional) <- colnames(LDFstate_selection_Attritional)
        
        output$LDFallstatecumulative <- renderDataTable(datatable(LDF_selection_display,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
        output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDF_selection_display_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
        output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDF_selection_display_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
        
        } else if (input$LDFstateweight <1) {
        
        LDFstate_selection_All_proxy <<- LDFstate_selection_All
        LDFstate_selection_All_proxy <<- if (ncol(LDFstate_selection_All_proxy)<ncol(LDFcw_selection_All)) {
          LDFstate_selection_All_proxy[(ncol(LDFstate_selection_All_proxy)):ncol(LDFcw_selection_All)]<<-1
          LDFstate_selection_All_proxy
        } else {
          LDFstate_selection_All_proxy}
        
        LDFstate_selection_Weather_proxy <<- LDFstate_selection_Weather
        LDFstate_selection_Weather_proxy <<- if (ncol(LDFstate_selection_Weather_proxy)<ncol(LDFcw_selection_Weather)) {
          LDFstate_selection_Weather_proxy[(ncol(LDFstate_selection_Weather_proxy)):ncol(LDFcw_selection_Weather)]<<-1
          LDFstate_selection_Weather_proxy
        } else {
          LDFstate_selection_Weather_proxy}
        
        LDFstate_selection_Attritional_proxy <<- LDFstate_selection_Attritional
        LDFstate_selection_Attritional_proxy <<- if (ncol(LDFstate_selection_Attritional_proxy)<ncol(LDFcw_selection_Attritional)) {
          LDFstate_selection_Attritional_proxy[(ncol(LDFstate_selection_Attritional_proxy)):ncol(LDFcw_selection_Attritional)]<<-1
          LDFstate_selection_Attritional_proxy
        } else {
          LDFstate_selection_Attritional_proxy}
       
       LDF_selection <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_All[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_All_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_All))]
       LDF_selection_weather <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_Weather[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_Weather_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_Weather))]
      
       LDF_selection_attritional <<- cbind(data.frame(Name = c("Selection", 'Cumulative')), LDFcw_selection_Attritional[-1]*(1-as.numeric(input$LDFstateweight)) + LDFstate_selection_Attritional_proxy[-1]*as.numeric(input$LDFstateweight))[1:(ncol(LDFstate_selection_Attritional))]
       
       LDFstate_selection_All_copy <<- LDFstate_selection_All[1,][1:(ncol(LDFstate_selection_All))]
       
       LDFstate_selection_All_copy[1] <- paste(input$State,'Selection', sep = ' ')

       LDFcw_selection_All_weighted <- LDFcw_selection_All[1,][1:(ncol(LDFstate_selection_All_copy))]
       LDFcw_selection_All_weighted[1] <- 'CW Selection'
       LDFcw_selection_All_weighted[ncol(LDFcw_selection_All_weighted)]<-NA
       weighted_plot_all <- LDFstate_selection_All_copy
       weighted_plot_all['first',] <- NA
       weighted_plot_all['first2',] <- NA
       weighted_plot_all['cw',] <- LDFcw_selection_All_weighted
       weighted_plot_all['second',] <- NA
       weighted_plot_all['second2',] <- NA
       weighted_plot_all['weighted_select',] <- LDF_selection[1,]
       weighted_plot_all['weighted_cum',] <- LDF_selection[2,]
       weighted_plot_all[ncol(weighted_plot_all)]<- NA
       weighted_plot_all<<-weighted_plot_all
       
       LDFstate_selection_Weather_copy <- LDFstate_selection_Weather[1,][1:(ncol(LDFstate_selection_Weather))]
       LDFstate_selection_Weather_copy[1] <- paste(input$State,'Selection', sep = ' ')
       LDFcw_selection_Weather_weighted <- LDFcw_selection_Weather[1,][1:(ncol(LDFstate_selection_Weather_copy))]
       LDFcw_selection_Weather_weighted[ncol(LDFcw_selection_Weather_weighted)]<-NA
       LDFcw_selection_Weather_weighted[1] <- 'CW Selection'
       weighted_plot_weather <- LDFstate_selection_Weather_copy
       weighted_plot_weather['first',] <- NA
       weighted_plot_weather['first2',] <- NA
       weighted_plot_weather['cw',] <- LDFcw_selection_Weather_weighted
       weighted_plot_weather['second',] <- NA
       weighted_plot_weather['second2',] <- NA
       weighted_plot_weather['weighted_select',] <- LDF_selection_weather[1,]
       weighted_plot_weather['weighted_cum',] <- LDF_selection_weather[2,]
       weighted_plot_weather[ncol(weighted_plot_weather)] <- NA
       weighted_plot_weather<<-weighted_plot_weather
       
       LDFstate_selection_Attritional_copy <- LDFstate_selection_Attritional[1,][1:(ncol(LDFstate_selection_Attritional))]
       LDFstate_selection_Attritional_copy[1] <- paste(input$State,'Selection', sep = ' ')
       LDFcw_selection_Attritional_weighted <- LDFcw_selection_Attritional[1,][1:(ncol(LDFstate_selection_Attritional_copy))]
       LDFcw_selection_Attritional_weighted[ncol(LDFcw_selection_Attritional_weighted)]<-NA
       LDFcw_selection_Attritional_weighted[1] <- 'CW Selection'
       weighted_plot_attritional <- LDFstate_selection_Attritional_copy
       weighted_plot_attritional['first',] <- NA
       weighted_plot_attritional['first',] <- NA
       weighted_plot_attritional['cw',] <- LDFcw_selection_Attritional_weighted
       weighted_plot_attritional['second',] <- NA
       weighted_plot_attritional['second',] <- NA
       weighted_plot_attritional['weighted_select',] <- LDF_selection_attritional[1,]
       weighted_plot_attritional['weighted_cum',] <- LDF_selection_attritional[2,]
       weighted_plot_attritional[ncol(weighted_plot_attritional)] <- NA
       weighted_plot_attritional<<- weighted_plot_attritional
       
       output$LDFallstatecumulative <- renderDataTable(datatable(weighted_plot_all,selection = 'none',class = 'compact',options = list(dom = 't'), rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All_copy)),digits = 3))
       output$LDFallstatecumulativeWeather <- renderDataTable(datatable(weighted_plot_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
       output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(weighted_plot_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
       
       } else {
        LDF_selection <<- LDFstate_selection_All
        LDF_selection_weather <<- LDFstate_selection_Weather
        LDF_selection_attritional <<- LDFstate_selection_Attritional
        
        
        output$LDFallstatecumulative <- renderDataTable(datatable(LDF_selection,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_All)-1),digits = 3))
        output$LDFallstatecumulativeWeather <- renderDataTable(datatable(LDF_selection_weather,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Weather)-1),digits = 3))
        output$LDFallstatecumulativeAttritional <- renderDataTable(datatable(LDF_selection_attritional,selection = 'none',class = 'compact',options = list(dom = 't'),rownames=FALSE)%>%formatRound(2:(length(LDFstate_selection_Attritional)-1),digits = 3))
        
        
        
        }
    },priority = 1)
  
  
  observeEvent( {c(input$Tablename, input$EvaluationDate,input$IndicationDate, input$State, input$CATstateweight,input$cw_exclude,input$state_exclude,input$expense_load_output_selected_cell_edit,input$useCalcExpense)},
                {
                  selected_expense_data <<- expense_select(input$Tablename, evaluation_use,input$IndicationDate, input$State, input$CATstateweight,input$cw_exclude,input$state_exclude)
                  if (as.numeric(selected_expense_data_selected)==as.numeric(selected_expense_data) | input$useCalcExpense | as.numeric(selected_expense_data_selected)==0) {
                    selected_expense_data_selected <<- selected_expense_data
                    row.names(selected_expense_data_selected) <<- c('Selected Expense Load')
                  }
                  output$expense_load_output <- renderDT(datatable(selected_expense_data,selection = 'none',class = 'compact',colnames='',rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))
                  output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))

                  modeled_cat <<- modeled_cat_load(input$Tablename, evaluation_use,input$IndicationDate, input$State,input$IncludePolicyFee,as.numeric(selected_expense_data_selected))
                  
                  output$ModeledCatLoad <- renderDT(datatable(modeled_cat,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%formatRound(c(1,2,3,5,6),digits = 0)%>%formatPercentage(c(4,7,8,10,11,12),digits = 1)%>%formatRound(c(9),digits = 2))
                  reinsurance_exhibit_table <<- reinsurance_exhibit(state_name_full(input$State), 
                                                                   table_name(input$Tablename), 
                                                                   reinsurance(input$State,evaluation_use,input$Tablename,'Hurricane'), 
                                                                   reinsurance(input$State,evaluation_use,input$Tablename,'STS'),
                                                                   reinsurance(input$State,evaluation_use,input$Tablename,'All Perils'),
                                                                   modeled_cat)
                  output$reinsuranceExhibit <- renderDT(datatable(reinsurance_exhibit_table,selection = 'none',class = 'compact', rownames=F, options = list(dom='t'))%>%
                                                          formatPercentage(5,digits = 1 ))
                  
                  },priority = 2
                )
  observeEvent( {c(input$expense_load_output_selected_cell_edit)},
                { 
                   selected_expense_data_selected <<- editData(selected_expense_data_selected,input$expense_load_output_selected_cell_edit,'expense_load_output_selected',rownames = T)
                   
                   output$expense_load_output_selected <- renderDT(datatable(selected_expense_data_selected,selection = 'none',class = 'compact',colnames='',editable = list(target = 'cell'),rownames = T,options = list(dom='t',paging=F))%>%formatRound(c(1),digits=2))

                },priority = 2
  )
  observeEvent( {
    c(input$Tablename,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendCW, input$projLossTrendCW,input$capped)
  },
  {
  #load in all the LLL data tables for each tab
  LLLdata_CW <<- LLL_data(input$Tablename,input$IndicationDate, evaluation_use,input$proposedEffective,'CW', input$currentLossTrendCW, input$projLossTrendCW,input$capped)
  LLLdata_CW_total <<- LLL_select_data(LLLdata_CW,'All Perils')
  LLLdata_CW_fire <<- LLL_select_data(LLLdata_CW,'FIRE')
  LLLdata_CW_water <<- LLL_select_data(LLLdata_CW,'WATER')
  LLLdata_CW_theft <<- LLL_select_data(LLLdata_CW,'THEFTVMM')
  LLLdata_CW_liability <<- LLL_select_data(LLLdata_CW,'LIABILITY')
  LLLdata_CW_otherAOP <<- LLL_select_data(LLLdata_CW,'OTHERAOP')
  LLLdata_CW_weather <<- LLL_select_data(LLLdata_CW,'NCW')
  LLLdata_CW_total_selected<<-LLL_selections(LLLdata_CW_total,'Selected')
  LLLdata_CW_fire_selected<<-LLL_selections(LLLdata_CW_fire,'Selected')
  LLLdata_CW_water_selected<<-LLL_selections(LLLdata_CW_water,'Selected')
  LLLdata_CW_theft_selected<<-LLL_selections(LLLdata_CW_theft,'Selected')
  LLLdata_CW_liability_selected<<-LLL_selections(LLLdata_CW_liability,'Selected')
  LLLdata_CW_otherAOP_selected<<-LLL_selections(LLLdata_CW_otherAOP,'Selected')
  LLLdata_CW_weather_selected<<-LLL_selections(LLLdata_CW_weather,'Selected')
  
  output$LLLTotalTableCW <- renderDT(datatable(LLLdata_CW_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWTotal<- renderDT(datatable(LLL_selections(LLLdata_CW_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWTotalSelected<- renderDT(datatable(LLLdata_CW_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWFire <- renderDT(datatable(LLLdata_CW_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWFire<- renderDT(datatable(LLL_selections(LLLdata_CW_fire,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWFireSelected<- renderDT(datatable(LLLdata_CW_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWWater <- renderDT(datatable(LLLdata_CW_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWWater<- renderDT(datatable(LLL_selections(LLLdata_CW_water,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWWaterSelected<- renderDT(datatable(LLLdata_CW_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWTheft <- renderDT(datatable(LLLdata_CW_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWTheft<- renderDT(datatable(LLL_selections(LLLdata_CW_theft,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWTheftSelect<- renderDT(datatable(LLLdata_CW_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWLiability <- renderDT(datatable(LLLdata_CW_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWLiability<- renderDT(datatable(LLL_selections(LLLdata_CW_liability,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWLiabilitySelected<- renderDT(datatable(LLLdata_CW_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWOtherAOP <- renderDT(datatable(LLLdata_CW_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_CW_otherAOP,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWOtherAOPSelected<- renderDT(datatable(LLLdata_CW_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  output$LLLTotalTableCWWeather <- renderDT(datatable(LLLdata_CW_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
  output$LLLselectCWWeather<- renderDT(datatable(LLL_selections(LLLdata_CW_weather,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  output$LLLselectCWWeatherSelected<- renderDT(datatable(LLLdata_CW_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
  
  },priority = 2
)
  
  observeEvent(input$LLLselectCWTotalSelected_cell_edit,
               {LLLdata_CW_total_selected <<- editData(LLLdata_CW_total_selected,input$LLLselectCWTotalSelected_cell_edit,'LLLselectCWTotalSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWFireSelected_cell_edit,
               {LLLdata_CW_fire_selected <<- editData(LLLdata_CW_fire_selected,input$LLLselectCWFireSelected_cell_edit,'LLLselectCWFireSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWWaterSelected_cell_edit,
               {LLLdata_CW_water_selected <<- editData(LLLdata_CW_water_selected,input$LLLselectCWWaterSelected_cell_edit,'LLLselectCWWaterSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWTheftSelected_cell_edit,
               {LLLdata_CW_theft_selected <<- editData(LLLdata_CW_theft_selected,input$LLLselectCWTheftSelected_cell_edit,'LLLselectCWTheftSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWLiabilitySelected_cell_edit,
               {LLLdata_CW_liability_selected <<- editData(LLLdata_CW_liability_selected,input$LLLselectCWLiabilitySelected_cell_edit,'LLLselectCWLiabilitySelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWOtherAOPSelected_cell_edit,
               {LLLdata_CW_otherAOP_selected <<- editData(LLLdata_CW_otherAOP_selected,input$LLLselectCWOtherAOPSelected_cell_edit,'LLLselectCWOtherAOPSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectCWWeatherSelected_cell_edit,
               {LLLdata_CW_weather_selected <<- editData(LLLdata_CW_weather_selected,input$LLLselectCWWeatherSelected_cell_edit,'LLLselectCWWeatherSelect',rownames = TRUE) },priority = 2) 
  
  observeEvent( {
    c(input$State,input$Tablename,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState,input$capped)
  },
  {
    LLLdata_state <<- LLL_data(input$Tablename,input$IndicationDate, evaluation_use,input$proposedEffective,input$State, input$currentLossTrendState, input$projLossTrendState,input$capped)
    LLLdata_state_total <<-LLL_select_data(LLLdata_state,'All Perils')
    LLLdata_state_fire <<-LLL_select_data(LLLdata_state,'FIRE')
    LLLdata_state_water <<-LLL_select_data(LLLdata_state,'WATER')
    LLLdata_state_theft <<-LLL_select_data(LLLdata_state,'THEFTVMM')
    LLLdata_state_liability <<-LLL_select_data(LLLdata_state,'LIABILITY')
    LLLdata_state_otherAOP <<-LLL_select_data(LLLdata_state,'OTHERAOP')
    LLLdata_state_weather <<-LLL_select_data(LLLdata_state,'NCW')
    LLLdata_state_total_selected<<-LLL_selections(LLLdata_state_total,'Selected')
    LLLdata_state_fire_selected<<-LLL_selections(LLLdata_state_fire,'Selected')
    LLLdata_state_water_selected<<-LLL_selections(LLLdata_state_water,'Selected')
    LLLdata_state_theft_selected<<-LLL_selections(LLLdata_state_theft,'Selected')
    LLLdata_state_liability_selected<<-LLL_selections(LLLdata_state_liability,'Selected')
    LLLdata_state_otherAOP_selected<<-LLL_selections(LLLdata_state_otherAOP,'Selected')
    LLLdata_state_weather_selected<<-LLL_selections(LLLdata_state_weather,'Selected')
    
    output$LLLTotalTablestate <- renderDT(datatable(LLLdata_state_total,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTotal<- renderDT(datatable(LLL_selections(LLLdata_state_total,'Calculated'),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTotalSelected<- renderDT(datatable(LLLdata_state_total_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateFire <- renderDT(datatable(LLLdata_state_fire,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateFire<- renderDT(datatable(LLL_selections(LLLdata_state_fire,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateFireSelected<- renderDT(datatable(LLLdata_state_fire_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWater<- renderDT(datatable(LLLdata_state_water,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWater<- renderDT(datatable(LLL_selections(LLLdata_state_water,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWaterSelected<- renderDT(datatable(LLLdata_state_water_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateTheft <- renderDT(datatable(LLLdata_state_theft,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateTheft<- renderDT(datatable(LLL_selections(LLLdata_state_theft,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateTheftSelected<- renderDT(datatable(LLLdata_state_theft_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateLiability <- renderDT(datatable(LLLdata_state_liability,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateLiability<- renderDT(datatable(LLL_selections(LLLdata_state_liability,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateLiabilitySelected<- renderDT(datatable(LLLdata_state_liability_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateOtherAOP <- renderDT(datatable(LLLdata_state_otherAOP,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateOtherAOP<- renderDT(datatable(LLL_selections(LLLdata_state_otherAOP,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateOtherAOPSelected<- renderDT(datatable(LLLdata_state_otherAOP_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    output$LLLTotalTablestateWeather <- renderDT(datatable(LLLdata_state_weather,selection = 'none',class = 'compact',options = list(dom='t',paging=F),rownames = F)%>%formatRound(c(2,3,4,5,6),digits = 0)%>%formatPercentage(7,digits=1))
    output$LLLselectStateWeather<- renderDT(datatable(LLL_selections(LLLdata_state_weather,'Calculated'),class = 'compact',editable = list(target = 'cell'),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    output$LLLselectStateWeatherSelected<- renderDT(datatable(LLLdata_state_weather_selected,class = 'compact',colnames='',selection = 'none',editable = list(target = 'cell', disable = list(columns = c(0))),options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
    
    },
  priority = 2
  )
  
  observeEvent(input$LLLselectStateTotalSelected_cell_edit,
               {LLLdata_state_total_selected <<- editData(LLLdata_state_total_selected,input$LLLselectStateTotalSelected_cell_edit,'LLLselectStateTotalSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateFireSelected_cell_edit,
               {LLLdata_state_fire_selected <<- editData(LLLdata_state_fire_selected,input$LLLselectStateFireSelected_cell_edit,'LLLselectStateFireSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateWaterSelected_cell_edit,
               {LLLdata_state_water_selected <<- editData(LLLdata_state_water_selected,input$LLLselectStateWaterSelected_cell_edit,'LLLselectStateWaterSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateTheftSelected_cell_edit,
               {LLLdata_state_theft_selected <<- editData(LLLdata_state_theft_selected,input$LLLselectStateTheftSelected_cell_edit,'LLLselectStateTheftSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateLiabilitySelected_cell_edit,
               {LLLdata_state_liability_selected <<- editData(LLLdata_state_liability_selected,input$LLLselectStateLiabilitySelected_cell_edit,'LLLselectStateLiabilitySelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateOtherAOPSelected_cell_edit,
               {LLLdata_state_otherAOP_selected <<- editData(LLLdata_state_otherAOP_selected,input$LLLselectStateOtherAOPSelected_cell_edit,'LLLselectStateOtherAOPSelect',rownames = TRUE) },priority = 2) 
  observeEvent(input$LLLselectStateWeatherSelected_cell_edit,
               {LLLdata_state_weather_selected <<- editData(LLLdata_state_weather_selected,input$LLLselectStateWeatherSelected_cell_edit,'LLLselectStateWeatherSelect',rownames = TRUE) },priority = 2) 
  
  
  observeEvent({c(input$State,input$Tablename,input$IndicationDate, input$EvaluationDate,input$proposedEffective,input$currentLossTrendState, input$projLossTrendState,input$capped,input$LLLstateweightTotal,
                  input$LLLselectCWTotalSelected_cell_edit,
                  input$LLLselectCWFireSelected_cell_edit,
                  input$LLLselectCWWaterSelected_cell_edit,
                  input$LLLselectCWTheftSelected_cell_edit,
                  input$LLLselectCWLiabilitySelected_cell_edit,
                  input$LLLselectCWOtherAOPSelected_cell_edit,
                  input$LLLselectCWWeatherSelected_cell_edit,
                  input$LLLselectStateTotalSelected_cell_edit,
                  input$LLLselectStateFireSelected_cell_edit,
                  input$LLLselectStateWaterSelected_cell_edit,
                  input$LLLselectStateTheftSelected_cell_edit,
                  input$LLLselectStateLiabilitySelected_cell_edit,
                  input$LLLselectStateOtherAOPSelected_cell_edit,
                  input$LLLselectStateWeatherSelected_cell_edit
  )},
               {
                 LLLTotal     <<-reactive({LLL_weighted(LLLdata_CW_total_selected    ,LLLdata_state_total_selected    ,input$LLLstateweightTotal)})
                 LLLFire      <<-reactive({LLL_weighted(LLLdata_CW_fire_selected     ,LLLdata_state_fire_selected     ,input$LLLstateweightTotal)})
                 LLLWater     <<-reactive({LLL_weighted(LLLdata_CW_water_selected    ,LLLdata_state_water_selected    ,input$LLLstateweightTotal)})
                 LLLTheft     <<-reactive({LLL_weighted(LLLdata_CW_theft_selected    ,LLLdata_state_theft_selected    ,input$LLLstateweightTotal)})
                 LLLLiability <<-reactive({LLL_weighted(LLLdata_CW_liability_selected,LLLdata_state_liability_selected,input$LLLstateweightTotal)})
                 LLLOtherAOP  <<-reactive({LLL_weighted(LLLdata_CW_otherAOP_selected ,LLLdata_state_otherAOP_selected ,input$LLLstateweightTotal)})
                 LLLWeather   <<-reactive({LLL_weighted(LLLdata_CW_weather_selected  ,LLLdata_state_weather_selected  ,input$LLLstateweightTotal)})
                 
                 output$LLLweightedTotal <- renderDT(datatable(LLLTotal(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedFire <- renderDT(datatable(LLLFire(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedWater <- renderDT(datatable(LLLWater(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedTheft <- renderDT(datatable(LLLTheft(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedLiability <- renderDT(datatable(LLLLiability(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedOtherAOP <- renderDT(datatable(LLLOtherAOP(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 output$LLLweightedWeather <- renderDT(datatable(LLLWeather(),selection = 'none',class = 'compact',options = list(dom='t',paging=F))%>%formatRound(c(1),digits=3))
                 
               },priority = 1
  )
  
  #save selections to SQL
  observeEvent(input$ldfselectionToSQL,
                 {save_selections(input$IndicationDate,evaluation_use, 'CW','All Perils','In Progress',LDFcw_selection_All,NA,input$selected_by[[1]],0)},priority = 1)
  observeEvent(input$ldfselectionToSQLWeather,
               {save_selections(input$IndicationDate,evaluation_use, 'CW','Weather','In Progress',LDFcw_selection_Weather,NA,input$selected_by[[1]],0)},priority = 1)
  observeEvent(input$ldfselectionToSQLAttritional, 
               {save_selections(input$IndicationDate,evaluation_use, 'CW','Attritional','In Progress',LDFcw_selection_Attritional,NA,input$selected_by[[1]],0)},priority = 1)
  observeEvent(input$ldfselectionToSQLstate, 
               {save_selections(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],0)},priority = 1)
  observeEvent(input$ldfselectionToSQLstateWeather, 
               {save_selections(input$IndicationDate,evaluation_use, input$State,'Weather','In Progress',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],0)},priority = 1)
  observeEvent(input$ldfselectionToSQLstateAttritional, 
               {save_selections(input$IndicationDate,evaluation_use, input$State,'Attritional','In Progress',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],0)},priority = 1)
   #on_level, coverageReport, targitPrem, Policyfee, perilTab,currentPrem, projPrem,proposedEffectiveDate,IndicationDate,LDF, currentLoss, projLoss, expenseData,modeledCat, catLoad
  
  # IndicationDate,EvaluationDate, Region,Class,Status,
  # catLoadWeight,catLoadSelection,LDFweight,curLossTrend,projLossTrend,LLLweight,LLLfire,LLLwater,LLLtheft,LLLliability,LLLotherAOP,LLLweather,
  # curPremTrend,projPremTrend,
  # selected_by,reviewed_by

  observeEvent({input$catLoadtoSQL},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                     input$selected_by[[1]],0)
               }
               )
  observeEvent({input$stateLossTrendtoSQL},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],0)
               }
  )
  observeEvent({input$LLLselectionsToSQL},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],0)
               }
  )
  observeEvent({input$ldfselectionToSQLstate},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],0)
               }
  )
  observeEvent({input$PremiumSave},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],0)
               }
  )
  observeEvent({input$nonmodeledsave},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Progress',input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],0)
               }
  )
  observeEvent({input$cwLossTrendtoSQL},#input$catLoadtoSQL)},
               {
                 save_selections_cw(input$IndicationDate,evaluation_use, 'CW' ,'All Perils','In Progress',input$currentLossTrendCW,input$projLossTrendCW,input$cw_exclude,input$selected_by[[1]],0) 
               })
  observe({
    #pull the most recent LDF selections on upload, so you don't always have to click into the LDF page first!
    dummy <<- c(input$LDFallstateaveragesAttritional_cell_edit,input$LDFstateAttritionalAselect,input$LDFstateAttritionalBselect,input$LDFstateAttritionalCselect,input$LDFstateAttritionalDselect,input$LDFstateAttritionalEselect,input$LDFstateAttritionalFselect,input$LDFstateAttritionalGselect,input$LDFstateAttritionalHselect,input$LDFstateAttritionalIselect,
                input$LDFallstateaveragesWeather_cell_edit,input$LDFstateWeatherAselect,input$LDFstateWeatherBselect,input$LDFstateWeatherCselect,input$LDFstateWeatherDselect,input$LDFstateWeatherEselect,input$LDFstateWeatherFselect,input$LDFstateWeatherGselect,input$LDFstateWeatherHselect,input$LDFstateWeatherIselect,
                input$LDFallstateaverages_cell_edit,input$LDFstateAselect,input$LDFstateBselect,input$LDFstateCselect,input$LDFstateDselect,input$LDFstateEselect,input$LDFstateFselect,input$LDFstateGselect,input$LDFstateHselect,input$LDFstateIselect,
                input$LDFallCWaveragesAttritional_cell_edit,input$LDFAttritionalAselect,input$LDFAttritionalBselect,input$LDFAttritionalCselect,input$LDFAttritionalDselect,input$LDFAttritionalEselect,input$LDFAttritionalFselect,input$LDFAttritionalGselect,input$LDFAttritionalHselect,input$LDFAttritionalIselect,
                input$LDFallCWaveragesWeather_cell_edit,input$LDFWeatherAselect,input$LDFWeatherBselect,input$LDFWeatherCselect,input$LDFWeatherDselect,input$LDFWeatherEselect,input$LDFWeatherFselect,input$LDFWeatherGselect,input$LDFWeatherHselect,input$LDFWeatherIselect,
                input$LDFallCWaverages_cell_edit,input$LDFAselect,input$LDFBselect,input$LDFCselect,input$LDFDselect,input$LDFEselect,input$LDFFselect,input$LDFGselect,input$LDFHselect,input$LDFIselect,
                input$LDFstateweight,input$useCalcExpense,input$catLoadtoSQL,input$CATstateweight,input$cw_exclude,input$state_exclude
                )
    print('ind1')
    on_level_load <<- on_level_factors_load(input$Tablename,input$IndicationDate, input$State)
    coverage_report_data <<- coverage_report_load(input$IndicationDate,evaluation_use, input$State,input$Tablename)
    losses_claims <<- rate_level_losses(input$IndicationDate, evaluation_use, input$State)
    #data from the rate level indication, 
    total_data <<- rate_level_indication(on_level_load,
                                        coverage_report_data,
                                        targit_EP_load(input$IndicationDate,evaluation_use, input$State),
                                        input$IncludePolicyFee,
                                        "All Perils",
                                        input$currentPremiumTrend,
                                        input$projPremiumTrend,
                                        input$proposedEffective,
                                        input$IndicationDate,
                                        evaluation_use,
                                        input$State,
                                        LDF_selection,
                                        input$currentLossTrendState,
                                        input$projLossTrendState,
                                        as.numeric(LLLTotal()['Selected','Weighted LLL'])#place holder for LL loads. Need to build out the selection still
                                        )
    #separate function for the perils rate level tabs because they look different. 
    fireLosses <<- rate_level_indication_peril(on_level_load, 
                                            input$proposedEffective,
                                            input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                            input$currentLossTrendState,
                                            input$projLossTrendState, as.numeric(LLLFire()['Selected','Weighted LLL']),
                                            coverage_report_data,'Fire')
    
    firePremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                  coverage_report_data, 'Fire',input$currentPremiumTrend,
                                                  input$projPremiumTrend,
                                                  input$proposedEffective,
                                                  input$IndicationDate,
                                                  evaluation_use,
                                                  input$State,
                                                  input$rateByPeril)
    
    output$FireIndicationLosses <- renderDT(datatable(fireLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    output$FireIndicationPremium <- renderDT(datatable(firePremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4), digits = 3))
    
    fireSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,fireLosses, firePremium,expense_ratios)
    output$FireIndicationSummary<- renderDT(datatable(fireSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    waterLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLWater()['Selected','Weighted LLL']),
                                               coverage_report_data,'Water')
    
    output$WaterIndicationLosses <- renderDT(datatable(waterLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    
    waterPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                     coverage_report_data, 'Water',input$currentPremiumTrend,
                                                     input$projPremiumTrend,
                                                     input$proposedEffective,
                                                     input$IndicationDate,
                                                     evaluation_use,
                                                     input$State,
                                                     input$rateByPeril)
    output$WaterIndicationPremium <- renderDT(datatable(waterPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                               formatRound(c(2,6,7), digits = 0)%>%
                                               formatRound(c(3,4), digits = 3))
    waterSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,waterLosses, waterPremium,expense_ratios)
    output$WaterIndicationSummary<- renderDT(datatable(waterSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    theftLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                               coverage_report_data,'TheftVMM')
    
    output$TheftIndicationLosses <- renderDT(datatable(theftLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    theftPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'TheftVMM',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      input$rateByPeril)
    output$TheftIndicationPremium <- renderDT(datatable(theftPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    theftSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,theftLosses, theftPremium,expense_ratios)
    output$TheftIndicationSummary<- renderDT(datatable(theftSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    OtherAOPLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                               coverage_report_data,'OtherAOP')
    
    output$OtherAOPIndicationLosses <- renderDT(datatable(OtherAOPLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    OtherAOPPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'OtherAOP',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      input$rateByPeril)
    output$OtherAOPIndicationPremium <- renderDT(datatable(OtherAOPPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    OtherAOPSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,OtherAOPLosses, OtherAOPPremium,expense_ratios)
    output$OtherAOPIndicationSummary<- renderDT(datatable(OtherAOPSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                              formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    liabilityLosses <<- rate_level_indication_peril(on_level_load,
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_attritional,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                               coverage_report_data,'Liability')

    output$LiabilityIndicationLosses <- renderDT(datatable(liabilityLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    liabilityPremium <<- rate_level_indication_prem_peril(on_level_load,
                                                      coverage_report_data, 'Liability',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                      input$rateByPeril)
    output$LiabilityIndicationPremium <- renderDT(datatable(liabilityPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    liabilitySummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,liabilityLosses, liabilityPremium,expense_ratios)
    output$LiabilityIndicationSummary<- renderDT(datatable(liabilitySummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))

    NCWLosses <<- rate_level_indication_peril(on_level_load, 
                                               input$proposedEffective,
                                               input$IndicationDate,evaluation_use,input$State,LDF_selection_weather,
                                               input$currentLossTrendState,
                                               input$projLossTrendState, as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                               coverage_report_data,'NCW')
    
    output$NCWIndicationLosses <- renderDT(datatable(NCWLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                              formatRound(c(2,6,7), digits = 0)%>%
                                              formatRound(c(3,4,5), digits = 3))
    NCWPremium <<- rate_level_indication_prem_peril(on_level_load, 
                                                      coverage_report_data, 'NCW',input$currentPremiumTrend,
                                                      input$projPremiumTrend,
                                                      input$proposedEffective,
                                                      input$IndicationDate,
                                                      evaluation_use,
                                                      input$State,
                                                    input$rateByPeril)
    output$NCWIndicationPremium <- renderDT(datatable(NCWPremium,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = '_all'))),rownames=F)%>%
                                                formatRound(c(2,6,7), digits = 0)%>%
                                                formatRound(c(3,4), digits = 3))
    NCWSummary <<- by_peril_indication_summary(input$State, evaluation_use, input$Tablename,NCWLosses, NCWPremium,expense_ratios)
    output$NCWIndicationSummary<- renderDT(datatable(NCWSummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1,rows = c(1,2,3,4,5,6,8,9,10,11)))
    
    HULosses <<- cat_peril_table('Hurricane',modeled_cat,input$HUexpFactor)
    HUsummary <<- cat_peril_summary(input$State, evaluation_use,input$Tablename,HULosses, expense_ratios,'Hurricane',input$HUexpFactor,input$HUyearExpAdj,modeled_cat)
    output$HUIndication <- renderDT(datatable(HULosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                      formatRound(c(2,3), digits = 0)%>%
                                      formatRound(c(4,6), digits = 3)%>%
                                      formatPercentage(c(5,7),digits = 1))
    output$HUIndicationSummary<- renderDT(datatable(HUsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    STSLosses <<- cat_peril_table('STS',modeled_cat,input$STSexpFactor)
    STSsummary <<- cat_peril_summary(input$State, evaluation_use,input$Tablename,STSLosses, expense_ratios,'STS',input$STSexpFactor,input$STSyearExpAdj,modeled_cat)
    output$STSIndication <- renderDT(datatable(STSLosses,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))),rownames=F)%>%
                                      formatRound(c(2,3), digits = 0)%>%
                                      formatRound(c(4,6), digits = 3)%>%
                                      formatPercentage(c(5,7),digits = 1))
    
    output$STSIndicationSummary<- renderDT(datatable(STSsummary,selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    #display the summary table
    output$TotalRateLevelIndication <- renderDT(datatable(total_data,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t'),rownames=F)%>%
                                                formatRound(c(2,5,6,10),digits = 0)%>%
                                                formatRound(c(3,4,7,8,9), digits = 3)%>%
                                                formatPercentage(c(11),digits = 1))
    #display all the results
    TotalSummary <<-rate_level_summary(total_data,
                                       modeled_cat,
                                       expense_ratios,
                                       losses_claims,
                                       input$projPremiumTrend,
                                       input$projLossTrendState,
                                       input$STSexpFactor,
                                       input$HUexpFactor)
    output$TotalRateLevelSummary <- renderDT(datatable(TotalSummary,colnames = ' ' ,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))))%>%
                                               formatPercentage(c(2), digits=1))
    
    indication_memo_data <<-indication_memo(TotalSummary, fireSummary, waterSummary, theftSummary, liabilitySummary, OtherAOPSummary, NCWSummary, STSsummary, HUsummary,coverage_report_data,non_peril_pull(input$IndicationDate,evaluation_use,input$State))#Replace with NonPeril

    output$memo <-  renderDT(datatable(indication_memo_data,selection = 'none',class = 'compact',rownames = F,options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',targets = '_all'))))%>%
                               formatPercentage(c(2,3,4), digits=1))
    
    output$FireRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Fire'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$WaterRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Water'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$TheftRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Theft & VMM'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$LiabilityRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Liability'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$OtherAOPRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'All Other Perils'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$NCWRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Non-Cat Weather'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$STSRateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'STS'),class = 'compact',selection = 'none',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    output$HURateLevelChange <- renderDT(datatable(memoToTables(indication_memo_data,'Hurricane'),selection = 'none',class = 'compact',colnames = ' ',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(0,2)),list(width ='500px',targets = c(1)))),rownames=F)%>%
                                             formatPercentage(c(3), digits = 1))
    
    
    
    #load the territorial CAT experience adjustment factors
    TerSTSexpAdj <<- ExperienceFactor(input$Tablename,input$IndicationDate, evaluation_use, input$State, 'STSexpFactor')
    TerHUexpAdj  <<- ExperienceFactor(input$Tablename,input$IndicationDate, evaluation_use, input$State, 'HUexpFactor')
    
    LossesCappedTable <<- LossesCapped(input$Tablename,input$IndicationDate, evaluation_use, input$State)
    EHY_PremTable <<- EHY_Prem(input$Tablename,input$IndicationDate, evaluation_use, input$State)
    InforceAALTable <<- InforceAAL(input$Tablename,input$IndicationDate, evaluation_use, input$State)
    
    SelectionTrendData <<- total_data[c(1:5), c(1,4,7,8)]
    colnames(SelectionTrendData) <- c('Adj', 'PremTrend','LDF','LossTrend')
    SelectionTrendDataAtt <<- data.frame(Adj = unlist(fireLosses[1]), LDF = unlist(fireLosses[3]))
    SelectionTrendDataWeather <<- data.frame(Adj = unlist(NCWLosses[1]), LDF = unlist(NCWLosses[3]))
    # LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
    # TargetLossRatio,TargetIndicatedChange,nonPeril
    
    TerritorialExhibitData <<- TerritorialExhibit(LossesCappedTable,EHY_PremTable,InforceAALTable,SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTotal()['Selected','Weighted LLL']),
                                                  SelectionTrendData[,c(1,3)],TerHUexpAdj,TerSTSexpAdj,selected_expense_data_selected,as.numeric(modeled_cat$`Modeled Hurricane Loss & LAE Ratio`) *  input$HUexpFactor,
                                                  as.numeric(modeled_cat$`Modeled CS Loss & LAE Ratio`) *  input$STSexpFactor,
                                                  reinsurance(input$State,evaluation_use,input$Tablename,'Hurricane'),reinsurance(input$State,evaluation_use,input$Tablename,'STS'),1082,
                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                  as.numeric(TotalSummary[10,2]),non_peril_pull(input$IndicationDate,evaluation_use,input$State))###STOP
    

    output$TerritorialExhibit <- renderDT(datatable(TerritorialExhibitData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(width = '100px',className = 'dt-right',targets = c(3,11,12)),list(className = 'dt-right',targets = c(0:12)))),rownames=F)%>%
                                            formatRound(c(1:5),digits = 0)%>%
                                            formatPercentage(c(6:13), digits = 1))
    #LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
    #TargetLossRatio,TargetIndicatedChange,nonPeril,peril
    
    TerritorialExhibitFireData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'Fire'),EHY_PremTable,InforceAALTable,
                                                                  SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLFire()['Selected','Weighted LLL']),
                                                                  SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                  as.numeric(memoToTables(indication_memo_data,'Fire')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'Fire')
    
    output$TerritorialExhibitFire <- renderDT(datatable(TerritorialExhibitFireData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                              formatRound(c(1:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1))
    TerritorialExhibitWaterData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'Water'),EHY_PremTable,InforceAALTable,
                                                                   SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWater()['Selected','Weighted LLL']),
                                                                   SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                   as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                   as.numeric(memoToTables(indication_memo_data,'Water')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'Water')
    
    output$TerritorialExhibitWater <- renderDT(datatable(TerritorialExhibitWaterData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                formatRound(c(1:5,7),digits = 0)%>%
                                                formatPercentage(c(6,8:11), digits = 1))

    TerritorialExhibitTheftData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'TheftVMM'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLTheft()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Theft & VMM')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'Theft')

    output$TerritorialExhibitTheft <- renderDT(datatable(TerritorialExhibitTheftData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(1:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1))
    
    TerritorialExhibitLiabilityData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'Liability'),EHY_PremTable,InforceAALTable,
                                                                    SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLLiability()['Selected','Weighted LLL']),
                                                                    SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                    as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                    as.numeric(memoToTables(indication_memo_data,'Liability')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'Liability')

    output$TerritorialExhibitLiab <- renderDT(datatable(TerritorialExhibitLiabilityData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                 formatRound(c(1:5,7),digits = 0)%>%
                                                 formatPercentage(c(6,8:11), digits = 1))
    
    TerritorialExhibitOtherAOPData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'OtherAOP'),EHY_PremTable,InforceAALTable,
                                                                        SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLOtherAOP()['Selected','Weighted LLL']),
                                                                       SelectionTrendDataAtt[,c(1,2)],selected_expense_data_selected,1082,
                                                                        as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                        as.numeric(memoToTables(indication_memo_data,'All Other Perils')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'OtherAOP')
    
    output$TerritorialExhibitAOP <- renderDT(datatable(TerritorialExhibitOtherAOPData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                     formatRound(c(1:5,7),digits = 0)%>%
                                                     formatPercentage(c(6,8:11), digits = 1))
    
    TerritorialExhibitNCWData <<-TerritorialExhibitAttritionalNCW(LossesCappedByPeril(input$Tablename,input$IndicationDate, evaluation_use, input$State,'NCW'),EHY_PremTable,InforceAALTable,
                                                                       SelectionTrendData[,c(1,2)],SelectionTrendData[,c(1,4)],as.numeric(LLLWeather()['Selected','Weighted LLL']),
                                                                       SelectionTrendDataWeather[,c(1,2)],selected_expense_data_selected,1082,
                                                                       as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')) ,
                                                                       as.numeric(memoToTables(indication_memo_data,'Non-Cat Weather')),non_peril_pull(input$IndicationDate,evaluation_use,input$State),'NCW')
    
    output$TerritorialExhibitNCW <- renderDT(datatable(TerritorialExhibitNCWData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                                    formatRound(c(1:5,7),digits = 0)%>%
                                                    formatPercentage(c(6,8:11), digits = 1))


    TerritorialExhibitHUData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                  as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')),
                                  as.numeric(memoToTables(indication_memo_data,'Hurricane')),'Hurricane','HU',TerHUexpAdj,as.numeric(HULosses[7]), as.numeric(reinsurance_exhibit_table[1,5]),input$HUyearExpAdj,20)

    output$TerritorialExhibitHU <- renderDT(datatable(TerritorialExhibitHUData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                               formatRound(c(1:4),digits = 0)%>%
                                               formatRound(6,digits = 2)%>%
                                               formatPercentage(c(5,7:12), digits = 1))
    
    
    TerritorialExhibitSTSData <<- TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,as.numeric(selected_expense_data_selected),
                                                                 as.numeric(expense_ratios[expense_ratios[1] == '(11)',][10]) + as.numeric(reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')),
                                                                 as.numeric(memoToTables(indication_memo_data,'STS')),'STS','STS',TerSTSexpAdj,as.numeric(STSLosses[7]), as.numeric(reinsurance_exhibit_table[2,5]), input$STSyearExpAdj,20)
    
    output$TerritorialExhibitSTS <- renderDT(datatable(TerritorialExhibitSTSData,selection = 'none',class = 'compact',options = list(paging=FALSE,dom ='t',columnDefs = list(list(className = 'dt-right',targets = c(0:10)))),rownames = F)%>%
                                              formatRound(c(1:4),digits = 0)%>%
                                              formatRound(6,digits = 2)%>%
                                              formatPercentage(c(5,7:12), digits = 1))
                                              
  },priority = 0)
  
  observeEvent({input$sendForReview},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',
                                      input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],input$reviewed_by[[1]])
                 
                save_selections(input$IndicationDate,evaluation_use, input$State,'All Perils','In Review',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$reviewed_by[[1]])
                save_selections(input$IndicationDate,evaluation_use, input$State,'Weather','In Review',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$reviewed_by[[1]])
                save_selections(input$IndicationDate,evaluation_use, input$State,'Attritional','In Review',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$reviewed_by[[1]])
               })
  observeEvent({input$publish},
               {
                 save_selections_rest(input$IndicationDate,evaluation_use, input$State,'All Perils','Published',
                                      input$CATstateweight,input$state_exclude,as.numeric(selected_expense_data_selected),input$LDFstateweight,input$currentLossTrendState,input$projLossTrendState,input$LLLstateweightTotal,
                                      as.numeric(LLLFire()),as.numeric(LLLWater()),as.numeric(LLLTheft()),as.numeric(LLLLiability()),as.numeric(LLLOtherAOP()),as.numeric(LLLWeather()),
                                      input$currentPremiumTrend,input$projPremiumTrend,input$HUexpFactor,input$HUyearExpAdj,input$STSexpFactor,input$STSyearExpAdj,
                                      input$selected_by[[1]],input$reviewed_by[[1]])
                 
                 save_selections(input$IndicationDate,evaluation_use, input$State,'All Perils','Published',LDFstate_selection_All,LDF_selection,input$selected_by[[1]],input$reviewed_by[[1]])
                 save_selections(input$IndicationDate,evaluation_use, input$State,'Weather','Published',LDFstate_selection_Weather,LDF_selection_weather,input$selected_by[[1]],input$reviewed_by[[1]])
                 save_selections(input$IndicationDate,evaluation_use, input$State,'Attritional','Published',LDFstate_selection_Attritional,LDF_selection_attritional,input$selected_by[[1]],input$reviewed_by[[1]])
               })
  #generate a html report based on the selections made which can easily be printed to pdf in your browser. HTML is much easier to style than pdf.

  output$report <- downloadHandler(
    filename = "report.html",
    content = function(file) {
      
      rmarkdown::render("Indication Report.Rmd", output_file = file,
                        params = list(
                          IndicationDate= input$IndicationDate,
                          proposedEffectiveDate= input$proposedEffective,
                          LOB = input$Tablename,
                          LOB_Full = table_name(input$Tablename),
                          State = input$State,
                          State_Full = state_name_full(input$State),
                          ldfallLoss = LDF_display(LDFdata,'Losses','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatio = LDF_display(LDFdata,'Loss Ratios','All Perils',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAverages =LDF_display_averages(LDFallAverages,LDFallAveragesState,input$LDFstateweight),
                          ldfallSelections = LDF_selections_choose(LDF_selection,weighted_plot_all,input$LDFstateweight),
                          ldfallLossWeather = LDF_display(LDFdata,'Losses','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatioWeather = LDF_display(LDFdata,'Loss Ratios','Weather',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAveragesWeather = LDF_display_averages(LDFallAveragesWeather,LDFallAveragesStateWeather,input$LDFstateweight),
                          ldfallSelectionsWeather =  LDF_selections_choose(LDF_selection_weather,weighted_plot_weather,input$LDFstateweight),
                          ldfallLossAttritional = LDF_display(LDFdata,'Losses','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallRatioAttritional = LDF_display(LDFdata,'Loss Ratios','Attritional',ifelse(input$LDFstateweight > 0, input$State,'CW'),input$IndicationDate, evaluation_use,NA),
                          ldfallAveragesAttritional = LDF_display_averages(LDFallAveragesAttritional,LDFallAveragesStateAttritional,input$LDFstateweight),
                          ldfallSelectionsAttritional =  LDF_selections_choose(LDF_selection_attritional,weighted_plot_attritional,input$LDFstateweight),
                          profit= as.numeric(state_profit),
                          TotalRateTable= total_data,
                          TotalRateCalc= TotalSummary,
                          FireLosses= fireLosses,
                          FirePrem= firePremium,
                          FireCalc= fireSummary,
                          WaterLosses= waterLosses,
                          WaterPrem= waterPremium,
                          WaterCalc= waterSummary,
                          TheftLosses= theftLosses,
                          TheftPrem= theftPremium,
                          TheftCalc= theftSummary,
                          LiabilityLosses= liabilityLosses,
                          LiabilityPrem= liabilityPremium,
                          LiabilityCalc= liabilitySummary,
                          OtherAOPLosses= OtherAOPLosses,
                          OtherAOPPrem= OtherAOPPremium,
                          OtherAOPCalc= OtherAOPSummary,
                          NCWLosses= NCWLosses,
                          NCWPrem= NCWPremium,
                          NCWCalc= NCWSummary,
                          STSLosses= STSLosses,
                          STSCalc= STSsummary,
                          HurricaneLosses= HULosses,
                          HurricaneCalc= HUsummary,
                          BalancedChange = indication_memo(TotalSummary, fireSummary, waterSummary, theftSummary, liabilitySummary, OtherAOPSummary, NCWSummary, STSsummary, HUsummary,coverage_report_data,non_peril_pull(input$IndicationDate,evaluation_use,input$State)),
                          PremiumTable= PremiumData_state%>%select(-Date),
                          PremiumFitting=premium_trend_fitting(PremiumData_state,0),
                          CurrentPremiumTrend= input$currentPremiumTrend,
                          ProjectedPremiumTrend=input$projPremiumTrend,
                          LossTable= lossTrendstateData%>%select(-Year,-Quarter),
                          LossFitting= loss_trend_fitting(lossTrendstateData,as.numeric(input$LosstrendstateLag)),
                          CurrentLossTrend= input$currentLossTrendState,
                          ProjectedLossTrend= input$projLossTrendState,
                          LLLStateTotal= LLLdata_state_total,
                          LLLStateTotalCalc= LLL_selections(LLLdata_state_total,'Calculated'),
                          LLLStateTotalSelected= LLLdata_state_total_selected,
                          LLLCWTotal= LLLdata_CW_total,
                          LLLCWTotalCalc= LLL_selections(LLLdata_CW_total,'Calculated'),
                          LLLCWTotalSelected= LLLdata_CW_total_selected,
                          LLLTotalFinal = LLLTotal(),
                          LLLStateFire= LLLdata_state_fire,
                          LLLStateFireCalc= LLL_selections(LLLdata_state_fire,'Calculated'),
                          LLLStateFireSelected= LLLdata_state_fire_selected,
                          LLLCWFire= LLLdata_CW_fire,
                          LLLCWFireCalc= LLL_selections(LLLdata_CW_fire,'Calculated'),
                          LLLCWFireSelected= LLLdata_CW_fire_selected,
                          LLLFireFinal = LLLFire(),
                          LLLStateWater= LLLdata_state_water,
                          LLLStateWaterCalc= LLL_selections(LLLdata_state_water,'Calculated'),
                          LLLStateWaterSelected= LLLdata_state_water_selected,
                          LLLCWWater= LLLdata_CW_water,
                          LLLCWWaterCalc= LLL_selections(LLLdata_CW_water,'Calculated'),
                          LLLCWWaterSelected= LLLdata_CW_water_selected,
                          LLLWaterFinal = LLLWater(),
                          LLLStateTheft= LLLdata_state_theft,
                          LLLStateTheftCalc= LLL_selections(LLLdata_state_theft,'Calculated'),
                          LLLStateTheftSelected= LLLdata_state_theft_selected,
                          LLLCWTheft= LLLdata_CW_theft,
                          LLLCWTheftCalc= LLL_selections(LLLdata_CW_theft,'Calculated'),
                          LLLCWTheftSelected= LLLdata_CW_theft_selected,
                          LLLTheftFinal = LLLTheft(),
                          LLLStateLiability= LLLdata_state_liability,
                          LLLStateLiabilityCalc= LLL_selections(LLLdata_state_liability,'Calculated'),
                          LLLStateLiabilitySelected= LLLdata_state_liability_selected,
                          LLLCWLiability= LLLdata_CW_liability,
                          LLLCWLiabilityCalc= LLL_selections(LLLdata_CW_liability,'Calculated'),
                          LLLCWLiabilitySelected= LLLdata_CW_liability_selected,
                          LLLLiabilityFinal = LLLLiability(),
                          LLLStateOtherAOP= LLLdata_state_otherAOP,
                          LLLStateOtherAOPCalc= LLL_selections(LLLdata_state_otherAOP,'Calculated'),
                          LLLStateOtherAOPSelected= LLLdata_state_otherAOP_selected,
                          LLLCWOtherAOP= LLLdata_CW_otherAOP,
                          LLLCWOtherAOPCalc= LLL_selections(LLLdata_CW_otherAOP,'Calculated'),
                          LLLCWOtherAOPSelected= LLLdata_CW_otherAOP_selected,
                          LLLOtherAOPFinal = LLLOtherAOP(),
                          LLLStateWeather= LLLdata_state_weather,
                          LLLStateWeatherCalc= LLL_selections(LLLdata_state_weather,'Calculated'),
                          LLLStateWeatherSelected= LLLdata_state_weather_selected,
                          LLLCWWeather= LLLdata_CW_weather,
                          LLLCWWeatherCalc= LLL_selections(LLLdata_CW_weather,'Calculated'),
                          LLLCWWeatherSelected= LLLdata_CW_weather_selected,
                          LLLWeatherFinal = LLLWeather(),
                          LLLWeight= input$LLLstateweightTotal,
                          Capping= input$capped,
                          ModeledCatLoad = modeled_cat,
                          ExpenseRatio = expense_ratios,
                          Credibility = credibility_exhibit(losses_claims),
                          Cumulative = on_level_cumulative(input$IndicationDate,input$Tablename,input$State),
                          OnLevelFactors = on_level_load,
                          HUreinsurance = reinsurance(input$State,evaluation_use,input$Tablename,'Hurricane'),
                          STSreinsurance = reinsurance(input$State,evaluation_use,input$Tablename,'STS'),
                          CostOfReinsurance = reinsurance(input$State,evaluation_use,input$Tablename,'All Perils')
                        ),
                        envir = new.env(parent = globalenv())
      )
      
    }
  )
}

# Run the application 

shinyApp(ui = ui, server = server)
