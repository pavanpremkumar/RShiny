--insert co.policySpatialKeyClean
select -- top 10 
[Policy Number],
State,
10 as [Model Version],
[TSv10 HU LongTerm Gross AAL] as [HU LongTerm Gross AAL],
[TSv10 ST Gross AAL] as [ST Gross AAL],
'2023-01-24' as rowStartDate,
'9999-12-31' as rowEndDate,
1 as currentRow
from stage.[policySpatialKey9.1.22]
where [Line of Business] like '%ren%'

select distinct rowStartDate, rowEndDate, currentRow from co.policySpatialKeyClean

update co.policySpatialKeyClean
set rowEndDate = case when rowEndDate = '9999-12-31' then '2023-01-23' else rowEndDate end
