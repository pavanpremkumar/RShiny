select 9 as Month, 2022 as Year , 189.6/162.2-1 as ConstantQualityIndex into #ConstantQuality
insert #ConstantQuality select 8 as Month, 2022 as Year , 186/160.3-1 as ConstantQualityIndex
insert #ConstantQuality select 7 as Month, 2022 as Year , 185/158.0-1 as ConstantQualityIndex
insert #ConstantQuality select 6 as Month, 2022 as Year , 185.1/155.7-1 as ConstantQualityIndex
insert #ConstantQuality select 5 as Month, 2022 as Year , 182.3/153.8-1 as ConstantQualityIndex
insert #ConstantQuality select 4 as Month, 2022 as Year , 179.1/151.4-1 as ConstantQualityIndex
insert #ConstantQuality select 3 as Month, 2022 as Year , 176.5/149.8-1 as ConstantQualityIndex
insert #ConstantQuality select 10 as Month, 2022 as Year , 192.4/164.2-1 as ConstantQualityIndex
insert #ConstantQuality select 11 as Month, 2022 as Year , 194.6/166-1 as ConstantQualityIndex

select * ,
cast('2022-12-01' as date) as rowStartDate,
cast('9999-12-31' as date) as rowEndDate,
1 as currentRow
into dbo.ConstantQuality
from #ConstantQuality
order by Month

drop table #ConstantQuality