

declare @state varchar(2) = 'TX', @ratingVersionID int = 114
declare @As_Of_Date varchar(10) = '2023-01-01', @Rolling_Year_End varchar(10) = '2023-01-01'
DECLARE @Rolling_Calc_Month varchar(2) = Month(DATEADD(day,-1,@Rolling_Year_End))
DECLARE @Min_Effective_Date varchar(10) = Convert(Date,DATEADD(year,-6,@Rolling_Year_End))
DECLARE @Rolling_Year5_Start varchar(10) = Convert(Date,DATEADD(year,-5,@Rolling_Year_End))
DECLARE @Rolling_Year4_Start varchar(10) = Convert(Date,DATEADD(year,-4,@Rolling_Year_End))
DECLARE @Rolling_Year3_Start varchar(10) = Convert(Date,DATEADD(year,-3,@Rolling_Year_End))
DECLARE @Rolling_Year2_Start varchar(10) = Convert(Date,DATEADD(year,-2,@Rolling_Year_End))
DECLARE @Rolling_Year1_Start varchar(10) = Convert(Date,DATEADD(year,-1,@Rolling_Year_End))
DECLARE @Rolling_Year_5_Year varchar(4) = year(dateadd(month,-1,@Rolling_Year4_start))
DECLARE @Rolling_Year_4_Year varchar(4) = year(dateadd(month,-1,@Rolling_Year3_start))
DECLARE @Rolling_Year_3_Year varchar(4) = year(dateadd(month,-1,@Rolling_Year2_start))
DECLARE @Rolling_Year_2_Year varchar(4) = year(dateadd(month,-1,@Rolling_Year1_start))
DECLARE @Rolling_Year_1_Year varchar(4) = year(dateadd(month,-1,@Rolling_Year_End))

select * ,
policyID as policyID_policyCoverages
into #policyCoverages
from ActuarialDataMart.ho.policyCoverage
where @As_Of_Date between rowStartDate and rowEndDate

alter table #policyCoverages
DROP COLUMN rowStartDate, rowEndDate,currentRow,policyID;

select * ,
policyID as policyID_policyElements
into #policyElements
from ActuarialDataMart.ho.policyElements
where @As_Of_Date between rowStartDate and rowEndDate


--rename duplicate columns

alter table #policyElements
DROP COLUMN rowStartDate, rowEndDate,currentRow,policyID,state,ratingVersionID;

select d.* ,
d.policyID as policyID_policyRate
into #policyRate
from ho.policyRate d
where @As_Of_Date between rowStartDate and rowEndDate
and state = @State
and ratingAlgorithm = 'CRL'
and ratingVersionID = @RatingVersionID

alter table #policyRate
DROP COLUMN rowStartDate, rowEndDate,currentRow,state;

select * ,
policyID as policyID_policyEndorsementPremium
into #policyEndorsementPremium
from ActuarialDataMart.ho.policyEndorsementPremium
where @As_Of_Date between rowStartDate and rowEndDate

alter table #policyEndorsementPremium
DROP COLUMN rowStartDate, rowEndDate,currentRow,policyID;


select @Rolling_Year_1_Year as RollingYear,
[policyNum],[effectiveDate],[expirationDate],a.[state],[txEffD],[txExpD],a.premiumTotal as premiumTotalinPTS
	  
	  ,b.*
	  ,c.*
	  ,d.* --end table d

	  ,e.*, --end table e
              Round(DateDiff(Day, Case when a.txEffD >= @Rolling_Year1_Start Then a.txEffD Else @Rolling_Year1_Start End
	            , Case when a.txExpD <= @Rolling_Year_End Then a.txExpD Else @Rolling_Year_End End) * 1.0 / DateDiff(Day, a.effectiveDate, a.ExpirationDate),4) as EHY ,
	            Round(DateDiff(Day, Case when a.txEffD >= @Rolling_Year1_Start Then a.txEffD Else @Rolling_Year1_Start End
	            , Case when a.txExpD <= @Rolling_Year_End Then a.txExpD Else @Rolling_Year_End End) * 1.0 / DateDiff(Day, a.effectiveDate, a.ExpirationDate) * a.PremiumTotal, 0) as EarnedPremiuminPTS
into #Exposure_Data_Year_1
from [ActuarialDataMart].[ho].[exposure] a 
inner join #policyCoverages b
on a.policyid = b.policyID_policyCoverages
inner join #policyElements c
	on a.policyID=c.policyID_policyElements
left join #policyRate d
on d.ratingAlgorithm = 'CRL'
  and a.policyID=d.policyID_policyRate
left join  #policyEndorsementPremium e
	on a.policyID=e.policyID_policyEndorsementPremium
where @As_Of_Date between a.rowStartDate and a.rowEndDate
  and a.effectiveDate >= @Min_Effective_Date
	and a.effectiveDate < @Rolling_Year_End
	and a.txEffD < @Rolling_Year_End 
	and a.txExpD >= @Rolling_Year1_Start
	and a.exposureType = 'BOUND'
	and a.state = @State


select * into #Exposure_Data from #Exposure_Data_Year_1
select * 
into #Exposure_Clean
from #Exposure_Data
where (EHY <> 0 and EarnedPremiuminPTS <> 0)
and policyNum <> 'AZ-002633-00'
and territoryCode is not NULL

select * 
into #inforceRaw
from #Exposure_Clean
where txExpD >= @Rolling_Year_End

alter table #inforceRaw
drop column RollingYear, txEffD, txExpD,EHY,EarnedPremiuminPTS;


select distinct *
into #inforce
from #inforceRaw

insert ho.InflationGuardCovA
select 
	@Rolling_Year_End as IndicationDate,
	@As_Of_Date as EvaluationDate,
	state,
	ratingVersionID,
	covALmt,
	sum(firePremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as firePercent,
	sum(waterPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as WaterPercent,
	sum(theftPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as TheftPercent,
	sum(liabilityPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as LiabilityPercent,
	sum(otherPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as OtherPercent,
	sum(NCWPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as NCWPercent,
	sum(STSPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as STSPercent,
	sum(hurricanePremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as HUPercent,
	--sum(WFPremium)*1./(sum(policyPremium)*1.-sum(endorsementPremium)*1.)*1. as WFPercent,
		sum(policyPremium) as policyPremium,
		sum(endorsementPremium) as endorsementPremium,
	sum(case when cast(right(policyNum,2) as int) = 0 then 1 else 0 end) as New,
	sum(case when cast(right(policyNum,2) as int) = 0 then 0 else 1 end) as Renew, count(policyNum) as InforceCount,
	sum(case when cast(right(policyNum,2) as int) = 0 and year(effectiveDate)-yearBuilt <= 1 then 1 else 0 end) as NewHomesNewPolicy,
	sum(case when cast(right(policyNum,2) as int) = 0 then case when year(effectiveDate)-yearBuilt <= 1 then 0 else 1 end else 0 end) as OldHomeNewPolicy,
	'ActuarialSandbox' as source
	
--drop table ho.InflationGuardCovA
--into ho.InflationGuardCovA
from #inforce e
group by covALmt,state, ratingVersionID
drop table #Exposure_Clean
drop table #Exposure_Data
drop table #Exposure_Data_Year_1
drop table #inforce
drop table #inforceRaw
drop table #policyCoverages
drop table #policyElements
drop table #policyEndorsementPremium
drop table #policyRate

/*
select  sum(policyPremium) as policyPremium,sum((policyPremium-endorsementPremium)*(--remove the endorsement section for increaseing the coverage A
(firePercent+TheftPercent+LiabilityPercent+OtherPercent+NCWPercent+STSPercent+HUPercent)*factorAmountInsuranceExWaterInflation/factorAmountInsuranceExWater
+WaterPercent*factorAmountInsuranceWaterInflation/factorAmountInsuranceWater
)
+endorsementPremium --add back in the endorsement component
) as InflationGuardPremium, 
sum(New) as New,
sum(InforceCount) as InforceCount,
sum(NewHomesNewPolicy) as NewHomesNewPolicy,
sum(OldHomeNewPolicy) as OldHomeNewPolicy
into #CovAmethod
from #CovAgroup i
*/


