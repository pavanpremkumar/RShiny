#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(sjmisc)
#define input options
LOB <- data.frame(matrix(ncol = 4,nrow=0))
colnames(LOB) <- c('HO','DF','RE','CO')
States <- data.frame(matrix(ncol = 58,nrow=0))
colnames(States) <- c(' ','AK', 'AL', 'AR', 'AS', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'GU', 'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI', 'MN', 'MO', 'MP', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 'TX', 'UM', 'UT', 'VA', 'VI', 'VT', 'WA', 'WI', 'WV', 'WY')
years <- c('2022','2021','2020')
LDF_Matrix <- matrix(c(1,1,1,1,1,1,1,1,1), 1, 9)
rownames(LDF_Matrix) <- c('Selected')
#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server',
                  server=server,
                  database=database,
                  trusted_connection='yes')

LDF_pull_selections <- function(Rolling_Year_End,AsOfDate,state,Classes) {
  #pull the most recent LDF selections
  df <- dbGetQuery(con,paste0("	
	select
	  'Cumulative' as Name,max(LDF1cumulative),max(LDF2cumulative),max(LDF3cumulative),max(LDF4cumulative),max(LDF5cumulative)
	from [actuarialsandbox].[ho].[indicationSelections]
	pivot (max(columnValue) for columnName in (LDF1cumulative,LDF2cumulative ,LDF3cumulative,LDF4cumulative,LDF5cumulative)) as PivotTable
	where IndicationDate = '",Rolling_Year_End,"' 
	and EvaluationDate = '",AsOfDate,"'
	and Region = '",state,"'
	and Class = '",Classes,"'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	group by currentRow
      "
  ))
  return(df)
}

test2 <- LDF_pull_selections('2022-01-01','2022-04-01','CW','All Perils')
test2['1',]
data.frame(`All Countrywide`=1, `All State`=1, `Weighted Average`=1)
LDF_options <- function() {
  out<-data.frame(matrix(ncol=3,nrow = 0))
  colnames(out)<- c('All Countrywide', 'All State', 'Weighted Average')
  print(out)
  return(out)
}
LDF_options()
state_options <- function(program) {
  df <- dbGetQuery(con,paste0("
      select state from 
      ",program,".policyRate
      group by state
    "))
  state <- data.frame(matrix(ncol=length(df[['state']])+1,nrow=0))
  colnames(state) <- c(df[['state']],' ')
  return(state)
}
state_options('ho')


LDFcw_selection_All[-1]
LDFstate_selection_All_proxy <- LDFstate_selection_All
test <- if (ncol(LDFstate_selection_All_proxy)<ncol(LDFcw_selection_All)) {
  print('T')
  LDFstate_selection_All_proxy[(ncol(LDFstate_selection_All_proxy)):ncol(LDFcw_selection_All)]<-1
  LDFstate_selection_All_proxy
  } else {
    LDFstate_selection_All}
test[-1] + LDFcw_selection_All[-1]
data.frame(NAME = c('Selection','Cumulative'),x1=c(1,1),x2=c(1,1),x3=c(1,1),x4=c(1,1),x5=c(1,1),x6=c(1,1),x7=c(1,1),x8=c(1,1),x9=c(1,1),x10=c(1,1))

test <- LDFstate_selection_All[1,]
test[1] <- 'Select'
test
round(1.091201901909310930190190,6)
df <- data.frame()
df['test',' '] <- 0
df
nothing <- data.frame()
nothing[1,1] <- 1
nothingelse <- data.frame()
nothingelse[1,1]<- 1
(try(as.numeric(nothing),silent = T)==try(as.numeric(nothingelse),silent = T)) | (!exists('nothing') & !exists('nothingelse'))

!exists('nothing')
nothing
deparse(substitute(nothing))

df <- dbGetQuery(con,"
	select
	columnValue,status
	from [actuarialsandbox].[ho].[indicationSelections]
	where IndicationDate = '2022-01-01' 
	and EvaluationDate = '2022-01-01'
	and Region = 'TX'
	and Class = 'All Perils'
	and Status = case when Status='Published' then 'Published' 
					 when Status='In Review' then 'In Review'
					 else 'In Progress' end 
	and currentRow = 1
	and columnName = 'LDFweight'
                   ")
df%>%
  filter(status == ifelse('Published' %in% df$status,'Published',
                          ifelse('In Review' %in% df$staus, 'In Review', 'In Progress')))%>%
  select(-status)

paste(c('1','2','3'),collapse = '')
nchar('12312321312124124')
strsplit('11111111','')
gsub("(.{4})", "\\1 ", "11111111")
string <- "2014"
sapply(seq(from=1, to=nchar(string), by=4), function(i) substr(string, i, i+3))
round(as.numeric("2014.000000000"),0)

other <- data.frame()
other[1] <- c(1)
other
print('1')
colnames(other) <- c('Donte Riddick')
print('2')
print(other)
