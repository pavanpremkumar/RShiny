library(excelR)
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(ExcelFunctionsR)

#define input options


#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')




coverage_report_load <- function(IndicationDate, EvaluationDate, State,Program) {
  dframe <- dbGetQuery(con, paste0("
      select RollingYear, ReratedEP ,ptsEHY, policyCharge , Peril,TotalIncurred,CappedTotalIncurred, claimCount from ActuarialSandbox.",Program,".coveragereport
      where IndicationDate = '",IndicationDate,"'
      and EvaluationDate = '",EvaluationDate,"'
      and state = '",State,"'
      order by Peril, RollingYear
                               "))
  return(dframe)
}



reconcilation_tab.fun <- function(coverageReport.data, Targit.data) {

reconciliationData <- coverageReport.data%>%
  filter(Peril == 'All Perils')%>%
  select(RollingYear, ReratedEP, ptsEHY, TotalIncurred, claimCount)


#excelTable(data = data, columns = columns,columnResize=T, allowComments = T, selectionCopy = T, showToolbar = T)

dframe <- data.frame(matrix(ncol = 18, nrow = 22))

#define the catergory labels!

dframe[5,1:17] <- c('Rolling Year',  #define the reconcilation headers!
                    'Financial Earned Premium (Rerated for Perils)',
                    'House Years',
                    'Uncapped Total Incurred',
                    'Claim Count',NA,
                    'Rolling Year',
                    'Targit Financial Earned Premium',
                    'House Years',
                    'Uncapped Incurred Loss & LAE (ex Cat)',
                    'Claim Count',NA,
                    'Rolling Year',
                    'Financial Earned Premium (Rerated for Perils)',
                    'House Years',
                    'Uncapped Incurred Loss & LAE (ex Cat)',
                    'Claim Count')

dframe[6:(nrow(reconciliationData)+5), 1:5] <- reconciliationData
dframe[6:(nrow(reconciliationData)+5),7] <- reconciliationData$RollingYear
dframe[6:(nrow(reconciliationData)+5),13] <- reconciliationData$RollingYear

for (i in 6:(nrow(reconciliationData)+5)) {
  dframe[i,14:17] <- c(paste0('=',toupper(letters)[8:11],i,'/',toupper(letters)[2:5],i,'-1'))
}

dframe[3,3] <- 'SQL Data'
dframe[3,9] <- 'Input Targit Data'
dframe[3,15] <- 'Difference'
dframe[14,3] <- 'Rerated Premium'
dframe[14,8] <- 'Notes:'


if (nrow(Targit.data) > 0) {
  dframe[6:(nrow(Targit.data)+5),8:11] <- Targit.data%>%select(-RollingYear)
}

summaryPremium <- coverageReport.data%>%
  filter(Peril != 'All Perils')%>%
  group_by(RollingYear)%>%
  summarise(Rerated = sum(ReratedEP, na.rm = T))

dframe[16,2:5] <- c('Rolling Year', 'Rerated', 'Trended/On-Leveled', 'Difference')
dframe[17:(nrow(summaryPremium)+16), 2:3] <- summaryPremium
for (i in 17:(nrow(summaryPremium)+16)) {
  dframe[i,5] <- c(paste0('=',toupper(letters)[4],i,'/',toupper(letters)[3],i,'-1'))
}

columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"60"},
  { "type": "number", "title": "B" ,"width":"120"},
  { "type": "number", "title": "C" ,"width":"120"},
  { "type": "number", "title": "D" ,"width":"100"},
  { "type": "number", "title": "E" ,"width":"120"},
  { "type": "number", "title": "F" ,"width":"20"},
  { "type": "text", "title": "G" ,"width":"60"},
  { "type": "number", "title": "H" ,"width":"120"},
  { "type": "number", "title": "I" ,"width":"100"},
  { "type": "number", "title": "J" ,"width":"120"},
  { "type": "number", "title": "K" ,"width":"100"},
  { "type": "text",  "title": "L" ,"width":"20"},
  { "type": "text",  "title": "M" ,"width":"60"},
  { "type": "number", "title": "N" ,"width":"120"},
  { "type": "number", "title": "O" ,"width":"100"},
  { "type": "number", "title": "P" ,"width":"120"},
  { "type": "number", "title": "Q" ,"width":"100"},
  { "type": "number", "title": "R" ,"width":"100"}
  ]')

updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if ( (row >= 4 & row < ",nrow(reconciliationData)+5," & col != 0 & col != 6 &  col != 5 & col < 11) | (col > 0 & col < 4 & row > 14 & row < ",nrow(summaryPremium)+16," ) ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0)
              if ( ((col == 1 | col ==3 | col ==7 | col ==9)& row < 10) | ( (col == 2 | col == 3) & row > 14 & row < ",nrow(summaryPremium)+16," )) {
                cell.innerHTML = '$' + numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
              } else if (col != 1) {
                cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
              }
            }
          } else if ( (col < 17 & col > 12 & row >= 4 & row < ",nrow(reconciliationData)+5,") | (col == 4 & row > 14 & row < ",nrow(summaryPremium)+16,") ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              scale = Number(txt) * 100
              scaleRound = scale.toFixed(2)
              cell.innerHTML = scaleRound + '%' ;
            }
          } else if ( (row <4 | row > ",nrow(reconciliationData)+4," | col == 5 | col == 11 | col == 17) & !(col >=7 & col <= 16 & row >= 15 & row <= 20)) {
            cell.style.backgroundColor = 'lightgrey';
          }
          
          if (row ==2 | (row ==13 & col ==2) | (row ==13 & col == 7)) {
            cell.innerHTML = cell.innerText.bold();
          }
         if ( row >= 4 & row <=9 & col >=6 & col <= 10) {
            cell.style.backgroundColor = '#FFFACD';
         }
         if (col >=7 & col <= 16 & row >= 13 & row <= 20) {
            cell.style.textAlign = 'left';
            cell.style.verticalAlign = 'top';
         }
          
}")

return(list(dframe, columns, updateTable))

}

manualTargitInput.pull <- function(Program, IndicationDate, EvaluationDate, State) {
  dframe <- dbGetQuery(con, paste0("
              select *
              from ActuarialSandbox.",Program,".ManualTargitInput 
              where IndicationDate ='",IndicationDate,"'
              and EvaluationDate = '",EvaluationDate,"'
              and state ='",State,"'
              and currentRow = 1
                                   "))
  dframe <- dframe%>%
    filter(status == ifelse('Published' %in% dframe$status,'Published',
                            ifelse('In Review' %in% dframe$status, 'In Review', 'In Progress')))%>%
    select(-status, -IndicationDate, -EvaluationDate, -state)
  return(dframe)
}

manualTargitInput.data <- manualTargitInput.pull('HO','2022-07-01','2022-10-01','GA')
coverageReport.data <- coverage_report_load('2022-07-01','2022-10-01','GA','HO')

reconciliation.data <- reconcilation_tab.fun(coverageReport.data,manualTargitInput.data)

reconciliation.update <- reconciliation.data[[1]]

trendedOnlevel <- data.frame(Premium = c(6817.20,718272.24,2373972.81,4532728.90,8345095.20))

if (nrow(trendedOnlevel) > 0) {
reconciliation.update[17:(nrow(trendedOnlevel)+16),4] <- trendedOnlevel
}


excelTable(data =reconciliation.update,columns = reconciliation.data[[2]],updateTable = htmlwidgets::JS(reconciliation.data[[3]]),
                        allowDeleteColumn = F,
                        allowInsertRow = F,
                        allowInsertColumn = F,
                        allowDeleteRow = F,
                        autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = T,mergeCells = list(H16 = c(10,6))
)

