library(stringr)
library(stringi)

ISO.files <- list.files("U:\\Actuarial\\Data Science\\ISO\\ISO Rater\\ISO Latest circulars 2022")

#if (nchar(ISO)>12 {
# ISO.filter <- str_replace(ISO.files[3],'.pdf','')
# stri_sub(ISO.filter, 9, 8) <-'-'
# stri_sub(ISO.filter, 5, 4) <-'-'
# stri_sub(ISO.filter, 3, 2) <-'-'
# 
# ISO.filter
# ISO.split <- unlist(strsplit(ISO.filter,'-'))
# 
# ISO.web <- paste0("https://circ.iso.com/circsearch/document?circnumber=",ISO.filter,"&circyear=",ISO.split[3],"&circdoctype=4&circfile=",paste0(ISO.split,collapse = ''),".pdf&circdoctitle=circTitle")

library(pdftools)

dframe<- data.frame(matrix(ncol = 3, nrow=0))
for (j in 1:length(ISO.files)) {

ISO.search <- ISO.files[j]
text <- pdftools::pdf_text(pdf = paste0("U:\\Actuarial\\Data Science\\ISO\\ISO Rater\\ISO Latest circulars 2022\\",ISO.search))

program <- if (grepl('DP',ISO.search)) 'Dwelling Fire' else if (grepl('HO',ISO.search)) 'Homeowners' else 'None'
i <- 0
condition <- T
while (condition & i <= length(state.name)) {
i <- i + 1
truthy <- str_extract(gsub("\\s+"," ",tolower(paste0(text,collapse=''))), paste(tolower(state.name), collapse='|'))
if (!is.na(truthy) & truthy != 'washington') {
  condition <- F
  state.found <- state.abb[match(truthy,tolower(state.name))]
} else {
  state.found <- 'DC'
}
}
dframe[j,] <- c(ISO.search,program, state.found)
print(dframe[j,])
}
write.csv(dframe,'ISO guesses.csv')
