if (!require(DBI)) install.packages('DBI')
if (!require(lubridate)) install.packages('lubridate')
if (!require(openxlsx)) install.packages('openxlsx')
if (!require(shiny)) install.packages('shiny')
if (!require(shinyWidgets)) install.packages('shinyWidgets')
if (!require(dplyr)) install.packages('dplyr')
if (!require(DT)) install.packages('DT')
if (!require(miscTools)) install.packages('miscTools')
if (!require(tidyr)) install.packages('tidyr')
if (!require(shinythemes)) install.packages('shinythemes')
if (!require(markdown)) install.packages('markdown')
if (!require(shinyjs)) install.packages('shinyjs')
if (!require(shinycssloaders)) install.packages('shinycssloaders')
if (!require(odbc)) install.packages('odbc')
if (!require(sjmisc)) install.packages('sjmisc')


library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)



#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server',
                  server=server,
                  database=database,
                  trusted_connection='yes')

LossesCapped <- function(Program,IndicationDate, EvaluationDate, state) {
    df <-  dbGetQuery(con, paste0(
      "select Loss_rolling_year,territoryCode, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCapped
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
    ))
}

LossesCappedByPeril <- function(Program,IndicationDate, EvaluationDate, state,peril) {
  df <-  dbGetQuery(con, paste0(
    "select Loss_rolling_year,territoryCode,Peril, Total_Incurred, Capped_Total_Incurred, Claim_Count 
      from ActuarialSandbox.",Program,".TerritorialLossesCappedByPeril
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and peril = '",peril,"'
      "
  ))
}

EHY_Prem <- function(Program,IndicationDate, EvaluationDate, state) {
  df <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".Territorial_EHY_Prem
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


InforceAAL <- function(Program,IndicationDate, EvaluationDate, state) {
  df <-  dbGetQuery(con, paste0(
    "select *
      from ActuarialSandbox.",Program,".TerritorialInforceAAL
    where state='",state,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
      "
  ))%>%
    select(-IndicationDate, -EvaluationDate)
}


ExperienceFactor <- function(Program,IndicationDate, EvaluationDate, state, name) {
  df <- dbGetQuery(con, paste0("
                               SELECT Territory, columnValue as ",name,"
  FROM [ActuarialSandbox].[",Program,"].[TerritorialExperienceAdjustmentFactor]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and Region = '",state,"'
  and columnName = '",name,"'
                               
                               "))
  if (nrow(df)>0) {
    return(df)
  } else {
    return(df)
  }
  
}

Program <- 'ho'
IndicationDate <- '2022-01-01'
EvaluationDate <- '2022-04-01'
state <- 'TX'
includeFee <- 'No'
peril <- 'Fire'

STSexpAdj <- ExperienceFactor(Program,IndicationDate, EvaluationDate, state, 'STSexpFactor')
HUexpAdj  <- ExperienceFactor(Program,IndicationDate, EvaluationDate, state, 'HUexpFactor')

YearsVector <-  as.character(c(2017,2018,2019,2020,2021))
premTrend   <- data.frame(Adj = YearsVector, PremTrend=c(1.1642033628994,1.17596299282768,1.18784140689664,1.19983980494611,1.21195939893546))
LossTrend   <- data.frame(Adj = YearsVector, LossTrend=c(1.34552492502939,1.35911608588828,1.37284453120028,1.38671164767705,1.40071883603742))
LDFall      <- data.frame(Adj = YearsVector, LDF=c(1,1,1,1.00889208104043,1.0320136211038))
LDFweather  <- data.frame(Adj = YearsVector, LDF=c(1,1,1,1.01193293752036,1.12179079583784))
LDFatt      <- data.frame(Adj = YearsVector, LDF=c(1,1,1,1.00765538534349,1.01231800369771))

LLL         <- 1.10255074308328 #the overall LLL load
LLLFire     <- 1.51267066425693
LLLWater    <- 1.002642197232
# HUexpAdj    <- 1
# STSexpAdj   <- 2.31132390733597
ExpenseLAE  <- 1.11619116910113

HUprojLossLAE  <- .108262891712903
STSprojLossLAE <- .279923342262827
HURe       <- .131497810745406
STSRe      <- .0123656721375977
CredStandard   <- 1082

TargetLossRatio <- 0.641845928636828
TargetIndicatedChange <- .255507572019583
nonPeril <- 0.00689440398824437



  LossesCappedTable <- LossesCapped(Program,IndicationDate, EvaluationDate, state)
  LossesCappedByPerilTable <- LossesCappedByPeril(Program,IndicationDate, EvaluationDate, state,peril)
  EHY_PremTable <- EHY_Prem(Program,IndicationDate, EvaluationDate, state)
  InforceAALTable <- InforceAAL(Program,IndicationDate, EvaluationDate, state)
  
TerritorialExhibit <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
                               TargetLossRatio,TargetIndicatedChange,nonPeril){
  
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    mutate(RollingYear = as.numeric(RollingYear))%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumatCRL*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  TrendedEP <- EHY_PremTableJoin%>%
          select(territoryCode,ReratedEP)%>%
          group_by(territoryCode)%>%
          summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T))%>%
          mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.numeric(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))

    Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
      right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(STSexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    left_join(HUexpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0),
           ModeledHUloss = coalesce(`HU AAL Total` * ExpenseLAE * coalesce(as.numeric(HUexpFactor),1) / `In Force Premium @ CRL`,0),
           ModeledSTSloss=  coalesce(`STS AAL Total`* ExpenseLAE * coalesce(as.numeric(STSexpFactor),1) / `In Force Premium @ CRL`,0),
           HU_Re_Load = (HUprojLossLAE+HURe)/HUprojLossLAE,
           TO_Re_Load = (STSprojLossLAE+STSRe)/STSprojLossLAE)%>%
    mutate(HU_Cost_Re = ModeledHUloss*(HU_Re_Load-1),
           TO_Cost_Re = ModeledSTSloss*(TO_Re_Load-1))%>%
    select(-state,-`HU AAL Total`, -`STS AAL Total`,-`HU Premium`,-`STS Premium`)%>%
    mutate(AdjLossLAEcost = round(ModeledHUloss + ModeledSTSloss + HU_Cost_Re + TO_Cost_Re + ProjLossTotal,3),
           Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = AdjLossLAEcost/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange)-1)*basePremTotal)%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
    group_by()%>%
    summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
    mutate(final = part1/part2)%>%
    select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange)-1,
           AveragePremium = coalesce(TrendedReratedEP/Claim_Count,1),
           CatLossRatio = ModeledHUloss+ModeledSTSloss,
           CostOfReinsurance = HU_Cost_Re+TO_Cost_Re)%>%
    mutate(AdjTotalLoss = CatLossRatio+CostOfReinsurance+ProjLossTotal)%>%
    select(territoryCode,Claim_Count,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,CatLossRatio,CostOfReinsurance,
           AdjLossLAEcost,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)

  colnames(Exhibit) <- c('Territory', 'Claim Count', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Cat Loss Ratio',
                         'Cost of Reinsurance','Adj Total Loss, LAE, & Cost of Reinsurance','Indicated Changed','Credibility',
                         'Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}

View(TerritorialExhibit(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDFall,HUexpAdj,STSexpAdj,ExpenseLAE,HUprojLossLAE,STSprojLossLAE,HURe,STSRe,CredStandard,
                        TargetLossRatio,TargetIndicatedChange,nonPeril))



TerritorialExhibitAttritionalNCW <- function(LossesCappedTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLL,LDF,ExpenseLAE,CredStandard,
                               TargetLossRatio,TargetIndicatedChange,nonPeril,peril){
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',ifelse(peril=='Theft', 'TheftVMM',peril))]]
  
  basePremTotal <- 1-nonPeril
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    arrange(territoryCode,RollingYear)%>%
    left_join(premTrend, by = c('RollingYear' = 'Adj'))%>%
    mutate(ReratedEP = EarnedPremiumUse*PremTrend)%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  TrendedEP <- EHY_PremTableJoin%>%
    select(territoryCode,ReratedEP,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(TrendedReratedEP =sum(ReratedEP,na.rm = T), EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  LossesCappedTableJoin <- LossesCappedTable%>%
    mutate(Loss_rolling_year = as.character(Loss_rolling_year),territoryCode = as.numeric(territoryCode))%>%
    arrange(as.numeric(territoryCode),Loss_rolling_year)%>%
    left_join(LossTrend, by = c('Loss_rolling_year' = 'Adj'))%>%
    left_join(LDF, by = c('Loss_rolling_year' = 'Adj'))%>%
    mutate(UltLoss = Capped_Total_Incurred*LLL*LossTrend*LDF)%>%
    left_join(EHY_PremTableJoin, by = c('Loss_rolling_year'='RollingYear','territoryCode' = 'territoryCode'))%>%
    mutate(ProjLoss = ifelse(ReratedEP >0 ,UltLoss/ReratedEP,0))
  
  Main <- LossesCappedTableJoin%>%
    group_by(territoryCode)%>%
    summarise(Claim_Count = sum(Claim_Count,na.rm = T),UltLossTotal = sum(UltLoss,na.rm = T))%>%
    left_join(TrendedEP, by = c('territoryCode' = 'territoryCode'))%>%
    right_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    mutate(Claim_Count=coalesce(Claim_Count,0),TrendedReratedEP = coalesce(TrendedReratedEP,0),UltLossTotal=coalesce(UltLossTotal,0),EHYUse = coalesce(EHYUse,0))%>%
    mutate(ProjLossTotal = ifelse(TrendedReratedEP>0, UltLossTotal/TrendedReratedEP,0))%>%
    mutate(Credibility = ifelse(((Claim_Count/CredStandard)^.5)>1, 1,(Claim_Count/CredStandard)^.5))%>%
    mutate(IndicatedChange = ProjLossTotal/TargetLossRatio -1)%>%
    mutate( CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange[3])-1)*as.numeric(basePremTotal))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange[3])-1,
           AveragePremium = coalesce(TrendedReratedEP/EHYUse,1))%>%
    select(territoryCode,EHYUse,AveragePremium,TrendedReratedEP,UltLossTotal,ProjLossTotal,Claim_Count,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'Average Premium', 'Trended Earned Rerated Premium at CRL', 'Capped Ultimate Losses Ex-Cat','Ex Cat Loss Ratio', 'Claim Count'
                         ,'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}

TargetIndicatedChangeFire <- c(NA,NA,.0950735031020524)
TargetIndicatedChangeWater<- c(NA,NA,.0428091587334138)

TerritorialExhibitAttritionalNCW(LossesCappedByPerilTable,EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLLFire,LDFatt,ExpenseLAE,CredStandard,
                                             TargetLossRatio,TargetIndicatedChangeFire,nonPeril,'Fire')
TerritorialExhibitAttritionalNCW(LossesCappedByPeril(Program,IndicationDate, EvaluationDate, state,'Water'),EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLLWater,LDFatt,ExpenseLAE,CredStandard,
                                 TargetLossRatio,TargetIndicatedChangeWater,nonPeril,'Water')


TerritorialExhibitAttritionalNCW(LossesCappedByPeril(Program,IndicationDate, EvaluationDate, state,'TheftVMM'),EHY_PremTable,InforceAALTable,premTrend,LossTrend,LLLWater,LDFatt,ExpenseLAE,CredStandard,
                                 TargetLossRatio,TargetIndicatedChangeWater,nonPeril,'Theft')





TerritorialExhibitAttritionalCAT <- function(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                             TargetLossRatio,TargetIndicatedChange,peril,peril_short,catExpAdj,perilLossLAE, CostRe, catYearsAdj,catCredStandard){
  
  EHY_PremTable$EarnedPremiumUse <- EHY_PremTable[[paste0('EarnedPremium_',peril)]]
  EHY_PremTable$EHYUse <- EHY_PremTable[[paste0('EHY_',peril)]]
  InforceAALTable$CatPrem <- InforceAALTable[[paste(peril_short,'Premium',sep = ' ')]]
  InforceAALTable$CatAAL <- InforceAALTable[[paste(peril_short,'AAL Total',sep = ' ')]]
  catExpAdj$expFactor <- as.numeric(catExpAdj[[paste0(peril_short,'expFactor')]])
  
  EHY_PremTableJoin <- EHY_PremTable%>%
    select(territoryCode,EHYUse)%>%
    group_by(territoryCode)%>%
    summarise(EHYUse = sum(EHYUse,na.rm = T))%>%
    mutate(territoryCode = as.numeric(territoryCode))
  
  Main <- EHY_PremTableJoin%>%
    left_join(InforceAALTable, by = c('territoryCode' = 'territoryCode'))%>%
    left_join(catExpAdj,  by = c('territoryCode' = 'Territory'))%>%
    mutate(ModeledLossRatio = ifelse(CatPrem > 0,CatAAL*ExpenseLAE/CatPrem ,0),
           ReinsLoad = (perilLossLAE+CostRe)/perilLossLAE,
           expFactor = coalesce(expFactor,1))%>%
    mutate(TerritoryCostRe = ModeledLossRatio*expFactor*(ReinsLoad - 1))%>%
    mutate(ProjectedLoss = ModeledLossRatio * expFactor + TerritoryCostRe,
           Credibility = ifelse(EHYUse==0, 0, 
                                ifelse(expFactor==1, 1, catYearsAdj/catCredStandard)))%>%
    mutate(IndicatedChange = ProjectedLoss/TargetLossRatio - 1)%>%
    mutate(CredibilityWeightedChange = ((1+IndicatedChange)*Credibility + (1-Credibility)*(1+TargetIndicatedChange)-1))%>%
    arrange(as.numeric(territoryCode))
  
  credWeightTotal <- as.numeric(Main%>%
                                  group_by()%>%
                                  summarise(part1 = sum(CredibilityWeightedChange*`In Force Premium @ CRL`,na.rm = T), part2 =sum(`In Force Premium @ CRL`,na.rm = T))%>%
                                  mutate(final = part1/part2)%>%
                                  select(final))
  
  Exhibit <- Main%>%
    mutate(BalancedIndicatedChange = ((1+CredibilityWeightedChange)/(1+credWeightTotal))*(1+TargetIndicatedChange)-1)%>%
    select(territoryCode,EHYUse,CatPrem,CatAAL,ModeledLossRatio,expFactor,TerritoryCostRe,ProjectedLoss,IndicatedChange,Credibility,CredibilityWeightedChange,BalancedIndicatedChange)
  
  colnames(Exhibit) <- c('Territory', 'Earned Exposures', 'In Force Premium @ Currend Rate Level','Peril Modeled Gross AAL','Modeled Loss & LAE Ratio','Experience Adjustment Factor','Cost of Reinsurance','Adj Loss, LAE, & Cost of Reinsurance',
                         'Indicated Changed','Credibility','Credibility Weighted Indicated Relativity Change With Complement of Credibility as Statewide Indicated Change',
                         'Balanced Indicated Change With Complement of Credibility as Statewide Indicated Change')
  
  return(Exhibit)
}

STSperilLoss <- .85735579427536
HUperilLoss <- .385595974769477
HUcostRe <- .468350934583288
STScostRe <- .0378738713662703
STSyearsAdj <- 16
HUyearAdj <- 0
TargetIndicatedChangeSTS <- .171798438125385
TargetIndicatedChangeHU <- .737175927516662

TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                             TargetLossRatio,TargetIndicatedChangeSTS,'STS','STS',STSexpAdj,STSperilLoss, STScostRe, STSyearsAdj,20)

TerritorialExhibitAttritionalCAT(EHY_PremTable,InforceAALTable,ExpenseLAE,
                                 TargetLossRatio,TargetIndicatedChangeHU,'Hurricane','HU',HUexpAdj,HUperilLoss, HUcostRe, HUyearsAdj,20)
  