
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(ExcelFunctionsR)
library(excelR)
library(shinyTree)

#define input options

server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')





Premium_Tables <- function(State,PremiumData,PremiumFitting ,inflationData,formulas,currentTrend,projTrend,ISOdata) {
  
  PremiumFitting <- PremiumFitting[!is.na(PremiumFitting[1]),]
  dframe <- data.frame(matrix(ncol = 13, nrow = nrow(PremiumData)+nrow(PremiumFitting)+20))
  dframe[1,1] <- State
  dframe[2,1] <- 'Homeowners of America Insurance Company'
  dframe[3,1] <- 'Homeowners: All Forms Combined'
  dframe[4,1] <- 'Premium Trend Selection'
  dframe[7,1:5] <- colnames(PremiumData)
  dframe[8:(nrow(PremiumData)+7),1:5] <- PremiumData
  
  
  dframe[(nrow(PremiumData)+12+nrow(PremiumFitting)),4] <- 'Selections'
  dframe[(nrow(PremiumData)+13+nrow(PremiumFitting)),4:5] <- c('Current',currentTrend)
  dframe[(nrow(PremiumData)+14+nrow(PremiumFitting)),4:5] <- c('Projected',projTrend)
  print(PremiumFitting)
  
  
  currentRow <- (nrow(PremiumData)+13+nrow(PremiumFitting))
  projRow <- (nrow(PremiumData)+14+nrow(PremiumFitting))
  
  
  dframe[(nrow(PremiumData)),8:9] <- c('Circular Number','ISO Trend')
  if (nrow(ISOdata) > 0) {
    dframe[(nrow(PremiumData)+1),8:9] <- c(ISOdata$CircularNumber,ISOdata$PremiumTrendFactor/100)
  } else {
    dframe[(nrow(PremiumData)+1),8:9] <- c('None Saved',0.025465456)
  }
  
  
  if (nrow(PremiumFitting)>0) {
    dframe[(nrow(PremiumData)+10),4:5] <- colnames(PremiumFitting)
    dframe[(nrow(PremiumData)+11):(nrow(PremiumData)+10+nrow(PremiumFitting)),4:5] <- PremiumFitting
    
    dframe[(nrow(PremiumData)+5),7:13] <- colnames(inflationData)
  dframe[(nrow(PremiumData)+6),7:13] <- inflationData
  inflation.row <- nrow(PremiumData)+6
  dframe[(nrow(PremiumData)+9):(nrow(PremiumData)+11),8] <- c('Renewal Inflation Guard',
                                                              'Assume New Policy New Homes keeps up with Infl. Guard',
                                                              'New Policy Old Home, Trend')

  dframe[(nrow(PremiumData)+8):(nrow(PremiumData)+11),9] <- c('CovA Inc to Infl.Gd.',
                                                               paste0("=H",inflation.row,"/G",inflation.row,"-1"),
                                                               paste0("=H",inflation.row,"/G",inflation.row,"-1"),
                                                               paste0("=AVERAGE(E",(nrow(PremiumData)+11),":E",(nrow(PremiumData)+10+nrow(PremiumFitting)),")")
                                                               
                                                               )
  dframe[(nrow(PremiumData)+8):(nrow(PremiumData)+11),10] <- c('% In Group',
                                                              paste0("=J",inflation.row,"/K",inflation.row),
                                                              paste0("=L",inflation.row,"/K",inflation.row),
                                                              paste0("=(I",inflation.row,"-L",inflation.row,")/K",inflation.row))
  
  dframe[(nrow(PremiumData)+8):(nrow(PremiumData)+11),11] <- c('Weight',
                                                               paste0("=I",inflation.row+3,"*J",inflation.row+3),
                                                               paste0("=I",inflation.row+4,"*J",inflation.row+4),
                                                               paste0("=I",inflation.row+5,"*J",inflation.row+5))
  
  dframe[(nrow(PremiumData)+8):(nrow(PremiumData)+9),13] <- c('Selection',
                                                               paste0("=SUM(K",inflation.row+3,":K",inflation.row+5,")"))
  
  }
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"120"},
  { "type": "number", "title": "B" ,"width":"120"},
  { "type": "number", "title": "C" ,"width":"120"},
  { "type": "number", "title": "D" ,"width":"120"},
  { "type": "number", "title": "E" ,"width":"120"},
  { "type": "number", "title": "F" ,"width":"50"},
  { "type": "number", "title": "G" ,"width":"125"},
  { "type": "number", "title": "H" ,"width":"225"},
  { "type": "number", "title": "I" ,"width":"125"},
  { "type": "number", "title": "J" ,"width":"125"},
  { "type": "number", "title": "K" ,"width":"125"},
  { "type": "number", "title": "L" ,"width":"175"} ,
  { "type": "number", "title": "M" ,"width":"175"}
  ]')
  #cell.style.borderBottomColor = 'black';
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if (col < 11 & row <=6)  {
            if (row < 3) {
              txt = cell.innerText;
              cell.innerHTML = txt.bold();
            }
            if (col <5 & row == 6) {
              cell.style.borderBottomColor = 'black';
              if (col ==0) {
                cell.style.borderRightColor = 'black';
              }
            }
        } else if (col >=0 & row < ",(nrow(PremiumData)+7)," & !(col== 8 & row == 15)) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0);
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
            if (row >5  & col == 0){
                cell.style.borderRightColor = 'black';
            
            }
          } else if ( (col >0 &  row > ",(nrow(PremiumData)+7),") | (col== 8 & row == 15) ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              num = Number(txt)*100
              cell.innerHTML = num.toFixed(1).toString().concat('%');
            }
          }
        
        if ( col > 4) {
            cell.style.backgroundColor = 'lightgrey';
        }
        
        if ((col == 3 | col ==4) & (row == ",nrow(PremiumData)+11+nrow(PremiumFitting)," | row == ",nrow(PremiumData)+12+nrow(PremiumFitting)," | row == ",nrow(PremiumData)+13+nrow(PremiumFitting),") ) {
        
            cell.innerHTML = cell.innerText.bold();
        }
        
}")
  out.table <- excelTable(data = dframe,columns = columns,updateTable = htmlwidgets::JS(updateTable),
             allowDeleteColumn = F,
             allowInsertRow = F,
             allowInsertColumn = F,
             allowDeleteRow = F,
             autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = T,
             mergeCells = list(A1 = c(5,1), A2=c(5,1), A3=c(5,1),A4=c(5,1) )
  )
  return(list(out.table,currentRow,projRow))
}
#Premium_Tables('Georgia',PremiumData_state%>%select(-Date), Premium_fitting,dframe.inflation,NA,0,0)[[1]]


state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select state from 
      actuarialsandbox.",program,".modeledCatLoad
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}
premium_trend_data <- function(Program,IndicationDate, EvaluationDate, State) {
  Evalutionadjust <- ifelse(as.Date(EvaluationDate)<as.Date('2022-06-01'),'2022-06-01', EvaluationDate)
  dframe <- dbGetQuery(con,paste0("
        select top (24) Date, EHY, EP, AdjustedEP
        from ActuarialSandbox.",Program,".PremiumTrend 
        where IndicationDate = '",IndicationDate,"'
        and EvaluationDate = '",Evalutionadjust,"'
        and state = '",State,"'
        order by Date desc
        ")
  )%>%
    arrange(Date)
  return(dframe)
}
premium_trend <- function(dframe) {
  df_out <- data.frame(matrix(ncol=6,nrow=1))
  colnames(df_out) <- c('Index', 'Date','Year Ending Quarter - X', 'Earned Exposures', 'Earned Premium', 'Adjusted Earned Premium') #, 'Frequency','Severity','Pure Premium')
  
  if (nrow(dframe) > 4) {
    for (row in (nrow(dframe)):4) {
      df_out <- df_out%>%
        add_row(Index = row,
                Date = as.Date(dframe[["Date"]][row]),
                `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(dframe[["Date"]][row])),' - ', year( as.Date(dframe[["Date"]][row]))),  #paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
                `Earned Exposures`=sum(dframe[['EHY']][max((row-3),0):row]),
                `Earned Premium`=sum(dframe[['EP']][max((row-3),0):row]),
                `Adjusted Earned Premium`=sum(dframe[['AdjustedEP']][max((row-3),0):row]))
    }
  } else {
    df_out <- df_out%>%
      add_row(Index = nrow(dframe),
              Date = as.Date(dframe[["Date"]][nrow(dframe)]),
              `Year Ending Quarter - X`= paste0('Qtr',quarter( as.Date(dframe[["Date"]][nrow(dframe)])),' - ', year( as.Date(dframe[["Date"]][nrow(dframe)]))),  #paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
              `Earned Exposures`=sum(dframe[['EHY']]),
              `Earned Premium`=sum(dframe[['EP']]),
              `Adjusted Earned Premium`=sum(dframe[['AdjustedEP']]))
  }
  #name the columns for display order based on above
  df_out <- df_out%>%
    mutate(`Average Earned Premium at CRL` = `Adjusted Earned Premium`/`Earned Exposures`)%>%
    arrange(Index)%>%
    select (-Index)
  
  data_clean <- na.omit(df_out) #omit the NA rows to clean it up a bit
  return(data_clean)
}
logest <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  exp(coef(result))
}
premium_trend_fitting <- function(data,lagtime){
  print('enter')
  dframe <- data%>%
    mutate(day_num = as.numeric(lubridate::ceiling_date(as.Date(Date),'month')-1)/365)%>%
    select(day_num,`Average Earned Premium at CRL`)
  df_out <- data.frame(matrix(ncol = 2,nrow=1))
  colnames(df_out) <- c('Exponential Trend','Pure Premium')
  fill_range <- if (nrow(data) > 20) {c(24,20,16,12,8,4)}
  else if (nrow(data) > 12) {c(20,16,12,8,6,4)}
  else if (nrow(data) > 8) {c(16,12,8,6,4)}
  else {c(8,6,4,2)}
  
  for (pt in fill_range) {
    print(nrow(data)-pt-lagtime+1)
    print(nrow(data)-lagtime)
    if ((nrow(data)-pt-lagtime+1)>0) {
      print('premium fitting!!!!!!!!!!!!!')
      print(dframe[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                `Pure Premium`=logest(dframe[['Average Earned Premium at CRL']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}

  shinyApp(
    ui = fluidPage(br(),
                   varSelectInput("State", "State", state_options('HO'),'GA'),
                   fluidRow(
                   column(12,align = 'center',
                  excelOutput("PremiumTrendExcel", width = '100%', height = '100%')))
                            
                   ),
    server = function(input, output, session) {  
      observeEvent({input$State},{
        #PremiumData <<- premium_trend_data(input$Program,input$IndicationDate, evaluation_use,input$State)
        PremiumData <<- premium_trend_data('HO','2022-07-01', '2022-10-01',input$State)
        PremiumData_state <<- premium_trend(PremiumData)
        print(PremiumData_state)

        #adding
        if (nrow(PremiumData_state) > 2) {
          Premium_fitting <<- premium_trend_fitting(PremiumData_state,0)
        } else {
          Premium_fitting <<- data.frame(matrix(ncol = 2,nrow = 0))
        }
      })
      observeEvent({input$State},{
        Premium_Tables.list <<- Premium_Tables('Georgia',PremiumData_state%>%select(-Date), Premium_fitting,dframe.inflation,NA,0,0,data.frame())
        output$PremiumTrendExcel <-renderExcel(Premium_Tables.list[[1]])
      })
      
      observeEvent({input$PremiumTrendExcel},{
        Premium.Interact <- excel_to_R(input$PremiumTrendExcel)
        currentPrem.raw <- Premium.Interact[Premium_Tables.list[[2]],5]
        projPrem.raw <- Premium.Interact[Premium_Tables.list[[3]],5]
        
        options(warn = -1)
        currentPrem.raw <- if (grepl('%',currentPrem.raw)) {as.numeric(str_replace_all(str_replace_all(currentPrem.raw,'%',''),' ',''))/100}else as.numeric(currentPrem.raw)
        projPrem.raw <- if (grepl('%',projPrem.raw)) {as.numeric(str_replace_all(str_replace_all(projPrem.raw,'%',''),' ',''))/100}else as.numeric(projPrem.raw)
        options(warn = 0)
        if (!is.na(currentPrem.raw)) {
          print(currentPrem.raw)
        } else {
          showNotification("Invalid Current Premium Trend Format")
        }
        if (!is.na(projPrem.raw)) {
          print(projPrem.raw)
        } else {
          showNotification("Invalid Projected Premium Trend Format")
        }
      })
      
   
   
    }
  )
  
  



