library(excelR)
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(ExcelFunctionsR)

#define input options


#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')


LDF_Excel_Pull <- function(Program,Rolling_Year_End,AsOfDate,state) {
  AsOfDate<- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  losses <- dbGetQuery(con,paste0("SELECT [IndicationDate]
      ,[EvaluationDate]
      ,[TableName]
      ,[Class]
      ,[Years]
      ,[Region]
	  ,	colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ, colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ
  FROM [ActuarialSandbox].[",Program,"].[ldfTriangles]
  pivot (avg(columnValue) for columnName in (colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ) ) as PivotTable 
  where indicationDate = '",Rolling_Year_End,"'
                             and EvaluationDate = '",AsOfDate,"'
                             
  "))%>%
    filter(Region == state | Region == 'CW')
  return(losses)
} #working to create tabels on LDF tabs for CW, state, weighted

LDF_Tables <- function(dframe, Data.Region, Peril.Class) {
dframe <- dframe%>%
  filter(Class == Peril.Class & Region == Data.Region)%>%
  select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
LDF_data <- dframe%>%
  filter(TableName == 'Averages')%>%
  select(-TableName)%>%
  arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','5 Yr. Wtd Avg','3 Yr. Wtd Avg')))

LDF_data.fil <- LDF_data[,c(1,12:ncol(LDF_data))]
LDF_data.filter <- LDF_data.fil[colSums(!is.na(LDF_data.fil)) > 0]
LDF_data.filter[6,] <- ''
LDF_data.filter[7,] <- c('Selections', paste0('=',toupper(letters)[2:(length(LDF_data.filter))],2))
LDF_data.filter[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:(length(LDF_data.filter))],7,':',toupper(letters)[length(LDF_data.filter)],7,'),1)'))
LDF_data.filter[7,4:ncol(LDF_data.filter)] <- 1
columns <- jsonlite::fromJSON(paste0(c('[',paste0('{"type": ',c('"text"',rep('"number"',length(LDF_data.filter)-1)),' , "title":"',toupper(letters)[1:(length(LDF_data.filter))],'", "width": "100"}',c(rep(',',length(LDF_data.filter)-1),'')),']'), collapse = ' '))
colnames(LDF_data.filter) <- toupper(letters)[1:(length(LDF_data.filter))]



updateTable <- "function(instance, cell, col, row, val, label, cellName) {
          if (col >0 & row < 10 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0)
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row < 31 ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
        }
}"

out.table <- excelTable(data = LDF_data.filter,columns = columns,updateTable = htmlwidgets::JS(updateTable),
                        allowDeleteColumn = F,
                        allowInsertRow = F,
                        allowInsertColumn = F,
                        allowDeleteRow = F,
                        autoWidth = F,columnSorting = F,columnResize = F)

return(list(out.table, LDF_data.filter))
}


LDF_Translate <- function(dframe) { #The averages table is always 8 rows long
  
  for (i in colnames(dframe)) {
    if (i != "A" & i != "M") {
      if (grepl('AVERAGE',dframe[[i]][34])) {
        dframe[[i]][34] <- Excel.Translate(dframe,i)
      } else {
        filter.string <- str_replace(paste0(str_replace_all(dframe[[i]][34],i,paste0("dframe[['",i,"']][")),']'),'=','')
        tryString <- tryCatch(as.numeric(eval(parse(text = filter.string))),warning = function(w){}, error = function(e) {})
        dframe[[i]][34] <- if (is.null(tryString)) 1 else tryString 
      }
    }
  }

  dframe[41,14:23] <- as.numeric(dframe[34,2:11]) *as.numeric(dframe[39,22]) + as.numeric(dframe[34,14:23]) *(1-as.numeric(dframe[39,22]))
  for (i in 2:ncol(dframe)) {
    if(i <= 11) {
      dframe[35,i] <- prod(unlist(as.numeric(dframe[34,i:11]))) 
    } else if (i >=14) {
      dframe[35,i] <- prod(unlist(as.numeric(dframe[34,i:ncol(dframe)])))
      dframe[42,i] <- prod(unlist(as.numeric(dframe[41,i:ncol(dframe)]))) 
    }
  }
    
  return(dframe)
}

Excel.Translate <- function(dframe,i) {
  i.dframe <- dframe[[i]]
  ii <- i.dframe[34]
  i.filter <- ii
  for (j in unlist(gregexpr(paste0(':',i),ii)))  {
    i.filter <- str_replace(i.filter,substr(ii,j,j+2),paste0(substr(ii,j,j),substr(ii,j+2,j+2),']'))
  }
  i.filter <- str_replace_all(str_replace(i.filter,'=',''),i,paste0(i,'['))
  
  
  for (k in unlist(gregexpr('\\d)',i.filter))) {
    if (k >0) {
      i.filter <- str_replace(i.filter,paste0(substr(i.filter,k-1,k),']'),paste0(substr(i.filter,k,k),']'))
    }
  }
  for (j in unlist(gregexpr('\\d,',i.filter))) {
    if (j >0) {
      i.filter  <- str_replace(i.filter,paste0(substr(i.filter,j-1,j),']'),paste0(substr(i.filter,j,j),']'))
    }
  }
  
  i.dframe <- as.numeric(i.dframe[1:5])
  i.out <- tryCatch(as.numeric(eval(parse(text = str_replace_all(i.filter,i,'i.dframe')))),warning = function(w){}, error = function(e) {})
  i.out <- if (is.null(i.out)) dframe[[i]][33] else i.out
  
  return(i.out)
}

LDF_Tables_All <- function(data, class, State, LDFweight, state.formulas, cw.formulas) {
  dframe.state <- data%>%
    filter(Class == class & Region != 'CW')%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
  LDF_data_Losses.State <- dframe.state[,1:12]%>%
    filter(TableName == 'Losses')%>% 
    select(-TableName)%>%   
    mutate(add2 = NA)%>%
    arrange(Years)
    
  LDF_data_LossRatio.State <- dframe.state[,c(1:2,13:ncol(dframe.state))]%>%
    filter(TableName == 'Loss Ratios')%>%  
    mutate(add = NA,add2 = NA)%>%
    arrange(Years)%>% 
    select(-TableName)
  
  LDF_data_Averages.State <- dframe.state[,c(1:2,13:ncol(dframe.state))]%>%
    filter(TableName == 'Averages')%>% 
    mutate(add = NA,add2 = NA)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','3 Yr. Wtd Avg','5 Yr. Wtd Avg')))%>% 
    select(-TableName)
  state.cols <- ncol(LDF_data_Averages.State)

  if (nrow(LDF_data_Losses.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Losses.State)))
    colnames(dummy) <- colnames(LDF_data_Losses.State)
    LDF_data_Losses.State <- dummy
    LDF_data_Losses.State[1,1] <- 'Not Enough Data'
  }  
  if (nrow(LDF_data_LossRatio.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_LossRatio.State)))
    colnames(dummy) <- colnames(LDF_data_LossRatio.State)
    LDF_data_LossRatio.State <- dummy
    LDF_data_LossRatio.State[1,1] <- 'Not Enough Data'
  }
  
  
  form.fill.state <- max(ncol(LDF_data_Averages.State[colSums(!is.na(LDF_data_Averages.State)) > 0]),1)
  if (nrow(LDF_data_Averages.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Averages.State)))
    colnames(dummy) <- colnames(LDF_data_Averages.State)
    LDF_data_Averages.State <- dummy
    LDF_data_Averages.State[1,1] <- 'Not Enough Data'
    LDF_data_Averages.State[6,1] <- NA
    LDF_data_Averages.State[7,1:2] <- c('Selections', NA)
    LDF_data_Averages.State[8,1:2] <-c('Cumulative', NA)
    
  } else {
    LDF_data_Averages.State[6,] <- NA
    fill.state.formulas <- if (length(state.formulas) > 0) state.formulas else paste0('=',toupper(letters)[2:form.fill.state],30)
    LDF_data_Averages.State[7,] <- c('Selections',fill.state.formulas, rep(NA,state.cols-form.fill.state))
    LDF_data_Averages.State[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:form.fill.state],34,':',toupper(letters)[form.fill.state],34,'),1)'), rep(NA,state.cols-form.fill.state))
    LDF_data_Averages.State[7,min(4,form.fill.state):form.fill.state] <- 1
  }
  
  colnames(LDF_data_Losses.State) <- colnames(LDF_data_LossRatio.State) <- colnames(LDF_data_Averages.State) <- toupper(letters)[1:state.cols]
  
  ###CW data
  dframe.CW <- data%>%
    filter(Class == class & Region == 'CW')%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
  LDF_data_Losses.CW <- dframe.CW[,1:12]%>%
    filter(TableName == 'Losses')%>%
    select(-TableName)%>%
    arrange(Years)
  
  LDF_data_LossRatio.CW <- dframe.CW[,c(1:2,13:ncol(dframe.CW))]%>%
    filter(TableName == 'Loss Ratios')%>%
    select(-TableName)%>%
    mutate(add = NA)%>%
    arrange(Years)
  
  LDF_data_Averages.CW <- dframe.CW[,c(1:2,13:ncol(dframe.CW))]%>%
    filter(TableName == 'Averages')%>%
    select(-TableName)%>%
    mutate(add = NA)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','3 Yr. Wtd Avg','5 Yr. Wtd Avg')))
  
  cw.cols <- ncol(LDF_data_Averages.CW)
  LDF_data_Averages.CW[6,] <- NA
  fill.cw.formulas <- if (length(cw.formulas) > 0) cw.formulas else  paste0('=',toupper(letters)[(state.cols+2):(state.cols + cw.cols-1)],30)
  LDF_data_Averages.CW[7,] <- c('Selections', fill.cw.formulas ,NA)
  LDF_data_Averages.CW[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[(state.cols+2):(state.cols + cw.cols-1)],34,':',toupper(letters)[(state.cols + cw.cols-1)],34,'),1)'),NA)
  LDF_data_Averages.CW[7,4:(ncol(LDF_data_Averages.CW)-1)] <- 1
  
  colnames(LDF_data_Losses.CW) <- colnames(LDF_data_LossRatio.CW) <- colnames(LDF_data_Averages.CW) <- toupper(letters)[(state.cols+1):(state.cols + cw.cols)]
  
  LDF_Table_All <- rbind(NA,NA,
                         merge(LDF_data_Losses.State%>%mutate(Join = A),LDF_data_Losses.CW%>%mutate(Join = M),by = 'Join', all = T)%>%select(-Join),NA,NA,NA,
                         merge(LDF_data_LossRatio.State%>%mutate(Join = A),LDF_data_LossRatio.CW%>%mutate(Join = M),by = 'Join', all = T)%>%select(-Join),NA,NA,NA,
                         cbind(LDF_data_Averages.State,LDF_data_Averages.CW),NA,NA,NA,NA,NA,NA,NA,NA)
  
  state.bold <- nrow(LDF_data_Losses.CW)-nrow(LDF_data_Losses.State)
  state.losses.colname <- column_names(LDF_data_Losses.State, 'Losses', '2022-07-01','2022-10-01')
  state.lossRatio.colname <- column_names(LDF_data_Losses.State, 'Loss Ratios', '2022-07-01','2022-10-01')
  
  cw.losses.colname <- column_names(LDF_data_Losses.CW, 'Losses', '2022-07-01','2022-10-01')
  cw.lossRatio.colname <- column_names(LDF_data_Losses.CW, 'Loss Ratios', '2022-07-01','2022-10-01')
  
  LDF_Table_All[(state.bold+2),1:length(state.losses.colname)] <-  state.losses.colname
  LDF_Table_All[2,13:(length(cw.losses.colname)+12)] <-  cw.losses.colname
  LDF_Table_All[(state.bold+1),1] <- LDF_Table_All[1,13] <- if (state.losses.colname[1] != 'Accident Year') 'Rolling Year' else NA
  LDF_Table_All[(state.bold+2),1] <- LDF_Table_All[2,13] <- if (state.losses.colname[1] != 'Accident Year')  paste0('Ending in ',month(as.Date('2022-07-01')-1),'/',day(as.Date('2022-07-01')-1)) else 'Accident Year'
  
  
  LDF_Table_All[(state.bold+15),1:length(state.lossRatio.colname)] <-  state.lossRatio.colname
  LDF_Table_All[15,13:(length(cw.lossRatio.colname)+12)] <-  cw.lossRatio.colname
  LDF_Table_All[(state.bold)+14,1] <- LDF_Table_All[14,13] <- if (state.losses.colname[1] != 'Accident Year') 'Rolling Year' else NA
  LDF_Table_All[(state.bold)+15,1] <- LDF_Table_All[15,13] <- if (state.losses.colname[1] != 'Accident Year')  paste0('Ending in ',month(as.Date('2022-07-01')-1),'/',day(as.Date('2022-07-01')-1)) else 'Accident Year'
  
  LDF_Table_All[41,13:23] <- c('Selections', paste0('=IF(ISBLANK(',toupper(letters)[2:10],34,'),1,',toupper(letters)[2:10],34,')* V39 + ',toupper(letters)[14:22],'34* (1-V39)'),NA)
  LDF_Table_All[42,13:23] <- c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[14:22],41,':',toupper(letters)[22],41,'),1)'),NA)
  
  LDF_Table_All[39,21:22] <- c(paste0(State,' Weight:'), LDFweight)
  
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"110"},
  { "type": "number", "title": "B" ,"width":"80"},
  { "type": "number", "title": "C" ,"width":"80"},
  { "type": "number", "title": "D" ,"width":"80"},
  { "type": "number", "title": "E" ,"width":"80"},
  { "type": "number", "title": "F" ,"width":"80"},
  { "type": "number", "title": "G" ,"width":"80"},
  { "type": "number", "title": "H" ,"width":"80"},
  { "type": "number", "title": "I" ,"width":"80"},
  { "type": "number", "title": "J" ,"width":"80"},
  { "type": "number", "title": "K" ,"width":"80"},
  { "type": "text",  "title": "L" ,"width":"50"},
  { "type": "text",  "title": "M" ,"width":"110"},
  { "type": "number", "title": "N" ,"width":"85"},
  { "type": "number", "title": "O" ,"width":"85"},
  { "type": "number", "title": "P" ,"width":"85"},
  { "type": "number", "title": "Q" ,"width":"85"},
  { "type": "number", "title": "R" ,"width":"85"},
  { "type": "number", "title": "S" ,"width":"85"},
  { "type": "number", "title": "T" ,"width":"85"},
  { "type": "number", "title": "U" ,"width":"85"},
  { "type": "number", "title": "V" ,"width":"85"},
  { "type": "number", "title": "W" ,"width":"85"}
  ]')
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if (col < 11 & (row == ",state.bold," | row == ",state.bold+1," |  row == ",state.bold + 13,"  | row == ",state.bold + 14," ))  {
            txt = cell.innerText;
            cell.innerHTML = txt.bold();
            if ( (row == ",state.bold+1," | row == ",state.bold + 14,") & col <=",form.fill.state," ) {
            cell.style.borderBottomColor = 'black';
            }
        } else if (col > 11 & (row == 0 | row == 1 | row == 13 | row ==14) ) {
            txt = cell.innerText;
            cell.innerHTML = txt.bold();
            if (row == 1 | row == 14 ) {
            cell.style.borderBottomColor = 'black';
            }
        } else if (col >0 & row < 15 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0);
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row < 43 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
          }
        
        if ( (col == 11 & row <= 36) | row == 36) {
            cell.style.backgroundColor = 'lightgrey';
        }
        if (col == 21 & row == 38) {
             cell.style.outline = 'thin solid';
        }
        if (col <= 21 & col >=20 & row == 38 ) {
            cell.style.backgroundColor = 'lightblue';
        }
        if (row >= 40 & row <= 41) {
            txt2 = cell.innerText;
            cell.innerHTML = txt2.bold();
        }
        
}")
  out.table <- excelTable(data = LDF_Table_All,columns = columns,updateTable = htmlwidgets::JS(updateTable),
             allowDeleteColumn = F,
             allowInsertRow = F,
             allowInsertColumn = F,
             allowDeleteRow = F,
             autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = F
  )
  return(list(out.table, LDF_Table_All))
}

state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select state from 
      actuarialsandbox.",program,".modeledCatLoad
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}
column_names <- function(dframe,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  dframe <- dframe[colSums(!is.na(dframe)) > 0]
  if (table == 'Losses') {
    c(
      ifelse(month(Rolling_Year_End %m-% months(1))==12,
             'Accident Year',
             paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 12*c(1:(length(dframe)-1)))
  }
  else {
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(dframe)))) {
      if (i == length(colnames(dframe))) {
        names <- c(names,paste(as.character((i-1)*12+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*12+adder),':',as.character((i-1)*12+adder+12),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
}


runApp(
  shinyApp(
    ui = fluidPage(br(),
                   varSelectInput("State", "State", state_options('HO'),'VA'),
                   fluidRow(column(6, h3('State Triangles')),
                            column(6, h3('Countrywide Triangles'))),
                   fluidRow(
                   column(12,align = 'center',
                  excelOutput("LDFAveragesAllTable", width = '100%', height = '100%')))
                            
                   ),
    server = function(input, output, session) {  
      observeEvent({input$State},{
      LDFDataPull <<- LDF_Excel_Pull('HO','2022-07-01','2022-10-01',input$State)
      LDFDataAll <<-LDF_Tables_All(LDFDataPull, 'All Perils', input$State, 0.5,NA,NA) 
      })
      observeEvent({input$State},{
        output$LDFAveragesAllTable <-renderExcel(LDFDataAll[[1]])
      })
      
      
   
      observeEvent({input$LDFAveragesAllTable},{
        test.dframe <<- excel_to_R(input$LDFAveragesAllTable)
      })

    }
  )
)

LDFDataAll[[2]]

readxl::read_excel(LDFDataAll[[2]])
###state data
state <- 'TX'
LDFweight <- 1
state.formulas.All <- pull_ldfs('co','2022-07-01','2022-10-01','tx','All Perils')
state.formulas.Weather <- pull_ldfs('ho','2022-07-01','2022-10-01','GA','Weather')
state.formulas.Attritional <- pull_ldfs('ho','2022-07-01','2022-10-01','GA','Attritional')

cw.formulas.All <- pull_ldfs('co','2022-07-01','2022-10-01','tx','All Perils','CW')
cw.formulas.Weather <- pull_ldfs('ho','2022-07-01','2022-10-01','GA','Weather','CW')
cw.formulas.Attritional <- pull_ldfs('ho','2022-07-01','2022-10-01','GA','Attritional','CW')


LDFDataPull <- LDF_Excel_Pull('CO','2022-07-01','2022-10-01',state)

LDFDataAll <-LDF_Tables_All(LDFDataPull, 'All Perils',state,LDFweight,state.formulas.All,cw.formulas.All)
LDFDataWeather <-LDF_Tables_All(LDFDataPull, 'Weather',state,LDFweight,state.formulas.Weather,cw.formulas.Weather)
LDFDataAttritional <-LDF_Tables_All(LDFDataPull, 'Attritional',state,LDFweight,state.formulas.Attritional,cw.formulas.Attritional)
LDFDataAll[[1]]

LDFAveragesAll.state.formulas <- LDFDataAll[[2]][34,2:11][colSums(!is.na(LDFDataAll[[2]][34,2:11])) > 0]
LDFAveragesAll.CW.formulas <- LDFDataAll[[2]][34,14:22]

LDFAveragesAll.Cumulative.Final <- LDF_Translate(LDFDataAll[[2]])[42,13:22] 
LDFAveragesWeather.Cumulative.Final <- LDF_Translate(LDFDataWeather[[2]])[42,14:22]
LDFAveragesAttritional.Cumulative.Final <- LDF_Translate(LDFDataAttritional[[2]])[42,14:22]

save_selections_LDF('ho','2022-07-01','2022-10-01','GA','All Perils','In Progress',
                    LDFAveragesAll.state.formulas,
                    LDFAveragesAll.CW.formulas,
                    LDFAveragesAll.Cumulative.Final,
                    LDFweight,
                    6,0,0
                )
save_selections_LDF <- function(Program,IndicationDate,EvaluationDate, Region,Class,Status,
                            LDF.state.formulas,
                            LDF.cw.formulas,
                            LDF.final.cumulative,
                            weight,selected_by,technicalReviewer, PeerReviewer){
  
  
  saveLDF <- function(variable, number, subregion) {
  dbGetQuery(con,paste0("
select
'",IndicationDate,"' as IndicationDate,
'",EvaluationDate,"' as EvaluationDate,
'",Region,"' as Region,
'",Class,"' as Class,
'",Status,"' as Status,
",selected_by," as selected_by,
",technicalReviewer," as technicalReviewer,
",PeerReviewer," as PeerReviewer,
'LDF",paste0(number,deparse(substitute(variable)),subregion),"' as columnName,
cast('",variable,"' as nvarchar(50)) as columnValue, 
getdate() as rowStartDate,
 convert(datetime,'9999-12-31 23:59:59') as rowEndDate,
1 as currentRow
into #load

MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	--AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end ,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET 
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);

	MERGE [actuarialsandbox].[",Program,"].[indicationSelections] AS TARGET
USING #load AS SOURCE 
ON 	(TARGET.IndicationDate = SOURCE.IndicationDate or (TARGET.IndicationDate is null and SOURCE.IndicationDate is null))
	AND (TARGET.EvaluationDate = SOURCE.EvaluationDate or (TARGET.EvaluationDate is null and SOURCE.EvaluationDate is null))
	AND (TARGET.Region = SOURCE.Region or (TARGET.Region is null and SOURCE.Region is null))
	AND (TARGET.Status = SOURCE.Status or (TARGET.Status is null and SOURCE.Status is null))
	AND (TARGET.Class = SOURCE.Class or (TARGET.Class is null and SOURCE.Class is null))
	AND (TARGET.columnName = SOURCE.columnName or (TARGET.columnName is null and SOURCE.columnName is null))
	AND (TARGET.columnValue = SOURCE.columnValue or (TARGET.columnValue is null and SOURCE.columnValue is null))
	AND TARGET.currentRow=1 -- Only update records matching current rows and for the state and algorithm being run
WHEN MATCHED 
THEN UPDATE SET TARGET.rowEndDate = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then dateadd(second,-1,getdate()) else TARGET.rowEndDate end, 
				TARGET.currentRow = case when SOURCE.Status <> 'In Progress' and TARGET.columnValue <> source.columnVALUE then 0 else TARGET.currentRow end,
				TARGET.columnValue = case when SOURCE.Status = 'In Progress' and TARGET.columnValue <> source.columnVALUE then SOURCE.columnValue else TARGET.columnValue end,
				TARGET.selected_by = SOURCE.selected_by,
				TARGET.technicalReviewer = SOURCE.technicalReviewer,
				TARGET.PeerReviewer = SOURCE.PeerReviewer	

WHEN NOT MATCHED BY TARGET and SOURCE.Status <> 'In Progress'
THEN INSERT (IndicationDate,EvaluationDate,Region, Status,Class,selected_by,technicalReviewer,PeerReviewer,columnName,columnValue,rowStartDate, rowEndDate, currentRow ) 
	VALUES (SOURCE.IndicationDate,SOURCE.EvaluationDate,SOURCE.Region, SOURCE.Status,SOURCE.Class,SOURCE.selected_by,SOURCE.technicalReviewer,SOURCE.PeerReviewer,SOURCE.columnName,SOURCE.columnValue,SOURCE.rowStartDate, SOURCE.rowEndDate, SOURCE.currentRow);
"))
  }
  
  
  for (i in 1:length(LDF.final.cumulative)) { 
    CumulativeFinal <- LDF.final.cumulative[[i]]
    saveLDF(CumulativeFinal,i,'') 
  }
  
  for (i in 1:length(LDF.state.formulas)) { 
    SelectFormula <- LDF.state.formulas[i]
    saveLDF(SelectFormula,i,'')
  }
  for (i in 1:length(LDF.cw.formulas)) { 
    SelectFormula <- LDF.cw.formulas[i]
    saveLDF(SelectFormula,i,'CW')
  }
  saveLDF(weight,'','')
}

test.copy <- LDFAveragesWeather.Cumulative.Final
if (!setequal(LDFAveragesWeather.Cumulative.Final,test.copy)) test <- 1  #check if 2 vectors are idential, use in when to load other exhibits logic for when to save LDF to reactiveVales
test 
deparse(substitute(test))
paste0('=',toupper(letters)[2:11],30)

pull_ldfs <- function(Program, IndicationDate, EvaluationDate, Region,Class,CW=NA) {
  CW <- ifelse(is.na(CW), '', CW)
  
  dframe <- dbGetQuery(con, paste0("
    select * from ActuarialSandbox.",Program,".indicationSelections
    where columnName like '%LDF%Formula",CW,"'
    and Region = '",Region,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and class = '",Class,"'
    order by columnName
    "
  ))
  
  dframe <- dframe%>%
    filter(Status == ifelse('Published' %in% dframe$Status,'Published',
                            ifelse('In Review' %in% dframe$Staus, 'In Review', 'In Progress')))%>%
    select(columnValue)
  return(dframe[[1]])
}
