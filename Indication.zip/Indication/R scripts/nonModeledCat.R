#load packages
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #pack

server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')


nonModeledPull <- function(Program, IndicationDate, EvaluationDate, State) {
  dframe <- dbGetQuery(con, paste0(
    "
    select t.*, coalesce(Zone, 'No Mapping') as Zone
    from ActuarialSandbox.",Program,".TerritorialNonModeled t
    left join (
       select * from
       ActuarialSandbox.",Program,".NonModeledZoneMapping
       where currentRow = 1
    )  m on t.state = m.state and t.territoryCode=m.territoryCode
    where IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
    and t.state = '",State,"'

    "
  ))%>%
  group_by(Loss_Rolling_Year,Zone)%>%
    summarise(TotalPaid_Non_Cat = sum(TotalPaid_Non_Cat), TotalPaid_Cat = sum(TotalPaid_Cat), .groups = 'drop')
  

  
  return(dframe)
}

inforceSummary <- function(Program, IndicationDate, EvaluationDate, State) {
  inforce <- dbGetQuery(con, paste0(
    "
 select coalesce(Zone, 'All Other') as Zone, sum(inforceCount) as inforceCount
  from ActuarialSandbox.",Program,".TerritorialInforceAAL a
  left join ActuarialSandbox.",Program,".NonModeledZoneMapping m on m.state=a.state and m.territoryCode=a.territoryCode
  where a.state = '",State,"'
    and IndicationDate = '",IndicationDate,"'
    and EvaluationDate = '",EvaluationDate,"'
  group by coalesce(Zone, 'All Other') 
    "
  ))
  inforce <- inforce %>%
    mutate(percent = inforceCount/ sum(inforce$inforceCount))
  return(inforce)
}

NonModeledSummary <- function(IndicationDate,data.in, LossTrend) {
  zone.list <- unique(data.in$Zone)
  trendTo <- year(as.Date(IndicationDate)-1)
  store <- list()
  for (zone in zone.list) {
    dframe <- data.in[data.in$Zone == zone,]%>%
      mutate(Trend = (1+LossTrend)^(trendTo-Loss_Rolling_Year))%>%
      mutate(TrendedNonCat = coalesce(Trend*TotalPaid_Non_Cat,0),
             TrendedCat = coalesce(Trend*TotalPaid_Cat,0))%>%
      mutate(EstimatedCatLoad = coalesce(TrendedCat/TrendedNonCat,0),
             Loss_Rolling_Year = as.character(Loss_Rolling_Year))%>%
      select(-Trend)
    straight.avg <- mean(dframe$EstimatedCatLoad)
    weighted.avg <- sum(dframe$TrendedCat)/sum(dframe$TrendedNonCat)
    dframe <- dframe%>%
      add_row(
        Loss_Rolling_Year = 'Total',
        Zone = max(dframe$Zone),
        TotalPaid_Non_Cat = sum(dframe$TotalPaid_Non_Cat),
        TotalPaid_Cat = sum(dframe$TotalPaid_Cat),
        TrendedNonCat = sum(dframe$TrendedNonCat),
        TrendedCat = sum(dframe$TrendedCat),
        EstimatedCatLoad = weighted.avg
        
      )
    store[[length(store)+1]] <-  list(dframe,data.frame(Name = c('Weighted Average','Straight Average'),Average = c(weighted.avg,straight.avg)))

  }
  return(store)
}

NonModeledZones <- nonModeledPull('ho','2022-07-01','2022-10-01','TX')

InforceSummary <- inforceSummary('ho','2022-07-01','2022-10-01','TX')

NonModeledResults <- NonModeledSummary('2022-07-01',NonModeledZones,.025)
NonModeledResults[[3]][[2]]


