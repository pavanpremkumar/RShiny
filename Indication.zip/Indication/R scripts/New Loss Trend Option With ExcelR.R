
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(ExcelFunctionsR)
library(excelR)
library(shinyTree)
library(glue)
#define input options
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"


con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')



Constant_Quality <- function(fillOutDate) {
  dframe <- dbGetQuery(con, glue_safe("
                                     select top 5 *
                                     from ActuarialSandbox.dbo.ConstantQuality
                                     where '",fillOutDate,"' between rowStartDate and rowEndDate
                                     order by year desc, month desc
                                     "))%>%
    select(Year, Month, ConstantQualityIndex)%>%
    arrange(Year, Month)%>%
    mutate(Month = month.name[Month])
  return(dframe)
}

Loss_Tables <- function(State,LossData,LossFitting ,CQI,formulas,currentTrend,projTrend,ISOdata) {
  
  LossFitting <- LossFitting[!is.na(LossFitting[1]),]
  dframe <- data.frame(matrix(ncol = 13, nrow = nrow(LossData)+nrow(LossFitting)+20))
  dframe[1,1] <- State
  dframe[2,1] <- 'Homeowners of America Insurance Company'
  dframe[3,1] <- 'Homeowners: All Forms Combined'
  dframe[4,1] <- 'Loss Trend Selection'
  dframe[7,1:7] <- colnames(LossData)
  dframe[8:(nrow(LossData)+7),1:7] <- LossData
  
  
  dframe[(nrow(LossData)+12+nrow(LossFitting)),6] <- 'Selections'
  dframe[(nrow(LossData)+13+nrow(LossFitting)),6:7] <- c('Current',currentTrend)
  dframe[(nrow(LossData)+14+nrow(LossFitting)),6:7] <- c('Projected',projTrend)
  
  
  currentRow <- (nrow(LossData)+13+nrow(LossFitting))
  projRow <- (nrow(LossData)+14+nrow(LossFitting))
  
  
  dframe[(nrow(LossData)),10:11] <- c('Circular Number','ISO Trend')
  if (nrow(ISOdata) > 0) {
    dframe[(nrow(LossData)+1),10:11] <- c(ISOdata$CircularNumber,ISOdata$LossTrendFactor/100)
  } else {
    dframe[(nrow(LossData)+1),10:11] <- c('None Saved',NA)
  }
  #print(CQI)
  if (nrow(CQI) > 0) {
    dframe[(nrow(LossData)+9),9:11] <- c('Year','Month','Constant Quality')
    dframe[(nrow(LossData)+10):(nrow(LossData)+9+nrow(CQI)),9:11] <- CQI
    dframe[(nrow(LossData)+11+nrow(CQI)),10:11] <- c('Average',coalesce(formulas,glue_safe('=AVERAGE(K',(nrow(LossData)+10),":K",(nrow(LossData)+9+nrow(CQI)) , ')')))
  }
  
  
  if (nrow(LossFitting)>0) {
    dframe[(nrow(LossData)+10),4:7] <- colnames(LossFitting)
    dframe[(nrow(LossData)+11):(nrow(LossData)+10+nrow(LossFitting)),4:7] <- LossFitting
  }
  
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"80"},
  { "type": "number", "title": "B" ,"width":"80"},
  { "type": "number", "title": "C" ,"width":"80"},
  { "type": "number", "title": "D" ,"width":"80"},
  { "type": "number", "title": "E" ,"width":"80"},
  { "type": "number", "title": "F" ,"width":"80"},
  { "type": "number", "title": "G" ,"width":"80"},
  { "type": "number", "title": "H" ,"width":"50"},
  { "type": "number", "title": "I" ,"width":"125"},
  { "type": "number", "title": "J" ,"width":"125"},
  { "type": "number", "title": "K" ,"width":"125"},
  { "type": "number", "title": "L" ,"width":"175"} ,
  { "type": "number", "title": "M" ,"width":"175"}
  ]')
  #cell.style.borderBottomColor = 'black';
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
          if (col < 11 & row <=6)  {
            if (row < 3) {
              txt = cell.innerText;
              cell.innerHTML = txt.bold();
            }
            if (col <7 & row == 6) {
              cell.style.borderBottomColor = 'black';
              if (col ==0) {
                cell.style.borderRightColor = 'black';
              }
            }
        } else if (col >=0 & row < ",(nrow(LossData)+7)," & !(col== 8 & row == 15)) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              if (col < 4 | col == 5) {
              numVal = Number(txt).toFixed(0);
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
              } else {
              numVal = Number(txt).toFixed(2);
              cell.innerHTML = numVal
              }
            }
            if (row >5  & col == 0){
                cell.style.borderRightColor = 'black';
            
            }
          } else if ( ((col >0 &  row > ",(nrow(LossData)+7),") | (col== 8 & row == 15)) & col != 8 & col != 9 ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              num = Number(txt)*100
              cell.innerHTML = num.toFixed(1).toString().concat('%');
            }
          }
        
        if ( col > 6) {
            cell.style.backgroundColor = 'lightgrey';
        }
        
        if ((col == 5 | col ==6) & (row == ",nrow(LossData)+11+nrow(LossFitting)," | row == ",nrow(LossData)+12+nrow(LossFitting)," | row == ",nrow(LossData)+13+nrow(LossFitting),") ) {
        
            cell.innerHTML = cell.innerText.bold();
        }
        
}")
  #print(dframe)
  out.table <- excelTable(data = dframe,columns = columns,
                          updateTable = htmlwidgets::JS(updateTable),
             allowDeleteColumn = F,
             allowInsertRow = F,
             allowInsertColumn = F,
             allowDeleteRow = F,
             autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = T,
             mergeCells = list(A1 = c(7,1), A2=c(7,1), A3=c(7,1),A4=c(7,1) )
  )
  return(list(out.table,currentRow,projRow))
}
#Loss_Tables('Georgia',LossData_state%>%select(-Date), Loss_fitting,dframe.inflation,NA,0,0)[[1]]


state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select state from 
      actuarialsandbox.",program,".modeledCatLoad
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}

logest <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  exp(coef(result))
}
loss_trend_state <- function(program,IndicationDate,EvaluationDate,input_state) {
  ##print('in')
  dframe <- dbGetQuery(con, glue_sql(
    "SELECT *
  FROM [ActuarialSandbox].[",program,"].[LossTrend]
  where IndicationDate = '",IndicationDate,"'
  and EvaluationDate = '",EvaluationDate,"'
  and state = '",input_state,"'  
  and dateadd(day, 1,EOMONTH(DATEFROMPARTS(Accident_Year,Accident_Year_Quarter*3,1))) > dateadd(quarter, 1,dateadd(year,-7,'",IndicationDate,"'))
  and concat(Accident_Year,Accident_Year_Quarter) >= (
    select  min(concat(year, quarter)) 
    from ActuarialSandbox.ho.targitPolicyMonth
    where state = '",input_state,"' )
    "
  ))%>%
    arrange(state,Accident_Year, Accident_Year_Quarter)%>%
    select(-state,-IndicationDate,-EvaluationDate)%>%
    group_by(Accident_Year,Accident_Year_Quarter)%>%
    summarize_all(sum)
  ##print('loaded')
  df_out <- data.frame(matrix(ncol=7,nrow=1))
  colnames(df_out) <- c('Index', 'Year','Quarter','Year Ending Quarter - X', 'Earned Exposures', 'Capped Incurred Loss & LAE', 'Incurred Claims') #, 'Frequency','Severity','Pure Premium')
  
  if (nrow(dframe) > 4) {
    for (row in (nrow(dframe)):4) {
      df_out <- df_out%>%
        add_row(Index=row,
                Year = dframe[["Accident_Year"]][row],
                Quarter = dframe[["Accident_Year_Quarter"]][row],
                `Year Ending Quarter - X`=paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][row]),' - ',as.character(dframe[["Accident_Year"]][row])),
                `Earned Exposures`=sum(dframe[['Earned Exposures']][(row-3):row]),
                `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']][(row-3):row]),
                `Incurred Claims`=sum(dframe[['Incurred Claims']][(row-3):row]))#, X2 = paste('Qrt',as.character(dframe$Accident_Year_Quarter[row]),' - ',as.character(dframe$AccidentYear[row])))
    }
  } else {
    df_out <- df_out%>%
      add_row(Index=nrow(dframe),
              Year = dframe[["Accident_Year"]][nrow(dframe)],
              Quarter = dframe[["Accident_Year_Quarter"]][nrow(dframe)],
              `Year Ending Quarter - X`=paste0('Qrt',as.character(dframe[["Accident_Year_Quarter"]][nrow(dframe)]),' - ',as.character(dframe[["Accident_Year"]][nrow(dframe)])),
              `Earned Exposures`=sum(dframe[['Earned Exposures']]),
              `Capped Incurred Loss & LAE`=sum(dframe[['Capped Incurred Loss & LAE']]),
              `Incurred Claims`=sum(dframe[['Incurred Claims']]))
  }
  
  #name the columns for display order based on above
  
  df_out <- df_out%>%
    mutate(Frequency = coalesce(`Incurred Claims`/`Earned Exposures`*100,0),
           Severity = coalesce(`Capped Incurred Loss & LAE`/`Incurred Claims`,0))%>%
    mutate(`Pure Premium` =coalesce(Frequency*Severity/100,0))%>%
    arrange(Index)%>%
    select(-Index)
  
  return(na.omit(df_out))
  
}


loss_trend_fitting <- function(data,lagtime) { 
  dframe <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365,0))%>%
    select(day_num,Frequency, Severity, `Pure Premium`)
  df_out <- data.frame(matrix(ncol = 4,nrow=1))
  colnames(df_out) <- c('Exponential Trend', 'Frequency','Severity','Pure Premium')
  
  fill_range <- if (nrow(data) > 20) {c(24,20,16,12,8,4)}
  else if (nrow(data) > 12) {c(20,16,12,8,6,4)}
  else if (nrow(data) > 8) {c(16,12,8,6,4)}
  else {c(8,6,4,2)}
  
  for (pt in fill_range) {
    if ((nrow(data)-pt-lagtime+1)>0) {
      df_out <- df_out %>%
        add_row(`Exponential Trend` = paste(pt,'pt',sep = ' '),
                Frequency=logest(dframe[['Frequency']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1, #select the right rows accounting for lag time
                Severity=logest(dframe[['Severity']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1,
                `Pure Premium`=logest(dframe[['Pure Premium']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)],dframe[['day_num']][(nrow(data)-pt-lagtime+1):(nrow(data)-lagtime)])['x']-1)
    }
  }
  return(df_out)
}
#Loss Trend Plots functions
logest_fit <- function(y, x, ...){
  if(missing(x) || is.null(x)) x <- seq_along(y)
  result <- lm(log(y) ~ x, ...)
  #exp(coef(result))
}

loss_trend_fitting_plot <- function(data,pt,name) {
  data$varChoose <- data[[name]]
  
  data1 <- data%>%
    mutate(day_num = coalesce(as.numeric(lubridate::ceiling_date(as.Date(paste(Year,3*Quarter,1,sep='-')),'month')-1)/365.25,0),
           YearQuarter = `Year Ending Quarter - X`)%>%
    separate(YearQuarter,into = c('one', 'two'), sep = ' - ')%>%
    unite('YearQuarter',c('two', 'one'), sep = ' - ')%>%
    select(YearQuarter,day_num,varChoose)
  
  data2 <- na.omit(data1)
  
  data2$Index <- 1:nrow(data2)
  
  chosenName=logest_fit(data2$varChoose[(nrow(data2)-pt+1):(nrow(data2))],data2[['day_num']][(nrow(data2)-pt+1):(nrow(data2))])
  
  data2 <- data2%>%
    mutate(IndexA = ifelse(Index > nrow(data2)-pt,1,NA))%>%
    select(YearQuarter, IndexA)
  
  data3 <- na.omit(data2)
  
  data1 <- data1%>%
    left_join(data2, by = c('YearQuarter'='YearQuarter'))%>%
    mutate(plotName = ifelse(YearQuarter >= min(data3$YearQuarter), exp(chosenName$coefficients['(Intercept)'] + chosenName$coefficients['x'] * day_num) ,NA),
           day_num = as.Date(day_num*365.25, origin = "1970-01-01"))
  
  return(list(data1,chosenName, summary(chosenName)))
}

  shinyApp(
    ui = fluidPage(br(),
                   varSelectInput("State", "State", state_options('HO'),'GA'),
                   fluidRow(
                   column(12,align = 'center',
                  excelOutput("LossTrendExcel", width = '100%', height = '100%')))
                            
                   ),
    server = function(input, output, session) {  
      observeEvent({input$State},{
        #LossData <<- Loss_trend_data(input$Program,input$IndicationDate, evaluation_use,input$State)
        #print(input$State)
        lossTrendstateData <<- loss_trend_state('HO','2022-07-01', '2022-10-01',input$State)
        
        
        #adding
        
        if (nrow(lossTrendstateData) > 2) {
          loss_trend_fitting_state <<- loss_trend_fitting(lossTrendstateData,0)
        } else {
          loss_trend_fitting_state <<- data.frame(matrix(ncol = 2,nrow = 0))
        }
      })
      observeEvent({input$State},{
        CQI <<- Constant_Quality('2022-12-15')
        
        Loss_Tables.list <<- Loss_Tables('Georgia',lossTrendstateData%>%select(-Year,-Quarter), loss_trend_fitting_state,CQI,'=K27',0,0,data.frame())
        #print(Loss_Tables.list)
        output$LossTrendExcel <-renderExcel(Loss_Tables.list[[1]])
      })
      
      observeEvent({input$LossTrendExcel},{
        Loss.Interact <- excel_to_R(input$LossTrendExcel)
        currentLoss.raw <- Loss.Interact[Loss_Tables.list[[2]],7]
        projLoss.raw <- Loss.Interact[Loss_Tables.list[[3]],7]
        
        options(warn = -1)
        currentLoss.raw <- if (grepl('%',currentLoss.raw)) {as.numeric(str_replace_all(str_replace_all(currentLoss.raw,'%',''),' ',''))/100}else as.numeric(currentLoss.raw)
        projLoss.raw <- if (grepl('%',projLoss.raw)) {as.numeric(str_replace_all(str_replace_all(projLoss.raw,'%',''),' ',''))/100}else as.numeric(projLoss.raw)
        options(warn = 0)
        if (!is.na(currentLoss.raw)) {
          #print(currentLoss.raw)
        } else {
          showNotification("Invalid Current Loss Trend Format")
        }
        if (!is.na(projLoss.raw)) {
          #print(projLoss.raw)
        } else {
          showNotification("Invalid Projected Loss Trend Format")
        }
      })
      
   
   
    }
  )
  
  



