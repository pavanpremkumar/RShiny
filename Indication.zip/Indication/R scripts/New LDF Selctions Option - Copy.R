library(excelR)
library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(mailtoR) #package to prep emails
library(stringr)
library(glue)
library(ExcelFunctionsR)

library(sqldf)

#define input options


#connect to the SQL server
server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')


LDF_Excel_Pull_Quarterly <- function(Program,Rolling_Year_End,AsOfDate,state, Table) {
  AsOfDate<- as.Date(AsOfDate)
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  losses <- dbGetQuery(con,paste0("SELECT [IndicationDate]
      ,[EvaluationDate]
      ,[TableName]
      ,[Class]
      ,[Years]
      ,[Region]
	  ,	colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colK, colL, colM, colN, colO, colP, colQ, colR, colS, colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ, colJK, colKL, colLM, colMN, colNO, colOP, colPQ, colQR, colRS
  FROM [ActuarialSandbox].[",Program,"].[ldfTrianglesQuarter",Table,"]
  pivot (avg(columnValue) for columnName in (colA,colB,colC,colD,colE,colF,colG,colH,colI,colJ,colK, colL, colM, colN, colO, colP, colQ, colR, colS,colAB, colBC, colCD, colDE, colEF, colFG, colGH, colHI ,colIJ, colJK, colKL, colLM, colMN, colNO, colOP, colPQ, colQR, colRS) ) as PivotTable 
  where indicationDate = '",Rolling_Year_End,"'
                             and EvaluationDate = '",AsOfDate,"'
                             
  "))%>%
    filter(Region == state | Region == 'CW')
  return(losses)
} #working to create tabels on LDF tabs for CW, state, weighted


LDF_Tables <- function(dframe, Data.Region, Peril.Class) {
dframe <- dframe%>%
  filter(Class == Peril.Class & Region == Data.Region)%>%
  select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
LDF_data <- dframe%>%
  filter(TableName == 'Averages')%>%
  select(-TableName)%>%
  arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','5 Yr. Wtd Avg','3 Yr. Wtd Avg')))

LDF_data.fil <- LDF_data[,c(1,12:ncol(LDF_data))]
LDF_data.filter <- LDF_data.fil[colSums(!is.na(LDF_data.fil)) > 0]
LDF_data.filter[6,] <- ''
LDF_data.filter[7,] <- c('Selections', paste0('=',toupper(letters)[2:(length(LDF_data.filter))],2))
LDF_data.filter[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:(length(LDF_data.filter))],7,':',toupper(letters)[length(LDF_data.filter)],7,'),1)'))
LDF_data.filter[7,4:ncol(LDF_data.filter)] <- 1
columns <- jsonlite::fromJSON(paste0(c('[',paste0('{"type": ',c('"text"',rep('"number"',length(LDF_data.filter)-1)),' , "title":"',toupper(letters)[1:(length(LDF_data.filter))],'", "width": "100"}',c(rep(',',length(LDF_data.filter)-1),'')),']'), collapse = ' '))
colnames(LDF_data.filter) <- toupper(letters)[1:(length(LDF_data.filter))]



updateTable <- "function(instance, cell, col, row, val, label, cellName) {
          if (col >0 & row < 10 & col != 12) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0)
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row < 31 ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
        }
}"

out.table <- excelTable(data = LDF_data.filter,columns = columns,updateTable = htmlwidgets::JS(updateTable),
                        allowDeleteColumn = F,
                        allowInsertRow = F,
                        allowInsertColumn = F,
                        allowDeleteRow = F,
                        autoWidth = F,columnSorting = F,columnResize = F)

return(list(out.table, LDF_data.filter))
}


LDF_Translate <- function(dframe) { #The averages table is always 8 rows long
  dframe$Index <- row.names(dframe)
  select_row <- as.numeric(dframe%>%filter(A == 'Selections')%>%select(Index))
  dframe <- dframe%>%select(-Index)
  for (i in colnames(dframe)) {
    if (i != "A" & !is.numeric(tryCatch(as.numeric(dframe[[i]][select_row]),warning = function(w){}, error = function(e) {})) ) {
      dframe[[i]][select_row] <- Excel.Translate(dframe,i,select_row)
    }
  }
  
  dframe.select <- dframe[select_row,]%>%
    mutate_all(funs(replace(., .== "", NA)))
  print(dframe.select)
  
  dframe.cols <- ncol(dframe.select[colSums(!is.na(dframe.select)) > 0])
  print(dframe.cols)
  
  for (i in 2:dframe.cols) {
      dframe[select_row+1,i] <- prod(unlist(as.numeric(dframe[select_row,i:dframe.cols]))) 
      
  }
  print(dframe[select_row+1,])
  
  return(dframe)
}


Excel.Translate <- function(dframe,col,select_row) {
  i.dframe <- dframe[[col]]
  ii <- i.dframe[select_row]
  i.filter <- ii
  for (i in 1:length(i.dframe)) {
    save.entry <- tryCatch(as.numeric(i.dframe[i]),warning = function(w){}, error = function(e) {})
    assign(glue_safe(col,i),save.entry)
    
  }
  i.filter<-str_replace(i.filter,'=',"")
  if (grepl('AVERAGE', i.dframe[select_row]) | grepl('SUM', i.dframe[select_row]) ) {
    i.filter<-str_replace(i.filter,'AVERAGE\\(',"")
    i.filter<-str_replace(i.filter,'SUM\\(',"")
    i.filter<-str_replace(i.filter,'\\)',"")
    i.filter <- unlist(str_split(i.filter,','))
    execute.vec <- c()
    for (i in i.filter) {
      searchString <- tryCatch(as.numeric(i),warning = function(w){}, error = function(e) {})
      if (is.null(searchString)) {
        searchString <- tryCatch(get(i),warning = function(w){}, error = function(e) {})
        if (is.null(searchString)) {
          if (grepl(":",i)) {
            i.split <- unlist(str_split(i,':'))
            min.part <- as.numeric(gsub("[^0-9.-]", "", min(i.split) ))
            max.part <- as.numeric(gsub("[^0-9.-]", "", max(i.split) ))
            for (k in min.part:max.part) {
              searchString <- tryCatch(get(paste0('N',k)),warning = function(w){}, error = function(e) {})
              if (!is.null(searchString) & !is.na(searchString)){
                execute.vec <- c(execute.vec,searchString)
              }
            }
          }
        } else if (is.numeric(searchString)) {
          execute.vec <- c(execute.vec,searchString)
        }
      } else if (!is.na(searchString)) {
        execute.vec <- c(execute.vec,searchString)}
    }
  } else {
    searchString <- tryCatch(get(i.filter),warning = function(w){}, error = function(e) {})
  }
  
  if (grepl('AVERAGE', i.dframe[select_row])) {
    return(coalesce(mean(execute.vec),1))
  } else if (grepl('SUM', i.dframe[select_row])) {
    return(coalesce(sum(execute.vec),1))
  } else {
    return(coalesce(searchString,1))
  }
}
LDF_Tables_All_Quarter <- function(data, class, State,state.formulas) {
  dframe.state <- data%>%
    filter(Class == class & Region != 'CW')%>%
    select(-IndicationDate, -EvaluationDate,-Class,-Region)
  
  LDF_data_Losses.State <- dframe.state[,1:21]%>%
    filter(TableName == 'Losses')%>% 
    select(-TableName)%>%   
    mutate(add2 = NA)%>%
    arrange(Years)
    
  LDF_data_LossRatio.State <- dframe.state[,c(1:2,22:ncol(dframe.state))]%>%
    filter(TableName == 'Loss Ratios')%>%  
    mutate(add = NA,add2 = NA)%>%
    arrange(Years)%>% 
    select(-TableName)
  
  LDF_data_Averages.State <- dframe.state[,c(1:2,22:ncol(dframe.state))]%>%
    filter(TableName == 'Averages')%>% 
    mutate(add = NA,add2 = NA)%>%
    arrange(match(Years,c('Averages', 'All Yr. Wtd Avg','Ex Hi/Low','3 Yr. Wtd Avg','5 Yr. Wtd Avg')))%>% 
    select(-TableName)
  
  state.cols <- ncol(LDF_data_Averages.State)

  if (nrow(LDF_data_Losses.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Losses.State)))
    colnames(dummy) <- colnames(LDF_data_Losses.State)
    LDF_data_Losses.State <- dummy
    LDF_data_Losses.State[1,1] <- 'Not Enough Data'
  }  
  if (nrow(LDF_data_LossRatio.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_LossRatio.State)))
    colnames(dummy) <- colnames(LDF_data_LossRatio.State)
    LDF_data_LossRatio.State <- dummy
    LDF_data_LossRatio.State[1,1] <- 'Not Enough Data'
  }
  
  dataRows <- nrow(LDF_data_Losses.State) + nrow(LDF_data_LossRatio.State) + 11
  withAverages <- nrow(LDF_data_Losses.State) + nrow(LDF_data_LossRatio.State) + nrow(LDF_data_Averages.State) + 10
   form.fill.state <- max(ncol(LDF_data_Averages.State[colSums(!is.na(LDF_data_Averages.State)) > 0]),1)
   #print(form.fill.state)
  if (nrow(LDF_data_Averages.State) == 0) {
    dummy<-data.frame(matrix(nrow = 1, ncol = ncol(LDF_data_Averages.State)))
    colnames(dummy) <- colnames(LDF_data_Averages.State)
    LDF_data_Averages.State <- dummy
    LDF_data_Averages.State[1,1] <- 'Not Enough Data'
    LDF_data_Averages.State[6,1] <- NA
    LDF_data_Averages.State[7,1:2] <- c('Selections', NA)
    LDF_data_Averages.State[8,1:2] <-c('Cumulative', NA)

  } else {
    #print(1)
    LDF_data_Averages.State[6,] <- NA
    #print(1)
    fill.state.formulas <- if (length(state.formulas) > 0) state.formulas else paste0('=',toupper(letters)[2:form.fill.state],dataRows)
    #print(fill.state.formulas)
    #print(state.cols)
    LDF_data_Averages.State[7,] <- c('Selections',fill.state.formulas, rep(NA,state.cols-form.fill.state))
    #print(1)
    LDF_data_Averages.State[8,] <-c('Cumulative', paste0('=IFERROR(PRODUCT(',toupper(letters)[2:form.fill.state],withAverages,':',toupper(letters)[form.fill.state],withAverages,'),1)'), rep(NA,state.cols-form.fill.state))
    #print(1)
    LDF_data_Averages.State[7,min(4,form.fill.state):form.fill.state] <- 1
  }

  colnames(LDF_data_Losses.State) <- colnames(LDF_data_LossRatio.State) <- colnames(LDF_data_Averages.State) <- toupper(letters)[1:state.cols]
  
  LDF_Table_All <- rbind(NA,NA,
                         LDF_data_Losses.State,NA,NA,NA,
                         LDF_data_LossRatio.State,NA,NA,NA,
                         LDF_data_Averages.State,NA,NA,NA,NA,NA,NA,NA,NA)
  
  state.losses.colname <- column_names(LDF_data_Losses.State, 'Losses', '2022-07-01','2022-10-01')
  state.lossRatio.colname <- column_names(LDF_data_Losses.State, 'Loss Ratios', '2022-07-01','2022-10-01')
  #print(state.losses.colname)
  
  LDF_Table_All[2,1:20] <- c(state.losses.colname,rep(NA, 20-length(state.losses.colname) ) )
  LossRatioHeader <-nrow(LDF_data_Losses.State) + 5

    LDF_Table_All[LossRatioHeader,1:20] <- c(state.lossRatio.colname,rep(NA, 20-length(state.lossRatio.colname)) )
  
  
  columns <- jsonlite::fromJSON('[
  { "type": "text", "title": "A" ,"width":"120"},
  { "type": "number", "title": "B" ,"width":"85"},
  { "type": "number", "title": "C" ,"width":"85"},
  { "type": "number", "title": "D" ,"width":"85"},
  { "type": "number", "title": "E" ,"width":"85"},
  { "type": "number", "title": "F" ,"width":"85"},
  { "type": "number", "title": "G" ,"width":"85"},
  { "type": "number", "title": "H" ,"width":"85"},
  { "type": "number", "title": "I" ,"width":"85"},
  { "type": "number", "title": "J" ,"width":"85"},
  { "type": "number", "title": "K" ,"width":"85"},
  { "type": "text",  "title": "L" ,"width": "85"},
  { "type": "text",  "title": "M" ,"width": "85"},
  { "type": "number", "title": "N" ,"width":"85"},
  { "type": "number", "title": "O" ,"width":"85"},
  { "type": "number", "title": "P" ,"width":"85"},
  { "type": "number", "title": "Q" ,"width":"85"},
  { "type": "number", "title": "R" ,"width":"85"},
  { "type": "number", "title": "S" ,"width":"85"},
  { "type": "number", "title": "T" ,"width":"85"},
  { "type": "number", "title": "U" ,"width":"85"}
  ]')
  updateTable <- paste0("function(instance, cell, col, row, val, label, cellName) {
        if (row == 1 | row == ",LossRatioHeader-1,") {
            txt = cell.innerText;
            cell.innerHTML = txt.bold();
            cell.style.borderBottomColor = 'black';
        } else if (col >0 & row < ",LossRatioHeader-1,") {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              numVal = Number(txt).toFixed(0);
              cell.innerHTML = numVal.toString().replace(/\\B(?<!\\.\\d*)(?=(\\d{3})+(?!\\d))/g, ',');
            }
          } else if (col >0 & row > ",LossRatioHeader-1," ) {
            txt = cell.innerText;
            if (!isNaN(Number(txt)) & txt != '') { //if the value is numeric, then round the display to 2 decimal points
              cell.innerHTML = Number(txt).toFixed(3);
            }
          }
        
        
              
}")
  out.table <- excelTable(data = LDF_Table_All,
                          columns = columns,
                          updateTable = htmlwidgets::JS(updateTable),
             allowDeleteColumn = F,
             allowInsertRow = F,
             allowInsertColumn = F,
             allowDeleteRow = F,
             autoWidth = F,columnSorting = F,columnResize = F,autoFill = T, wordWrap = T
  )
  return(list(out.table, LDF_Table_All))
}



state_options <- function(program) {
  dframe <- dbGetQuery(con,paste0("
      select state from 
      actuarialsandbox.",program,".modeledCatLoad
      group by state
    "))
  state <- data.frame(matrix(ncol=length(dframe[['state']])+1,nrow=0))
  colnames(state) <- c(dframe[['state']],' ')
  return(state)
}
column_names <- function(dframe,table,Rolling_Year_End,AsOfDate){
  Rolling_Year_End <- as.Date(Rolling_Year_End)
  AsOfDate <- as.Date(AsOfDate)
  numCols <- ncol(dframe)
  dframe <- dframe[colSums(!is.na(dframe)) > 0]
  numColsAfter <- ncol(dframe)
  
  if (table == 'Losses') {
    c(
      ifelse(month(Rolling_Year_End %m-% months(1))==12,
             'Accident Year',
             paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))),'/' , as.character(day(Rolling_Year_End %m-% days(1))))),(month(AsOfDate)-month(Rolling_Year_End)) + 3*c(1:(length(dframe)-1)))
  }
  else {
    
    if ( (numCols-numColsAfter) <=1 ) {
      dframe <- dframe[,1:(numColsAfter-1)]
    }
    names <- c()
    adder <- month(AsOfDate)-month(Rolling_Year_End)
    for (i in 1:(length(colnames(dframe)))) {
      if (i == length(colnames(dframe))) {
        names <- c(names,paste(as.character((i-1)*3+adder),':Ult',sep = ' ' ))
      }
      else if (i>1) {
        names <- c(names,paste(as.character((i-1)*3+adder),':',as.character((i-1)*3+adder+3),sep = " "))
      }
      else {
        names <- c(names,ifelse(month(Rolling_Year_End %m-% months(1))==12,
                                'Accident Year',
                                paste0('Rolling Year Ending In ' , as.character(month(Rolling_Year_End %m-% months(1))) ,'/', as.character(day(Rolling_Year_End %m-% days(1))))))
      }
    }
    return(names)
  }
}


runApp(
  shinyApp(
    ui = fluidPage(br(),
                   tabsetPanel(
                     tabPanel('Quarterly LDFs',
                              tabsetPanel(
                                tabPanel('Summary',
                                         tableOutput('LDFQuarterSummary')
                                ),
                                tabPanel("All Perils",
                                         varSelectInput("State", "State", state_options('HO'),'VA'),
                                         fluidRow(
                                           column(12,align = 'center',
                                                  excelOutput("LDFquarterAll", width = '100%', height = '100%')))
                                         ),
                                tabPanel('Weather',
                                         fluidRow(
                                           column(12,align = 'center',
                                                  excelOutput("LDFquarterWeather", width = '100%', height = '100%')))
                                         ),
                                tabPanel('Attritional',
                                         fluidRow(
                                           column(12,align = 'center',
                                                  excelOutput("LDFquarterAtt", width = '100%', height = '100%')))
                                         )
                              ))
                   ),
                   
                            
                   ),
    server = function(input, output, session) {  
      observeEvent({input$State},{
      LDFDataPullQuarterly <<- LDF_Excel_Pull_Quarterly('HO','2022-07-01','2022-10-01',input$State,'')
      LDFDataPullQuarterlyCounts <<- LDF_Excel_Pull_Quarterly('HO','2022-07-01','2022-10-01',input$State,'Counts')
      #LDFDataPull <- LDF_Excel_Pull('HO','2022-07-01','2022-10-01','TX')
      LDFDataAllQuarter <<-LDF_Tables_All_Quarter(LDFDataPullQuarterly, 'All Perils', input$State, c()) 
      LDFDataAttritionalQuarter <<-LDF_Tables_All_Quarter(LDFDataPullQuarterly, 'Attritional', input$State, c()) 
      LDFDataWeatherQuarter <<-LDF_Tables_All_Quarter(LDFDataPullQuarterly, 'Weather', input$State, c())
      
      LDFquarterAll.select      <<- LDF_Translate(LDFDataAllQuarter[[2]]) %>%filter(A=='Cumulative')%>%select(-A)
      LDFquarterWeather.select <<- LDF_Translate(LDFDataWeatherQuarter[[2]]) %>%filter(A=='Cumulative')%>%select(-A)
      LDFquarterAtt.select <<- LDF_Translate(LDFDataAttritionalQuarter[[2]]) %>%filter(A=='Cumulative')%>%select(-A)
      })
      observeEvent({input$State},{
        output$LDFquarterAll <-renderExcel(LDFDataAllQuarter[[1]])
        output$LDFquarterWeather <-renderExcel(LDFDataWeatherQuarter[[1]])
        output$LDFquarterAtt <-renderExcel(LDFDataAttritionalQuarter[[1]])
      })
      
      
   
      observeEvent({input$LDFquarterAll},{
        LDFquarterAll.data      <<- excel_to_R(input$LDFquarterAll)
        LDFquarterAll.select      <<- LDF_Translate(LDFquarterAll.data)%>%filter(A=='Cumulative')%>%select(-A)
        print(LDFquarterAll.select)
      })
      
      observeEvent({
        input$LDFquarterWeather
        },{
        LDFquarterWeather.data  <<- excel_to_R(input$LDFquarterWeather)
        LDFquarterWeather.select <<- LDF_Translate(LDFquarterWeather.data)%>%filter(A=='Cumulative')%>%select(-A)
        
      })
      
      observeEvent({
        input$LDFquarterAtt
      },{
        LDFquarterAtt.data      <<- excel_to_R(input$LDFquarterAtt)
        LDFquarterAtt.select <<- LDF_Translate(LDFquarterAtt.data)%>%filter(A=='Cumulative')%>%select(-A)
      })
      
      observeEvent({
        input$LDFquarterAll
        input$LDFquarterWeather
        input$LDFquarterAtt
        input$State
      },{
        LDFquarterSummaryTable <<- data.frame('Total' = unlist(LDFquarterAll.select),
                                              'Weather' = unlist(LDFquarterWeather.select),
                                              'Attritional' = unlist(LDFquarterAtt.select),
                                              Column_Names = colnames(LDFquarterAtt.select) )%>%
          mutate_all(funs(replace(., .== "", NA)))%>%
          filter(!is.na(Weather) )%>%
          arrange(desc(Column_Names))%>%
          select(-Column_Names)
          
        
        output$LDFQuarterSummary <- renderTable(LDFquarterSummaryTable)
      })
      
    }
  )
)
