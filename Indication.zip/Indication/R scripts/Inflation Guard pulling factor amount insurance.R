#validated for GA HO, TX HO, and SC HO so far


library(DBI)
library(lubridate)
library(openxlsx)
library(shiny)
library(shinyWidgets)
library(dplyr)
library(DT)
library(miscTools)
library(tidyr)
library(shinythemes)
library(markdown)
library(shinyjs)
library(shinycssloaders)
library(odbc)
library(sjmisc)
library(ggplot2)
library(kimisc)
library(stringr)

server <- "HOAIC-WAREHOUSE"
database<- "ActuarialDataMart"
databaseSandbox<- "ActuarialSandbox"

con <-  dbConnect(odbc::odbc(),
                  Driver='SQL Server', # SQLServer   #SQL Server
                  server=server,
                  database=database,
                  trusted_connection='yes')



conSand <-  dbConnect(odbc::odbc(),
                      Driver='SQL Server', # SQLServer   #SQL Server
                      server=server,
                      database=databaseSandbox,
                      trusted_connection='yes')





Program <- 'HO'
State <- 'TX' #doesn't work for NC, maybe can change the format of that rater to match all of the others?

ratingVersionID <-114
InflationGuard <- 1.19
IndicationDate<- '2023-01-01'
EvaluationDate <- '2023-01-01'
by.Peril <- T
data.source1 <- 'ActuarialSandbox'
#data.source1 <- 'ADM'


pull.rater <- function(Program,State,data.source1,ratingVersionID) {
data.source <- if (data.source1 == 'ADM') 'ActuarialDataMart' else data.source1
  dframe <- dbGetQuery(con, paste0("
declare @state varchar(2) = '",State,"',
@Program varchar(2) = '",Program,"'

SELECT 
	'ActuarialDataMart' as DB,
	schema_id,
  SCHEMA_NAME(schema_id) AS [Schema],
  right(name, len(name)- 9) as ratingVersion,
  name 
FROM ActuarialDataMart.sys.objects
WHERE type = 'P'
and name like concat('%rate%',@state,'%')
and schema_id = SCHEMA_ID(@Program)
union all 
SELECT 
	'ActuarialSandbox' as DB,
	schema_id,
  @Program AS [Schema],
  right(name, len(name)- 9) as ratingVersion,
  name
FROM ActuarialSandbox.sys.objects
WHERE type = 'P'
and name like concat('%rate%',@state,'%')
and schema_id = case when @Program = 're' then 7
					 when @Program = 'co' then 8
					 when @Program = 'DF' then 6 else 5 end
  "
  ))
  dframe <- dframe%>%
    filter(ratingVersion == ratingVersionID, DB == data.source )#%>%
    #arrange(desc(as.numeric(ratingVersion))) #this is where to filter to the correct rating version ID, 
  #dframe <- head(dframe,1) #if duplicates, then head() to take the ADM row use the one in the ADM
  databaseUse <- dframe$DB
  currentRater <- paste0(dframe$DB,'.',dframe$Schema,'.',dframe$name)
  
  
  
  if (databaseUse == 'ActuarialSandbox') {
    raterText <- dbGetQuery(conSand,
                            paste0("
                  exec sp_helptext '",currentRater,"'
                                 "))
    
  } else {
    
    raterText <- dbGetQuery(con,
                            paste0("
                  exec sp_helptext '",currentRater,"'
                                 "))
  }
 return(raterText) 
}

raterText <- pull.rater(Program, State, data.source1,ratingVersionID)  

getFactorAmountInsurance <- function(raterText,peril.list) {
raterText.filter <-  data.frame(Text = tolower(raterText[1:max(as.numeric(rownames(raterText)[str_detect(tolower(raterText$Text), 'into #factors')])),]))
  
  raterText.filter2 <-  data.frame(Text = raterText.filter[1:max(as.numeric(rownames(raterText.filter)[str_detect(raterText.filter$Text, 'factor&amount|insurance')])),])
  
  
  raterText.filter3 <- data.frame(Text =raterText.filter2[max(as.numeric(rownames(raterText.filter2)[str_detect(raterText.filter2$Text, 'select')])):nrow(raterText.filter2),])
  raterText.filter4 <- raterText.filter3[min(as.numeric(rownames(raterText.filter3)[str_detect(raterText.filter3$Text, 'case')])):nrow(raterText.filter3),]
  for (row in 1:length(raterText.filter4)) {
    raterText.filter4[row] <- unlist(str_split(raterText.filter4[row],"--"))[1]
  }
  raterText.filter5 <- paste(raterText.filter4,collapse="")
  raterText.filter6 <- str_replace_all(str_replace_all(str_replace_all(raterText.filter5,'\\t',''),'\\n',''),'\\r','')
  raterText.filter7 <- unlist(str_split(raterText.filter6,'case'))
  raterText.filter8 <- raterText.filter7[raterText.filter7!= '']

#peril.list <- c('Fire', 'Water', 'Theft', 'Liability', 'Other', 'NCW','STS', 'Hurricane','WF')
raterText.filter9 <- raterText.filter8
peril.list.2 <- peril.list
selected.factor <- list()
selected.factor.inflation <- list()

while (length(raterText.filter9) > 1) {
  for (peril in peril.list.2) {
  peril.low <- tolower(peril) 
  entry <- str_detect(raterText.filter9,peril.low) & !str_detect(raterText.filter9,paste0('ex',peril.low)) #
  chosen.factor <- raterText.filter9[entry]
  if (length(chosen.factor) > 0) {
    text <- paste0('case',chosen.factor)
    chosen.factor.formula <- paste0(unlist(str_split(text,'end'))[1],'end')
    chosen.factor.formula.inflation <- str_replace_all(chosen.factor.formula,'e.covalmt','e.covalmt*@InflationGuard')
    peril.list.2 <- peril.list.2[peril.list.2!=peril]
    raterText.filter9 <- raterText.filter9[!entry]
    
    select.list <- list(chosen.factor.formula)
    names(select.list) <- c(peril)
    
    select.list.inflation <- list(chosen.factor.formula.inflation)
    names(select.list.inflation) <- c(peril)
    
    selected.factor <- append(selected.factor,select.list)
    selected.factor.inflation <- append(selected.factor.inflation,select.list.inflation)
  }
  
  }
}  
for (peril in peril.list.2) {
  text <- paste0('case',raterText.filter9)
  chosen.factor.formula <- paste0(unlist(str_split(text,'end'))[1],'end')
  chosen.factor.formula.inflation <- str_replace_all(chosen.factor.formula,'e.covalmt','e.covalmt*@InflationGuard')
  select.list <- list(chosen.factor.formula)
  names(select.list) <- c(peril)
  
  select.list.inflation <- list(chosen.factor.formula.inflation)
  names(select.list.inflation) <- c(peril)
  
  selected.factor <- append(selected.factor,select.list)
  selected.factor.inflation <- append(selected.factor.inflation,select.list.inflation)
  
}
return(list(inforce = selected.factor,inforceInflation = selected.factor.inflation))
}

peril.list <- c('Fire', 'Water', 'Theft', 'Liability', 'Other', 'NCW','STS', 'Hurricane','WF')
factorAmountInsurance <- getFactorAmountInsurance(raterText,peril.list)

#check if any peril is in the string, so don't use it if it is peril specific down the line
#once you assign a fact to a peril, remove it from the list that you loop through!
calcInflationGuard <- function(Program, State,IndicationDate,EvaluationDate,ratingVersionID,selected.factor,selected.factor.inflation,InflationGuard) {
if (by.Peril == T) {
dframe.inflation <- dbGetQuery(con, 
                               paste0(
  "
DECLARE @InflationGuard float = ",InflationGuard,"
select  sum(policyPremium) as policyPremium,sum((policyPremium-endorsementPremium)*(
firePercent* (",selected.factor.inflation$Fire,")/(",selected.factor$Fire,")
+WaterPercent* (",selected.factor.inflation$Water,")/(",selected.factor$Water,")
+TheftPercent* (",selected.factor.inflation$Theft,")/(",selected.factor$Theft,")
+LiabilityPercent* (",selected.factor.inflation$Liability,")/(",selected.factor$Liability,")
+OtherPercent* (",selected.factor.inflation$Other,")/(",selected.factor$Other,")
+NCWPercent* (",selected.factor.inflation$NCW,")/(",selected.factor$NCW,")
+STSPercent* (",selected.factor.inflation$STS,")/(",selected.factor$STS,")
+coalesce(HUPercent* (",selected.factor.inflation$Hurricane,")/(",selected.factor$Hurricane,") ,0)
)
+endorsementPremium --add back in the endorsement component
) as InflationGuardPremium, 
sum(New) as New,
sum(Renew) as Renew,
sum(InforceCount) as InforceCount,
sum(NewHomesNewPolicy) as NewHomesNewPolicy,
sum(OldHomeNewPolicy) as OldHomeNewPolicy
from ACtuarialSandbox.ho.InflationGuardCovA e
where indicationDate = '",IndicationDate,"'
and EvaluationDate = '",EvaluationDate,"'
and state = '",State,"'
and source= '",data.source1,"'
and ratingVersionID = ",ratingVersionID,"
  "
)
)
} else {
  dframe.inflation <- dbGetQuery(con, 
                                 paste0(
                                   "
DECLARE @InflationGuard float = ",InflationGuard,"
select  sum(policyPremium) as policyPremium,sum((policyPremium-endorsementPremium)*(
(",selected.factor.inflation$Fire,")/(",selected.factor$Fire,")
)
+endorsementPremium --add back in the endorsement component
) as InflationGuardPremium, 
sum(New) as New,
sum(Renew) as Renew,
sum(InforceCount) as InforceCount,
sum(NewHomesNewPolicy) as NewHomesNewPolicy,
sum(OldHomeNewPolicy) as OldHomeNewPolicy
from ACtuarialSandbox.ho.InflationGuardCovA e
where indicationDate = '",IndicationDate,"'
and EvaluationDate = '",EvaluationDate,"'
and state = '",State,"'
and source= '",data.source1,"'
and ratingVersionID = ",ratingVersionID,"
  "
                                 )
  )
  
}
 return(dframe.inflation) 
}

dframe.inflation <- calcInflationGuard(Program, State,IndicationDate,EvaluationDate,ratingVersionID,factorAmountInsurance$inforce,factorAmountInsurance$inforceInflation,InflationGuard)

print(dframe.inflation)
print(dframe.inflation$InflationGuardPremium/dframe.inflation$policyPremium -1)
