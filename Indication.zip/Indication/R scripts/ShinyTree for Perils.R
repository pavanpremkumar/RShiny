library(shiny)
library(shinyTree)
server <- shinyServer(function(input, output, session) {
  
  includePerils <- reactiveValues(input = c())
  
  output$tree <- renderTree({ 
    peril.tree <-list( `Not By Peril` = 'Not By Peril', 
                       `All Perils`= list(Fire='1', Water = '1', Theft = '1', Liability = '1', Other = '1', NCW = '1', STS = '1', Hurricane = '1')) 
    peril.preselected <- c('Fire','Water','Theft','Liability','Other','NCW','STS')#,'Hurricane')
    peril.preselected.sum <- length(peril.preselected)
    
    if (peril.preselected.sum == length(peril.tree$`All Perils`)) {
      attr(peril.tree[[2]],"stselected")=TRUE
      attr(peril.tree[[2]],"stopened")=TRUE
      
    }else if (peril.preselected.sum > 0) {
      for (peril in peril.preselected) {attr(peril.tree[[2]][[peril]],"stselected")=T}
    # attr(peril.tree[[2]][['Fire']],"stselected")=peril.preselected$Fire
    # attr(peril.tree[[2]][['Water']],"stselected")=peril.preselected$Water
    # attr(peril.tree[[2]][['Theft']],"stselected")=peril.preselected$Theft
    # attr(peril.tree[[2]][['Liability']],"stselected")=peril.preselected$Liability
    # attr(peril.tree[[2]][['Other']],"stselected")=peril.preselected$Other
    # attr(peril.tree[[2]][['NCW']],"stselected")=peril.preselected$NCW
    # attr(peril.tree[[2]][['STS']],"stselected")=peril.preselected$STS
    # attr(peril.tree[[2]][['Hurricane']],"stselected")=peril.preselected$Hurricane
    attr(peril.tree[[2]],"stopened")=TRUE
    
    } else {
      attr(peril.tree[[1]],"stselected")=TRUE
      attr(peril.tree[[2]],"stopened")=FALSE
      
    }
        
    
    peril.tree
  })
  
  observe({
    peril.selected <- unlist(get_selected(input$tree, format = c('names')))
    print(peril.selected[peril.selected != 'All Perils'])
    includePerils$input <<- if (!is.null(peril.selected)) {if ('Not By Peril' %in% peril.selected) {NULL} else {peril.selected} }
  })
  
  observe({
    print(includePerils$input)
  })
  
})
ui <- shinyUI(
  shiny::fluidPage(
    h4('Shiny hierarchical checkbox')
    ,shinyTree("tree",theme="proton", themeIcons = FALSE, themeDots = FALSE,checkbox = T, multiple = F)
    
  )
)
shinyApp(ui, server)


setequal(NULL,c(1,1,1))





